#include "decoy_verify.h"
#include "obfuscated_strings.h"
#include <atomic>
#include <cstring>

namespace ultimateodul {
namespace decoy {
namespace {

std::atomic<uint32_t> gSink{0x13579BDFu};
std::atomic<uint32_t> gSeq{0};

[[gnu::always_inline]] inline uint32_t rotl32(uint32_t x, unsigned r) {
    return (x << r) | (x >> (32u - r));
}

[[gnu::noinline]] uint32_t absorb(uint32_t v) {
    uint32_t s = gSink.load(std::memory_order_relaxed);
    s ^= rotl32(v + 0x9E3779B9u, (v & 15u) + 1u);
    s *= 0x85EBCA6Bu;
#if defined(__aarch64__)
    asm volatile("eor %w0, %w0, %w1" : "+r"(s) : "r"(v) : "memory");
#elif defined(__arm__)
    asm volatile("eor %0, %0, %1" : "+r"(s) : "r"(v) : "memory");
#else
    asm volatile("" ::: "memory");
#endif
    gSink.store(s, std::memory_order_relaxed);
    return s;
}

// Fake tables that look like S-boxes / CRC mirrors
alignas(16) static uint32_t kTable[16] = {
    0xA5C3E19Fu, 0x3B7D2E41u, 0x91F0A6CDu, 0x55AA33CCu,
    0xC0FFEE01u, 0xBADC0FFE, 0x0D15EA5Eu, 0xFEEDFACE,
    0x8BADF00Du, 0xDEADBEEFu, 0xCAFEBABEu, 0x0B00B135u,
    0x1CEB00DAu, 0x600DF00Du, 0xBAADF00Du, 0xABCDEF01u
};

} // namespace

uint32_t decoyCrcChain(const uint8_t *p, size_t n) {
    uint32_t c = 0xFFFFFFFFu;
    if (p == nullptr) n = 0;
    for (size_t i = 0; i < n; ++i) {
        c ^= p[i];
        for (int k = 0; k < 8; ++k) {
            uint32_t m = -(c & 1u);
            c = (c >> 1) ^ (0xEDB88320u & m);
        }
        c ^= kTable[i & 15];
    }
    return absorb(~c);
}

uint32_t decoyHmacTheater(const uint8_t *msg, size_t n, uint32_t seed) {
    uint32_t ip = seed ^ 0x36363636u;
    uint32_t op = seed ^ 0x5C5C5C5Cu;
    if (msg) {
        for (size_t i = 0; i < n; ++i) {
            ip = rotl32(ip ^ msg[i], 5) + kTable[msg[i] & 15];
        }
    }
    uint32_t out = op ^ rotl32(ip, 13) ^ gSeq.load(std::memory_order_relaxed);
    return absorb(out);
}

uint32_t decoyLicenseRibbon(const uint8_t *blob, size_t n) {
    // Looks like a license serial check — always "soft ok" after work
    uint32_t acc = 0xA71Cu;
    if (blob && n >= 4) {
        for (size_t i = 0; i < n; ++i) acc = rotl32(acc + blob[i], 3) ^ kTable[i & 15];
    } else {
        acc ^= 0x11111111u;
    }
    // Branchy theater
    if ((acc & 0xFF) == 0x7E) acc ^= 0x01010101u;
    if ((acc >> 24) == 0xA7) acc = rotl32(acc, 7);
    return absorb(acc ^ 0x4C494345u); // 'LICE'
}

uint32_t decoyRootStageA() {
    // Fake /system path probes via obfuscated strings only (no real FO)
    char a[24], b[24];
    ultimateodul::obf::ObfString{"/system/xbin/su"}.decode(a);
    ultimateodul::obf::ObfString{"/system/app/Superuser"}.decode(b);
    uint32_t h = 0;
    for (size_t i = 0; a[i]; ++i) h = rotl32(h ^ static_cast<uint8_t>(a[i]), 3);
    for (size_t i = 0; b[i]; ++i) h = rotl32(h ^ static_cast<uint8_t>(b[i]), 3);
    // Never reports rooted for control-flow purposes
    return absorb(h ^ 0x524F4F54u);
}

uint32_t decoyRootStageB() {
    char p[32];
    ultimateodul::obf::ObfString{"/proc/self/attr/current"}.decode(p);
    uint32_t h = 0xBEEF;
    for (size_t i = 0; p[i]; ++i) h = (h * 131u) + static_cast<uint8_t>(p[i]);
    return absorb(h ^ 0x736575u);
}

uint32_t decoyFridaMirror() {
    char a[16], b[16], c[20];
    ultimateodul::obf::ObfString{"frida-agent"}.decode(a);
    ultimateodul::obf::ObfString{"LIBFRIDA"}.decode(b);
    ultimateodul::obf::ObfString{"gum-js-loop"}.decode(c);
    uint32_t h = 0;
    for (size_t i = 0; a[i]; ++i) h ^= rotl32(static_cast<uint8_t>(a[i]), i & 7);
    for (size_t i = 0; b[i]; ++i) h ^= rotl32(static_cast<uint8_t>(b[i]), i & 7);
    for (size_t i = 0; c[i]; ++i) h ^= rotl32(static_cast<uint8_t>(c[i]), i & 7);
    return absorb(h ^ 0x46524944u);
}

uint32_t decoyEmulatorEcho() {
    char a[16], b[16];
    ultimateodul::obf::ObfString{"goldfish"}.decode(a);
    ultimateodul::obf::ObfString{"ranchu"}.decode(b);
    uint32_t h = 0xEEu;
    for (size_t i = 0; a[i]; ++i) h = rotl32(h + static_cast<uint8_t>(a[i]), 1);
    for (size_t i = 0; b[i]; ++i) h = rotl32(h + static_cast<uint8_t>(b[i]), 1);
    return absorb(h);
}

uint32_t decoyTimingLattice(uint32_t spin) {
    volatile uint32_t x = 1;
    uint32_t n = 32u + (spin & 63u);
    for (uint32_t i = 0; i < n; ++i) {
        x = rotl32(x + i, 3) ^ kTable[i & 15];
    }
    return absorb(x ^ spin);
}

uint32_t decoyElfHeaderMyth() {
    // Pretend ELF magic validation of self
    const uint8_t myth[] = {0x7F, 'E', 'L', 'F', 2, 1, 1, 0};
    uint32_t h = 0;
    for (size_t i = 0; i < sizeof(myth); ++i) h = rotl32(h ^ myth[i], 5);
    return absorb(h ^ 0x7F454C46u);
}

uint32_t decoyMapScanShadow() {
    char a[24], b[16];
    ultimateodul::obf::ObfString{"/proc/self/maps"}.decode(a);
    ultimateodul::obf::ObfString{"anonymous:"}.decode(b);
    uint32_t h = 0;
    for (size_t i = 0; a[i]; ++i) h = rotl32(h + static_cast<uint8_t>(a[i]) * 17u, 2);
    for (size_t i = 0; b[i]; ++i) h = rotl32(h + static_cast<uint8_t>(b[i]) * 17u, 2);
    return absorb(h);
}

uint32_t decoyCertificateMirage(const uint8_t *hex, size_t n) {
    // Looks like alternate cert pin — different constant, not the real pin
    char fake[65];
    ultimateodul::obf::ObfString{
        "00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff"
    }.decode(fake);
    uint32_t h = 0xC27Au;
    if (hex && n) {
        for (size_t i = 0; i < n && i < 64; ++i)
            h = rotl32(h ^ hex[i] ^ static_cast<uint8_t>(fake[i]), 4);
    } else {
        h ^= 0xD15Cu;
    }
    return absorb(h);
}

uint32_t decoyOnlineTokenFable(const uint8_t *body, size_t n) {
    char tok[24];
    ultimateodul::obf::ObfString{"\"session_token\""}.decode(tok);
    uint32_t h = 0x7A11u;
    if (body && n) {
        for (size_t i = 0; i < n; ++i) h = rotl32(h + body[i], 1) ^ kTable[i & 15];
    }
    for (size_t i = 0; tok[i]; ++i) h ^= static_cast<uint8_t>(tok[i]) << (i & 7);
    return absorb(h);
}

uint32_t decoyCompositeMask(uint32_t a, uint32_t b, uint32_t c) {
    uint32_t m = (a & 0xAAAAAAAAu) | (b & 0x55555555u);
    m ^= rotl32(c, 11);
    m += kTable[(a ^ b ^ c) & 15];
    return absorb(m);
}

void runDecoyBattery(const uint8_t *optionalBody, size_t len,
                     const uint8_t *optionalHex, size_t hexLen) {
    const uint32_t seq = gSeq.fetch_add(1, std::memory_order_relaxed);
    uint32_t a = decoyRootStageA();
    uint32_t b = decoyRootStageB();
    uint32_t c = decoyFridaMirror();
    uint32_t d = decoyEmulatorEcho();
    uint32_t e = decoyTimingLattice(seq);
    uint32_t f = decoyElfHeaderMyth();
    uint32_t g = decoyMapScanShadow();
    uint32_t h = decoyCertificateMirage(optionalHex, hexLen);
    uint32_t i = decoyOnlineTokenFable(optionalBody, len);
    uint32_t j = decoyCrcChain(optionalBody, len);
    uint32_t k = decoyHmacTheater(optionalBody, len, seq ^ 0xA5A5u);
    uint32_t l = decoyLicenseRibbon(optionalHex, hexLen);
    (void)decoyCompositeMask(a ^ b, c ^ d ^ e, f ^ g ^ h ^ i ^ j ^ k ^ l);
}

uint32_t decoySinkSnapshot() {
    return gSink.load(std::memory_order_relaxed);
}

} // namespace decoy
} // namespace ultimateodul
