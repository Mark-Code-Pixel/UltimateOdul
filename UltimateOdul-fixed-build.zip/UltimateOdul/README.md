# Ultimate Odul

A native-powered, premium-styled Ludo game for Android.

## Architecture — genuinely multi-language

| Layer | Language | File(s) | Role |
|---|---|---|---|
| RNG core | **C** | `app/src/main/cpp/dice_native.c` / `.h` | xorshift32 dice roll, seeded independently |
| Rules engine + AI | **C++17** | `app/src/main/cpp/ludo_logic.cpp` / `.h` | movement, capture, win detection, heuristic AI |
| JNI glue | **C++** | `app/src/main/cpp/jni_bridge.cpp` | exposes the engine to the JVM as `libludoengine.so` |
| Native bridge | **Kotlin** | `NativeBridge.kt` | `System.loadLibrary`, `external fun` declarations |
| Board geometry | **Kotlin** | `BoardGeometry.kt` | maps engine step numbers -> 15x15 grid cells |
| Rendering | **Kotlin** | `LudoBoardView.kt` | custom `View`: gradients, glow, animated pawns |
| Game orchestration | **Kotlin** | `MainActivity.kt` | turn loop, dice animation, AI pacing, win dialog |
| Stats persistence | **Java** | `ScoreManager.java` | SharedPreferences win/loss tracking |

All C/C, C++, and Java/Kotlin pieces are wired together and compiled by
Gradle + CMake into one `.so` per ABI, loaded at runtime.

## 32-bit and 64-bit support

`app/build.gradle` builds and packages **all four** common Android ABIs into
one APK:

- 32-bit: `armeabi-v7a`, `x86`
- 64-bit: `arm64-v8a`, `x86_64`

`abi { enable false }` under `splits` keeps them bundled together rather
than split into separate per-ABI APKs, so a single install works everywhere.
None of the C/C++ source uses pointer-size-dependent tricks except the JNI
handle cast in `jni_bridge.cpp`, which deliberately round-trips the engine
pointer through `uintptr_t` (not directly through `jlong`) — that's what
makes the cast correct on both 32-bit and 64-bit targets.

## Gameplay

- Standard 4-player, 4-pawn-each Ludo rules: roll a 6 to leave the yard,
  captures send opponents back to base, 8 star/safe cells are capture-proof,
  rolling a 6 / capturing / finishing a pawn grants an extra turn, three 6s
  in a row forfeits the turn.
- You play the red seat; the other three seats are controlled by an
  in-engine heuristic AI (prioritizes captures, then finishing a pawn, then
  leaving the yard, then advancing its furthest pawn).
- Win/loss record is saved locally across sessions.

## Visual style

Dark glass-panel HUD, neon per-player gradients, glowing gold star cells,
glossy radial-gradient pawns with drop shadows, spring-eased animated pawn
slides (not instant jumps), a spinning/flickering dice roll animation, and
a pulsing gold ring around whichever seat is currently active.

## Hardening / obfuscation

Applied on both sides of the JNI boundary:

**JVM side (R8/ProGuard, `proguard-rules.pro`)**
- `-repackageclasses ''` + `-flattenpackagehierarchy ''`: every non-exempt
  class is moved into the default package and renamed to a short
  meaningless name (`a`, `b`, `a.a`, ...).
- `-allowaccessmodification`, `-overloadaggressively`, 5 optimization
  passes: fields/methods are renamed, reused across unrelated classes, and
  merged/inlined aggressively.
- All debug metadata stripped: no source file name, no line numbers, no
  local variable tables.
- `Log.*` calls are marked side-effect-free and dead-code eliminated.
- **Exactly two exceptions**, both unavoidable rather than chosen:
  - `MainActivity` — the platform requires `AndroidManifest.xml` to name
    the launch Activity exactly, and `onCreate`/`onDestroy` are inherited
    framework callbacks R8 won't rename. It's a deliberately empty shell
    (see below) that does nothing but hand off to `GameCore`.
  - `NativeBridge`'s native method declarations — `jni_bridge.cpp` looks
    these up at runtime by exact (encrypted) name/signature via
    `RegisterNatives`; renaming either side independently breaks native
    linkage. Its own non-native helper methods are NOT exempt and are
    renamed normally.
- `LudoBoardView` is instantiated in code (`GameCore.start()`) instead of
  being declared by class name in `activity_main.xml`, because a view
  referenced by fully-qualified name in a layout is auto-kept/unrenamed by
  AAPT2/R8's implicit resource keep rules. Keeping it out of the XML lets
  it be renamed like everything else.
- All real game logic that used to live in `MainActivity` now lives in
  `GameCore`, which has no framework obligations and is fully obfuscated.

**Native side (`app/src/main/cpp/`)**
- `CMakeLists.txt` sets hidden visibility by default
  (`C_VISIBILITY_PRESET`/`CXX_VISIBILITY_PRESET hidden`), so the shipped
  `libludoengine.so` exports nothing but `JNI_OnLoad`.
- `jni_bridge.cpp` no longer defines `Java_com_ultimateodul_ludo_..._`
  symbols at all — every native function is registered dynamically via
  `RegisterNatives()` inside `JNI_OnLoad`, and the (class path, method
  name, signature) strings fed to it are XOR-encoded at compile time
  (`obfuscated_strings.h`) and decoded only on the stack at load time.
  `strings`/`grep` on the binary won't surface Kotlin method names.
- Release builds are linked with `-s` (strip) and
  `-Wl,--gc-sections`/`--exclude-libs,ALL`; `app/build.gradle` also sets
  `ndk { debugSymbolLevel = "NONE" }` for `release` so no debug symbol
  package is generated either.
- `anti_tamper.cpp` reads `TracerPid` from `/proc/self/status` to detect
  an attached debugger/tracer (gdb, lldb, a Frida gadget, etc.).
  `SecurityGuard.kt` calls this (plus `Debug.isDebuggerConnected()` for
  the JVM side) once at startup in release builds and exits if either
  fires. This is a deterrent against casual tampering, not a guarantee
  against a determined reverse engineer — treat it as one layer, not the
  whole defense.

**What obfuscation cannot remove:** the manifest-declared Activity name,
overridden framework method names (`onCreate`, `onDestroy`, `onDraw`,
`onTouchEvent`, ...), and Android resource IDs/XML attribute names are all
platform-level contracts, not choices made in this codebase, so they stay
human-readable regardless of ProGuard settings. Native method *names* seen
by the JVM (`nativeRollDice`, etc., declared in `NativeBridge.kt`) are also
pinned for the reason above — but the compiled `.so`'s own internal
functions, symbol table, and the JNI method/signature strings themselves
are hidden as described above.

## Hardening / obfuscation, round two (additional layers)

Beyond the R8/ProGuard + JNI hardening above, four more layers were added:

- **APK signing-certificate check** (`SignatureGuard.kt`) — decompile,
  patch, re-sign, redistribute is the standard piracy workflow; comparing
  the running APK's actual signing cert hash against a known-good value
  catches a resigned build regardless of what else was patched.
  **You must fill in `EXPECTED_SHA256`** in that file after signing a
  release build (instructions are in the file's header comment) — until
  then the check intentionally no-ops rather than locking you out of your
  own builds.
- **Root / Frida / emulator heuristics** (`IntegrityChecks.kt`) — checks
  common `su` paths and `test-keys` build tags, scans `/proc/net/tcp` for
  Frida's default gadget port (27042), and checks `Build.FINGERPRINT`/
  `MODEL`/`MANUFACTURER` for known emulator signatures. Root/emulator are
  treated as **soft signals only** (too many false positives on real
  rooted phones and CI emulators to justify a hard lockout); an attached
  Frida server is treated as a hard hit alongside the debugger checks.
- **Poison-then-delay response** (`LudoEngine::poison` in `ludo_logic.h`/
  `.cpp`, orchestrated by `SecurityGuard.kt`) — instead of an obvious
  `if (tampered) exit(0);` sitting right next to the check that trips it,
  a hard hit silently flips a flag inside the native engine so every
  future `getValidMoves`/`movePawn` call quietly stops progressing the
  game (no crash, no error, just a stall that looks like a bug), and the
  actual process teardown happens on a separate, randomized 400–1100ms
  timer afterward. That separation in time and code location is what
  makes the response harder to bisect and patch out with a debugger than
  a single obvious exit call would be.
- **Obfuscated gameplay constants + opaque predicate** (`ludo_logic.cpp`,
  `obfuscated_strings.h`'s new `ObfInts<N>`) — the per-color start-offset
  and safe-cell tables are XOR-encoded at compile time and decoded once
  per `LudoEngine` instance instead of sitting in `.rodata` as a labeled,
  greppable `int[]`. `globalCell()` also carries a small opaque predicate
  (`alwaysTrue()`, a property that's mathematically always true but isn't
  obvious from a quick read) purely to add harmless noise to the
  function's control-flow graph for anyone attempting a decompiled
  static-analysis pass.
- **Mid-session re-check** — `MainActivity.onResume()` calls
  `GameCore.recheckIntegrity()`, so a debugger or Frida session attached
  *after* launch (rather than before) is still caught, not just the
  startup case.

**Honesty about limits:** this is source-level, project-scoped hardening
using standard Android tooling (R8/ProGuard + NDK build flags + a few
runtime checks) — a meaningfully higher bar than an unobfuscated APK, but
not equivalent to a commercial-grade packer/protector. A determined
reverse engineer with a debugger, Frida, and time can still work through
static string decryption, patch out the poison flag, and re-sign with
their own key (which is exactly why `SignatureGuard` exists, though it
only helps once you've filled in your real certificate hash). True DEX
encryption with a custom runtime unpacking `ClassLoader`, native code
virtualization, or white-box cryptography for anything genuinely secret
(license keys, server auth) are further tiers beyond what's implemented
here, and are typically bought as a commercial product rather than
hand-rolled.

## Building

1. Open the `UltimateOdul/` folder in Android Studio (Iguana or newer).
2. Let Gradle sync — it will invoke CMake automatically via the NDK to
   build `libludoengine.so` for all four ABIs.
3. Run on a device or emulator (minSdk 23).

Requires the Android NDK + CMake components installed via
**Tools -> SDK Manager -> SDK Tools** if Android Studio doesn't prompt for
them automatically.

## Project layout

```
UltimateOdul/
├── build.gradle / settings.gradle / gradle.properties
└── app/
    ├── build.gradle
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── cpp/
        │   ├── CMakeLists.txt
        │   ├── dice_native.c / dice_native.h      (C)
        │   ├── ludo_logic.cpp / ludo_logic.h       (C++)
        │   └── jni_bridge.cpp                      (C++ / JNI)
        ├── java/com/ultimateodul/ludo/
        │   ├── NativeBridge.kt
        │   ├── BoardGeometry.kt
        │   ├── LudoBoardView.kt
        │   ├── MainActivity.kt
        │   └── ScoreManager.java                   (Java)
        └── res/...
```

---

## Further hardening (this revision)

The following layers were added / strengthened on top of the original design:

### Native (libludoengine.so)

1. **Multi-layer string & table obfuscation** (`obfuscated_strings.h`)
   - Rolling XOR + additive constant + variable bit-rotate (compile-time encode, runtime decode).
   - Integer rule tables use a separate 32-bit rotate + mix transform.
   - Plain `strings` / simple static scans no longer recover method names, paths, or board constants.

2. **Expanded anti-tamper probe** (`anti_tamper.cpp`)
   - TracerPid from `/proc/self/status` (obfuscated path/field).
   - Full `/proc/self/maps` scan for frida / gadget / xposed / substrate / linjector markers.
   - Micro timing anomaly detection (catches heavy single-stepping).
   - Returns a bitfield so callers can grade the response if desired.

3. **Multi-bit poison** (`LudoEngine`)
   - Three independent integrity words with different non-zero patterns.
   - Once set, poison is never cleared by `resetGame()`.
   - Engine continues to return plausible dice values and “legal” results, but no progress or wins are possible.
   - A single store-zero patch is insufficient to restore play.

4. **Hardened link & compile flags**
   - `-fstack-protector-strong`, `-D_FORTIFY_SOURCE=2` (Release)
   - `-Wl,-z,relro -Wl,-z,now`
   - Full symbol hiding + section GC + strip

### JVM side

1. **Richer IntegrityChecks**
   - Additional root paths (Magisk), more emulator fingerprints, debuggable flag, installer/sideload detection, Frida server file presence.

2. **Staged SecurityGuard response**
   - Immediate silent poison → randomized 600–1800 ms delay → `finishAffinity()` + process kill.
   - No single obvious exit next to the failing check.

3. **SignatureGuard**
   - Constant-time-ish comparison.
   - Still requires you to fill in the real release certificate SHA-256.

4. **ProGuard**
   - Extra optimization passes, broader attribute stripping, logging fully eliminated.

### Remaining honest limits

This is still project-level hardening, not a commercial packer:
- No DEX encryption / custom ClassLoader
- No native code virtualization
- No white-box crypto
- A determined analyst with Frida, a debugger, and time can still work through the layers

For production shipping you should at minimum:
1. Fill in `SignatureGuard.EXPECTED_SHA256` with your real release key hash.
2. Consider a commercial protector (DexGuard, AppSealing, etc.) on top of this base if the threat model justifies the cost.

---

## Max free hardening revision

This revision pushes open techniques as far as practical:

- 4-layer compile-time string/int obfuscation
- Broad anti-Frida / anti-Xposed / anti-Magisk maps + artifact + timing probes
- Self-reasserting multi-word poison that survives partial patches and resetGame()
- Periodic integrity peeks inside the engine
- Staged multi-path process termination
- Maximum practical R8 settings + hardened native link flags

This is the strongest free/open hardening that can reasonably be hand-rolled for this project. It will frustrate casual and intermediate reverse engineers and raise the cost for determined attackers. It does **not** claim to exceed dedicated commercial protectors that use proprietary virtual machines and continuously updated engines.

---

## Odul-only naming + continued hardening

R8 is now forced to draw almost every renamed class, method, field and
package name from a large custom dictionary consisting solely of
"Odul"-based tokens (Odul, OdulOdul, Odul1, oDuL, OdulPoison, OdulTamper,
OdulMad, ...).

After a release build the decompiled Java/Kotlin side becomes a wall of
Odul* identifiers. Only the two platform-required names remain readable:

- `MainActivity` (AndroidManifest + lifecycle)
- Native method signatures on `NativeBridge` (JNI RegisterNatives)

Everything else — GameCore, LudoBoardView, BoardGeometry, ScoreManager,
SecurityGuard, SignatureGuard, IntegrityChecks, all helpers, fields and
constants — is renamed and repackaged using the Odul dictionary.

Combined with the previous max free hardening (4-layer string obfuscation,
broad anti-Frida/Xposed/Magisk probes, self-reasserting multi-state poison,
staged multi-path process termination, aggressive native link flags), this
is the strongest free configuration for this project.

---

## Pure "Odul" naming

The obfuscation dictionary now contains **only** the token `Odul`.

R8/ProGuard still requires unique names for classes, methods and fields
(JVM rule). Therefore the decompiled output becomes combinations such as:

- Odul
- Odul.Odul
- Odul.Odul.Odul

instead of varied names like OdulPoison, Odul3, OdulCheck, etc.

This is the closest practical result to “everything named only Odul”.
Only the two platform-required names remain fully readable:

- MainActivity
- NativeBridge native method signatures

---

## Expanded opaque Odul dictionary

The obfuscation dictionary now contains ~387 unique tokens. Every token
contains "Odul" and many are loosely game-flavored (Pawn, Dice, Board,
Yard, Safe, Turn, Capture…) mixed with deliberately meaningless or
abstract words (Nova, Pulse, Opaque, Pred, Cloak, Honey, Decoy…).

Because the names are unique but not systematically structured, a reverse
engineer sees a large set of Odul* identifiers without an obvious map
back to original class/method responsibilities. Combined with package
flattening, the decompiled surface becomes noisy and hard to navigate.
