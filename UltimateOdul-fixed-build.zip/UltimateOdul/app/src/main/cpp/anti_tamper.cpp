#include "anti_tamper.h"
#include "obfuscated_strings.h"

#include <cstdio>
#include <cstring>
#include <ctime>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

using ultimateodul::obf::ObfString;
using ultimateodul::obf::mix32;

namespace ultimateodul {

namespace {

bool checkTracerPid() {
    static constexpr ObfString kPath{"/proc/self/status"};
    static constexpr ObfString kField{"TracerPid:"};
    char path[64], field[32];
    kPath.decode(path);
    kField.decode(field);

    FILE *f = fopen(path, "r");
    if (!f) return false;
    bool hit = false;
    char line[256];
    size_t flen = kField.size();
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, field, flen) == 0) {
            int pid = 0;
            if (sscanf(line + flen, "%d", &pid) == 1 && pid != 0) hit = true;
            break;
        }
    }
    fclose(f);
    return hit;
}

bool checkSuspiciousMaps() {
    static constexpr ObfString kMaps{"/proc/self/maps"};
    // Broad set of known instrumentation markers
    static constexpr ObfString n0{"frida"};
    static constexpr ObfString n1{"gadget"};
    static constexpr ObfString n2{"frida-agent"};
    static constexpr ObfString n3{"xposed"};
    static constexpr ObfString n4{"substrate"};
    static constexpr ObfString n5{"linjector"};
    static constexpr ObfString n6{"libhook"};
    static constexpr ObfString n7{"edxp"};
    static constexpr ObfString n8{"riru"};
    static constexpr ObfString n9{"lsposed"};
    static constexpr ObfString n10{"magisk"};
    static constexpr ObfString n11{"zygisk"};

    char mapsPath[32];
    kMaps.decode(mapsPath);
    FILE *f = fopen(mapsPath, "r");
    if (!f) return false;

    char needles[12][24];
    n0.decode(needles[0]); n1.decode(needles[1]); n2.decode(needles[2]);
    n3.decode(needles[3]); n4.decode(needles[4]); n5.decode(needles[5]);
    n6.decode(needles[6]); n7.decode(needles[7]); n8.decode(needles[8]);
    n9.decode(needles[9]); n10.decode(needles[10]); n11.decode(needles[11]);

    bool hit = false;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        for (char *p = line; *p; ++p)
            if (*p >= 'A' && *p <= 'Z') *p += 32;
        for (int i = 0; i < 12; ++i) {
            if (strstr(line, needles[i])) { hit = true; break; }
        }
        if (hit) break;
    }
    fclose(f);
    return hit;
}

bool checkTimingAnomaly() {
    struct timespec t0{}, t1{};
    clock_gettime(CLOCK_MONOTONIC, &t0);
    volatile uint32_t acc = 0xC3A5A5A5u;
    for (int i = 0; i < 96; ++i) {
        acc = mix32(acc + static_cast<uint32_t>(i * 0x9E3779B9u));
        acc ^= (acc << 7) | (acc >> 25);
    }
    clock_gettime(CLOCK_MONOTONIC, &t1);
    long long ns = (t1.tv_sec - t0.tv_sec) * 1000000000LL + (t1.tv_nsec - t0.tv_nsec);
    // Generous threshold; still catches single-step / heavy interception
    return ns > 45000000LL;
}

bool checkBadArtifacts() {
    static constexpr ObfString a0{"/data/local/tmp/frida-server"};
    static constexpr ObfString a1{"/data/local/tmp/re.frida.server"};
    static constexpr ObfString a2{"/sdcard/frida-server"};
    static constexpr ObfString a3{"/data/local/tmp/fsocket"};
    static constexpr ObfString a4{"/dev/socket/qemud"};
    static constexpr ObfString a5{"/system/bin/qemud"};
    char p[96];
    a0.decode(p); if (access(p, F_OK) == 0) return true;
    a1.decode(p); if (access(p, F_OK) == 0) return true;
    a2.decode(p); if (access(p, F_OK) == 0) return true;
    a3.decode(p); if (access(p, F_OK) == 0) return true;
    a4.decode(p); if (access(p, F_OK) == 0) return true;
    a5.decode(p); if (access(p, F_OK) == 0) return true;
    return false;
}

// Very lightweight self-consistency check on obfuscation constants
bool checkSelfIntegrity() {
    // If someone patched the seed values in the binary, this can diverge.
    uint32_t expected = mix32(0xC3u * 0x7Au);
    uint32_t got = mix32(static_cast<uint32_t>(obf::kSeedA) * static_cast<uint32_t>(obf::kSeedB));
    return expected == got;
}

} // namespace

uint32_t probeIntegrity() {
    uint32_t flags = 0;
    if (checkTracerPid())       flags |= 1u;
    if (checkSuspiciousMaps())  flags |= 2u;
    if (checkTimingAnomaly())   flags |= 4u;
    if (checkBadArtifacts())    flags |= 8u;
    if (!checkSelfIntegrity())  flags |= 16u;
    return flags;
}

bool isBeingTraced() {
    return (probeIntegrity() & 0x1Fu) != 0;
}

bool quickIntegrityCheck() {
    // Cheaper subset for periodic calls
    return checkTracerPid() || checkSuspiciousMaps();
}

} // namespace ultimateodul
