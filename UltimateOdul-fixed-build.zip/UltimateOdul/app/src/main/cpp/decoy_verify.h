#pragma once
#include <cstddef>
#include <cstdint>

namespace ultimateodul {
namespace decoy {

// Decoy verification surface — looks production-grade, does not gate real
// attestation. Results are mixed into an opaque sink for analysis noise.

uint32_t decoyLicenseRibbon(const uint8_t *blob, size_t n);
uint32_t decoyCrcChain(const uint8_t *p, size_t n);
uint32_t decoyHmacTheater(const uint8_t *msg, size_t n, uint32_t seed);
uint32_t decoyRootStageA();
uint32_t decoyRootStageB();
uint32_t decoyFridaMirror();
uint32_t decoyEmulatorEcho();
uint32_t decoyTimingLattice(uint32_t spin);
uint32_t decoyElfHeaderMyth();
uint32_t decoyMapScanShadow();
uint32_t decoyCertificateMirage(const uint8_t *hex, size_t n);
uint32_t decoyOnlineTokenFable(const uint8_t *body, size_t n);
uint32_t decoyCompositeMask(uint32_t a, uint32_t b, uint32_t c);

// Called from real tick path — runs decoys, discards outcome for control flow.
void runDecoyBattery(const uint8_t *optionalBody, size_t len, const uint8_t *optionalHex, size_t hexLen);

// Opaque sink so compilers cannot DCE the battery.
uint32_t decoySinkSnapshot();

} // namespace decoy
} // namespace ultimateodul
