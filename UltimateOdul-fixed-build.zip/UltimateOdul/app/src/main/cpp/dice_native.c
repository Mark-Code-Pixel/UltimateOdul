#include "dice_native.h"
#include <time.h>

/*
 * Ultimate Odul - dice module (C)
 *
 * A small, fast xorshift32 PRNG. Kept in plain C so the "randomness core"
 * of the game is independent from the C++ rules engine and can be unit
 * tested / swapped out on its own.
 *
 * Uses uint32_t/int32_t exclusively (no `int`, `long`, or pointer-sized
 * arithmetic) so the compiled output is bit-for-bit equivalent whether
 * this file is built for a 32-bit ABI (armeabi-v7a, x86) or a 64-bit ABI
 * (arm64-v8a, x86_64).
 */

static uint32_t g_state = 0;

static uint32_t xorshift32(void) {
    uint32_t x = g_state;
    if (x == 0) {
        x = 0x9E3779B9u; /* never allow a zero state */
    }
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    g_state = x;
    return x;
}

void dice_seed(uint32_t seed) {
    if (seed == 0) {
        seed = (uint32_t) time(NULL);
    }
    g_state = seed;
    /* warm up the generator so early rolls aren't correlated with the seed */
    for (int32_t i = 0; i < 8; i++) {
        xorshift32();
    }
}

int32_t dice_roll(void) {
    if (g_state == 0) {
        dice_seed(0);
    }
    uint32_t r = xorshift32();
    return (int32_t) (r % 6u) + 1; /* 1..6 */
}
