#pragma once
#include <cstddef>
#include <cstdint>

namespace ultimateodul {
namespace attest {

// Result codes returned to JVM (nativeAttestTick / validate).
enum class Code : int32_t {
    Ok = 0,
    NeedNetwork = 1,
    BadPayload = 2,
    PinMismatch = 3,
    Stale = 4,
    Poisoned = 5,
};

// Feed a full HTTP body from /health or /keepalive. Returns Ok only if
// structure + integrity markers match expected online service.
Code validateRemotePayload(const uint8_t *data, size_t len);

// Constant-time compare of a hex SHA-256 (64 ascii chars) against the
// compile-time pinned release certificate fingerprint.
bool pinSha256Matches(const uint8_t *hex64, size_t len);

// Called every second from the guard path. Returns NeedNetwork if no
// successful validate occurred recently; Poisoned if integrity collapsed.
Code tick();

// Mark last successful network attestation timestamp (monotonic ms from JVM).
void markOnlineSuccess(int64_t monoMs);

// Hard fail latch (cannot be cleared without process death).
void poison();
bool isPoisoned();

} // namespace attest
} // namespace ultimateodul
