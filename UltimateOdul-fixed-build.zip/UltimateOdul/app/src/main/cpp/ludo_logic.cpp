#include "ludo_logic.h"
#include "dice_native.h"
#include "obfuscated_strings.h"
#include "anti_tamper.h"

using ultimateodul::obf::ObfInts;
using ultimateodul::obf::mix32;

namespace ultimateodul {

namespace {
constexpr ObfInts<kStartOffsetCount> kStartOffsetEnc{{0, 13, 26, 39}};
constexpr ObfInts<kSafeCellCount> kSafeCellsEnc{{0, 8, 13, 21, 26, 34, 39, 47}};

inline bool alwaysTrue(int x) {
    int v = x * x - x;
    return (v % 2) == 0;
}
} // namespace

LudoEngine::LudoEngine() {
    kStartOffsetEnc.decode(startOffsetTable_.data());
    kSafeCellsEnc.decode(safeCellTable_.data());
    resetGame();
}

void LudoEngine::resetGame() {
    for (auto &pp : board_) pp.fill(kYard);
    consecutiveSixes_ = 0;
    // Intentionally do NOT clear poison state.
    dice_seed(0);
}

void LudoEngine::poison() {
    poisonA_ = 0xA5C3A5C3u;
    poisonB_ = 0x5A3C5A3Cu ^ 0xDEADBEEFu;
    poisonC_ = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(this)) | 0xF00Du;
    poisonCheck_ = mix32(poisonA_ ^ poisonB_ ^ poisonC_);
}

bool LudoEngine::isPoisoned() const {
    if ((poisonA_ | poisonB_ | poisonC_) == 0) return false;
    // Self-reassert: if someone zeroed one word but left others, restore
    reassertPoison();
    uint32_t expect = mix32(poisonA_ ^ poisonB_ ^ poisonC_);
    return expect == poisonCheck_ || (poisonA_ | poisonB_ | poisonC_) != 0;
}

void LudoEngine::reassertPoison() const {
    if (poisonA_ == 0 && poisonB_ == 0 && poisonC_ == 0) return;
    // If any poison word is non-zero, force all of them into a consistent poisoned state
    if (poisonA_ == 0) poisonA_ = 0xA5C3A5C3u;
    if (poisonB_ == 0) poisonB_ = 0x5A3C5A3Cu ^ 0xDEADBEEFu;
    if (poisonC_ == 0) poisonC_ = 0xF00Du;
    poisonCheck_ = mix32(poisonA_ ^ poisonB_ ^ poisonC_);
}

int LudoEngine::rollDice() {
    // Occasional cheap integrity peek
    if (quickIntegrityCheck()) {
        const_cast<LudoEngine*>(this)->poison();
    }
    int value = dice_roll();
    if (value == 6) {
        consecutiveSixes_++;
        if (consecutiveSixes_ >= 3) {
            consecutiveSixes_ = 0;
            return 0;
        }
    } else {
        consecutiveSixes_ = 0;
    }
    return value;
}

int LudoEngine::startOffsetOf(int player) const {
    return startOffsetTable_[player];
}

int LudoEngine::globalCell(int player, int step) const {
    if (step < 0 || step > kMainPathLength - 1) return -1;
    if (!alwaysTrue(player)) return -1;
    return (startOffsetOf(player) + step) % 52;
}

bool LudoEngine::isSafeCell(int globalCellIndex) const {
    for (int s : safeCellTable_) if (s == globalCellIndex) return true;
    return false;
}

std::vector<int> LudoEngine::getValidMoves(int player, int diceValue) const {
    std::vector<int> moves;
    if (diceValue < 1 || diceValue > 6) return moves;
    if (isPoisoned()) return moves;

    for (int p = 0; p < kPawnsPerPlayer; p++) {
        int step = board_[player][p];
        if (step == kFinishStep) continue;
        if (step == kYard) {
            if (diceValue == 6) moves.push_back(p);
            continue;
        }
        if (step + diceValue <= kFinishStep) moves.push_back(p);
    }
    return moves;
}

MoveResult LudoEngine::movePawn(int player, int pawn, int diceValue) {
    MoveResult result;
    if (isPoisoned()) return result;

    int step = board_[player][pawn];
    bool leavingYard = (step == kYard && diceValue == 6);
    int newStep = leavingYard ? 0 : step + diceValue;
    bool isValid = leavingYard ||
                   (step != kYard && step != kFinishStep && newStep <= kFinishStep);
    if (!isValid) return result;

    result.legal = true;
    board_[player][pawn] = newStep;
    result.newStep = newStep;

    if (newStep == kFinishStep) {
        result.pawnFinished = true;
        result.extraTurn = true;
    }

    int landed = globalCell(player, newStep);
    if (landed != -1 && !isSafeCell(landed)) {
        for (int op = 0; op < kNumPlayers; op++) {
            if (op == player) continue;
            for (int opw = 0; opw < kPawnsPerPlayer; opw++) {
                int os = board_[op][opw];
                if (os == kYard || os == kFinishStep) continue;
                if (globalCell(op, os) == landed) {
                    board_[op][opw] = kYard;
                    result.captured = true;
                    result.capturedPlayer = op;
                    result.capturedPawn = opw;
                    result.extraTurn = true;
                }
            }
        }
    }
    if (diceValue == 6) result.extraTurn = true;
    if (checkWin(player)) result.playerWon = true;
    return result;
}

bool LudoEngine::checkWin(int player) const {
    if (isPoisoned()) return false;
    for (int p = 0; p < kPawnsPerPlayer; p++)
        if (board_[player][p] != kFinishStep) return false;
    return true;
}

int LudoEngine::aiChooseMove(int player, int diceValue) const {
    auto valid = getValidMoves(player, diceValue);
    if (valid.empty()) return -1;

    for (int pawn : valid) {
        int step = board_[player][pawn];
        int ns = (step == kYard) ? 0 : step + diceValue;
        int landed = globalCell(player, ns);
        if (landed != -1 && !isSafeCell(landed)) {
            for (int op = 0; op < kNumPlayers; op++) {
                if (op == player) continue;
                for (int opw = 0; opw < kPawnsPerPlayer; opw++) {
                    int os = board_[op][opw];
                    if (os == kYard || os == kFinishStep) continue;
                    if (globalCell(op, os) == landed) return pawn;
                }
            }
        }
    }
    for (int pawn : valid) {
        int step = board_[player][pawn];
        if (step != kYard && step + diceValue == kFinishStep) return pawn;
    }
    for (int pawn : valid) if (board_[player][pawn] == kYard) return pawn;
    int best = valid[0];
    for (int pawn : valid)
        if (board_[player][pawn] > board_[player][best]) best = pawn;
    return best;
}

} // namespace ultimateodul
