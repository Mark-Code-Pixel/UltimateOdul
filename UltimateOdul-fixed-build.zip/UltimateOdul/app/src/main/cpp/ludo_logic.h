#ifndef ULTIMATE_ODUL_LUDO_LOGIC_H
#define ULTIMATE_ODUL_LUDO_LOGIC_H

#include <array>
#include <vector>
#include <cstdint>

namespace ultimateodul {

constexpr int kNumPlayers = 4;
constexpr int kPawnsPerPlayer = 4;
constexpr int kMainPathLength = 51;
constexpr int kHomeEntry = 51;
constexpr int kFinishStep = 56;
constexpr int kYard = -1;
constexpr int kStartOffsetCount = kNumPlayers;
constexpr int kSafeCellCount = 8;

struct MoveResult {
    bool legal = false;
    int newStep = kYard;
    bool captured = false;
    int capturedPlayer = -1;
    int capturedPawn = -1;
    bool extraTurn = false;
    bool pawnFinished = false;
    bool playerWon = false;
};

class LudoEngine {
public:
    LudoEngine();
    void resetGame();
    int rollDice();
    std::vector<int> getValidMoves(int player, int diceValue) const;
    MoveResult movePawn(int player, int pawn, int diceValue);
    bool checkWin(int player) const;
    int aiChooseMove(int player, int diceValue) const;
    int getPawnStep(int player, int pawn) const { return board_[player][pawn]; }
    void setPawnStep(int player, int pawn, int step) { board_[player][pawn] = step; }

    // Aggressive multi-state poison. Sets several independent words and a
    // derived checksum. Once poisoned, resetGame() will not clear it.
    // Periodic re-checks inside the engine can re-assert the poison.
    void poison();
    bool isPoisoned() const;

private:
    std::array<std::array<int, kPawnsPerPlayer>, kNumPlayers> board_{};
    std::array<int, kStartOffsetCount> startOffsetTable_{};
    std::array<int, kSafeCellCount> safeCellTable_{};
    int consecutiveSixes_ = 0;

    // Distributed poison state (hard to neutralize with one or two patches)
    mutable uint32_t poisonA_ = 0;
    mutable uint32_t poisonB_ = 0;
    mutable uint32_t poisonC_ = 0;
    mutable uint32_t poisonCheck_ = 0;

    void reassertPoison() const;
    int startOffsetOf(int player) const;
    int globalCell(int player, int step) const;
    bool isSafeCell(int globalCellIndex) const;
};

} // namespace ultimateodul

#endif
