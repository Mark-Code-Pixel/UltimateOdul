#include "attest_engine.h"
#include "obfuscated_strings.h"
#include "decoy_verify.h"
#include <atomic>
#include <cstring>

#if defined(__aarch64__) || defined(__arm__)
#include <arm_neon.h>
#endif

namespace ultimateodul {
namespace attest {
namespace {

// Pinned release cert SHA-256 (lowercase hex), held obfuscated.
// 7c06908428d491f722cb49c2...
constexpr ultimateodul::obf::ObfString kPinnedSha256{
    "7c06908428d491f722cb49c21f183ee04309ef5412fd3a7a136fb09d3ef87c4a"
};

// Expected JSON fragments for odul-online-v1 health/keepalive (not full schema).
constexpr ultimateodul::obf::ObfString kFragService{"odul-online-v1"};
constexpr ultimateodul::obf::ObfString kFragOkTrue{"\"ok\":true"};
constexpr ultimateodul::obf::ObfString kFragPhase{"\"phase\":\"online\""};

std::atomic<bool> gPoison{false};
std::atomic<int64_t> gLastOkMs{0};
std::atomic<uint32_t> gTickCtr{0};
std::atomic<uint32_t> gMix{0xA5A5A5A5u};

// Opaque mix so trivial NOP-patching of a single branch is harder.
[[gnu::always_inline]] inline uint32_t diffuse(uint32_t x) {
    x ^= x >> 16;
    x *= 0x7feb352du;
    x ^= x >> 15;
    x *= 0x846ca68bu;
    x ^= x >> 16;
    return x;
}

[[gnu::noinline]] bool ctEq(const char *a, const char *b, size_t n) {
    volatile uint8_t d = 0;
    for (size_t i = 0; i < n; ++i) {
        d = static_cast<uint8_t>(d | (static_cast<uint8_t>(a[i]) ^ static_cast<uint8_t>(b[i])));
    }
    return d == 0;
}

[[gnu::noinline]] bool contains(const uint8_t *hay, size_t hlen, const char *needle, size_t nlen) {
    if (nlen == 0 || hlen < nlen) return false;
    for (size_t i = 0; i + nlen <= hlen; ++i) {
        size_t j = 0;
        for (; j < nlen; ++j) {
            if (static_cast<char>(hay[i + j]) != needle[j]) break;
        }
        if (j == nlen) return true;
    }
    return false;
}

// Light assembly barrier — forces materialization of integrity mix on ARM.
[[gnu::always_inline]] inline void barrierMix(uint32_t &v) {
#if defined(__aarch64__)
    asm volatile("eor %w0, %w0, %w0\n\torr %w0, %w0, %w1" : "+r"(v) : "r"(v) : "memory");
#elif defined(__arm__)
    asm volatile("eor %0, %0, %0\n\torr %0, %0, %1" : "+r"(v) : "r"(v) : "memory");
#else
    v ^= 0;
    asm volatile("" ::: "memory");
#endif
}

} // namespace

Code validateRemotePayload(const uint8_t *data, size_t len) {
    if (gPoison.load(std::memory_order_acquire)) return Code::Poisoned;
    // Decoy battery first — analysts see heavy work before real gates
    ultimateodul::decoy::runDecoyBattery(data, len, nullptr, 0);
    (void)ultimateodul::decoy::decoySinkSnapshot();
    if (data == nullptr || len < 12 || len > 4096) {
        gMix.store(diffuse(gMix.load() ^ 0x11u), std::memory_order_relaxed);
        return Code::BadPayload;
    }

    char svc[32], ok[16], phase[24];
    kFragService.decode(svc);
    kFragOkTrue.decode(ok);
    kFragPhase.decode(phase);

    const bool a = contains(data, len, ok, std::strlen(ok));
    const bool b = contains(data, len, svc, std::strlen(svc));
    // phase marker preferred; keepalive body may only carry ok+service
    const bool c = contains(data, len, phase, std::strlen(phase)) || b;

    uint32_t m = gMix.load(std::memory_order_relaxed);
    m = diffuse(m ^ (a ? 0x91u : 0x22u) ^ (b ? 0x44u : 0x08u));
    barrierMix(m);
    gMix.store(m, std::memory_order_relaxed);

    if (!(a && b && c)) {
        return Code::BadPayload;
    }
    return Code::Ok;
}

bool pinSha256Matches(const uint8_t *hex64, size_t len) {
    ultimateodul::decoy::runDecoyBattery(nullptr, 0, hex64, len);
    if (hex64 == nullptr || len != 64) return false;
    char expect[65];
    kPinnedSha256.decode(expect);
    // normalize: accept only [0-9a-f]
    char got[65];
    for (size_t i = 0; i < 64; ++i) {
        char c = static_cast<char>(hex64[i]);
        if (c >= 'A' && c <= 'F') c = static_cast<char>(c - 'A' + 'a');
        if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return false;
        got[i] = c;
    }
    got[64] = 0;
    return ctEq(got, expect, 64);
}

void markOnlineSuccess(int64_t monoMs) {
    if (gPoison.load(std::memory_order_acquire)) return;
    gLastOkMs.store(monoMs, std::memory_order_release);
    uint32_t m = gMix.load(std::memory_order_relaxed);
    m = diffuse(m ^ 0x5a5a5a5au ^ static_cast<uint32_t>(monoMs));
    barrierMix(m);
    gMix.store(m, std::memory_order_relaxed);
}

Code tick() {
    if (gPoison.load(std::memory_order_acquire)) return Code::Poisoned;
    ultimateodul::decoy::runDecoyBattery(nullptr, 0, nullptr, 0);
    const uint32_t n = gTickCtr.fetch_add(1, std::memory_order_relaxed) + 1;
    uint32_t m = gMix.load(std::memory_order_relaxed);
    m = diffuse(m + n);
    barrierMix(m);
    gMix.store(m, std::memory_order_relaxed);

    // Stale if never succeeded or older than ~4 seconds (allows brief blips).
    // Caller supplies mono time via markOnlineSuccess; we only know last ok.
    // tick itself cannot read Android clock — staleness enforced in JVM using
    // native return of last-ok via separate path. Here: if never marked, fail.
    if (gLastOkMs.load(std::memory_order_acquire) == 0) {
        return Code::NeedNetwork;
    }
    return Code::Ok;
}

void poison() {
    gPoison.store(true, std::memory_order_release);
}

bool isPoisoned() {
    return gPoison.load(std::memory_order_acquire);
}

} // namespace attest
} // namespace ultimateodul
