#ifndef ULTIMATE_ODUL_ANTI_TAMPER_H
#define ULTIMATE_ODUL_ANTI_TAMPER_H

#include <cstdint>

namespace ultimateodul {

// Aggressive multi-signal integrity probe.
// Returns bitfield:
//  bit 0 : TracerPid / ptrace attach
//  bit 1 : suspicious maps (Frida/Xposed/etc)
//  bit 2 : timing anomaly
//  bit 3 : known bad files / pipes
//  bit 4 : integrity self-check failed
// Any non-zero is treated as hard hit.
uint32_t probeIntegrity();

// Convenience
bool isBeingTraced();

// Lightweight periodic re-check that can be called from game loop
bool quickIntegrityCheck();

} // namespace ultimateodul

#endif
