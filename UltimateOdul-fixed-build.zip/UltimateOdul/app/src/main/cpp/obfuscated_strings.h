#ifndef ULTIMATE_ODUL_OBFUSCATED_STRINGS_H
#define ULTIMATE_ODUL_OBFUSCATED_STRINGS_H

#include <cstddef>
#include <cstdint>

namespace ultimateodul {
namespace obf {

// Aggressive multi-layer compile-time obfuscation.
// Layers: rolling XOR → additive mix → variable rotate → second XOR with derived key.
// Designed so static strings / simple pattern matching fail; attacker must
// reverse or emulate the exact decode path.

constexpr uint8_t  kSeedA = 0xC3;
constexpr uint8_t  kSeedB = 0x7A;
constexpr uint32_t kPrime = 0x01000193u;

constexpr uint8_t rotl8(uint8_t v, unsigned n) {
    n &= 7u;
    return static_cast<uint8_t>((v << n) | (v >> (8u - n)));
}
constexpr uint8_t rotr8(uint8_t v, unsigned n) {
    n &= 7u;
    return static_cast<uint8_t>((v >> n) | (v << (8u - n)));
}

template <std::size_t N>
struct ObfString {
    uint8_t data[N]{};
    std::size_t len = N - 1;

    constexpr explicit ObfString(const char (&plain)[N]) : data{} {
        for (std::size_t i = 0; i < N; ++i) {
            uint8_t b = static_cast<uint8_t>(plain[i]);
            // Layer 1
            uint8_t k1 = static_cast<uint8_t>(kSeedA + i * 37u);
            b ^= k1;
            // Layer 2
            b = static_cast<uint8_t>(b + kSeedB + (i * 13u));
            // Layer 3
            b = rotl8(b, static_cast<unsigned>((i % 7) + 1));
            // Layer 4
            uint8_t k2 = static_cast<uint8_t>((kSeedA * 31u + i * 17u) ^ 0xA5);
            b ^= k2;
            data[i] = b;
        }
    }

    void decode(char *out) const {
        for (std::size_t i = 0; i < N; ++i) {
            uint8_t b = data[i];
            // Inverse layer 4
            uint8_t k2 = static_cast<uint8_t>((kSeedA * 31u + i * 17u) ^ 0xA5);
            b ^= k2;
            // Inverse layer 3
            b = rotr8(b, static_cast<unsigned>((i % 7) + 1));
            // Inverse layer 2
            b = static_cast<uint8_t>(b - kSeedB - (i * 13u));
            // Inverse layer 1
            uint8_t k1 = static_cast<uint8_t>(kSeedA + i * 37u);
            b ^= k1;
            out[i] = static_cast<char>(b);
        }
    }

    [[nodiscard]] std::size_t size() const { return len; }
};

template <std::size_t N>
struct ObfInts {
    uint32_t data[N]{};

    constexpr explicit ObfInts(const int (&plain)[N]) : data{} {
        for (std::size_t i = 0; i < N; ++i) {
            uint32_t v = static_cast<uint32_t>(plain[i]);
            uint32_t mix = kSeedA * kPrime + static_cast<uint32_t>(i) * 2654435761u;
            v ^= mix;
            v = (v << 11) | (v >> 21);
            v += 0x9E3779B9u ^ static_cast<uint32_t>(i * 0x85EBCA6Bu);
            v ^= (v >> 16);
            data[i] = v;
        }
    }

    void decode(int *out) const {
        for (std::size_t i = 0; i < N; ++i) {
            uint32_t v = data[i];
            v ^= (v >> 16);
            v -= 0x9E3779B9u ^ static_cast<uint32_t>(i * 0x85EBCA6Bu);
            v = (v >> 11) | (v << 21);
            uint32_t mix = kSeedA * kPrime + static_cast<uint32_t>(i) * 2654435761u;
            v ^= mix;
            out[i] = static_cast<int>(v);
        }
    }
};

// Simple runtime integrity mix used by anti-tamper and poison paths
inline uint32_t mix32(uint32_t x) {
    x ^= x >> 16;
    x *= 0x7FEB352Du;
    x ^= x >> 15;
    x *= 0x846CA68Bu;
    x ^= x >> 16;
    return x;
}

} // namespace obf
} // namespace ultimateodul

#endif
