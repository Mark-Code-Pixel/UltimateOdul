#include <jni.h>
#include <cstdint>
#include <cstring>
#include <vector>
#include "ludo_logic.h"
#include "anti_tamper.h"
#include "obfuscated_strings.h"
#include "attest_engine.h"
#include "decoy_verify.h"

using ultimateodul::LudoEngine;
using ultimateodul::obf::ObfString;

// --------------------------------------------------------------------------
// Hardened JNI wiring.
//
// Nothing here is exported under the default JNI naming convention
// (Java_com_ultimateodul_ludo_NativeBridge_xxx). Every function below is a
// plain, hidden-visibility, arbitrarily-named C++ function; the ONLY thing
// that ties them to Kotlin's `external fun` declarations is the
// RegisterNatives() call in JNI_OnLoad, and even the (name, signature)
// strings fed to RegisterNatives are XOR-encoded at compile time and
// decoded on the stack at load time -- so static analysis of the shipped
// .so (strings/grep, objdump symbol table) surfaces neither the Java
// method names nor a readable JNI_ symbol per method.
//
// JNI_OnLoad itself must stay exported (the JVM calls it by that exact
// name to initialize the library), and NativeBridge's class path must stay
// stable, which is why proguard-rules.pro keeps that one class name intact
// -- everything else in the app is free to be renamed by R8.
// --------------------------------------------------------------------------

namespace {

// A native engine pointer is handed to Kotlin as a jlong "handle". jlong is
// always 64-bit per the JVM spec, but a pointer is only 32-bit on
// armeabi-v7a/x86 -- round-tripping through uintptr_t (never directly
// through jlong) is what keeps this exact on both bit-widths.
inline jlong toHandle(LudoEngine *engine) {
    return static_cast<jlong>(reinterpret_cast<uintptr_t>(engine));
}

inline LudoEngine *fromHandle(jlong handle) {
    return reinterpret_cast<LudoEngine *>(static_cast<uintptr_t>(handle));
}

jlong n_init(JNIEnv *, jobject) {
    return toHandle(new LudoEngine());
}

void n_destroy(JNIEnv *, jobject, jlong handle) {
    delete fromHandle(handle);
}

void n_resetGame(JNIEnv *, jobject, jlong handle) {
    fromHandle(handle)->resetGame();
}

jint n_rollDice(JNIEnv *, jobject, jlong handle) {
    return fromHandle(handle)->rollDice();
}

jintArray n_getValidMoves(JNIEnv *env, jobject, jlong handle, jint player, jint diceValue) {
    std::vector<int> moves = fromHandle(handle)->getValidMoves(player, diceValue);
    jintArray result = env->NewIntArray(static_cast<jsize>(moves.size()));
    if (!moves.empty()) {
        env->SetIntArrayRegion(result, 0, static_cast<jsize>(moves.size()), moves.data());
    }
    return result;
}

// [legal, newStep, captured, capturedPlayer, capturedPawn, extraTurn, pawnFinished, playerWon]
jintArray n_movePawn(JNIEnv *env, jobject, jlong handle, jint player, jint pawn, jint diceValue) {
    ultimateodul::MoveResult r = fromHandle(handle)->movePawn(player, pawn, diceValue);
    jint packed[8] = {
            r.legal ? 1 : 0, r.newStep, r.captured ? 1 : 0, r.capturedPlayer,
            r.capturedPawn, r.extraTurn ? 1 : 0, r.pawnFinished ? 1 : 0, r.playerWon ? 1 : 0
    };
    jintArray result = env->NewIntArray(8);
    env->SetIntArrayRegion(result, 0, 8, packed);
    return result;
}

jboolean n_checkWin(JNIEnv *, jobject, jlong handle, jint player) {
    return fromHandle(handle)->checkWin(player) ? JNI_TRUE : JNI_FALSE;
}

jint n_aiChooseMove(JNIEnv *, jobject, jlong handle, jint player, jint diceValue) {
    return fromHandle(handle)->aiChooseMove(player, diceValue);
}

jintArray n_getBoardState(JNIEnv *env, jobject, jlong handle) {
    LudoEngine *engine = fromHandle(handle);
    jint flat[ultimateodul::kNumPlayers * ultimateodul::kPawnsPerPlayer];
    int idx = 0;
    for (int p = 0; p < ultimateodul::kNumPlayers; p++) {
        for (int w = 0; w < ultimateodul::kPawnsPerPlayer; w++) {
            flat[idx++] = engine->getPawnStep(p, w);
        }
    }
    jintArray result = env->NewIntArray(idx);
    env->SetIntArrayRegion(result, 0, idx, flat);
    return result;
}

jboolean n_isBeingTraced(JNIEnv *, jobject) {
    return ultimateodul::isBeingTraced() ? JNI_TRUE : JNI_FALSE;
}

void n_poison(JNIEnv *, jobject, jlong handle) {
    fromHandle(handle)->poison();
}


jboolean n_attestValidate(JNIEnv *env, jobject, jbyteArray body) {
    if (body == nullptr) return JNI_FALSE;
    const jsize len = env->GetArrayLength(body);
    if (len <= 0) return JNI_FALSE;
    jbyte *bytes = env->GetByteArrayElements(body, nullptr);
    if (bytes == nullptr) return JNI_FALSE;
    auto code = ultimateodul::attest::validateRemotePayload(
            reinterpret_cast<const uint8_t *>(bytes), static_cast<size_t>(len));
    env->ReleaseByteArrayElements(body, bytes, JNI_ABORT);
    return code == ultimateodul::attest::Code::Ok ? JNI_TRUE : JNI_FALSE;
}

jboolean n_attestPin(JNIEnv *env, jobject, jstring hex) {
    if (hex == nullptr) return JNI_FALSE;
    const char *utf = env->GetStringUTFChars(hex, nullptr);
    if (utf == nullptr) return JNI_FALSE;
    const size_t n = std::strlen(utf);
    const bool ok = ultimateodul::attest::pinSha256Matches(
            reinterpret_cast<const uint8_t *>(utf), n);
    env->ReleaseStringUTFChars(hex, utf);
    return ok ? JNI_TRUE : JNI_FALSE;
}

void n_attestMarkOk(JNIEnv *, jobject, jlong monoMs) {
    ultimateodul::attest::markOnlineSuccess(static_cast<int64_t>(monoMs));
}

jint n_attestTick(JNIEnv *, jobject) {
    return static_cast<jint>(ultimateodul::attest::tick());
}

void n_attestPoison(JNIEnv *, jobject) {
    ultimateodul::attest::poison();
}

jboolean n_attestPoisoned(JNIEnv *, jobject) {
    return ultimateodul::attest::isPoisoned() ? JNI_TRUE : JNI_FALSE;
}

jint n_decoyProbe(JNIEnv *env, jobject, jbyteArray blob) {
    const uint8_t *p = nullptr;
    size_t n = 0;
    jbyte *bytes = nullptr;
    if (blob != nullptr) {
        n = static_cast<size_t>(env->GetArrayLength(blob));
        bytes = env->GetByteArrayElements(blob, nullptr);
        p = reinterpret_cast<const uint8_t *>(bytes);
    }
    ultimateodul::decoy::runDecoyBattery(p, n, p, n);
    uint32_t snap = ultimateodul::decoy::decoySinkSnapshot();
    if (bytes) env->ReleaseByteArrayElements(blob, bytes, JNI_ABORT);
    return static_cast<jint>(snap & 0x7fffffff);
}

jint n_decoyLicense(JNIEnv *env, jobject, jstring serial) {
    const char *utf = serial ? env->GetStringUTFChars(serial, nullptr) : nullptr;
    size_t n = utf ? std::strlen(utf) : 0;
    uint32_t v = ultimateodul::decoy::decoyLicenseRibbon(
        reinterpret_cast<const uint8_t *>(utf), n);
    v ^= ultimateodul::decoy::decoyHmacTheater(
        reinterpret_cast<const uint8_t *>(utf), n, 0x51C0u);
    if (utf) env->ReleaseStringUTFChars(serial, utf);
    return static_cast<jint>(v & 0x7fffffff);
}

jboolean n_decoyEnvClear(JNIEnv *, jobject) {
    uint32_t a = ultimateodul::decoy::decoyRootStageA();
    uint32_t b = ultimateodul::decoy::decoyFridaMirror();
    uint32_t c = ultimateodul::decoy::decoyEmulatorEcho();
    // Always JNI_TRUE — decoy does not gate
    (void)ultimateodul::decoy::decoyCompositeMask(a, b, c);
    return JNI_TRUE;
}


// --- encrypted (name, signature) pairs, decoded once at JNI_OnLoad time ---

template <std::size_t NN, std::size_t NS>
JNINativeMethod makeMethod(char *nameBuf, char *sigBuf,
                            const ObfString<NN> &name, const ObfString<NS> &sig,
                            void *fn) {
    name.decode(nameBuf);
    sig.decode(sigBuf);
    return JNINativeMethod{nameBuf, sigBuf, fn};
}

} // namespace

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *) {
    JNIEnv *env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }

    static constexpr ObfString kClassPath{"com/ultimateodul/ludo/NativeBridge"};
    char classPathBuf[kClassPath.size() + 1];
    kClassPath.decode(classPathBuf);

    jclass clazz = env->FindClass(classPathBuf);
    if (clazz == nullptr) return JNI_ERR;

    static constexpr ObfString nInit{"nativeInit"};
    static constexpr ObfString sInit{"()J"};
    static constexpr ObfString nDestroy{"nativeDestroy"};
    static constexpr ObfString sDestroy{"(J)V"};
    static constexpr ObfString nReset{"nativeResetGame"};
    static constexpr ObfString sReset{"(J)V"};
    static constexpr ObfString nRoll{"nativeRollDice"};
    static constexpr ObfString sRoll{"(J)I"};
    static constexpr ObfString nValid{"nativeGetValidMoves"};
    static constexpr ObfString sValid{"(JII)[I"};
    static constexpr ObfString nMove{"nativeMovePawn"};
    static constexpr ObfString sMove{"(JIII)[I"};
    static constexpr ObfString nWin{"nativeCheckWin"};
    static constexpr ObfString sWin{"(JI)Z"};
    static constexpr ObfString nAi{"nativeAiChooseMove"};
    static constexpr ObfString sAi{"(JII)I"};
    static constexpr ObfString nBoard{"nativeGetBoardState"};
    static constexpr ObfString sBoard{"(J)[I"};
    static constexpr ObfString nTrace{"nativeIsBeingTraced"};
    static constexpr ObfString sTrace{"()Z"};
    static constexpr ObfString nPoison{"nativePoison"};
    static constexpr ObfString sPoison{"(J)V"};
    static constexpr ObfString nAttVal{"nativeAttestValidate"};
    static constexpr ObfString sAttVal{"([B)Z"};
    static constexpr ObfString nAttPin{"nativeAttestPin"};
    static constexpr ObfString sAttPin{"(Ljava/lang/String;)Z"};
    static constexpr ObfString nAttMark{"nativeAttestMarkOk"};
    static constexpr ObfString sAttMark{"(J)V"};
    static constexpr ObfString nAttTick{"nativeAttestTick"};
    static constexpr ObfString sAttTick{"()I"};
    static constexpr ObfString nAttPsn{"nativeAttestPoison"};
    static constexpr ObfString sAttPsn{"()V"};
    static constexpr ObfString nAttPsnQ{"nativeAttestPoisoned"};
    static constexpr ObfString sAttPsnQ{"()Z"};
    static constexpr ObfString nDecoyP{"nativeDecoyProbe"};
    static constexpr ObfString sDecoyP{"([B)I"};
    static constexpr ObfString nDecoyL{"nativeDecoyLicense"};
    static constexpr ObfString sDecoyL{"(Ljava/lang/String;)I"};
    static constexpr ObfString nDecoyE{"nativeDecoyEnvClear"};
    static constexpr ObfString sDecoyE{"()Z"};

    char b1[nInit.size() + 1], b2[sInit.size() + 1];
    char b3[nDestroy.size() + 1], b4[sDestroy.size() + 1];
    char b5[nReset.size() + 1], b6[sReset.size() + 1];
    char b7[nRoll.size() + 1], b8[sRoll.size() + 1];
    char b9[nValid.size() + 1], b10[sValid.size() + 1];
    char b11[nMove.size() + 1], b12[sMove.size() + 1];
    char b13[nWin.size() + 1], b14[sWin.size() + 1];
    char b15[nAi.size() + 1], b16[sAi.size() + 1];
    char b17[nBoard.size() + 1], b18[sBoard.size() + 1];
    char b19[nTrace.size() + 1], b20[sTrace.size() + 1];
    char b21[nPoison.size() + 1], b22[sPoison.size() + 1];
    char b23[nAttVal.size() + 1], b24[sAttVal.size() + 1];
    char b25[nAttPin.size() + 1], b26[sAttPin.size() + 1];
    char b27[nAttMark.size() + 1], b28[sAttMark.size() + 1];
    char b29[nAttTick.size() + 1], b30[sAttTick.size() + 1];
    char b31[nAttPsn.size() + 1], b32[sAttPsn.size() + 1];
    char b33[nAttPsnQ.size() + 1], b34[sAttPsnQ.size() + 1];
    char b35[nDecoyP.size() + 1], b36[sDecoyP.size() + 1];
    char b37[nDecoyL.size() + 1], b38[sDecoyL.size() + 1];
    char b39[nDecoyE.size() + 1], b40[sDecoyE.size() + 1];

    JNINativeMethod methods[] = {
            makeMethod(b1, b2, nInit, sInit, reinterpret_cast<void *>(n_init)),
            makeMethod(b3, b4, nDestroy, sDestroy, reinterpret_cast<void *>(n_destroy)),
            makeMethod(b5, b6, nReset, sReset, reinterpret_cast<void *>(n_resetGame)),
            makeMethod(b7, b8, nRoll, sRoll, reinterpret_cast<void *>(n_rollDice)),
            makeMethod(b9, b10, nValid, sValid, reinterpret_cast<void *>(n_getValidMoves)),
            makeMethod(b11, b12, nMove, sMove, reinterpret_cast<void *>(n_movePawn)),
            makeMethod(b13, b14, nWin, sWin, reinterpret_cast<void *>(n_checkWin)),
            makeMethod(b15, b16, nAi, sAi, reinterpret_cast<void *>(n_aiChooseMove)),
            makeMethod(b17, b18, nBoard, sBoard, reinterpret_cast<void *>(n_getBoardState)),
            makeMethod(b19, b20, nTrace, sTrace, reinterpret_cast<void *>(n_isBeingTraced)),
            makeMethod(b21, b22, nPoison, sPoison, reinterpret_cast<void *>(n_poison)),
            makeMethod(b23, b24, nAttVal, sAttVal, reinterpret_cast<void *>(n_attestValidate)),
            makeMethod(b25, b26, nAttPin, sAttPin, reinterpret_cast<void *>(n_attestPin)),
            makeMethod(b27, b28, nAttMark, sAttMark, reinterpret_cast<void *>(n_attestMarkOk)),
            makeMethod(b29, b30, nAttTick, sAttTick, reinterpret_cast<void *>(n_attestTick)),
            makeMethod(b31, b32, nAttPsn, sAttPsn, reinterpret_cast<void *>(n_attestPoison)),
            makeMethod(b33, b34, nAttPsnQ, sAttPsnQ, reinterpret_cast<void *>(n_attestPoisoned)),
            makeMethod(b35, b36, nDecoyP, sDecoyP, reinterpret_cast<void *>(n_decoyProbe)),
            makeMethod(b37, b38, nDecoyL, sDecoyL, reinterpret_cast<void *>(n_decoyLicense)),
            makeMethod(b39, b40, nDecoyE, sDecoyE, reinterpret_cast<void *>(n_decoyEnvClear)),
    };

    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != JNI_OK) {
        return JNI_ERR;
    }

    return JNI_VERSION_1_6;
}
