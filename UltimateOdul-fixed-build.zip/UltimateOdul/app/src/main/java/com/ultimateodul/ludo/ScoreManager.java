package com.ultimateodul.ludo;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Local Odul stats + player preferences.
 * Online sync still requires dual attestation on the Worker.
 */
public final class ScoreManager {

    private static final String PREFS_NAME = "ultimate_odul_prefs";
    private static final String KEY_WINS_PREFIX = "wins_player_";
    private static final String KEY_GAMES_PLAYED = "games_played";
    private static final String KEY_CAPTURES = "captures_total";
    private static final String KEY_PLAYER_NAME = "player_name";
    private static final String KEY_SOUND = "sound_enabled";
    private static final String KEY_LAST_RESULT = "last_result";
    private static final String KEY_STREAK = "win_streak";
    private static final String KEY_BEST_STREAK = "best_streak";

    private final SharedPreferences prefs;

    public ScoreManager(Context context) {
        this.prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void recordWin(int playerIndex) {
        SharedPreferences.Editor editor = prefs.edit();
        String key = KEY_WINS_PREFIX + playerIndex;
        editor.putInt(key, prefs.getInt(key, 0) + 1);
        editor.putInt(KEY_GAMES_PLAYED, prefs.getInt(KEY_GAMES_PLAYED, 0) + 1);
        if (playerIndex == 0) {
            int streak = prefs.getInt(KEY_STREAK, 0) + 1;
            editor.putInt(KEY_STREAK, streak);
            int best = prefs.getInt(KEY_BEST_STREAK, 0);
            if (streak > best) editor.putInt(KEY_BEST_STREAK, streak);
            editor.putString(KEY_LAST_RESULT, "WIN");
        } else {
            editor.putInt(KEY_STREAK, 0);
            editor.putString(KEY_LAST_RESULT, "LOSS");
        }
        editor.apply();
    }

    public void recordCapture() {
        prefs.edit().putInt(KEY_CAPTURES, prefs.getInt(KEY_CAPTURES, 0) + 1).apply();
    }

    public int getWins(int playerIndex) {
        return prefs.getInt(KEY_WINS_PREFIX + playerIndex, 0);
    }

    public int getGamesPlayed() {
        return prefs.getInt(KEY_GAMES_PLAYED, 0);
    }

    public int getCaptures() {
        return prefs.getInt(KEY_CAPTURES, 0);
    }

    public int getWinStreak() {
        return prefs.getInt(KEY_STREAK, 0);
    }

    public int getBestStreak() {
        return prefs.getInt(KEY_BEST_STREAK, 0);
    }

    public String getLastResult() {
        return prefs.getString(KEY_LAST_RESULT, "—");
    }

    public String getPlayerName() {
        String n = prefs.getString(KEY_PLAYER_NAME, "Commander");
        if (n == null || n.trim().length() < 2) return "Commander";
        return n.trim();
    }

    public void setPlayerName(String name) {
        if (name == null) return;
        String n = name.trim();
        if (n.length() < 2) n = "Commander";
        if (n.length() > 24) n = n.substring(0, 24);
        prefs.edit().putString(KEY_PLAYER_NAME, n).apply();
    }

    public boolean isSoundEnabled() {
        return prefs.getBoolean(KEY_SOUND, true);
    }

    public void setSoundEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_SOUND, enabled).apply();
    }

    public void resetStats() {
        boolean sound = isSoundEnabled();
        String name = getPlayerName();
        prefs.edit().clear().apply();
        setSoundEnabled(sound);
        setPlayerName(name);
    }
}
