package com.ultimateodul.ludo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Odul online phase client — talks only to the dedicated odul-online-v1 Worker.
 * Does not touch system-killer or other existing backends.
 * Score submits require X-Odul-Attest = pinned cert SHA-256.
 */
object OdulOnline {

    private const val BASE = "https://odul-online-v1.cark4-sk.workers.dev"
    private val io = Executors.newSingleThreadExecutor()

    data class Entry(val name: String, val wins: Int, val matches: Int, val rank: Int = 0)

    fun fetchLeaderboard(limit: Int = 20, onResult: (Result<List<Entry>>) -> Unit) {
        io.execute {
            try {
                val conn = (URL("$BASE/leaderboard?limit=$limit").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 12000
                    readTimeout = 12000
                }
                val code = conn.responseCode
                val body = readBody(conn)
                if (code !in 200..299) {
                    onResult(Result.failure(RuntimeException("HTTP $code")))
                    return@execute
                }
                val root = JSONObject(body)
                val arr = root.optJSONArray("leaderboard") ?: JSONArray()
                val list = ArrayList<Entry>(arr.length())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        Entry(
                            name = o.optString("name"),
                            wins = o.optInt("wins"),
                            matches = o.optInt("matches"),
                            rank = i + 1
                        )
                    )
                }
                onResult(Result.success(list))
            } catch (t: Throwable) {
                onResult(Result.failure(t))
            }
        }
    }

    fun submitScore(
        context: Context,
        name: String,
        wins: Int,
        matches: Int,
        onResult: (Result<Entry>) -> Unit
    ) {
        io.execute {
            try {
                val attest256 = SignatureGuard.currentSigningCertSha256(context)
                    ?: throw RuntimeException("no_cert")
                val attest1 = SignatureGuard.currentSigningCertSha1(context) ?: ""
                val payload = JSONObject()
                    .put("name", name)
                    .put("wins", wins)
                    .put("matches", matches)
                val conn = (URL("$BASE/score").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 12000
                    readTimeout = 12000
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("X-Odul-Attest", attest256)
                    if (attest1.isNotEmpty()) {
                        setRequestProperty("X-Odul-Attest-Sha1", attest1)
                    }
                }
                OutputStreamWriter(conn.outputStream).use { it.write(payload.toString()) }
                val code = conn.responseCode
                val body = readBody(conn)
                if (code !in 200..299) {
                    onResult(Result.failure(RuntimeException("HTTP $code $body")))
                    return@execute
                }
                val root = JSONObject(body)
                val e = root.getJSONObject("entry")
                onResult(
                    Result.success(
                        Entry(
                            name = e.optString("name"),
                            wins = e.optInt("wins"),
                            matches = e.optInt("matches"),
                            rank = root.optInt("rank")
                        )
                    )
                )
            } catch (t: Throwable) {
                onResult(Result.failure(t))
            }
        }
    }

    private fun readBody(conn: HttpURLConnection): String {
        val stream = try {
            if (conn.responseCode >= 400) conn.errorStream else conn.inputStream
        } catch (_: Throwable) {
            conn.inputStream
        } ?: return ""
        return BufferedReader(InputStreamReader(stream)).use { it.readText() }
    }
}
