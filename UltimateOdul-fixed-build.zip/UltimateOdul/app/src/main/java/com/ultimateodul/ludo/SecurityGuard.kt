package com.ultimateodul.ludo

import android.app.Activity
import android.os.Debug
import android.os.Handler
import android.os.Looper
import kotlin.random.Random

/**
 * Aggressive multi-stage integrity orchestrator.
 * Hard signals → silent poison + delayed multi-path process death.
 * Soft signals only mark environmentSuspicious.
 *
 * After R8 this class and all its members become Odul* names.
 */
object SecurityGuard {

    @Volatile
    var environmentSuspicious: Boolean = false
        private set

    @Volatile
    private var alreadyResponding = false

    fun verifyOrRespond(activity: Activity, engine: NativeBridge): Boolean {
        if (BuildConfig.DEBUG) return true
        if (alreadyResponding) return false

        environmentSuspicious = IntegrityChecks.looksRooted() ||
            IntegrityChecks.looksLikeEmulator() ||
            IntegrityChecks.looksSideloaded(activity)

        val hard = Debug.isDebuggerConnected() ||
            safe { engine.isBeingTraced() } ||
            safe { IntegrityChecks.looksFridaAttached() } ||
            safe { IntegrityChecks.hasInstrumentationArtifacts() } ||
            safe { IntegrityChecks.isDebuggable(activity) } ||
            !SignatureGuard.isSignatureValid(activity)

        if (hard) {
            respond(activity, engine)
            return false
        }
        return true
    }

    private fun respond(activity: Activity, engine: NativeBridge) {
        alreadyResponding = true

        // Stage 1 — silent poison (engine still looks alive)
        try { engine.poison() } catch (_: Throwable) {}

        // Stage 2 — randomized delay then several independent kill paths
        val delay = Random.nextLong(800L, 2400L)
        Handler(Looper.getMainLooper()).postDelayed({
            // Path A
            try { activity.finishAffinity() } catch (_: Throwable) {}
            // Path B
            try { activity.finishAndRemoveTask() } catch (_: Throwable) {}
            // Path C
            try { Runtime.getRuntime().exit(0) } catch (_: Throwable) {}
            // Path D
            try {
                android.os.Process.killProcess(android.os.Process.myPid())
            } catch (_: Throwable) {}
            // Path E — last resort
            try {
                System.exit(0)
            } catch (_: Throwable) {}
        }, delay)
    }

    private inline fun safe(block: () -> Boolean): Boolean =
        try { block() } catch (_: Throwable) { false }
}
