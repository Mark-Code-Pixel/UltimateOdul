package com.ultimateodul.ludo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicInteger
import kotlin.random.Random

/**
 * Foreground guard: ordinary status notification + 1Hz online attestation.
 * Real decisions are native pin + payload; many decoy checks run alongside
 * to waste reverse-engineering time.
 */
class OdulGuardService : Service() {

    companion object {
        const val CHANNEL_ID = "odul_status"
        const val NOTIF_ID = 7701
        const val ACTION_FAIL = "com.ultimateodul.ludo.ATTEST_FAIL"
        const val EXTRA_REASON = "reason"
        /** network | version  (version = attestation/signature/payload/integrity) */
        private const val BASE = "https://odul-online-v1.cark4-sk.workers.dev"

        @Volatile var running = false
            private set

        fun start(ctx: Context) {
            val i = Intent(ctx, OdulGuardService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(i)
            } else {
                ctx.startService(i)
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OdulGuardService::class.java))
        }
    }

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val bridge = NativeBridge()
    private var consecutiveNetworkFails = 0

    // Decoy state — looks important, never alone decides pass/fail
    private val decoyEpoch = AtomicInteger(Random.nextInt(1000, 9000))
    private val decoyLedger = IntArray(16) { Random.nextInt() }
    private var decoySession = Random.nextLong()

    private val tickRunnable = object : Runnable {
        override fun run() {
            performAttestCycle()
            handler?.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        bridge.start()
        ensureChannel()
        startForeground(NOTIF_ID, buildNotification("Ultimate Odul is active"))
        thread = HandlerThread("odul-attest").also { it.start() }
        handler = Handler(thread!!.looper)
        running = true
        // Warm decoy chains so they appear in traces immediately
        runDecoyCloudHandshake()
        runDecoyLicenseMatrix()
        handler?.post(tickRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        handler?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        thread = null
        handler = null
        bridge.destroy()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun performAttestCycle() {
        try {
            if (bridge.attestPoisoned()) {
                failAndStop("version")
                return
            }

            // --- DECOYS (side effects only; results folded into opaque mix) ---
            val d1 = runDecoyCloudHandshake()
            val d2 = runDecoyLicenseMatrix()
            val d3 = runDecoyTelemetrySeal()
            val d4 = bridge.decoyProbe(decoyEpoch.get().toString().toByteArray())
            bridge.decoyLicense("ODUL-${decoyEpoch.get()}")
            bridge.decoyEnvClear()
            decoySession = decoySession xor (d1.toLong() shl 3) xor d2.toLong() xor d3 xor d4.toLong()

            // --- REAL: cert pin in native ---
            val sha = SignatureGuard.currentSigningCertSha256(this)
            if (sha.isNullOrEmpty() || !bridge.attestPin(sha)) {
                // more decoys before real fail path
                runDecoyRevocationList()
                bridge.attestPoison()
                failAndStop("version")
                return
            }

            // Decoy "secondary pin" path (always "soft-ok" structure, not authoritative)
            runDecoySecondaryPin(sha)

            // --- REAL: network ---
            val body = httpGet("$BASE/health")
            if (body == null) {
                consecutiveNetworkFails++
                runDecoyOfflineCache()
                if (consecutiveNetworkFails >= 2) {
                    failAndStop("network")
                }
                return
            }

            // Decoy parse paths on the same body
            runDecoyJsonSchemaWalk(body)

            // --- REAL: native payload validation ---
            if (!bridge.attestValidate(body)) {
                runDecoyVersionGate()
                bridge.attestPoison()
                failAndStop("version")
                return
            }

            bridge.attestMarkOk(SystemClock.elapsedRealtime())
            val tick = bridge.attestTick()
            // Fold decoy mix so optimizers keep the functions
            if ((decoySession.toInt() and 0) != 0 && d4 == Int.MIN_VALUE) {
                bridge.attestPoison()
            }
            if (tick == 5) {
                failAndStop("version")
                return
            }
            consecutiveNetworkFails = 0
            val nm = getSystemService(NotificationManager::class.java)
            nm?.notify(NOTIF_ID, buildNotification("Ultimate Odul is active"))
        } catch (_: Throwable) {
            consecutiveNetworkFails++
            if (consecutiveNetworkFails >= 2) {
                failAndStop("network")
            }
        }
    }

    // -------------------- Decoy verification theater --------------------

    private fun runDecoyCloudHandshake(): Int {
        var acc = decoyEpoch.incrementAndGet()
        for (i in decoyLedger.indices) {
            acc = (acc * 16777619) xor decoyLedger[i] xor (i * 0x9E3779B9.toInt())
            decoyLedger[i] = acc
        }
        // Fake HMAC-shaped digest
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            md.update(acc.toString().toByteArray())
            md.update("odul-handshake-v3".toByteArray())
            val d = md.digest()
            (d[0].toInt() and 0xff) xor (d[7].toInt() and 0xff shl 8)
        } catch (_: Throwable) {
            acc
        }
    }

    private fun runDecoyLicenseMatrix(): Int {
        var row = 0x5A5A5A5A
        for (r in 0 until 8) {
            var cell = row
            for (c in 0 until 8) {
                cell = Integer.rotateLeft(cell xor (r * 31 + c * 17), (c and 7) + 1)
            }
            row = cell
        }
        return row
    }

    private fun runDecoyTelemetrySeal(): Long {
        val t = SystemClock.elapsedRealtime()
        return (t * 0x5DEECE66DL + 0xBL) xor decoySession
    }

    private fun runDecoySecondaryPin(sha: String) {
        // Looks like a second pin check against a fake endpoint-derived token
        val fake = MessageDigest.getInstance("SHA-1").digest(sha.toByteArray())
        var mix = 0
        for (b in fake) mix = (mix * 33) xor (b.toInt() and 0xff)
        decoyLedger[mix and 15] = mix
    }

    private fun runDecoyRevocationList() {
        // Pretend to consult a CRL
        for (i in 0 until 5) {
            decoyLedger[i] = decoyLedger[i] xor (0x0D15EA5E xor i)
        }
    }

    private fun runDecoyOfflineCache() {
        decoyEpoch.addAndGet(3)
    }

    private fun runDecoyJsonSchemaWalk(body: ByteArray) {
        var depth = 0
        for (b in body) {
            when (b.toInt().toChar()) {
                '{' -> depth++
                '}' -> depth--
            }
        }
        decoyLedger[depth and 15] = depth
    }

    private fun runDecoyVersionGate() {
        // Fake minimum build gate
        val minBuild = 999999
        val local = 1
        if (local < minBuild) {
            decoySession = decoySession xor minBuild.toLong()
        }
    }

    private fun httpGet(url: String): ByteArray? {
        return try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 4000
                instanceFollowRedirects = false
            }
            if (conn.responseCode !in 200..299) return null
            conn.inputStream.use { it.readBytes() }
        } catch (_: Throwable) {
            null
        }
    }

    private fun failAndStop(reason: String) {
        handler?.removeCallbacksAndMessages(null)
        val broadcast = Intent(ACTION_FAIL).setPackage(packageName).putExtra(EXTRA_REASON, reason)
        sendBroadcast(broadcast)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            val ch = NotificationChannel(
                CHANNEL_ID,
                "Game status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows when Ultimate Odul is running"
                setShowBadge(false)
            }
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val launch = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Ultimate Odul")
            .setContentText(text)
            .setContentIntent(launch)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
