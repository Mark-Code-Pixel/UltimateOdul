package com.ultimateodul.ludo

/**
 * Thin Kotlin wrapper around the native engine (libludoengine.so), which is
 * itself built from dice_native.c (C) + ludo_logic.cpp / jni_bridge.cpp (C++).
 *
 * The .so is compiled for armeabi-v7a, x86 (32-bit) and arm64-v8a, x86_64
 * (64-bit) — System.loadLibrary picks the correct variant for the running
 * device automatically, so this class never needs to know which one it is.
 */
class NativeBridge {

    private var handle: Long = 0L

    companion object {
        init {
            System.loadLibrary("ludoengine")
        }
    }

    fun start() {
        handle = nativeInit()
    }

    fun destroy() {
        if (handle != 0L) {
            nativeDestroy(handle)
            handle = 0L
        }
    }

    fun resetGame() = nativeResetGame(handle)

    fun rollDice(): Int = nativeRollDice(handle)

    fun getValidMoves(player: Int, diceValue: Int): IntArray =
        nativeGetValidMoves(handle, player, diceValue)

    fun movePawn(player: Int, pawn: Int, diceValue: Int): MoveOutcome {
        val r = nativeMovePawn(handle, player, pawn, diceValue)
        return MoveOutcome(
            legal = r[0] == 1,
            newStep = r[1],
            captured = r[2] == 1,
            capturedPlayer = r[3],
            capturedPawn = r[4],
            extraTurn = r[5] == 1,
            pawnFinished = r[6] == 1,
            playerWon = r[7] == 1
        )
    }

    fun checkWin(player: Int): Boolean = nativeCheckWin(handle, player)

    fun aiChooseMove(player: Int, diceValue: Int): Int = nativeAiChooseMove(handle, player, diceValue)

    /** Flattened board: index = player * 4 + pawn -> step (-1 yard, 0-50 track, 51-56 home column/finish). */
    fun getBoardState(): IntArray = nativeGetBoardState(handle)

    /** True if a debugger/tracer appears attached to this process (see anti_tamper.cpp). */
    fun isBeingTraced(): Boolean = nativeIsBeingTraced()

    /**
     * Silently disables further legitimate play (see LudoEngine::poison in
     * ludo_logic.h) instead of crashing or exiting outright -- see
     * SecurityGuard.kt for why a quiet stall is the preferred response.
     */
    fun poison() = nativePoison(handle)

    // NOTE ON OBFUSCATION: this class's fully-qualified name and every
    // `external fun` below are deliberately kept un-renamed by
    // proguard-rules.pro. That's not a gap in the hardening -- it's a
    // hard requirement: jni_bridge.cpp resolves these methods at runtime
    // via RegisterNatives() using a hardcoded class path + these exact
    // (name, signature) pairs (XOR-encoded in the .so, decoded at load
    // time). Renaming either side without the other breaks native
    // linkage at startup. Every other class/method/field in the app --
    // including this class's own non-native helper methods above -- is
    // freely renamed by R8.
    private external fun nativeInit(): Long
    private external fun nativeDestroy(handle: Long)
    private external fun nativeResetGame(handle: Long)
    private external fun nativeRollDice(handle: Long): Int
    private external fun nativeGetValidMoves(handle: Long, player: Int, diceValue: Int): IntArray
    private external fun nativeMovePawn(handle: Long, player: Int, pawn: Int, diceValue: Int): IntArray
    private external fun nativeCheckWin(handle: Long, player: Int): Boolean
    private external fun nativeAiChooseMove(handle: Long, player: Int, diceValue: Int): Int
    private external fun nativeGetBoardState(handle: Long): IntArray
    private external fun nativeIsBeingTraced(): Boolean
    private external fun nativePoison(handle: Long)
}

data class MoveOutcome(
    val legal: Boolean,
    val newStep: Int,
    val captured: Boolean,
    val capturedPlayer: Int,
    val capturedPawn: Int,
    val extraTurn: Boolean,
    val pawnFinished: Boolean,
    val playerWon: Boolean
)
