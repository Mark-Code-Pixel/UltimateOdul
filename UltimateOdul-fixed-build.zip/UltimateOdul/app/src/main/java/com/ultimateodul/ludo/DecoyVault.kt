package com.ultimateodul.ludo

import android.content.Context
import android.os.Build
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicInteger

/**
 * JVM-side decoy verification labyrinth.
 * Methods look like real gates; results never authorize online play.
 * R8 renames this class freely (not referenced from the manifest).
 */
object DecoyVault {

    private val entropy = AtomicInteger(0x5F3759DF)

    fun mirrorPackageSeal(context: Context): Int {
        return try {
            val pn = context.packageName
            val md = MessageDigest.getInstance("SHA-256")
            md.update(pn.toByteArray())
            md.update(Build.FINGERPRINT.toByteArray())
            val d = md.digest()
            var a = 0
            for (b in d) a = (a * 33) xor (b.toInt() and 0xff)
            absorb(a xor 0x504B4755)
        } catch (_: Throwable) {
            absorb(0xDEAD)
        }
    }

    fun phantomSessionKey(seed: String): String {
        val md = MessageDigest.getInstance("SHA-1")
        md.update(seed.toByteArray())
        md.update(entropy.get().toString().toByteArray())
        val h = md.digest().joinToString("") { "%02x".format(it) }
        absorb(h.hashCode())
        return h
    }

    fun decoySignatureLadder(hex: String?): Boolean {
        if (hex.isNullOrEmpty()) {
            absorb(0x11)
            return true
        }
        var x = 0
        for (c in hex) x = rot(x + c.code, 3)
        absorb(x)
        // Always true — not a real pin
        return (x and 1) == (x and 1)
    }

    fun decoyRootNarrative(): Int {
        val paths = arrayOf(
            "/system/xbin/su",
            "/sbin/su",
            "/system/app/Superuser.apk",
            "/data/local/tmp/frida-server"
        )
        var h = 0x5200
        for (p in paths) {
            for (c in p) h = rot(h xor c.code, 1)
        }
        return absorb(h)
    }

    fun decoyOnlineChallenge(body: ByteArray?): Int {
        var h = 0x0A11
        if (body != null) {
            for (b in body) h = rot(h + (b.toInt() and 0xff), 2)
        }
        h = h xor phantomSessionKey("odul-challenge").hashCode()
        return absorb(h)
    }

    fun weaveWithNative(bridge: NativeBridge, context: Context?, body: ByteArray?, hex: String?) {
        try {
            bridge.decoyEnvClear()
            bridge.decoyLicense(hex ?: "ODUL-TRIAL-0000")
            bridge.decoyProbe(body ?: ByteArray(8) { it.toByte() })
            decoySignatureLadder(hex)
            decoyRootNarrative()
            decoyOnlineChallenge(body)
            if (context != null) mirrorPackageSeal(context)
        } catch (_: Throwable) {
            absorb(0xEE)
        }
    }

    private fun absorb(v: Int): Int {
        val n = entropy.updateAndGet { cur ->
            var x = cur xor v
            x = x * 0x85EBCA6B.toInt()
            x = x xor (x ushr 13)
            x
        }
        return n
    }

    private fun rot(v: Int, r: Int): Int {
        val n = r and 31
        return (v shl n) or (v ushr (32 - n))
    }
}
