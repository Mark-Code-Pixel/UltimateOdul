package com.ultimateodul.ludo

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * Launcher Activity (name pinned by the manifest).
 * Odul splash → combat menu → match flow.
 */
class MainActivity : AppCompatActivity() {

    private var core: GameCore? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var guardReceiver: BroadcastReceiver? = null

    private lateinit var splashPanel: View
    private lateinit var menuPanel: View
    private lateinit var gamePanel: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        splashPanel = findViewById(R.id.splashPanel)
        menuPanel = findViewById(R.id.menuPanel)
        gamePanel = findViewById(R.id.gamePanel)

        registerGuardReceiver()
        OdulGuardService.start(this)

        bindMenu()
        showSplashThenMenu()
    }

    private fun showSplashThenMenu() {
        splashPanel.visibility = View.VISIBLE
        menuPanel.visibility = View.GONE
        gamePanel.visibility = View.GONE

        val title = findViewById<TextView>(R.id.splashTitle)
        val tag = findViewById<TextView>(R.id.splashTagline)
        title.alpha = 0f
        title.scaleX = 0.82f
        title.scaleY = 0.82f
        tag.alpha = 0f

        title.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(650)
            .setInterpolator(OvershootInterpolator(1.15f))
            .start()
        tag.animate().alpha(1f).setStartDelay(280).setDuration(480).start()

        mainHandler.postDelayed({
            splashPanel.animate()
                .alpha(0f)
                .setDuration(340)
                .withEndAction {
                    splashPanel.visibility = View.GONE
                    splashPanel.alpha = 1f
                    showMenu()
                }
                .start()
        }, 1550)
    }

    private fun bindMenu() {
        val buttons = listOf(
            R.id.btnPlay, R.id.btnHow, R.id.btnStats, R.id.btnOnline, R.id.btnSettings, R.id.btnAbout, R.id.btnExit
        )
        buttons.forEach { id ->
            findViewById<View>(id).setOnTouchListener { v, e ->
                when (e.action) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
                    }
                    android.view.MotionEvent.ACTION_UP,
                    android.view.MotionEvent.ACTION_CANCEL -> {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    }
                }
                false
            }
        }

        findViewById<View>(R.id.btnPlay).setOnClickListener { startMatch() }
        findViewById<View>(R.id.btnHow).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.how_title)
                .setMessage(R.string.how_body)
                .setPositiveButton(R.string.ok, null)
                .show()
        }
        findViewById<View>(R.id.btnStats).setOnClickListener { showStats() }
        findViewById<View>(R.id.btnOnline).setOnClickListener { showOnlineBoard() }
        findViewById<View>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<View>(R.id.btnAbout).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.about_title)
                .setMessage(R.string.about_body)
                .setPositiveButton(R.string.ok, null)
                .show()
        }
        findViewById<View>(R.id.btnExit).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.exit_confirm)
                .setPositiveButton(R.string.yes) { _, _ -> finishAffinity() }
                .setNegativeButton(R.string.no, null)
                .show()
        }
        findViewById<View>(R.id.btnMenu).setOnClickListener { returnToMenu() }
    }

    private fun showMenu() {
        refreshMenuStats()
        menuPanel.alpha = 0f
        menuPanel.translationY = 28f
        menuPanel.visibility = View.VISIBLE
        gamePanel.visibility = View.GONE
        menuPanel.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(360)
            .setInterpolator(DecelerateInterpolator())
            .start()

        // Stagger menu buttons for a heavier entrance
        val ids = intArrayOf(R.id.btnPlay, R.id.btnHow, R.id.btnStats, R.id.btnOnline, R.id.btnSettings, R.id.btnAbout, R.id.btnExit)
        ids.forEachIndexed { index, id ->
            val btn = findViewById<View>(id)
            btn.alpha = 0f
            btn.translationY = 18f
            btn.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(80L + index * 55L)
                .setDuration(280)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    private fun refreshMenuStats() {
        val stats = ScoreManager(this)
        findViewById<TextView>(R.id.menuGamesPlayed).text =
            getString(R.string.games_played_fmt, stats.gamesPlayed)
    }

    private fun showStats() {
        val stats = ScoreManager(this)
        val body = getString(
            R.string.stats_body_v2,
            stats.gamesPlayed,
            stats.getWins(0),
            stats.getWins(1),
            stats.getWins(2),
            stats.getWins(3),
            stats.captures,
            stats.winStreak,
            stats.bestStreak,
            stats.lastResult
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.stats_title)
            .setMessage(body)
            .setPositiveButton(R.string.ok, null)
            .setNeutralButton(R.string.reset_stats) { _, _ ->
                stats.resetStats()
                refreshMenuStats()
            }
            .show()
    }


    private fun showOnlineBoard() {
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.online_title)
            .setMessage(R.string.online_loading)
            .setPositiveButton(R.string.ok, null)
            .setNeutralButton(R.string.online_sync, null)
            .create()
        dialog.setOnShowListener {
            val syncBtn = dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
            syncBtn.setOnClickListener {
                dialog.setMessage(getString(R.string.online_loading))
                val stats = ScoreManager(this)
                OdulOnline.submitScore(
                    this,
                    stats.playerName,
                    stats.getWins(0),
                    stats.gamesPlayed
                ) { result ->
                    runOnUiThread {
                        result.fold(
                            onSuccess = { e ->
                                dialog.setMessage(getString(R.string.online_synced, e.rank))
                                // refresh board after sync
                                reloadLeaderboard(dialog)
                            },
                            onFailure = {
                                dialog.setMessage(getString(R.string.online_error))
                            }
                        )
                    }
                }
            }
            reloadLeaderboard(dialog)
        }
        dialog.show()
    }

    private fun reloadLeaderboard(dialog: AlertDialog) {
        OdulOnline.fetchLeaderboard { result ->
            runOnUiThread {
                result.fold(
                    onSuccess = { list ->
                        if (list.isEmpty()) {
                            dialog.setMessage(getString(R.string.online_empty))
                        } else {
                            val sb = StringBuilder()
                            list.forEach { e ->
                                sb.append("#${e.rank}  ${e.name}  —  ${e.wins}W / ${e.matches}M\n")
                            }
                            dialog.setMessage(sb.toString().trim())
                        }
                    },
                    onFailure = {
                        dialog.setMessage(getString(R.string.online_error))
                    }
                )
            }
        }
    }


    private fun showSettings() {
        val stats = ScoreManager(this)
        val nameInput = android.widget.EditText(this).apply {
            setText(stats.playerName)
            hint = getString(R.string.name_hint)
            setSingleLine()
        }
        val soundOn = stats.isSoundEnabled
        val soundLabel = if (soundOn) getString(R.string.settings_sound_on) else getString(R.string.settings_sound_off)
        AlertDialog.Builder(this)
            .setTitle(R.string.settings_title)
            .setMessage(soundLabel + "\n\n" + getString(R.string.settings_name))
            .setView(nameInput)
            .setPositiveButton(R.string.ok) { _, _ ->
                stats.setPlayerName(nameInput.text?.toString() ?: stats.playerName)
                android.widget.Toast.makeText(this, R.string.settings_saved, android.widget.Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton(if (soundOn) R.string.settings_sound_off else R.string.settings_sound_on) { _, _ ->
                stats.setSoundEnabled(!soundOn)
                showSettings()
            }
            .setNegativeButton(R.string.back_to_menu, null)
            .show()
    }

    private fun startMatch() {
        core?.stop()
        core = null

        menuPanel.visibility = View.GONE
        gamePanel.alpha = 0f
        gamePanel.scaleX = 0.97f
        gamePanel.scaleY = 0.97f
        gamePanel.visibility = View.VISIBLE
        gamePanel.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(320)
            .setInterpolator(DecelerateInterpolator())
            .start()

        findViewById<android.widget.FrameLayout>(R.id.boardHost).removeAllViews()
        core = GameCore(this).also { it.start() }
    }

    fun returnToMenuPublic() {
        returnToMenu()
    }

    private fun returnToMenu() {
        core?.stop()
        core = null
        findViewById<android.widget.FrameLayout>(R.id.boardHost).removeAllViews()
        gamePanel.visibility = View.GONE
        showMenu()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            gamePanel.visibility == View.VISIBLE -> {
                val nowPaused = core?.togglePause() ?: true
                if (nowPaused) {
                    AlertDialog.Builder(this)
                        .setTitle(R.string.pause_title)
                        .setPositiveButton(R.string.pause_resume) { _, _ ->
                            core?.togglePause()
                        }
                        .setNegativeButton(R.string.pause_menu) { _, _ -> returnToMenu() }
                        .setCancelable(false)
                        .show()
                }
            }
            menuPanel.visibility == View.VISIBLE -> {
                AlertDialog.Builder(this)
                    .setTitle(R.string.exit_confirm)
                    .setPositiveButton(R.string.yes) { _, _ -> finishAffinity() }
                    .setNegativeButton(R.string.no, null)
                    .show()
            }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        try { OdulGuardService.stop(this) } catch (_: Throwable) {}
        try { guardReceiver?.let { unregisterReceiver(it) } } catch (_: Throwable) {}
        guardReceiver = null
        core?.stop()
        core = null
        super.onDestroy()
    }

    private fun registerGuardReceiver() {
        guardReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action != OdulGuardService.ACTION_FAIL) return
                val reason = intent.getStringExtra(OdulGuardService.EXTRA_REASON) ?: "network"
                showGuardFailureAndExit(reason)
            }
        }
        val filter = IntentFilter(OdulGuardService.ACTION_FAIL)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(guardReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(guardReceiver, filter)
        }
    }

    private fun showGuardFailureAndExit(reason: String) {
        try { core?.stop() } catch (_: Throwable) {}
        core = null
        try { OdulGuardService.stop(this) } catch (_: Throwable) {}
        val isNetwork = reason == "network"
        AlertDialog.Builder(this)
            .setTitle(if (isNetwork) R.string.internet_required_title else R.string.version_blocked_title)
            .setMessage(if (isNetwork) R.string.internet_required_body else R.string.version_blocked_body)
            .setCancelable(false)
            .setPositiveButton(R.string.internet_required_ok) { _, _ ->
                finishAffinity()
            }
            .show()
    }

    override fun onResume() {
        super.onResume()
        core?.recheckIntegrity()
    }
}
