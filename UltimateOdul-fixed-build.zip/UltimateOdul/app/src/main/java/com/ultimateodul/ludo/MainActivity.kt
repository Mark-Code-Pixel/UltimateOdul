package com.ultimateodul.ludo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Intentionally the only "readable" class in the app.
 *
 * AndroidManifest.xml has to reference an Activity by its exact,
 * unobfuscated fully-qualified name for the OS to launch it, and
 * onCreate/onDestroy are framework-overridden methods R8 cannot rename
 * without breaking the Activity lifecycle contract. Both of those are
 * platform requirements, not a hardening gap: everything this class
 * actually DOES is delegated straight to GameCore, which -- along with
 * every other class in the app except NativeBridge (see the note there)
 * -- is freely renamed and repackaged by R8's obfuscation pass.
 */
class MainActivity : AppCompatActivity() {

    private var core: GameCore? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        core = GameCore(this).also { it.start() }
    }

    override fun onDestroy() {
        core?.stop()
        core = null
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        core?.recheckIntegrity()
    }
}
