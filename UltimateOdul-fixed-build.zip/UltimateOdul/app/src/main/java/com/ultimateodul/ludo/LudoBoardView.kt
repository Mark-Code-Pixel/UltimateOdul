package com.ultimateodul.ludo

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import kotlin.math.min

/**
 * Renders the full board every frame from a flat 16-int board state
 * (player*4+pawn -> step), exactly as produced by NativeBridge.getBoardState().
 *
 * Visual language: dark glass board, neon per-player gradients, glowing
 * gold star/safe cells, glossy radial-gradient pawns with drop shadows,
 * and spring-eased animated slides between cells instead of instant jumps.
 */
class LudoBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        val PLAYER_CORE = intArrayOf(
            Color.parseColor("#FF3B5C"),
            Color.parseColor("#22E08B"),
            Color.parseColor("#FFD23F"),
            Color.parseColor("#3FA9FF")
        )
        val PLAYER_GLOW = intArrayOf(
            Color.parseColor("#FF8FA3"),
            Color.parseColor("#8CFFCB"),
            Color.parseColor("#FFF0A8"),
            Color.parseColor("#A8DBFF")
        )
    }

    var onPawnTapped: ((player: Int, pawn: Int) -> Unit)? = null
    var highlightedMoves: Set<Int> = emptySet() // pawn indices of the current player that can legally move
    var currentPlayer: Int = 0

    // displayStep is what's actually drawn; it eases toward targetStep so
    // moves glide across cells instead of teleporting.
    private val targetStep = Array(4) { IntArray(4) { -1 } }
    private val displaySteps = Array(4) { FloatArray(4) { -1f } }
    private var animator: ValueAnimator? = null

    private var cellSize = 0f
    private val boardRect = RectF()

    private val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = Color.parseColor("#3A3260")
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pawnShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#66000000")
    }
    private val pawnPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pawnRimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = Color.parseColor("#FFC94D")
    }
    private val centerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F5F3FF")
        textAlign = Paint.Align.CENTER
    }

    /** pawn tap targets computed fresh each draw so hit-testing matches what's on screen */
    private data class HitTarget(val player: Int, val pawn: Int, val cx: Float, val cy: Float, val r: Float)
    private var hitTargets: List<HitTarget> = emptyList()

    fun updateBoardState(flat: IntArray, animate: Boolean = true) {
        var changed = false
        for (p in 0 until 4) {
            for (w in 0 until 4) {
                val step = flat[p * 4 + w]
                if (targetStep[p][w] != step) {
                    targetStep[p][w] = step
                    changed = true
                    if (!animate || displaySteps[p][w] < -0.5f) {
                        displaySteps[p][w] = step.toFloat()
                    }
                }
            }
        }
        if (changed && animate) startAnimation() else if (changed) invalidate()
    }

    private fun startAnimation() {
        animator?.cancel()
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 420
        anim.interpolator = OvershootInterpolator(0.6f)
        val startSnapshot = Array(4) { p -> displaySteps[p].copyOf() }
        anim.addUpdateListener { va ->
            val t = va.animatedValue as Float
            for (p in 0 until 4) {
                for (w in 0 until 4) {
                    val from = startSnapshot[p][w]
                    val to = targetStep[p][w].toFloat()
                    displaySteps[p][w] = from + (to - from) * t
                }
            }
            invalidate()
        }
        anim.start()
        animator = anim
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val size = min(measuredWidth, measuredHeight)
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val size = min(w, h).toFloat()
        cellSize = size / BoardGeometry.GRID
        boardRect.set(0f, 0f, size, size)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawBoardBase(canvas)
        drawYards(canvas)
        drawTrack(canvas)
        drawHomeColumns(canvas)
        drawCenterTriangle(canvas)
        drawPawns(canvas)
    }

    private fun rc(row: Int, col: Int): FloatArray =
        floatArrayOf(col * cellSize, row * cellSize)

    private fun drawBoardBase(canvas: Canvas) {
        cellPaint.shader = LinearGradient(
            0f, 0f, boardRect.width(), boardRect.height(),
            Color.parseColor("#1A1630"), Color.parseColor("#241E3D"),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(boardRect, 28f, 28f, cellPaint)
    }

    private fun drawYards(canvas: Canvas) {
        for (player in 0 until 4) {
            val origin = BoardGeometry.yardOrigin[player]
            val (row0, col0) = origin[0] to origin[1]
            val left = col0 * cellSize
            val top = row0 * cellSize
            val yardSize = 6 * cellSize
            val rect = RectF(left + 6, top + 6, left + yardSize - 6, top + yardSize - 6)

            cellPaint.shader = RadialGradient(
                rect.centerX(), rect.centerY(), yardSize * 0.75f,
                withAlpha(PLAYER_GLOW[player], 60), withAlpha(PLAYER_CORE[player], 18),
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rect, 22f, 22f, cellPaint)

            // 4 pawn "sockets" so an empty yard doesn't look bare
            for (slot in BoardGeometry.yardSlotOffsets) {
                val cx = left + (slot[1] + 0.5f) * cellSize
                val cy = top + (slot[0] + 0.5f) * cellSize
                glowPaint.shader = null
                glowPaint.color = withAlpha(Color.BLACK, 70)
                canvas.drawCircle(cx, cy, cellSize * 0.34f, glowPaint)
            }
        }
    }

    private fun drawTrack(canvas: Canvas) {
        for (i in 0 until 52) {
            val (row, col) = BoardGeometry.trackCells[i][0] to BoardGeometry.trackCells[i][1]
            val left = col * cellSize
            val top = row * cellSize
            val rect = RectF(left + 1, top + 1, left + cellSize - 1, top + cellSize - 1)

            val isSafe = BoardGeometry.safeCells.contains(i)
            val ownerPlayer = BoardGeometry.startOffset.indexOf(i).let { if (it >= 0) it else -1 }

            cellPaint.shader = null
            cellPaint.color = if (isSafe) withAlpha(Color.parseColor("#FFD700"), 40)
            else Color.parseColor("#2B2447")
            canvas.drawRoundRect(rect, 6f, 6f, cellPaint)

            if (ownerPlayer >= 0) {
                glowPaint.shader = null
                glowPaint.color = withAlpha(PLAYER_CORE[ownerPlayer], 130)
                glowPaint.style = Paint.Style.STROKE
                glowPaint.strokeWidth = 4f
                canvas.drawRoundRect(rect, 6f, 6f, glowPaint)
            }
            canvas.drawRoundRect(rect, 6f, 6f, gridPaint)

            if (isSafe) {
                drawStar(canvas, rect.centerX(), rect.centerY(), cellSize * 0.28f)
            }
        }
    }

    private fun drawHomeColumns(canvas: Canvas) {
        for (player in 0 until 4) {
            for (cellRc in BoardGeometry.homeColumns[player]) {
                val left = cellRc[1] * cellSize
                val top = cellRc[0] * cellSize
                val rect = RectF(left + 1, top + 1, left + cellSize - 1, top + cellSize - 1)
                cellPaint.shader = LinearGradient(
                    rect.left, rect.top, rect.right, rect.bottom,
                    withAlpha(PLAYER_GLOW[player], 220), withAlpha(PLAYER_CORE[player], 220),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRoundRect(rect, 6f, 6f, cellPaint)
            }
        }
    }

    private fun drawCenterTriangle(canvas: Canvas) {
        val cx = (BoardGeometry.CENTER_COL + 0.5f) * cellSize
        val cy = (BoardGeometry.CENTER_ROW + 0.5f) * cellSize
        val r = cellSize * 1.6f
        glowPaint.shader = RadialGradient(
            cx, cy, r, withAlpha(Color.parseColor("#FF6EC7"), 160), withAlpha(Color.parseColor("#FF6EC7"), 0),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, glowPaint)
        centerTextPaint.textSize = cellSize * 0.9f
        centerTextPaint.color = Color.parseColor("#F5F3FF")
        canvas.drawText("★", cx, cy + cellSize * 0.3f, centerTextPaint)
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        centerTextPaint.textSize = radius * 2.1f
        centerTextPaint.color = Color.parseColor("#FFEFA8")
        canvas.drawText("★", cx, cy + radius * 0.7f, centerTextPaint)
    }

    private fun drawPawns(canvas: Canvas) {
        val targets = mutableListOf<HitTarget>()
        val radius = cellSize * 0.36f

        for (player in 0 until 4) {
            for (pawn in 0 until 4) {
                val step = displaySteps[player][pawn]
                val (cx, cy) = pawnCenter(player, pawn, step)

                pawnShadowPaint.let {
                    canvas.drawCircle(cx + 3f, cy + 4f, radius, it)
                }

                pawnPaint.shader = RadialGradient(
                    cx - radius * 0.3f, cy - radius * 0.3f, radius * 1.6f,
                    PLAYER_GLOW[player], PLAYER_CORE[player], Shader.TileMode.CLAMP
                )
                canvas.drawCircle(cx, cy, radius, pawnPaint)

                pawnRimPaint.color = withAlpha(Color.WHITE, 160)
                canvas.drawCircle(cx, cy, radius, pawnRimPaint)

                val isMovable = player == currentPlayer && highlightedMoves.contains(pawn)
                if (isMovable) {
                    highlightPaint.alpha = 220
                    canvas.drawCircle(cx, cy, radius + 6f, highlightPaint)
                }

                targets.add(HitTarget(player, pawn, cx, cy, radius + 10f))
            }
        }
        hitTargets = targets
    }

    private fun pawnCenter(player: Int, pawn: Int, step: Float): Pair<Float, Float> {
        if (step < -0.5f) {
            val origin = BoardGeometry.yardOrigin[player]
            val slot = BoardGeometry.yardSlotOffsets[pawn]
            val cx = (origin[1] + slot[1] + 0.5f) * cellSize
            val cy = (origin[0] + slot[0] + 0.5f) * cellSize
            return cx to cy
        }
        val lower = step.toInt().coerceIn(0, 56)
        val upper = (lower + 1).coerceAtMost(56)
        val frac = step - lower

        val lowerCell = BoardGeometry.cellForStep(player, lower) ?: BoardGeometry.cellForStep(player, 0)!!
        val upperCell = BoardGeometry.cellForStep(player, upper) ?: lowerCell

        val lx = (lowerCell[1] + 0.5f) * cellSize
        val ly = (lowerCell[0] + 0.5f) * cellSize
        val ux = (upperCell[1] + 0.5f) * cellSize
        val uy = (upperCell[0] + 0.5f) * cellSize

        return (lx + (ux - lx) * frac) to (ly + (uy - ly) * frac)
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val x = event.x
            val y = event.y
            for (target in hitTargets) {
                val dx = x - target.cx
                val dy = y - target.cy
                if (dx * dx + dy * dy <= target.r * target.r) {
                    onPawnTapped?.invoke(target.player, target.pawn)
                    return true
                }
            }
        }
        return true
    }
}
