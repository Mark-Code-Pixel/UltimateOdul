package com.ultimateodul.ludo

import android.media.AudioManager
import android.media.ToneGenerator

/**
 * Tiny built-in tones — no media assets, nothing network-related.
 * Respects ScoreManager sound preference.
 */
object OdulAudio {
    @Volatile private var tones: ToneGenerator? = null

    private fun tg(): ToneGenerator? {
        return try {
            tones ?: ToneGenerator(AudioManager.STREAM_MUSIC, 70).also { tones = it }
        } catch (_: Throwable) {
            null
        }
    }

    fun roll(enabled: Boolean) {
        if (!enabled) return
        try { tg()?.startTone(ToneGenerator.TONE_PROP_BEEP, 80) } catch (_: Throwable) {}
    }

    fun capture(enabled: Boolean) {
        if (!enabled) return
        try { tg()?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 120) } catch (_: Throwable) {}
    }

    fun win(enabled: Boolean) {
        if (!enabled) return
        try { tg()?.startTone(ToneGenerator.TONE_CDMA_CONFIRM, 180) } catch (_: Throwable) {}
    }

    fun release() {
        try { tones?.release() } catch (_: Throwable) {}
        tones = null
    }
}
