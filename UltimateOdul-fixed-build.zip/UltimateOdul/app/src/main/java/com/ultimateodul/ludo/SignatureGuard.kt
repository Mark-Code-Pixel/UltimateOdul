package com.ultimateodul.ludo

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/**
 * Verifies the running APK was signed with the expected certificate.
 *
 * SETUP: After you produce a real release APK signed with your keystore,
 * extract the SHA-256 fingerprint and place the lowercase hex (no colons)
 * into EXPECTED_SHA256 below. Until then the check is a no-op so you are
 * not locked out of your own builds.
 *
 * The constant itself is kept as a simple string; R8 will not leave it
 * in cleartext form once the surrounding code is renamed and the class
 * is repackaged. For even stronger hiding you can later split the hex
 * into several XOR-encoded pieces and reassemble at runtime.
 */
object SignatureGuard {

    // TODO: replace with your real release certificate SHA-256 (lowercase, no colons)
    private const val EXPECTED_SHA256 = ""

    fun isSignatureValid(context: Context): Boolean {
        if (EXPECTED_SHA256.isBlank()) return true

        val actual = currentSigningCertSha256(context) ?: return false
        // Constant-time-ish compare to avoid trivial early-out timing oracles
        if (actual.length != EXPECTED_SHA256.length) return false
        var diff = 0
        for (i in actual.indices) {
            diff = diff or (actual[i].code xor EXPECTED_SHA256[i].lowercaseChar().code)
        }
        return diff == 0
    }

    fun currentSigningCertSha256(context: Context): String? {
        return try {
            val pm = context.packageManager
            val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                val signingInfo = info.signingInfo ?: return null
                if (signingInfo.hasMultipleSigners()) {
                    signingInfo.apkContentsSigners
                } else {
                    signingInfo.signingCertificateHistory
                }
            } else {
                @Suppress("DEPRECATION")
                val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
                @Suppress("DEPRECATION")
                info.signatures
            }
            val cert = signatures?.firstOrNull() ?: return null
            val digest = MessageDigest.getInstance("SHA-256").digest(cert.toByteArray())
            digest.joinToString("") { "%02x".format(it) }
        } catch (_: Throwable) {
            null
        }
    }
}
