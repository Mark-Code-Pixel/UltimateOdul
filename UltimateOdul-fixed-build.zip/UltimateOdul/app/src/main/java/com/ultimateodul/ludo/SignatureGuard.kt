package com.ultimateodul.ludo

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/**
 * Online / local attestation: the running APK must be signed with the
 * certificate whose SHA-1 and SHA-256 fingerprints are pinned below.
 *
 * Only fingerprints are stored — never the keystore or private key.
 * Comparison is constant-time-ish to reduce trivial timing oracles.
 * R8 will rename this class/members to Odul* dictionary tokens.
 */
object SignatureGuard {

    // Pinned release cert fingerprints (lowercase hex, no colons)
    private const val EXPECTED_SHA1 =
        "3f87e8f23be637b96e2283416559b1676b5e6a75"
    private const val EXPECTED_SHA256 =
        "7c06908428d491f722cb49c21f183ee04309ef5412fd3a7a136fb09d3ef87c4a"

    fun isSignatureValid(context: Context): Boolean {
        val sha1 = currentSigningCertDigest(context, "SHA-1") ?: return false
        val sha256 = currentSigningCertDigest(context, "SHA-256") ?: return false
        return constantTimeEquals(sha1, EXPECTED_SHA1) &&
            constantTimeEquals(sha256, EXPECTED_SHA256)
    }

    fun currentSigningCertSha256(context: Context): String? =
        currentSigningCertDigest(context, "SHA-256")

    fun currentSigningCertSha1(context: Context): String? =
        currentSigningCertDigest(context, "SHA-1")

    private fun currentSigningCertDigest(context: Context, algorithm: String): String? {
        return try {
            val pm = context.packageManager
            val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNING_CERTIFICATES
                )
                val signingInfo = info.signingInfo ?: return null
                if (signingInfo.hasMultipleSigners()) {
                    signingInfo.apkContentsSigners
                } else {
                    signingInfo.signingCertificateHistory
                }
            } else {
                @Suppress("DEPRECATION")
                val info = pm.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNATURES
                )
                @Suppress("DEPRECATION")
                info.signatures
            }
            val cert = signatures?.firstOrNull() ?: return null
            val digest = MessageDigest.getInstance(algorithm).digest(cert.toByteArray())
            digest.joinToString("") { "%02x".format(it) }
        } catch (_: Throwable) {
            null
        }
    }

    private fun constantTimeEquals(actual: String, expected: String): Boolean {
        if (actual.length != expected.length) return false
        var diff = 0
        for (i in actual.indices) {
            diff = diff or (actual[i].code xor expected[i].code)
        }
        return diff == 0
    }
}
