package com.ultimateodul.ludo

import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build
import java.io.File

object IntegrityChecks {

    private val ROOT_PATHS = arrayOf(
        "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su",
        "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su",
        "/system/bin/failsafe/su", "/data/local/su", "/su/bin/su",
        "/system/xbin/busybox", "/data/adb/magisk", "/sbin/.magisk",
        "/data/adb/modules", "/system/app/Magisk"
    )

    fun looksRooted(): Boolean {
        if (Build.TAGS?.contains("test-keys") == true) return true
        return ROOT_PATHS.any { File(it).exists() }
    }

    fun looksFridaAttached(): Boolean {
        return try {
            File("/proc/net/tcp").readLines().any { line ->
                line.contains(":69A2", true) || // 27042
                line.contains(":69A3", true) || // 27043
                line.contains(":5D8A", true) || // 23946
                line.contains(":69A4", true)
            }
        } catch (_: Throwable) { false }
    }

    fun looksLikeEmulator(): Boolean {
        val fp = Build.FINGERPRINT ?: ""
        val model = Build.MODEL ?: ""
        val man = Build.MANUFACTURER ?: ""
        val prod = Build.PRODUCT ?: ""
        val hw = Build.HARDWARE ?: ""
        return fp.startsWith("generic") || fp.contains("vbox") || fp.contains("test-keys") ||
            model.contains("Emulator") || model.contains("Android SDK built for") ||
            man.contains("Genymotion") || prod.contains("sdk_gphone") ||
            prod.contains("google_sdk") || hw.contains("goldfish") || hw.contains("ranchu") ||
            (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
    }

    fun isDebuggable(context: Context): Boolean =
        try { (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0 }
        catch (_: Throwable) { false }

    fun looksSideloaded(context: Context): Boolean {
        return try {
            val installer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.packageManager.getInstallSourceInfo(context.packageName).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getInstallerPackageName(context.packageName)
            }
            installer.isNullOrBlank() ||
                installer.contains("packageinstaller") ||
                installer.contains("adb") ||
                installer.contains("shell")
        } catch (_: Throwable) { true }
    }

    fun hasInstrumentationArtifacts(): Boolean {
        val suspects = arrayOf(
            "/data/local/tmp/frida-server",
            "/data/local/tmp/re.frida.server",
            "/sdcard/frida-server",
            "/data/local/tmp/fsocket",
            "/data/local/tmp/frida",
            "/data/local/tmp/re.frida"
        )
        return suspects.any { File(it).exists() }
    }
}
