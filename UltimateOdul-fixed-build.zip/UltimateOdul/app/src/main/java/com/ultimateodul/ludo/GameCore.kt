package com.ultimateodul.ludo

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar

/**
 * Everything the game actually does lives here rather than in the
 * manifest-declared Activity, and this class carries no framework
 * obligations of its own -- so unlike the Activity (whose name is pinned
 * by AndroidManifest.xml and whose onCreate/onDestroy overrides are pinned
 * by the Activity base class), R8 is free to rename this class and every
 * member on it, and to repackage it anywhere it likes.
 */
class GameCore(private val activity: AppCompatActivity) {

    private lateinit var engine: NativeBridge
    private lateinit var scoreManager: ScoreManager
    private lateinit var boardView: LudoBoardView

    private lateinit var statusText: TextView
    private lateinit var subStatusText: TextView
    private lateinit var diceButton: TextView

    private val playerNames = arrayOf("You", "Coral", "Sable", "Indigo")
    private val playerCore = intArrayOf(
        Color.parseColor("#FF2D55"),
        Color.parseColor("#00F5A0"),
        Color.parseColor("#FFD60A"),
        Color.parseColor("#2F9BFF")
    )
    private val diceFaces = arrayOf("🎲", "⚀", "⚁", "⚂", "⚃", "⚄", "⚅")

    private val humanPlayer = 0
    private var currentPlayer = 0
    private var lastRoll = 0
    private var awaitingHumanPawnChoice = false
    private var rolling = false
    private var paused = false
    private var matchOver = false

    private val avatarRings = arrayOfNulls<View>(4)
    private val avatarDots = arrayOfNulls<View>(4)
    private val avatarLabels = arrayOfNulls<TextView>(4)
    private val pulseAnimators = arrayOfNulls<ObjectAnimator>(4)

    private val mainHandler = Handler(Looper.getMainLooper())

    fun start() {
        engine = NativeBridge().also { it.start() }
        scoreManager = ScoreManager(activity)

        if (!SecurityGuard.verifyOrRespond(activity, engine)) return

        boardView = LudoBoardView(activity)
        activity.findViewById<FrameLayout>(R.id.boardHost).addView(
            boardView,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        statusText = activity.findViewById(R.id.statusText)
        subStatusText = activity.findViewById(R.id.subStatusText)
        diceButton = activity.findViewById(R.id.diceButton)

        bindAvatarStrip()
        boardView.onPawnTapped = { player, pawn -> onPawnTapped(player, pawn) }

        diceButton.setOnClickListener { onDiceTapped() }
        activity.findViewById<View>(R.id.titleText).setOnLongClickListener {
            confirmNewGame()
            true
        }

        refreshBoard(animate = false)
        setActivePlayer(currentPlayer)
    }

    fun stop() {
        if (::engine.isInitialized) engine.destroy()
        mainHandler.removeCallbacksAndMessages(null)
        OdulAudio.release()
    }

    /** Re-checked from MainActivity.onResume() -- a debugger/Frida session can attach mid-play. */
    fun recheckIntegrity() {
        if (::engine.isInitialized) {
            SecurityGuard.verifyOrRespond(activity, engine)
        }
    }

    // ---------------------------------------------------------------- HUD

    private fun bindAvatarStrip() {
        val ids = intArrayOf(R.id.avatar0, R.id.avatar1, R.id.avatar2, R.id.avatar3)
        for (i in 0 until 4) {
            val chip = activity.findViewById<View>(ids[i])
            avatarRings[i] = chip.findViewById(R.id.avatarRing)
            avatarDots[i] = chip.findViewById(R.id.avatarDot)
            avatarLabels[i] = chip.findViewById(R.id.avatarLabel)
            avatarDots[i]?.background?.setTint(playerCore[i])
            avatarLabels[i]?.text = playerNames[i]
        }
    }

    private fun setActivePlayer(player: Int) {
        currentPlayer = player
        boardView.currentPlayer = player
        for (i in 0 until 4) {
            pulseAnimators[i]?.cancel()
            avatarRings[i]?.setBackgroundResource(if (i == player) R.drawable.bg_avatar_active else R.drawable.bg_avatar_idle)
            avatarRings[i]?.scaleX = 1f
            avatarRings[i]?.scaleY = 1f
            if (i == player) {
                val pulse = ObjectAnimator.ofFloat(avatarRings[i], "scaleX", 1f, 1.18f, 1f)
                pulse.duration = 900
                pulse.repeatCount = ValueAnimator.INFINITE
                val pulseY = ObjectAnimator.ofFloat(avatarRings[i], "scaleY", 1f, 1.18f, 1f)
                pulseY.duration = 900
                pulseY.repeatCount = ValueAnimator.INFINITE
                pulse.start(); pulseY.start()
                pulseAnimators[i] = pulse
            }
        }

        if (player == humanPlayer) {
            statusText.text = activity.getString(R.string.your_turn)
            subStatusText.text = activity.getString(R.string.tap_dice_to_roll)
            diceButton.isEnabled = true
            diceButton.alpha = 1f
        } else {
            statusText.text = activity.getString(R.string.ai_thinking, playerNames[player])
            subStatusText.text = ""
            diceButton.isEnabled = false
            diceButton.alpha = 0.4f
            mainHandler.postDelayed({
                if (!paused && !matchOver) takeAiTurn(player)
            }, 700)
        }
    }

    private fun refreshBoard(animate: Boolean = true) {
        boardView.updateBoardState(engine.getBoardState(), animate)
    }

    // ---------------------------------------------------------------- Dice

    private fun onDiceTapped() {
        if (currentPlayer != humanPlayer || rolling || awaitingHumanPawnChoice) return
        performRoll(humanPlayer)
    }

    private fun performRoll(player: Int) {
        if (paused || matchOver) return
        rolling = true
        OdulAudio.roll(scoreManager.isSoundEnabled())
        val spin = ObjectAnimator.ofFloat(diceButton, "rotation", 0f, 360f * 2)
        spin.duration = 500
        spin.interpolator = OvershootInterpolator()
        spin.start()

        var ticks = 0
        val flicker = object : Runnable {
            override fun run() {
                diceButton.text = diceFaces[(1..6).random()]
                ticks++
                if (ticks < 6) mainHandler.postDelayed(this, 60)
            }
        }
        mainHandler.post(flicker)

        mainHandler.postDelayed({
            val roll = engine.rollDice()
            lastRoll = roll
            diceButton.text = if (roll in 1..6) diceFaces[roll] else "💥"
            rolling = false
            // Impact pulse on the dice
            diceButton.animate()
                .scaleX(1.22f).scaleY(1.22f)
                .setDuration(90)
                .withEndAction {
                    diceButton.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                }
                .start()
            handleRollResult(player, roll)
        }, 430)
    }

    private fun handleRollResult(player: Int, roll: Int) {
        if (roll == 0) {
            toast(activity.getString(R.string.forfeit_six))
            advanceTurn(extra = false)
            return
        }

        val validMoves = engine.getValidMoves(player, roll)
        if (validMoves.isEmpty()) {
            if (player == humanPlayer) {
                subStatusText.text = activity.getString(R.string.no_moves)
            }
            mainHandler.postDelayed({ advanceTurn(extra = false) }, 500)
            return
        }

        if (player == humanPlayer) {
            statusText.text = activity.getString(R.string.rolled_value, roll)
            subStatusText.text = activity.getString(R.string.pick_a_pawn)
            boardView.highlightedMoves = validMoves.toSet()
            boardView.invalidate()
            awaitingHumanPawnChoice = true
        } else {
            val chosenPawn = engine.aiChooseMove(player, roll)
            mainHandler.postDelayed({ applyMove(player, chosenPawn, roll) }, 450)
        }
    }

    // ---------------------------------------------------------------- Moves

    private fun onPawnTapped(player: Int, pawn: Int) {
        if (paused || matchOver || !awaitingHumanPawnChoice || player != humanPlayer || player != currentPlayer) return
        if (!boardView.highlightedMoves.contains(pawn)) return
        awaitingHumanPawnChoice = false
        boardView.highlightedMoves = emptySet()
        applyMove(player, pawn, lastRoll)
    }

    private fun applyMove(player: Int, pawn: Int, roll: Int) {
        if (pawn < 0) {
            advanceTurn(extra = false)
            return
        }
        val outcome = engine.movePawn(player, pawn, roll)
        refreshBoard(animate = true)

        mainHandler.postDelayed({
            if (outcome.captured) {
                // Board impact flash
                boardView.animate()
                    .scaleX(1.035f).scaleY(1.035f)
                    .setDuration(70)
                    .withEndAction {
                        boardView.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    }
                    .start()
                if (player == humanPlayer) scoreManager.recordCapture()
                OdulAudio.capture(scoreManager.isSoundEnabled())
                toast(activity.getString(R.string.captured_toast, playerNames[player]))
            }
            if (outcome.playerWon) {
                onPlayerWon(player)
                return@postDelayed
            }
            if (outcome.extraTurn) {
                if (player == humanPlayer) {
                    subStatusText.text = activity.getString(R.string.six_extra_turn)
                }
                setActivePlayer(player)
            } else {
                advanceTurn(extra = false)
            }
        }, 460)
    }

    private fun advanceTurn(extra: Boolean) {
        if (extra) {
            setActivePlayer(currentPlayer)
            return
        }
        setActivePlayer((currentPlayer + 1) % 4)
    }

    private fun takeAiTurn(player: Int) {
        if (paused || matchOver || player != currentPlayer) return
        performRoll(player)
    }

    // ---------------------------------------------------------------- Win

    private fun onPlayerWon(player: Int) {
        matchOver = true
        paused = true
        scoreManager.recordWin(player)
        val label = if (player == humanPlayer) scoreManager.playerName else playerNames[player]
        OdulAudio.win(scoreManager.isSoundEnabled())
        boardView.animate()
            .scaleX(1.06f).scaleY(1.06f)
            .setDuration(180)
            .withEndAction {
                boardView.animate().scaleX(1f).scaleY(1f).setDuration(220).start()
            }
            .start()
        val msg = activity.getString(R.string.player_wins, label) + "\n\n" +
            activity.getString(R.string.games_played_fmt, scoreManager.gamesPlayed) +
            "\nStreak: ${scoreManager.winStreak} (best ${scoreManager.bestStreak})"
        val dialog = AlertDialog.Builder(activity)
            .setTitle(R.string.win_title)
            .setMessage(msg)
            .setPositiveButton(R.string.win_rematch) { _, _ -> startNewGame() }
            .setNeutralButton(R.string.win_sync, null)
            .setNegativeButton(R.string.back_to_menu) { _, _ ->
                (activity as? MainActivity)?.returnToMenuPublic()
            }
            .setCancelable(false)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                OdulOnline.submitScore(
                    activity,
                    scoreManager.playerName,
                    scoreManager.getWins(0),
                    scoreManager.gamesPlayed
                ) { result ->
                    activity.runOnUiThread {
                        result.fold(
                            onSuccess = { e ->
                                toast(activity.getString(R.string.online_synced, e.rank))
                            },
                            onFailure = {
                                toast(activity.getString(R.string.online_error))
                            }
                        )
                    }
                }
            }
        }
        dialog.show()
    }

    private fun confirmNewGame() {
        AlertDialog.Builder(activity)
            .setTitle("New game?")
            .setMessage("This will reset the current board.")
            .setPositiveButton("Reset") { _, _ -> startNewGame() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startNewGame() {
        engine.resetGame()
        awaitingHumanPawnChoice = false
        rolling = false
        paused = false
        matchOver = false
        boardView.highlightedMoves = emptySet()
        refreshBoard(animate = false)
        setActivePlayer(0)
    }

    fun togglePause(): Boolean {
        if (matchOver) return paused
        paused = !paused
        if (!paused && currentPlayer != humanPlayer) {
            mainHandler.postDelayed({ takeAiTurn(currentPlayer) }, 400)
        }
        return paused
    }

    fun isPaused(): Boolean = paused


    private fun toast(message: String) {
        Snackbar.make(boardView, message, Snackbar.LENGTH_SHORT)
            .setBackgroundTint(0xE61A0F2C.toInt())
            .setTextColor(0xFFFFD60A.toInt())
            .show()
    }
}
