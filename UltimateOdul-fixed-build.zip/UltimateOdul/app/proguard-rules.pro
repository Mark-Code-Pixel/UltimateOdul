# ============================================================
# Ultimate Odul — maximum free hardening
# Dictionary contains ONLY the token "Odul".
# R8 still requires unique names, so the decompiled result becomes
# a sea of Odul / Odul.Odul / Odul.Odul.Odul instead of meaningful
# or varied identifiers. This is the closest practical outcome.
# ============================================================

-optimizationpasses 7
-allowaccessmodification
-overloadaggressively
-repackageclasses ''
-flattenpackagehierarchy ''
-mergeinterfacesaggressively
-dontpreverify
-dontusemixedcaseclassnames
-useuniqueclassmembernames

# Force every renamed symbol to be drawn from a dictionary that
# contains only the word "Odul".
-obfuscationdictionary odul-dictionary.txt
-classobfuscationdictionary odul-dictionary.txt
-packageobfuscationdictionary odul-dictionary.txt

# Strip mapping aids
-renamesourcefileattribute Odul
-keepattributes !SourceFile,!SourceDir,!LineNumberTable,!LocalVariableTable,!LocalVariableTypeTable,!RuntimeVisibleAnnotations,!RuntimeInvisibleAnnotations,!InnerClasses,!EnclosingMethod,!Signature

# Eliminate logging
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
    public static *** wtf(...);
}

# ------------------------------------------------------------
# Only two keep rules (platform constraints — cannot be renamed)
# ------------------------------------------------------------

-keep public class com.ultimateodul.ludo.MainActivity {
    public <init>(...);
    protected void onCreate(...);
    protected void onDestroy(...);
    protected void onResume(...);
}

-keep class com.ultimateodul.ludo.NativeBridge {
    native <methods>;
}

# Everything else is renamed using the single-token "Odul" dictionary
# and flattened into the default package hierarchy.
