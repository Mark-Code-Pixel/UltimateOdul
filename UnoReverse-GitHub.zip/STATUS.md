# Uno Reverse — completion status

**Package:** `com.uno.reverse`  
**Brand:** gold UNO / Aim For Gain  
**Mode:** virtual-container only + Shizuku assist  
**Target:** Carrom Pool (Miniclip) only  

## Done
- Dual ABI native (`unoreverse32` / `unoreverse64`)
- Physics constant scan (live memory)
- Adaptive piece cluster scan → ShotSolver → getLastShot
- AssetExtractor + "Loading The Main Engine"
- VirtualPackageManager (BitAIM-style parent-dir clone API)
- FloatControlPanel (AutoPlay, AutoQueue, Aim, Hide Line, Hide Stream)
- Accessibility InputInjector swipe
- Full permission set + BootReceiver
- Gold launcher icon + wordmark
- SessionOrchestrator end-to-end pipeline
- Lab dumps: libgame-CARROM-1477 armv7 + arm64

## Device requirements
1. Carrom Pool from Play (open once for feature module)
2. Shizuku optional but recommended
3. Overlay + Accessibility + battery ignore

## Build
```
./gradlew :app:assembleDebug
```

## Not claimed
- Guaranteed pot rate without on-device calibration of board↔screen mapping
- Embedded full VirtualApp commercial binary (API ready for drop-in)
