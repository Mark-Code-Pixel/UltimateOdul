# Engine SO dumps — versionCode 1477 (game 19.4.0)

| file | ABI | size |
|------|-----|------|
| libgame-CARROM-1477-armv7.so | ELF32 ARM | ~31 MB |
| libgame-CARROM-1477-arm64.so | ELF64 AArch64 | ~46 MB |

Source: Play feature splits (`split_config.armeabi_v7a.apk`, `config.arm64_v8a.apk`)

## Runtime physics
Static SO images do not contain float constants 0.12 / 8.2 / 2.55 as raw data.
Commercial tools find them in **live process memory** after a table session loads.

## Uno Reverse mode
**Virtual container only (Path A)** + **Shizuku** for elevation.
PackageClone uses parent-dir of splits (same as BitAIM).
