# Confirmed facts from public reverse-engineering (BitAIM+ analysis, Sep 2026)

Source: https://chocapikk.com/posts/2026/bitaim-carrom-pool-cheat-reverse-engineering/

## Package / version
- Package: com.miniclip.carrom
- Engine ships as Play Feature Module, NOT in base APK
- Native engine name pattern: libgame-CARROM-GooglePlay-Gold-Release-Module-<versionCode>.so
- VersionCode 1477 corresponds to game 19.4.0 era (blog notes 1323 was stale, current 1477)
- Base APK alone has zero .so files — feature module required

## How commercial tools attach
- VirtualApp / rebranded container (com.vbox.*) so host and guest share UID
- process_vm_readv works without root because same UID
- YAHFA for ART method hooks
- Version-keyed memory offsets (mismatch → recloned)

## Physics / memory approach used by BitAIM (confirmed strings)
- Memory scanner searches for physics engine constants: **0.12**, **8.2**, **2.55**
  (exact float constants from the game's physics engine layout)
- Blog: "sweeps for the physics engine's own constants, 0.12, 8.2 and 2.55,
  sitting in the arrangement only that engine produces"
- Module base discovered by signature + fallback byte-pattern scan
- String in their native: "libgame-CARROM-GooglePlay-Gold-Release-Module-1323.so"
  "Module base = %p" / "Found base by signature = 0x%lx"

## What we do NOT assume
- Exact struct layouts of pieces / striker
- Exact RVAs for 19.4.0 without dumping libgame / libil2cpp ourselves
- Board coordinate system units
- Which of 0.12 / 8.2 / 2.55 map to friction vs restitution vs scale

## Action for Uno Reverse
- Scan for float constants 0.12f, 8.2f, 2.55f as anchor in remote process
- Locate module by name pattern libgame-CARROM*
- Only publish board data after real reads validate finite coords
- Never invent offsets
