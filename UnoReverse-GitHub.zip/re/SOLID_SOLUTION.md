# Uno Reverse — solid solution (no assumptions)

## Problem
Carrom Pool 19.4.0 (versionCode 1477) ships the physics engine as a **Play Feature Module**:
`libgame-CARROM-GooglePlay-Gold-Release-Module-1477.so`
Base APK from mirrors has **zero** native libraries. Piece struct offsets are not public;
commercial tools use version-keyed tables + same-UID virtual container.

## Solution architecture (real)

### Layer 1 — Discovery (done)
- `VirtualCore.probe()` walks the Play install dir (base + splits + lib paths)
- Detects whether `libgame-CARROM*` artifacts exist on device
- Reports versionName / versionCode for signature selection

### Layer 2 — Attach (done, native)
- `findPidByName("com.miniclip.carrom")`
- Map `libgame-CARROM*` from `/proc/<pid>/maps`
- Scan for **confirmed** physics floats **0.12 / 8.2 / 2.55** (from public BitAIM RE)
- Maps-wide fallback if module name not yet visible

### Layer 3 — Same-UID container (the commercial solid path)
- Why: `process_vm_readv` without root only works reliably when host and guest share UID
- How: VirtualApp / fork (rebranded `com.vbox.*` in BitAIM)
- Uno Reverse: `ContainerStrategy` + `VirtualCore` prepare install paths; full VirtualApp
  binary drop-in is the next integration step (large dependency, not inventable as offsets)

### Layer 4 — Piece layout (blocked until dump)
- Once physics block is found, disc array requires **confirmed** stride/offsets for 1477
- Obtained by dumping feature SO from a live install, not by guessing
- Until then `board.valid = false` (hard rule)

### Layer 5 — Vision fallback (optional later)
- BitAIM also uses board-skin templates + screen capture
- Useful when memory is blocked; secondary path only

## User flow that works today
1. Install **Carrom Pool from Google Play** (not a stripped mirror)
2. Open Carrom once → Play downloads feature module
3. Open Uno Reverse → probe shows engine SO / version
4. START ENGINE → launches Carrom, native attaches, scans physics constants
5. When physics found: aim pipeline can run on solver once layout is locked

## What we will not do
- Invent piece offsets
- Ship pirated Carrom binaries
- Claim AutoPlay is complete without a confirmed layout for the running versionCode
