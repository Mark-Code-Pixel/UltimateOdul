# How commercial tools grab Carrom Pool's engine SO

## Source
BitAIM+ decompilation analysis (chocapikk.com, September 2026).

## They do NOT download the SO from the internet
User must install Carrom Pool from **Google Play**. Play Feature Delivery
then places:
  libgame-CARROM-GooglePlay-Gold-Release-Module-<versionCode>.so
into the app's install directory (with base + config splits).

## Clone algorithm (exact)
```java
String parent = applicationInfo.publicSourceDir;
if (parent == null) parent = applicationInfo.sourceDir;
if (applicationInfo.splitPublicSourceDirs != null
 || applicationInfo.splitSourceDirs != null) {
    parent = new File(parent).getParent(); // critical
}
VirtualCore.get().installPackage(parent, flags);
```

Why getParent()? Base APK has no engine. Parent directory contains:
- base.apk
- split_config.*.apk
- feature module holding libgame-CARROM-*.so

## Version lock
```java
if (deviceVersion != sandboxVersionCode()) {
    VirtualCore.get().uninstallPackage("com.miniclip.carrom");
    // then re-clone
}
```
Offsets are keyed to versionCode (e.g. 1477 for 19.4.0). Mismatch = garbage reads.

## After clone
- Guest runs under host UID
- process_vm_readv works without root
- Native finds module by name / signature
- Scans floats 0.12, 8.2, 2.55 for physics block
- Version table supplies disc struct offsets

## AimCarromKing family
Telegram channel states "supports Carrom Pool installed directly from the Google Store"
and "dual-app engine" — same pattern: virtual dual-app + Play install, not redistributed game.

## Uno Reverse
- PackageClone.resolveSource() implements the same path resolution
- installPackage requires embedding VirtualApp/VirtualCore runtime (Path A)
- Until then Path B attaches to the user's Play process after they open the game once
