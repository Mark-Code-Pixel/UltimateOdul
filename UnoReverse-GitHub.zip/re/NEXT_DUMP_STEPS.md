# Next steps to lock real piece layout (no guessing)

## Why piece arrays are still invalid
Commercial tools (BitAIM+) locate the **physics parameter block** via constants
0.12 / 8.2 / 2.55, then use **version-keyed offsets** downloaded from their
server (`cv` versionCode → `o6` offset table) to read disc positions.

We have the first half (constant scan). We do **not** have the second half
(disc struct offsets for versionCode 1477 / game 19.4.0).

## What must be obtained from a live 19.4.0 install
1. Feature module SO after Play delivery:
   `libgame-CARROM-GooglePlay-Gold-Release-Module-1477.so`
   Typical path on device (varies):
   `/data/app/.../com.miniclip.carrom-.../lib/arm64/libgame-CARROM-*.so`
   or split feature dir under `split_config` / `split_feature_*`

2. Optional: runtime dump of `libil2cpp.so` + `global-metadata.dat` if Unity
   layer holds board state (some builds do; engine SO is primary for physics).

3. Once SO is in lab:
   - strings / nm / llvm-objdump for physics symbols
   - locate the 0.12/8.2/2.55 block in the file
   - trace xrefs to disc/striker arrays
   - lock SignatureSet entry for "19.4.0" / 1477

## What Uno Reverse will do when that arrives
- Fill `signatures.h` with real pattern + stride + field offsets
- `readBoard(false)` returns valid pieces from memory only
- Solver runs on real coordinates

## Current honest status
- process attach: yes
- libgame-CARROM* map: yes (when process has feature module loaded)
- physics constant signature: implemented from public RE
- piece layout: **not confirmed → board.valid = false**
