# Changelog
## [1.0.0] - 2026-09-18
### Added
- Complete custom virtualization engine
- Binder ioctl + ServiceManager proxy
- VirtualClassLoader, Stub* lifecycle
- File redirect, agent loader
- IL2CPP reader, physics solver, offset pipeline
- Overlay, headless, account bridges
- mini_hook fallback
