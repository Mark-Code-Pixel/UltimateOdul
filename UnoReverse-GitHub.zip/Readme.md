# Uno Reverse

An Android application virtualization and runtime instrumentation framework.

Uno Reverse hosts other Android applications inside a container it controls,
runs them under its own UID, and instruments them at runtime through native
inline hooks. It is the same class of software as VirtualApp, BlackBox, and
Parallel Space — a from-scratch implementation of the same techniques with a
different focus: runtime visibility and control over the hosted application's
internal state.

The default target is Carrom Pool (`com.miniclip.carrom`). The container is
engine-agnostic: it does not require Unity, IL2CPP, or any other specific
runtime to be present. It fingerprints whatever it finds and adapts.

---

## What it does

1. **Detects** a target app already installed on the device.
2. **Imports** it silently into a virtual container under Uno Reverse's UID.
3. **Spawns** the target under the container, injecting a native agent
   before the target's own native libraries load.
4. **Inventories** everything the target loads in its first five seconds:
   every native module, every DEX file, every JNI binding, every open file
   descriptor. Writes the result to `runtime_inventory.json`.
5. **Resolves** field and method offsets by calling the target's own runtime
   API — never by hardcoded addresses.
6. **Installs** inline hooks on the target's update loop, turn dispatch, and
   primary action method.
7. **Solves** the game state on every frame: reads the live board, builds
   candidate shots analytically, verifies them in parallel with a
   deterministic physics simulation, and publishes the highest-scoring
   valid shot.
8. **Renders** candidate lines and the chosen shot on an optional overlay,
   or runs entirely headless.

Autoplay, autoqueue, keep-line, and table-select run whether or not the
overlay is enabled. The overlay is a display; the work is done by the native
agent inside the guest process.

---

## Requirements

- **Android SDK 34** (compile target)
- **Android NDK r26d** or newer
- **JDK 17**
- **CMake 3.22.1** (installed via the SDK Manager)
- **Gradle 8.2** (via the wrapper)

Optional but recommended for first-time setup:

- Android Studio Hedgehog (2023.1.1) or newer

---

## Build

```bash
# 1. Clone or unzip the source tree.
cd uno-reverse

# 2. Generate the Gradle wrapper if it is not present.
#    Android Studio does this automatically. On the command line:
gradle wrapper --gradle-version 8.2

# 3. Build the universal release APK.
./gradlew :app:assembleUniversalRelease