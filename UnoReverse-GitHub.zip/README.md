# Uno Reverse

**Package:** `com.uno.reverse`  
**Tagline:** Aim For Gain  

Virtual-container assist for Carrom Pool (Miniclip). Dual ABI. Native physics + adaptive piece scan.

## Build unsigned release APK
```bash
./gradlew :app:assembleRelease
```
Output (unsigned):
```
app/build/outputs/apk/release/app-release-unsigned.apk
```

## Sign with your own keystore
```bash
# align (optional but recommended)
zipalign -v -p 4 app-release-unsigned.apk app-release-aligned.apk

# sign with YOUR keystore
apksigner sign \
  --ks /path/to/your.keystore \
  --ks-key-alias YOUR_ALIAS \
  --out UnoReverse-release.apk \
  app-release-aligned.apk

apksigner verify UnoReverse-release.apk
```

No project keystore is included. You control signing.

## GitHub Actions
Workflow builds **unsigned** release and uploads artifact `uno-reverse-unsigned-apk`.

## Device
1. Carrom Pool from Play (open once)
2. Grant Overlay + Accessibility
3. Optional Shizuku
