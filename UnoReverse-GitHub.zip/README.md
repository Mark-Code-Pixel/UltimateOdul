# Uno Reverse v1.0.0

Custom Android application virtualization framework with runtime instrumentation.
Built from scratch. Target guest: com.miniclip.carrom

## Build
```bash
./gradlew :app:assembleUniversalRelease
```

## Features
- Silent auto-detect/import of target APK
- Full Binder / ClassLoader / lifecycle virtualization
- Native agent + IL2CPP offset pipeline
- Physics solver (ghost-ball + multi-cushion)
- Optional VIP overlay
- Headless mode
- Google / Facebook account bridging
- Anti-detection hooks

## Headless
Place headless.json in external files dir. Overlay is a detection surface.

## Limitations
Play Integrity may still fail ranked/purchase flows. No container is permanently undetectable.
