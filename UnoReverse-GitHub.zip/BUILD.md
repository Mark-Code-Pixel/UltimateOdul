# Uno Reverse — build notes

## Requirements
- Android SDK 34+, NDK 26+
- JDK 17
- Carrom Pool installed from Play on device (feature module)
- Optional: Shizuku for elevated ops

## Assemble
```bash
cd UnoReverse
./gradlew :app:assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## Device flow
1. Install Carrom Pool from Play → open once
2. Install Shizuku → pair → start
3. Install Uno Reverse → grant Overlay + Accessibility + Battery ignore
4. START ENGINE → Loading The Main Engine → extract → launch + float panel

## Native
- ABI: armeabi-v7a + arm64-v8a
- piece_scan: adaptive float clusters after physics block
- No invented fixed offsets; board.valid only on confident cluster
