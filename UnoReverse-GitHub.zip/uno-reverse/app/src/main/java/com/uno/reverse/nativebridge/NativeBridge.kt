package com.uno.reverse.nativebridge
import com.uno.reverse.util.Log
object NativeBridge {
    @Volatile private var loaded = false
    init {
        try { System.loadLibrary("unoreverse"); loaded = true; Log.i("NativeBridge", "loaded") }
        catch (t: Throwable) { Log.e("NativeBridge", "${t.message}"); loaded = false }
    }
    fun isReady() = loaded
    fun loadAgent(libDir: String) { if (loaded) try { nativeLoadAgent(libDir) } catch (_: Throwable) {} }
    fun installHooks() { if (loaded) try { nativeInstallHooks() } catch (_: Throwable) {} }
    fun runSolverTick() { if (loaded) try { nativeSolverTick() } catch (_: Throwable) {} }
    fun getAimLine(): FloatArray = if (loaded) try { nativeGetAimLine() } catch (_: Throwable) { floatArrayOf(0f,-80f,0f,0f) } else floatArrayOf(0f,-80f,0f,0f)
    fun setAutoPlay(on: Boolean) { if (loaded) try { nativeSetAutoPlay(on) } catch (_: Throwable) {}; SharedState.setAutoPlay(on) }
    fun setSolveRate(rate: Int) { if (loaded) try { nativeSetSolveRate(rate) } catch (_: Throwable) {}; SharedState.setSolveRate(rate) }
    fun loadOffsets(path: String): Boolean = if (loaded) try { nativeLoadOffsets(path) } catch (_: Throwable) { false } else false
    private external fun nativeLoadAgent(libDir: String)
    private external fun nativeInstallHooks()
    private external fun nativeSolverTick()
    private external fun nativeGetAimLine(): FloatArray
    private external fun nativeSetAutoPlay(on: Boolean)
    private external fun nativeSetSolveRate(rate: Int)
    private external fun nativeLoadOffsets(path: String): Boolean
}
