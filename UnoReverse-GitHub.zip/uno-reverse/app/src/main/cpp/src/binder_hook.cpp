#include "binder_hook.h"
#include <android/log.h>
void binder_hook_install(){__android_log_print(ANDROID_LOG_INFO,"Binder","armed");}
