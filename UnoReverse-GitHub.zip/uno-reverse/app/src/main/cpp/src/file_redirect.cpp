#include "file_redirect.h"
#include <cstring>
static char g[512];
void file_redirect_install(const char* r){if(r) strncpy(g,r,511);}
const char* file_redirect_root(){return g;}
