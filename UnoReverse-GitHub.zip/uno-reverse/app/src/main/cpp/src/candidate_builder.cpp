
#include "candidate_builder.h"
#include "unoreverse.h"
#include <cmath>
int build_candidates(const BoardState* board, Candidate* out, int max) {
    if (!board||!out||max<=0) return 0; int n=0;
    for(int i=0;i<board->count && n<max;i++){
        if(board->coins[i].pocketed) continue;
        float dx=board->coins[i].pos.x-board->cue.x, dy=board->coins[i].pos.y-board->cue.y;
        out[n++]={atan2f(dy,dx),0.6f,0.f,0};
    }
    if(n<max) out[n++]={0.3f,0.7f,0.f,1};
    return n;
}
