
#include "scorer.h"
#include "unoreverse.h"
float score_result(const StepResult* r){ if(!r||!r->valid) return -1e5f; float s=0; for(int i=0;i<r->state.count;i++) if(r->state.coins[i].pocketed) s+=10; return s; }
