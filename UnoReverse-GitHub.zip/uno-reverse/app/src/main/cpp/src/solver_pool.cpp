
#include "solver_pool.h"
#include "candidate_builder.h"
#include "physics_sim.h"
#include "scorer.h"
#include "physics_reader.h"
Candidate solve_best(const BoardState* board, const PhysicsConfig* cfg) {
    BoardState local{}; if(!board){ read_board(&local); board=&local; }
    Candidate cands[32]; int n=build_candidates(board,cands,32);
    Candidate best{}; best.score=-1e9f;
    PhysicsConfig def{0.98f,0.8f,0}; const PhysicsConfig* c=cfg?cfg:&def;
    for(int i=0;i<n;i++){ auto st=simulate(board,cands[i].angle,cands[i].power,c); float s=score_result(&st); if(s>best.score){best=cands[i];best.score=s;} }
    return best;
}
