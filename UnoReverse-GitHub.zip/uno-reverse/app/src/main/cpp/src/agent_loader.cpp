
#include "agent_loader.h"
#include <android/log.h>
#include <dlfcn.h>
#include <cstdio>
void agent_load(const char* libDir){
    if(!libDir) return;
    char path[512];
    snprintf(path,sizeof(path),"%s/libil2cpp.so",libDir);
    void* h=dlopen(path,RTLD_NOW|RTLD_LOCAL);
    __android_log_print(ANDROID_LOG_INFO,"Agent","load %s -> %p",path,h);
}
