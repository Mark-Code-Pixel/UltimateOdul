
#include "physics_reader.h"
#include "unoreverse.h"
bool read_board(BoardState* out) {
    if (!out) return false;
    out->count = 5; out->cue = {0,-80}; out->angle=0; out->power=0.5f;
    float d[][2]={{0,0},{20,0},{-20,0},{0,20},{0,-20}};
    for(int i=0;i<5;i++){ out->coins[i].pos={d[i][0],d[i][1]}; out->coins[i].vel={0,0}; out->coins[i].radius=4.5f; out->coins[i].id=i; out->coins[i].pocketed=0; }
    return true;
}
