#include <jni.h>
#include <android/log.h>
#include <cmath>
#include "unoreverse.h"
#include "agent_loader.h"
#include "hooks.h"
#include "solver_pool.h"
#include "physics_reader.h"
#include "shared_mem.h"
#include "offsets_runtime.h"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "URNative", __VA_ARGS__)
static SharedState* g_shared = nullptr;
extern "C" {
JNIEXPORT void JNICALL Java_com_uno_reverse_nativebridge_NativeBridge_nativeLoadAgent(JNIEnv* env, jclass, jstring libDir) {
    const char* dir = libDir ? env->GetStringUTFChars(libDir, nullptr) : nullptr;
    LOGI("nativeLoadAgent %s", dir ? dir : "");
    agent_load(dir);
    if (dir) env->ReleaseStringUTFChars(libDir, dir);
    if (!g_shared) g_shared = shared_create();
}
JNIEXPORT void JNICALL Java_com_uno_reverse_nativebridge_NativeBridge_nativeInstallHooks(JNIEnv*, jclass) { hooks_install(); }
JNIEXPORT void JNICALL Java_com_uno_reverse_nativebridge_NativeBridge_nativeSolverTick(JNIEnv*, jclass) {
    BoardState board{}; read_board(&board);
    PhysicsConfig cfg{0.985f, 0.8f, 0.f};
    Candidate best = solve_best(&board, &cfg);
    if (g_shared) {
        g_shared->seq.fetch_add(1);
        g_shared->chosenLine[0] = board.cue.x; g_shared->chosenLine[1] = board.cue.y;
        g_shared->chosenLine[2] = board.cue.x + cosf(best.angle) * 50.f;
        g_shared->chosenLine[3] = board.cue.y + sinf(best.angle) * 50.f;
    }
}
JNIEXPORT jfloatArray JNICALL Java_com_uno_reverse_nativebridge_NativeBridge_nativeGetAimLine(JNIEnv* env, jclass) {
    jfloatArray arr = env->NewFloatArray(4);
    float line[4] = {0,-80,0,0};
    if (g_shared) for (int i=0;i<4;i++) line[i]=g_shared->chosenLine[i];
    env->SetFloatArrayRegion(arr,0,4,line); return arr;
}
JNIEXPORT void JNICALL Java_com_uno_reverse_nativebridge_NativeBridge_nativeSetAutoPlay(JNIEnv*, jclass, jboolean on) {
    if (!g_shared) g_shared = shared_create();
    if (g_shared) g_shared->autoPlay.store(on?1:0);
}
JNIEXPORT void JNICALL Java_com_uno_reverse_nativebridge_NativeBridge_nativeSetSolveRate(JNIEnv*, jclass, jint rate) {
    if (!g_shared) g_shared = shared_create();
    if (g_shared) g_shared->solveRate.store(rate);
}
JNIEXPORT jboolean JNICALL Java_com_uno_reverse_nativebridge_NativeBridge_nativeLoadOffsets(JNIEnv* env, jclass, jstring path) {
    const char* p = path ? env->GetStringUTFChars(path, nullptr) : nullptr;
    bool ok = p && offsets_load(p);
    if (p) env->ReleaseStringUTFChars(path, p);
    return ok ? JNI_TRUE : JNI_FALSE;
}
}
