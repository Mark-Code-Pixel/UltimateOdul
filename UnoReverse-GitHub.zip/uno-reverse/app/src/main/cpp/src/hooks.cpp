#include "hooks.h"
#include "binder_hook.h"
#include "file_redirect.h"
void hooks_install(){binder_hook_install();file_redirect_install("/data/user/0/com.uno.reverse/virtual");}
