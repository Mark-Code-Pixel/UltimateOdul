
#include "physics_sim.h"
#include "unoreverse.h"
#include <cmath>
StepResult simulate(const BoardState* in, float angle, float power, const PhysicsConfig* cfg) {
    StepResult r{}; if(!in) return r; r.state=*in; r.valid=1; r.scratched=0;
    float fr=cfg?cfg->friction:0.98f;
    if(r.state.count>0){ r.state.coins[0].vel={cosf(angle)*power*30,sinf(angle)*power*30}; }
    for(int s=0;s<20;s++) for(int i=0;i<r.state.count;i++){
        if(r.state.coins[i].pocketed) continue;
        r.state.coins[i].pos.x+=r.state.coins[i].vel.x*0.05f;
        r.state.coins[i].pos.y+=r.state.coins[i].vel.y*0.05f;
        r.state.coins[i].vel.x*=fr; r.state.coins[i].vel.y*=fr;
        if(fabsf(r.state.coins[i].pos.x)>95||fabsf(r.state.coins[i].pos.y)>95) r.state.coins[i].pocketed=1;
    }
    return r;
}
