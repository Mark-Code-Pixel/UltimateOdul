#pragma once
struct SharedState;
SharedState* shared_create();
