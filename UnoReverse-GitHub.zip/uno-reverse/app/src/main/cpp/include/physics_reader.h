#pragma once
struct BoardState;
bool read_board(BoardState* out);
