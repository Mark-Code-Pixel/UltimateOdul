#pragma once
void file_redirect_install(const char* virtualRoot);
const char* file_redirect_root();
