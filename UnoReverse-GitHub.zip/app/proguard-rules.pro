# Uno Reverse — ProGuard rules.
#
# Minification is disabled in the release build, so these rules are
# only a safety net for a future where minification is enabled.

# Keep our JNI bridge — the native side resolves these by name.
-keep class com.uno.reverse.nativebridge.NativeBridge { *; }
-keep class com.uno.reverse.nativebridge.SharedState { *; }
-keep class com.uno.reverse.nativebridge.SharedState$Snapshot { *; }

# Keep VirtualCore — referenced from native via JNI NewGlobalRef.
-keep class com.uno.reverse.core.VirtualCore {
    public static void onRuntimeManifestReady(java.lang.String, java.lang.String);
}

# Keep every stub component — the framework instantiates them.
-keep class com.uno.reverse.lifecycle.StubActivity { *; }
-keep class com.uno.reverse.lifecycle.StubActivity$P0 { *; }
-keep class com.uno.reverse.lifecycle.StubActivity$P1 { *; }
-keep class com.uno.reverse.lifecycle.StubActivity$P2 { *; }
-keep class com.uno.reverse.lifecycle.StubActivity$P3 { *; }
-keep class com.uno.reverse.lifecycle.StubActivity$P4 { *; }
-keep class com.uno.reverse.lifecycle.StubActivity$P5 { *; }
-keep class com.uno.reverse.lifecycle.StubActivity$P6 { *; }
-keep class com.uno.reverse.lifecycle.StubActivity$P7 { *; }
-keep class com.uno.reverse.lifecycle.StubService { *; }
-keep class com.uno.reverse.lifecycle.StubService$P0 { *; }
-keep class com.uno.reverse.lifecycle.StubService$P1 { *; }
-keep class com.uno.reverse.lifecycle.StubService$P2 { *; }
-keep class com.uno.reverse.lifecycle.StubService$P3 { *; }
-keep class com.uno.reverse.lifecycle.StubProvider { *; }
-keep class com.uno.reverse.lifecycle.StubReceiver { *; }
-keep class com.uno.reverse.lifecycle.RedirectCaptureActivity { *; }

# Keep every Activity, Service, Receiver, Provider declared in the manifest.
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider

# Keep reflection-accessed fields used by the container.
-keepclassmembers class * {
    @androidx.annotation.Keep <fields>;
    @androidx.annotation.Keep <methods>;
}

# Keep Kotlin metadata.
-keep class kotlin.Metadata { *; }
-keepclassmembers class **$WhenMappings { <fields>; }

# Strip log calls in release builds.
-assumenosideeffects class android.util.Log {
    public static *** v(...);
    public static *** d(...);
    public static *** i(...);
}

# Native methods.
-keepclasseswithmembernames class * {
    native <methods>;
}

# Enum values accessed via reflection.
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}