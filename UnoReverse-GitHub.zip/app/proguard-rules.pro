-keep class com.uno.reverse.core.NativeBridge { *; }
-keepclassmembers class com.uno.reverse.core.NativeBridge {
    native <methods>;
}
-keep class com.uno.reverse.inject.InputInjector { *; }
-keep class com.uno.reverse.virtual.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
