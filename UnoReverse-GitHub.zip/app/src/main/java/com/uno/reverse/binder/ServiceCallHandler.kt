package com.uno.reverse.binder

import android.os.IBinder
import com.uno.reverse.core.VirtualActivityManager
import com.uno.reverse.core.VirtualPackageManager
import com.uno.reverse.core.VirtualUserManager
import com.uno.reverse.util.Log as ULog
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Method

/*
 * Per-service invocation handler. Dispatches to the right virtual
 * manager based on the service name, and passes through every method
 * the virtual manager does not intercept.
 *
 * Service names come from ServiceManager.getService(name). The relevant
 * set for a virtual container:
 *
 *   "activity"      -> VirtualActivityManager
 *   "package"       -> VirtualPackageManager
 *   "user"          -> VirtualUserManager
 *   "account"       -> reserved for future account isolation
 *
 * Every other service passes through untouched.
 */
class ServiceCallHandler(
    private val serviceName: String,
    private val original: IBinder
) : InvocationHandler {

    override fun invoke(proxy: Any?, method: Method, args: Array<out Any?>?): Any? {
        return try {
            when (serviceName) {
                "activity" -> VirtualActivityManager.invoke(original, method, args ?: emptyArray())
                "package"  -> VirtualPackageManager.invoke(original, method, args ?: emptyArray())
                "user"     -> VirtualUserManager.invoke(original, method, args ?: emptyArray())
                else       -> method.invoke(original, *(args ?: emptyArray()))
            }
        } catch (t: Throwable) {
            val cause = t.cause
            if (cause != null) throw cause
            throw t
        }
    }

    companion object {
        private const val TAG = "ServiceCallHandler"
    }
}