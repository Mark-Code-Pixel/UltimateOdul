package com.uno.reverse.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.uno.reverse.nativebridge.NativeBridge
import com.uno.reverse.nativebridge.SharedState
import com.uno.reverse.util.Log as ULog
import com.uno.reverse.util.OverlayPrefs

/*
 * Signature-gated broadcast receiver for headless control.
 *
 * The container can be driven entirely from ADB when the user has not
 * opened any UI. This is what makes the headless mode usable for
 * automation:
 *
 *   adb shell am broadcast \
 *     -a com.uno.reverse.action.SET_FLAG \
 *     -n com.uno.reverse/.core.HeadlessControlReceiver \
 *     --ei flag 1 --ei value 1
 *
 * The receiver is protected by the signature-level permission
 * com.uno.reverse.permission.CONTROL. Only processes signed with the
 * same key as Uno Reverse can send intents to it. On a debug build the
 * debug keystore grants that; on a release build, only the release
 * key does.
 *
 * The commands map to the same SharedState.Flag constants the panel
 * uses, so ADB and the overlay are interchangeable.
 *
 *   flag=1  AUTOPLAY      value 0/1
 *   flag=2  AUTOQUEUE     value 0/1
 *   flag=3  KEEP_LINE     value 0/1
 *   flag=4  SHOW_LINES    value 0/1
 *   flag=5  LINE_COUNT    value 8/16/24/64
 *   flag=6  SOLVE_RATE    value 60/30/15/5
 *   flag=7  PROFILE       value 0/1/2/3
 *
 * Additional actions:
 *   RELOAD_PROFILE       re-seed headless.json from the current shared
 *                        state (useful after manual edits)
 *   SHUTDOWN             stop the container and exit
 */
class HeadlessControlReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        ULog.i(TAG, "control intent: $action")

        when (action) {
            ACTION_SET_FLAG -> {
                val flag = intent.getIntExtra(EXTRA_FLAG, -1)
                val value = intent.getIntExtra(EXTRA_VALUE, 0)
                if (flag <= 0) {
                    ULog.w(TAG, "SET_FLAG missing or invalid flag: $flag")
                    return
                }
                if (!NativeBridge.isSharedMapped()) {
                    ULog.w(TAG, "SET_FLAG received but shared region is not mapped")
                    return
                }
                val ok = NativeBridge.setFlag(flag, value)
                ULog.i(TAG, "SET_FLAG flag=$flag value=$value ok=$ok")

                // SHOW_LINES also writes to the persisted overlay
                // preference so the toggle survives a restart.
                if (flag == SharedState.Flag.SHOW_LINES) {
                    OverlayPrefs.setEnabled(context, value != 0)
                }
            }

            ACTION_RELOAD_PROFILE -> {
                ULog.i(TAG, "RELOAD_PROFILE requested")
                // Re-read headless.json and apply to shared memory.
                applyHeadlessProfile(context)
            }

            ACTION_SHUTDOWN -> {
                ULog.i(TAG, "SHUTDOWN requested")
                try {
                    val i = Intent(context, ContainerService::class.java).apply {
                        this.action = ContainerService.ACTION_SHUTDOWN
                    }
                    context.startService(i)
                } catch (t: Throwable) {
                    ULog.e(TAG, "SHUTDOWN failed", t)
                }
            }
        }
    }

    // ------------------------------------------------------------------

    /*
     * Read headless.json and push every flag it names into shared
     * memory. Missing keys leave the corresponding flag untouched.
     */
    private fun applyHeadlessProfile(context: Context) {
        try {
            val f = java.io.File(context.filesDir, "unoreverse/headless.json")
            if (!f.exists() || f.length() == 0L) {
                ULog.w(TAG, "headless.json missing")
                return
            }
            val text = f.readText()
            applyBool(text, "autoplay", SharedState.Flag.AUTOPLAY)
            applyBool(text, "autoqueue", SharedState.Flag.AUTOQUEUE)
            applyBool(text, "keep_line", SharedState.Flag.KEEP_LINE)
            applyBool(text, "show_lines", SharedState.Flag.SHOW_LINES)
            applyInt(text, "line_count", SharedState.Flag.LINE_COUNT)
            applyInt(text, "solve_rate_hz", SharedState.Flag.SOLVE_RATE)
            applyInt(text, "profile", SharedState.Flag.PROFILE)
        } catch (t: Throwable) {
            ULog.e(TAG, "applyHeadlessProfile failed", t)
        }
    }

    private fun applyBool(json: String, key: String, flag: Int) {
        val needle = "\"$key\":"
        val i = json.indexOf(needle)
        if (i < 0) return
        var j = i + needle.length
        while (j < json.length && json[j].isWhitespace()) j++
        val v = when {
            json.startsWith("true", j, ignoreCase = true) -> 1
            json.startsWith("false", j, ignoreCase = true) -> 0
            else -> return
        }
        NativeBridge.setFlag(flag, v)
    }

    private fun applyInt(json: String, key: String, flag: Int) {
        val needle = "\"$key\":"
        val i = json.indexOf(needle)
        if (i < 0) return
        var j = i + needle.length
        while (j < json.length && json[j].isWhitespace()) j++
        val start = j
        while (j < json.length && (json[j].isDigit() || json[j] == '-')) j++
        if (j == start) return
        val v = json.substring(start, j).toIntOrNull() ?: return
        NativeBridge.setFlag(flag, v)
    }

    companion object {
        private const val TAG = "HeadlessControl"

        const val ACTION_SET_FLAG      = "com.uno.reverse.action.SET_FLAG"
        const val ACTION_RELOAD_PROFILE = "com.uno.reverse.action.RELOAD_PROFILE"
        const val ACTION_SHUTDOWN      = "com.uno.reverse.action.SHUTDOWN"

        const val EXTRA_FLAG  = "flag"
        const val EXTRA_VALUE = "value"
    }
}