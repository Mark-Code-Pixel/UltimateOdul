package com.uno.reverse.pipeline
import com.uno.reverse.util.Log
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
class MetadataParser {
    fun parse(data: ByteArray): JSONObject {
        val buf = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val o = JSONObject()
        try {
            val sanity = buf.int; val ver = buf.int
            Log.i("MetaParser", "sanity=${sanity.toString(16)} ver=$ver")
            o.put("version", ver)
            o.put("Rigidbody2D_position", 0)
            o.put("Rigidbody2D_velocity", 8)
            o.put("Cue_shoot", 0)
            o.put("TurnManager_isMyTurn", 0)
        } catch (e: Exception) { Log.e("MetaParser", "${e.message}") }
        return o
    }
}
