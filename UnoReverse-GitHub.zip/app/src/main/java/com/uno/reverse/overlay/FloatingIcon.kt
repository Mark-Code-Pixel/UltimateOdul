package com.uno.reverse.overlay
import android.content.Context
class FloatingIcon(c: Context, onTap: () -> Unit, onLong: () -> Unit) {
    fun show() {}
    fun hide() {}
}
