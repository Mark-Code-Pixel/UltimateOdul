package com.uno.reverse.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs

/*
 * The floating icon. A logo drawn inside a gold ring, draggable, with
 * tap and long-press detection.
 *
 * Rendering: the view draws the ring itself and asks the parent to
 * supply a bitmap for the inner logo via `logoDrawable`. This keeps the
 * ring crisp at any density while the logo can be any drawable.
 */
@SuppressLint("ViewConstructor")
class FloatingIcon(
    context: Context,
    private val onTap: () -> Unit,
    private val onLongPress: () -> Unit
) : View(context) {

    private var logoDrawable: android.graphics.drawable.Drawable? = null

    private val density = resources.displayMetrics.density
    private val ringWidthPx = Theme.ICON_RING_DP * density
    private val sizePx = (Theme.ICON_SIZE_DP * density).toInt()

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Theme.GOLD
        strokeWidth = ringWidthPx
        setShadowLayer(8f, 0f, 0f, Theme.GOLD)
    }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Theme.BG
    }

    private val ringRect = RectF()

    // ---- Touch handling -------------------------------------------

    private var downRawX = 0f
    private var downRawY = 0f
    private var downViewX = 0f
    private var downViewY = 0f
    private var dragging = false
    private var longPressFired = false
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private val longPressTimeout = ViewConfiguration.getLongPressTimeout().toLong()

    private val longPressRunnable = Runnable {
        if (!dragging) {
            longPressFired = true
            onLongPress()
        }
    }

    // ---- Drag callback --------------------------------------------

    var dragHandler: ((dx: Float, dy: Float, end: Boolean) -> Unit)? = null

    // ---- Public API -----------------------------------------------

    fun setLogo(d: android.graphics.drawable.Drawable) {
        logoDrawable = d
        d.setBounds(0, 0, sizePx, sizePx)
        invalidate()
    }

    fun desiredSizePx(): Int = sizePx

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(sizePx, sizePx)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = (minOf(width, height) / 2f) - ringWidthPx
        val inset = ringWidthPx + 4f

        canvas.drawCircle(cx, cy, r - inset * 0.3f, bgPaint)
        ringRect.set(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(ringRect, 0f, 360f, false, ringPaint)

        logoDrawable?.let {
            val s = (sizePx * 0.60f).toInt()
            val off = (sizePx - s) / 2
            it.setBounds(off, off, off + s, off + s)
            it.draw(canvas)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = event.rawX
                downRawY = event.rawY
                downViewX = x
                downViewY = y
                dragging = false
                longPressFired = false
                postDelayed(longPressRunnable, longPressTimeout)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downRawX
                val dy = event.rawY - downRawY
                if (!dragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                    dragging = true
                    removeCallbacks(longPressRunnable)
                }
                if (dragging) {
                    dragHandler?.invoke(dx, dy, false)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPressRunnable)
                if (dragging) {
                    dragHandler?.invoke(0f, 0f, true)
                } else if (!longPressFired) {
                    onTap()
                }
                dragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPressRunnable)
                if (dragging) dragHandler?.invoke(0f, 0f, true)
                dragging = false
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}