package com.uno.reverse.core

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.uno.reverse.virtual.VirtualContainer

/**
 * Watches Carrom Pool process health and restarts it when AutoQueue is on.
 * Lightweight – no root required.
 */
class CrashRecovery(private val context: Context) {

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var consecutiveMisses = 0

    private val checkRunnable = object : Runnable {
        override fun run() {
            if (!running) return

            val installed = VirtualContainer.isCarromInstalled(context)
            if (!installed) {
                consecutiveMisses = 0
                handler.postDelayed(this, CHECK_INTERVAL_MS)
                return
            }

            // Heuristic: if we expected Carrom to stay up and package is still
            // installed, try a soft re-launch when AutoQueue wants continuity.
            // Real process liveness can be improved with ActivityManager later.
            if (EngineConfig.autoQueue) {
                consecutiveMisses++
                if (consecutiveMisses >= 3) {
                    Log.w(TAG, "Recovery: re-launching Carrom Pool")
                    VirtualContainer.launchCarrom(context)
                    consecutiveMisses = 0
                }
            }

            handler.postDelayed(this, CHECK_INTERVAL_MS)
        }
    }

    fun start() {
        if (running) return
        running = true
        consecutiveMisses = 0
        handler.postDelayed(checkRunnable, CHECK_INTERVAL_MS)
        Log.i(TAG, "Crash recovery started")
    }

    fun stop() {
        running = false
        handler.removeCallbacks(checkRunnable)
        Log.i(TAG, "Crash recovery stopped")
    }

    fun notifyAlive() {
        consecutiveMisses = 0
    }

    companion object {
        private const val TAG = "UnoRecovery"
        private const val CHECK_INTERVAL_MS = 12_000L
    }
}
