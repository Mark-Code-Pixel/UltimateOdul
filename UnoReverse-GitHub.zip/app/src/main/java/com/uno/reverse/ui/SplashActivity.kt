package com.uno.reverse.ui

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.uno.reverse.MainActivity
import com.uno.reverse.R
import com.uno.reverse.ui.widget.PulseRing
import com.uno.reverse.ui.theme.Anim
import com.uno.reverse.ui.theme.ColorPalette
import com.uno.reverse.ui.theme.Typography

/*
 * Animated splash screen.
 *
 * Sequence:
 *   1. Logo fades in and scales from 0.6 to 1.0 with overshoot.
 *   2. Pulse ring behind the logo activates.
 *   3. App name fades in from below.
 *   4. Tagline fades in after the name.
 *   5. A gold underline sweeps across.
 *   6. After SPLASH ms total, transition to MainActivity.
 *
 * Every animation is cancellable and the activity finishes cleanly if
 * the user leaves early.
 */
class SplashActivity : AppCompatActivity() {

    private lateinit var logo: View
    private lateinit var pulse: PulseRing
    private lateinit var name: TextView
    private lateinit var tagline: TextView
    private lateinit var underline: View

    private val runningAnimators = mutableListOf<android.animation.Animator>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        logo       = findViewById(R.id.splash_logo)
        pulse      = findViewById(R.id.splash_pulse)
        name       = findViewById(R.id.splash_name)
        tagline    = findViewById(R.id.splash_tagline)
        underline  = findViewById(R.id.splash_underline)

        name.typeface = Typography.bold(this)
        tagline.typeface = Typography.medium(this)

        // Initial state.
        logo.alpha = 0f
        logo.scaleX = 0.6f
        logo.scaleY = 0.6f
        name.alpha = 0f
        name.translationY = 24f
        tagline.alpha = 0f
        tagline.translationY = 16f
        underline.scaleX = 0f

        runIntro()
    }

    override fun onDestroy() {
        for (a in runningAnimators) a.cancel()
        runningAnimators.clear()
        super.onDestroy()
    }

    private fun runIntro() {
        val logoAlpha = ObjectAnimator.ofFloat(logo, View.ALPHA, 0f, 1f).apply {
            duration = Anim.SLOW
        }
        val logoScaleX = ObjectAnimator.ofFloat(logo, View.SCALE_X, 0.6f, 1f).apply {
            duration = Anim.EPIC
            interpolator = DecelerateInterpolator()
        }
        val logoScaleY = ObjectAnimator.ofFloat(logo, View.SCALE_Y, 0.6f, 1f).apply {
            duration = Anim.EPIC
            interpolator = DecelerateInterpolator()
        }

        val nameAlpha = ObjectAnimator.ofFloat(name, View.ALPHA, 0f, 1f).apply {
            duration = Anim.NORMAL
            startDelay = 180
        }
        val nameY = ObjectAnimator.ofFloat(name, View.TRANSLATION_Y, 24f, 0f).apply {
            duration = Anim.SLOW
            startDelay = 180
            interpolator = DecelerateInterpolator()
        }

        val tagAlpha = ObjectAnimator.ofFloat(tagline, View.ALPHA, 0f, 1f).apply {
            duration = Anim.NORMAL
            startDelay = 360
        }
        val tagY = ObjectAnimator.ofFloat(tagline, View.TRANSLATION_Y, 16f, 0f).apply {
            duration = Anim.SLOW
            startDelay = 360
            interpolator = DecelerateInterpolator()
        }

        val underlineScale = ObjectAnimator.ofFloat(underline, View.SCALE_X, 0f, 1f).apply {
            duration = Anim.SLOW
            startDelay = 520
            interpolator = DecelerateInterpolator()
        }

        val set = AnimatorSet().apply {
            playTogether(
                logoAlpha, logoScaleX, logoScaleY,
                nameAlpha, nameY,
                tagAlpha, tagY,
                underlineScale
            )
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationStart(animation: android.animation.Animator) {
                    pulse.active = true
                }
            })
        }

        runningAnimators.add(set)
        set.start()

        // Trigger the transition after the full splash duration.
        underline.postDelayed({
            if (!isFinishing) {
                startActivity(Intent(this, MainActivity::class.java))
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                finish()
            }
        }, Anim.SPLASH)
    }
}