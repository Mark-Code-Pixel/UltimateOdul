package com.uno.reverse.ui.widget

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat
import com.uno.reverse.R
import com.uno.reverse.ui.theme.Anim
import com.uno.reverse.ui.theme.ColorPalette
import com.uno.reverse.ui.theme.Typography

/*
 * Primary action button. Draws its own background, supports two
 * variants (filled gold, ghost outline), an animated press scale, and
 * a travelling highlight on tap.
 *
 * The view is not a Button subclass; it is a plain View that manages
 * its own state. This avoids the platform's stateListAnimator and
 * elevation shadows, which fight the design language.
 */
class UnoButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class Variant { Primary, Ghost }

    var variant: Variant = Variant.Primary
        set(value) {
            field = value
            invalidate()
        }

    var label: String = ""
        set(value) {
            field = value
            invalidate()
        }

    var onClick: (() -> Unit)? = null

    // Press animation state.
    private var pressFraction = 0f
    private var pressAnimator: ValueAnimator? = null

    // Travelling highlight state.
    private var shineFraction = -1f
    private var shineAnimator: ValueAnimator? = null

    private val density = resources.displayMetrics.density

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
    }
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typography.bold(context)
        textSize = 17f * resources.displayMetrics.scaledDensity
        color = ColorPalette.BG
    }

    private val rect = RectF()

    init {
        isClickable = true
        isFocusable = true
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    fun setVariant(v: Variant) {
        variant = v
        textPaint.color = when (v) {
            Variant.Primary -> ColorPalette.BG
            Variant.Ghost   -> ColorPalette.GOLD
        }
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = (52 * density).toInt()
        val finalH = when (MeasureSpec.getMode(heightMeasureSpec)) {
            MeasureSpec.EXACTLY -> MeasureSpec.getSize(heightMeasureSpec)
            MeasureSpec.AT_MOST -> minOf(h, MeasureSpec.getSize(heightMeasureSpec))
            else -> h
        }
        setMeasuredDimension(w, finalH)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        val radius = h / 2f

        // Shrink on press.
        val scale = 1f - 0.03f * pressFraction
        val cx = w / 2f
        val cy = h / 2f
        val scaledW = w * scale
        val scaledH = h * scale
        rect.set(
            cx - scaledW / 2f,
            cy - scaledH / 2f,
            cx + scaledW / 2f,
            cy + scaledH / 2f
        )

        when (variant) {
            Variant.Primary -> {
                // Gold fill with a vertical sheen.
                fillPaint.shader = LinearGradient(
                    0f, rect.top, 0f, rect.bottom,
                    intArrayOf(ColorPalette.GOLD_SOFT, ColorPalette.GOLD, ColorPalette.GOLD_DIM),
                    floatArrayOf(0f, 0.5f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRoundRect(rect, radius, radius, fillPaint)

                // Inner top highlight.
                fillPaint.shader = LinearGradient(
                    0f, rect.top, 0f, rect.top + rect.height() * 0.5f,
                    intArrayOf(ColorPalette.withAlpha(0xFFFFFFFF.toInt(), 0.35f), 0x00FFFFFF),
                    floatArrayOf(0f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRoundRect(rect, radius, radius, fillPaint)

                // Travelling shine.
                if (shineFraction in 0f..1f) {
                    val shineX = rect.left + rect.width() * shineFraction
                    val shineW = rect.width() * 0.22f
                    val grad = LinearGradient(
                        shineX - shineW, 0f, shineX + shineW, 0f,
                        intArrayOf(0x00FFFFFF, ColorPalette.withAlpha(0xFFFFFFFF.toInt(), 0.30f), 0x00FFFFFF),
                        floatArrayOf(0f, 0.5f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    shinePaint.shader = grad
                    val save = canvas.save()
                    val clipPath = android.graphics.Path()
                    clipPath.addRoundRect(rect, radius, radius, android.graphics.Path.Direction.CW)
                    canvas.clipPath(clipPath)
                    canvas.drawRect(rect, shinePaint)
                    canvas.restoreToCount(save)
                }
            }
            Variant.Ghost -> {
                // Ghost outline.
                fillPaint.shader = null
                fillPaint.color = ColorPalette.withAlpha(ColorPalette.SURFACE_2, 0.6f)
                canvas.drawRoundRect(rect, radius, radius, fillPaint)

                borderPaint.color = ColorPalette.BORDER
                canvas.drawRoundRect(rect, radius, radius, borderPaint)

                // Top inner highlight.
                fillPaint.color = ColorPalette.GLASS_WHITE_05
                canvas.drawRoundRect(
                    RectF(rect.left + 1, rect.top + 1, rect.right - 1, rect.top + rect.height() * 0.5f),
                    radius, radius, fillPaint
                )
            }
        }

        // Text.
        val fm = textPaint.fontMetrics
        val textY = cy - (fm.ascent + fm.descent) / 2f
        canvas.drawText(label, cx, textY, textPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animatePress(1f)
                return true
            }
            MotionEvent.ACTION_UP -> {
                animatePress(0f)
                if (isEnabled) {
                    runShine()
                    onClick?.invoke()
                    performClick()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                animatePress(0f)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun animatePress(target: Float) {
        pressAnimator?.cancel()
        pressAnimator = ValueAnimator.ofFloat(pressFraction, target).apply {
            duration = Anim.FAST
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                pressFraction = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun runShine() {
        shineAnimator?.cancel()
        shineAnimator = ValueAnimator.ofFloat(-0.2f, 1.2f).apply {
            duration = Anim.SLOW
            addUpdateListener {
                shineFraction = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }
}