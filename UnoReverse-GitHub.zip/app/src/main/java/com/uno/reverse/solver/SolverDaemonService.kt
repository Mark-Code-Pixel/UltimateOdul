package com.uno.reverse.solver
import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.uno.reverse.nativebridge.NativeBridge
import com.uno.reverse.nativebridge.SharedState
import com.uno.reverse.util.Log
import kotlinx.coroutines.*
class SolverDaemonService : Service() {
    private val scope = CoroutineScope(Dispatchers.Default + Job())
    private var job: Job? = null
    override fun onCreate() {
        super.onCreate()
        job = scope.launch {
            while (isActive) {
                if (SharedState.isAutoPlay()) NativeBridge.runSolverTick()
                delay(1000L / SharedState.getSolveRate().coerceIn(5, 60))
            }
        }
        Log.i("SolverDaemon", "started")
    }
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
    override fun onDestroy() { job?.cancel(); super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}
