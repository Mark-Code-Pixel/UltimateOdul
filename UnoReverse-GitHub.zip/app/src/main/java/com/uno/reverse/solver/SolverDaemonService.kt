package com.uno.reverse.solver

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.uno.reverse.R
import com.uno.reverse.nativebridge.NativeBridge
import com.uno.reverse.nativebridge.SharedState
import com.uno.reverse.util.Log as ULog
import java.util.concurrent.atomic.AtomicBoolean

/*
 * Solver status monitor.
 *
 * The solver itself runs inside the guest process (see the native
 * agent's unoreverse_agent_start_solver). This host-side service is a
 * monitor. Its jobs:
 *
 *   1. Keep a foreground notification visible so the OS does not
 *      aggressively trim the host process while the solver is doing
 *      work in the guest.
 *   2. Poll shared memory every second and log the solver's health:
 *      solve time, candidate count, current state.
 *   3. Detect a stalled solver. If the sequence counter has not moved
 *      in 5 seconds while autoplay is enabled and it is our turn, that
 *      is a stall. It logs at WARN.
 *
 * The service does not solve anything itself. Killing it does not
 * affect the solver; the solver lives in the guest.
 */
class SolverDaemonService : Service() {

    companion object {
        const val TAG = "SolverDaemonService"

        const val ACTION_START = "com.uno.reverse.action.START_SOLVER_MONITOR"
        const val ACTION_STOP  = "com.uno.reverse.action.STOP_SOLVER_MONITOR"

        private const val CHANNEL_ID = "unoreverse.solver"
        private const val NOTIFICATION_ID = 0x5503

        private const val POLL_INTERVAL_MS = 1000L
        private const val STALL_THRESHOLD_MS = 5000L

        @JvmStatic
        fun start(context: Context) {
            val i = Intent(context, SolverDaemonService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }

        @JvmStatic
        fun stop(context: Context) {
            try {
                val i = Intent(context, SolverDaemonService::class.java).apply {
                    action = ACTION_STOP
                }
                context.startService(i)
            } catch (_: Throwable) {}
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private var lastSeq = -1
    private var lastSeqChangeMs = 0L
    private var lastWarnMs = 0L

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!running.get()) return
            try {
                pollOnce()
            } catch (t: Throwable) {
                ULog.e(TAG, "poll threw", t)
            }
            mainHandler.postDelayed(this, POLL_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForegroundSafe(buildNotification("Monitoring solver"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopMonitoring()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> startMonitoring()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopMonitoring()
        super.onDestroy()
    }

    // ------------------------------------------------------------------

    private fun startMonitoring() {
        if (!running.compareAndSet(false, true)) return
        ULog.i(TAG, "Solver monitor started")
        lastSeq = -1
        lastSeqChangeMs = System.currentTimeMillis()
        mainHandler.post(pollRunnable)
    }

    private fun stopMonitoring() {
        if (!running.compareAndSet(true, false)) return
        mainHandler.removeCallbacks(pollRunnable)
        ULog.i(TAG, "Solver monitor stopped")
    }

    private fun pollOnce() {
        if (!NativeBridge.isSharedMapped()) {
            updateNotification("Solver idle (no shared region)")
            return
        }

        val s = SharedState.Snapshot()
        NativeBridge.snapshot(s)

        val now = System.currentTimeMillis()

        if (s.seq != lastSeq) {
            lastSeq = s.seq
            lastSeqChangeMs = now
        }

        val idleMs = now - lastSeqChangeMs

        val state = when {
            !s.autoplay -> "Autoplay off"
            !s.isMyTurn -> "Waiting for turn"
            s.readyToFire -> "Ready to fire"
            else -> "Solving"
        }

        updateNotification(
            buildString {
                append(state)
                append("  ·  ")
                append(s.solveTimeUs / 1000).append(" ms")
                append("  ·  ")
                append(s.candidateCount).append(" cand")
            }
        )

        if (s.autoplay && s.isMyTurn && idleMs > STALL_THRESHOLD_MS) {
            if (now - lastWarnMs > STALL_THRESHOLD_MS) {
                lastWarnMs = now
                ULog.w(
                    TAG,
                    "Solver stall detected: idle ${idleMs}ms  " +
                    "seq=${s.seq}  solveUs=${s.solveTimeUs}  cands=${s.candidateCount}"
                )
            }
        }
    }

    // ------------------------------------------------------------------
    // Notification
    // ------------------------------------------------------------------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val mgr = getSystemService(NotificationManager::class.java) ?: return
        if (mgr.getNotificationChannel(CHANNEL_ID) != null) return
        val ch = NotificationChannel(
            CHANNEL_ID,
            "Uno Reverse solver",
            NotificationManager.IMPORTANCE_MIN
        ).apply {
            description = "Solver status and health"
            setShowBadge(false)
        }
        mgr.createNotificationChannel(ch)
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Uno Reverse")
            .setContentText(text)
            .setSmallIcon(R.drawable.uno_reverse_logo)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

    private fun startForegroundSafe(n: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, n,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    private fun updateNotification(text: String) {
        val mgr = getSystemService(NotificationManager::class.java) ?: return
        mgr.notify(NOTIFICATION_ID, buildNotification(text))
    }
}