package com.uno.reverse.ui.widget

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import com.uno.reverse.ui.theme.Anim
import com.uno.reverse.ui.theme.ColorPalette
import kotlin.math.cos
import kotlin.math.sin

/*
 * A slowly drifting aurora background. Three radial gradients orbit
 * around the view's centre on different periods, blended with a base
 * vertical gradient. The result is a calm, dark, expensive-looking
 * backdrop that never repeats visibly.
 *
 * Runs on the UI thread at ~30fps. Cheap because the shaders are
 * rebuilt only when the view size changes, and per-frame work is a
 * single drawRect per layer.
 */
class AuroraBackground @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private var baseShader: Shader? = null
    private var blobA: RadialGradient? = null
    private var blobB: RadialGradient? = null
    private var blobC: RadialGradient? = null

    private var animator: ValueAnimator? = null
    private var phase = 0f

    // Blob centre positions, updated per frame.
    private var ax = 0f; private var ay = 0f
    private var bx = 0f; private var by = 0f
    private var cx = 0f; private var cy = 0f

    private var radiusA = 0f
    private var radiusB = 0f
    private var radiusC = 0f

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        // Base vertical gradient.
        baseShader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(
                ColorPalette.BG,
                ColorPalette.BG_2,
                ColorPalette.BG
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        basePaint.shader = baseShader

        // Blob radii scale with the view size.
        val minDim = minOf(w, h).toFloat()
        radiusA = minDim * 0.70f
        radiusB = minDim * 0.55f
        radiusC = minDim * 0.45f

        rebuildBlobs()
    }

    private fun rebuildBlobs() {
        val w = width.toFloat().coerceAtLeast(1f)
        val h = height.toFloat().coerceAtLeast(1f)
        val minDim = minOf(w, h)

        // Deep purple halo.
        blobA = RadialGradient(
            ax, ay, radiusA,
            intArrayOf(
                ColorPalette.withAlpha(0xFF3A1E6E.toInt(), 0.55f),
                ColorPalette.withAlpha(0xFF3A1E6E.toInt(), 0.18f),
                ColorPalette.withAlpha(0xFF3A1E6E.toInt(), 0f)
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )

        // Warm amber halo.
        blobB = RadialGradient(
            bx, by, radiusB,
            intArrayOf(
                ColorPalette.withAlpha(0xFF7A4A0F.toInt(), 0.45f),
                ColorPalette.withAlpha(0xFF7A4A0F.toInt(), 0.14f),
                ColorPalette.withAlpha(0xFF7A4A0F.toInt(), 0f)
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )

        // Gold sheen.
        blobC = RadialGradient(
            cx, cy, radiusC,
            intArrayOf(
                ColorPalette.withAlpha(ColorPalette.GOLD, 0.28f),
                ColorPalette.withAlpha(ColorPalette.GOLD, 0.08f),
                ColorPalette.withAlpha(ColorPalette.GOLD, 0f)
            ),
            floatArrayOf(0f, 0.6f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startAnimator()
    }

    override fun onDetachedFromWindow() {
        stopAnimator()
        super.onDetachedFromWindow()
    }

    private fun startAnimator() {
        if (animator != null) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = Anim.AURORA
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                updateBlobPositions()
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimator() {
        animator?.cancel()
        animator = null
    }

    private fun updateBlobPositions() {
        val w = width.toFloat().coerceAtLeast(1f)
        val h = height.toFloat().coerceAtLeast(1f)
        val minDim = minOf(w, h)

        // Three orbiters with different periods and phases. The maths
        // is cheap: two trig calls per blob per frame.

        // Slow purple blob — 1 orbit per cycle.
        val thetaA = phase * (2f * Math.PI.toFloat())
        ax = w * 0.30f + cos(thetaA) * minDim * 0.30f
        ay = h * 0.30f + sin(thetaA * 0.7f) * minDim * 0.22f

        // Counter-rotating amber blob — 1.4 orbits per cycle.
        val thetaB = -phase * (2f * Math.PI.toFloat()) * 1.4f
        bx = w * 0.72f + cos(thetaB) * minDim * 0.28f
        by = h * 0.72f + sin(thetaB) * minDim * 0.20f

        // Fast gold sheen — 2 orbits per cycle.
        val thetaC = phase * (2f * Math.PI.toFloat()) * 2f
        cx = w * 0.5f + cos(thetaC) * minDim * 0.20f
        cy = h * 0.5f + sin(thetaC) * minDim * 0.16f

        rebuildBlobs()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Base.
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), basePaint)

        // Three halo layers. Additive-ish blending via alpha.
        blobA?.let {
            blobPaint.shader = it
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), blobPaint)
        }
        blobB?.let {
            blobPaint.shader = it
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), blobPaint)
        }
        blobC?.let {
            blobPaint.shader = it
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), blobPaint)
        }
    }
}