package com.uno.reverse.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import com.uno.reverse.R
import com.uno.reverse.inject.ShotExecutor
import com.uno.reverse.overlay.OverlayController
import com.uno.reverse.shizuku.ShizukuBridge
import com.uno.reverse.ui.LauncherActivity
import com.uno.reverse.virtual.PackageClone
import com.uno.reverse.virtual.VirtualEngine

/**
 * Foreground engine — virtual container path only + Shizuku assist.
 */
class UnoEngineService : Service() {

    private var overlay: OverlayController? = null
    private var recovery: CrashRecovery? = null
    private val handler = Handler(Looper.getMainLooper())
    private var monitorRunnable: Runnable? = null
    private var attachAttempts = 0
    private var tick = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        EngineConfig.applyToNative()
        NativeBridge.startEngine(NativeBridge.MODE_FULL)

        try {
            overlay = OverlayController(this).also { it.show() }
        } catch (t: Throwable) {
            Log.w(TAG, "Overlay not available", t)
        }

        recovery = CrashRecovery(this).also { it.start() }

        // Path A only
        VirtualEngine.start(this)
        scheduleAttachRetries()
        startMonitor()
        return START_STICKY
    }

    override fun onDestroy() {
        stopMonitor()
        handler.removeCallbacksAndMessages(null)
        recovery?.stop()
        recovery = null
        ShotExecutor.clear(overlay)
        overlay?.hide()
        overlay = null
        VirtualEngine.stop()
        NativeBridge.stopEngine()
        super.onDestroy()
    }

    /** Retry native attach until engine maps / physics appears (smooth, no spam). */
    private fun scheduleAttachRetries() {
        attachAttempts = 0
        val retry = object : Runnable {
            override fun run() {
                attachAttempts++
                try {
                    val ok = NativeBridge.attachCarrom()
                    val phys = NativeBridge.pollPhysics()
                    val status = NativeBridge.getReaderStatus()
                    Log.i(TAG, "attach#$attachAttempts ok=$ok phys=${phys.found} $status")
                    recovery?.notifyAlive()
                    if (phys.found || attachAttempts >= 12) return
                } catch (t: Throwable) {
                    Log.w(TAG, "attach retry", t)
                }
                handler.postDelayed(this, 2500)
            }
        }
        handler.postDelayed(retry, 2000)
    }

    private fun startMonitor() {
        stopMonitor()
        monitorRunnable = object : Runnable {
            override fun run() {
                tick++
                val state = try {
                    NativeBridge.getEngineState()
                } catch (_: Throwable) {
                    0
                }
                if (state != 1) {
                    handler.postDelayed(this, 800)
                    return
                }
                recovery?.notifyAlive()

                if (tick % 16 == 0) {
                    val st = VirtualEngine.status(this@UnoEngineService)
                    Log.i(TAG, "virtual: ${st.detail} shizuku=${st.shizuku}")
                }

                val shot = NativeBridge.pollShot()
                if (shot.valid) {
                    ShotExecutor.execute(
                        overlay,
                        shot.startX, shot.startY,
                        shot.endX, shot.endY,
                        shot.power
                    )
                }
                handler.postDelayed(this, 350)
            }
        }
        handler.post(monitorRunnable!!)
    }

    private fun stopMonitor() {
        monitorRunnable?.let { handler.removeCallbacks(it) }
        monitorRunnable = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Uno Reverse Engine",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Virtual Carrom engine"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, LauncherActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val src = PackageClone.resolveSource(this)
        val sh = ShizukuBridge.probe(this)
        val line = when {
            src == null -> "Install Carrom Pool from Play"
            !src.engineArtifacts.isEmpty() && sh.running ->
                "Virtual · engine SO · Shizuku ON · v${src.versionName}"
            !src.engineArtifacts.isEmpty() ->
                "Virtual · engine SO · start Shizuku · v${src.versionName}"
            else ->
                "Open Carrom once for feature module"
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Uno Reverse")
            .setContentText(line)
            .setSmallIcon(R.drawable.ic_uno_notification)
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    companion object {
        private const val TAG = "UnoEngineService"
        private const val CHANNEL_ID = "uno_engine"
        private const val NOTIFICATION_ID = 7701
    }
}
