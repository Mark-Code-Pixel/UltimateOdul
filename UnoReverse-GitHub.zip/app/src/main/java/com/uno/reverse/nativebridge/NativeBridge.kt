package com.uno.reverse.nativebridge

import android.os.Build
import com.uno.reverse.util.Log as ULog
import java.io.File

/*
 * JNI surface for libunoreverse.so.
 *
 * Two sets of calls live here:
 *   1. Container-side calls used by ContainerService.
 *   2. Overlay-side calls used by OverlayService to read shared state
 *      and write control flags.
 *
 * All methods are safe to call before load(). They return benign
 * defaults.
 */
object NativeBridge {

    private const val TAG = "NativeBridge"
    private const val LIB_NAME = "unoreverse"

    @Volatile private var loaded = false

    // ---- Container side -------------------------------------------

    external fun nativeInit(agentDir: String, ashmemName: String): Int
    external fun nativeAgentReady(): Boolean
    external fun nativeInventoryComplete(): Boolean
    external fun nativeEngineName(): String
    external fun nativeActiveAbi(): String
    external fun nativeDefaultProfile(): String
    external fun nativeStartRuntimeDump(guestPkg: String, outputPath: String): Int
    external fun nativeInstallHooks(offsetsPath: String): Int
    external fun nativeStartSolver(): Int
    external fun nativeStopSolver()
    external fun nativeResolveOffsets(reportPath: String, outputPath: String, reasonHolder: String): Int
    external fun nativeShutdown()

    // ---- Overlay side ---------------------------------------------

    external fun nativeCreateSharedRegion(): String
    external fun nativeMapSharedRegion(path: String): Int
    external fun nativeUnmapSharedRegion()
    external fun nativeIsSharedMapped(): Boolean
    external fun nativeSnapshot(out: SharedState.Snapshot)
    external fun nativeSetFlag(flag: Int, value: Int): Boolean
    external fun nativeGetLine(index: Int, out: FloatArray): Boolean

    // ---- Lifecycle -------------------------------------------------

    @JvmStatic
    fun load(): Boolean {
        if (loaded) return true
        return try {
            System.loadLibrary(LIB_NAME)
            loaded = true
            ULog.i(TAG, "libunoreverse loaded. abi=${activeAbi()}")
            true
        } catch (t: Throwable) {
            ULog.e(TAG, "libunoreverse not loadable", t)
            false
        }
    }

    @JvmStatic fun isLoaded(): Boolean = loaded

    @JvmStatic
    fun activeAbi(): String =
        if (loaded) try { nativeActiveAbi() } catch (_: Throwable) { fallbackAbi() }
        else fallbackAbi()

    @JvmStatic
    fun defaultProfile(): String =
        if (loaded) try { nativeDefaultProfile() } catch (_: Throwable) { "auto" }
        else "auto"

    @JvmStatic
    fun engineName(): String =
        if (loaded) try { nativeEngineName() } catch (_: Throwable) { "unknown" }
        else "unknown"

    @JvmStatic
    fun startRuntimeDump(guestPkg: String, outputDir: File): Boolean {
        if (!loaded) return false
        return try {
            if (!outputDir.exists()) outputDir.mkdirs()
            val out = File(outputDir, "runtime_inventory.json").absolutePath
            nativeStartRuntimeDump(guestPkg, out) == 0
        } catch (t: Throwable) {
            ULog.e(TAG, "startRuntimeDump failed", t)
            false
        }
    }

    @JvmStatic
    fun installHooks(offsetsJsonPath: String): Boolean {
        if (!loaded) return false
        return try {
            nativeInstallHooks(offsetsJsonPath) == 0
        } catch (t: Throwable) {
            ULog.e(TAG, "installHooks failed", t)
            false
        }
    }

    @JvmStatic
    fun startSolver(): Boolean {
        if (!loaded) return false
        return try {
            nativeStartSolver() == 0
        } catch (t: Throwable) {
            ULog.e(TAG, "startSolver failed", t)
            false
        }
    }

    @JvmStatic
    fun stopSolver() {
        if (!loaded) return
        try { nativeStopSolver() } catch (_: Throwable) {}
    }

    @JvmStatic
    fun resolveOffsets(reportPath: String, outputPath: String): Pair<Boolean, String> {
        if (!loaded) return false to "native bridge not loaded"
        return try {
            val rc = nativeResolveOffsets(reportPath, outputPath, "")
            val reasonFile = File("$outputPath.reason")
            val reason = if (reasonFile.exists() && reasonFile.length() > 0L)
                reasonFile.readText().trim()
            else ""
            (rc == 0) to reason
        } catch (t: Throwable) {
            ULog.e(TAG, "resolveOffsets failed", t)
            false to (t.message ?: "unknown")
        }
    }

    // ---- Shared memory --------------------------------------------

    @JvmStatic
    fun createSharedRegion(): String {
        if (!loaded) return ""
        return try {
            nativeCreateSharedRegion()
        } catch (t: Throwable) {
            ULog.e(TAG, "createSharedRegion failed", t)
            ""
        }
    }

    @JvmStatic
    fun mapSharedRegion(path: String): Boolean {
        if (!loaded) return false
        return try {
            nativeMapSharedRegion(path) == 0
        } catch (t: Throwable) {
            ULog.e(TAG, "mapSharedRegion failed", t)
            false
        }
    }

    @JvmStatic
    fun unmapSharedRegion() {
        if (!loaded) return
        try { nativeUnmapSharedRegion() } catch (_: Throwable) {}
    }

    @JvmStatic
    fun isSharedMapped(): Boolean =
        if (loaded) try { nativeIsSharedMapped() } catch (_: Throwable) { false }
        else false

    @JvmStatic
    fun snapshot(out: SharedState.Snapshot) {
        if (!loaded) { out.mapped = false; return }
        try {
            nativeSnapshot(out)
        } catch (_: Throwable) {
            out.mapped = false
        }
    }

    @JvmStatic
    fun setFlag(flag: Int, value: Int): Boolean {
        if (!loaded) return false
        return try {
            nativeSetFlag(flag, value)
        } catch (_: Throwable) {
            false
        }
    }

    @JvmStatic
    fun getLine(index: Int, out: FloatArray): Boolean {
        if (!loaded) return false
        return try {
            nativeGetLine(index, out)
        } catch (_: Throwable) {
            false
        }
    }

    @JvmStatic
    fun shutdown() {
        if (!loaded) return
        try { nativeShutdown() } catch (_: Throwable) {}
    }

    private fun fallbackAbi(): String =
        Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"

    fun getAimLine(): FloatArray {
        val out = FloatArray(4)
        if (!loaded) return out
        return try {
            if (nativeGetLine(0, out)) out else FloatArray(4)
        } catch (_: Throwable) { FloatArray(4) }
    } catch (_: Throwable) { floatArrayOf(0f, 0f, 0f, 0f) }
    }
    

}