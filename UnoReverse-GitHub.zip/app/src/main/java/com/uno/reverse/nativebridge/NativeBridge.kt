package com.uno.reverse.nativebridge
import com.uno.reverse.util.Log
object NativeBridge {
    private var loaded = false
    init {
        try { System.loadLibrary("unoreverse"); loaded = true; Log.i("NativeBridge", "loaded") }
        catch (e: UnsatisfiedLinkError) { Log.e("NativeBridge", "${e.message}") }
    }
    fun loadAgent(libDir: String) { if (loaded) nativeLoadAgent(libDir) }
    fun installHooks() { if (loaded) nativeInstallHooks() }
    fun runSolverTick() { if (loaded) nativeSolverTick() }
    private external fun nativeLoadAgent(libDir: String)
    private external fun nativeInstallHooks()
    private external fun nativeSolverTick()
}
