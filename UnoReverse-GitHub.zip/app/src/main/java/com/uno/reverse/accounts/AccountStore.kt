package com.uno.reverse.accounts

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.uno.reverse.util.Log as ULog
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/*
 * Per-guest account store.
 *
 * Each guest gets its own directory under
 * <filesDir>/unoreverse/virtual/<guest>/accounts/. Values written
 * through this store are encrypted with a per-guest AES-GCM key held
 * in the Android Keystore. The plaintext never touches disk.
 *
 * Two files per guest:
 *   store.enc   — encrypted key/value blob, rewritten on each put
 *   meta.txt    — non-sensitive metadata (guest package, created time)
 *
 * The store is used for:
 *   - the guest's original UID (used by Binder UID spoofing)
 *   - Google Sign-In tokens
 *   - Facebook Login tokens
 *   - the guest's virtual data directory path
 *
 * Any read or write that fails returns a safe default. Nothing in the
 * container crashes because a token could not be read.
 */
class AccountStore(private val guestPackage: String) {

    private val keyAlias = "unoreverse_account_$guestPackage"

    private fun storeFile(context: Context): File {
        val dir = File(context.filesDir, "unoreverse/virtual/$guestPackage/accounts")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "store.enc")
    }

    private fun metaFile(context: Context): File {
        val dir = File(context.filesDir, "unoreverse/virtual/$guestPackage/accounts")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "meta.txt")
    }

    // ------------------------------------------------------------------

    fun put(context: Context, key: String, value: String) {
        val existing = loadAll(context).toMutableMap()
        existing[key] = value
        saveAll(context, existing)
    }

    fun get(context: Context, key: String): String? = loadAll(context)[key]

    fun remove(context: Context, key: String) {
        val existing = loadAll(context).toMutableMap()
        existing.remove(key)
        saveAll(context, existing)
    }

    fun clear(context: Context) {
        try {
            storeFile(context).delete()
            metaFile(context).delete()
        } catch (t: Throwable) {
            ULog.e(TAG, "clear failed", t)
        }
    }

    fun writeMeta(context: Context, text: String) {
        try {
            metaFile(context).writeText(text)
        } catch (_: Throwable) {}
    }

    fun readMeta(context: Context): String? = try {
        val f = metaFile(context)
        if (f.exists() && f.length() > 0L) f.readText() else null
    } catch (_: Throwable) {
        null
    }

    // ------------------------------------------------------------------
    // Encrypted map storage
    // ------------------------------------------------------------------

    private fun loadAll(context: Context): Map<String, String> {
        return try {
            val f = storeFile(context)
            if (!f.exists() || f.length() == 0L) return emptyMap()

            val cipher = Cipher.getInstance(TRANSFORM)
            val key = getOrCreateKey()
            val iv = ByteArray(IV_BYTES)
            val fileBytes = f.readBytes()
            if (fileBytes.size < IV_BYTES) return emptyMap()
            System.arraycopy(fileBytes, 0, iv, 0, IV_BYTES)
            val ciphertext = fileBytes.copyOfRange(IV_BYTES, fileBytes.size)

            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_BITS, iv))
            val plain = cipher.doFinal(ciphertext)
            parseKv(String(plain, Charsets.UTF_8))
        } catch (t: Throwable) {
            ULog.w(TAG, "loadAll failed for $guestPackage: ${t.message}")
            emptyMap()
        }
    }

    private fun saveAll(context: Context, map: Map<String, String>) {
        try {
            val key = getOrCreateKey()
            val cipher = Cipher.getInstance(TRANSFORM)
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val iv = cipher.iv
            val plain = serializeKv(map).toByteArray(Charsets.UTF_8)
            val ciphertext = cipher.doFinal(plain)

            val out = ByteArray(iv.size + ciphertext.size)
            System.arraycopy(iv, 0, out, 0, iv.size)
            System.arraycopy(ciphertext, 0, out, iv.size, ciphertext.size)

            val f = storeFile(context)
            f.writeBytes(out)
        } catch (t: Throwable) {
            ULog.e(TAG, "saveAll failed for $guestPackage", t)
        }
    }

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)

        val existing = ks.getKey(keyAlias, null)
        if (existing is SecretKey) return existing

        val gen = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            "AndroidKeyStore"
        )
        val spec = KeyGenParameterSpec.Builder(
            keyAlias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        gen.init(spec)
        return gen.generateKey()
    }

    // ------------------------------------------------------------------
    // Simple key=value serialization. Each line is key<TAB>value.
    // Values may contain anything except a newline.
    // ------------------------------------------------------------------

    private fun serializeKv(map: Map<String, String>): String {
        val sb = StringBuilder()
        for ((k, v) in map) {
            sb.append(k.replace('\t', ' ').replace('\n', ' '))
            sb.append('\t')
            sb.append(v.replace('\n', ' '))
            sb.append('\n')
        }
        return sb.toString()
    }

    private fun parseKv(text: String): Map<String, String> {
        val out = HashMap<String, String>()
        for (line in text.split('\n')) {
            if (line.isEmpty()) continue
            val tab = line.indexOf('\t')
            if (tab <= 0) continue
            val k = line.substring(0, tab)
            val v = line.substring(tab + 1)
            out[k] = v
        }
        return out
    }

    companion object {
        private const val TAG = "AccountStore"
        private const val TRANSFORM = "AES/GCM/NoPadding"
        private const val IV_BYTES = 12
        private const val TAG_BITS = 128
    }
}