package com.uno.reverse.accounts
import android.accounts.Account
import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
object AccountStore {
    private lateinit var prefs: SharedPreferences
    fun init(c: Context) { prefs = c.getSharedPreferences("ur_accounts", Context.MODE_PRIVATE) }
    fun getAccounts(type: String?): List<Account> {
        val all = getAll(); return if (type == null) all else all.filter { it.type == type }
    }
    fun getAll(): List<Account> {
        val arr = JSONArray(prefs.getString("accounts", "[]"))
        return (0 until arr.length()).map { Account(arr.getJSONObject(it).getString("name"), arr.getJSONObject(it).getString("type")) }
    }
    fun add(name: String, type: String) {
        val l = getAll().toMutableList()
        if (l.none { it.name == name && it.type == type }) { l.add(Account(name, type)); persist(l) }
    }
    private fun persist(l: List<Account>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("name", it.name).put("type", it.type)) }
        prefs.edit().putString("accounts", a.toString()).apply()
    }
}
