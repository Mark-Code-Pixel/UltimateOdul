package com.uno.reverse.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.uno.reverse.R
import com.uno.reverse.core.BoardSelector
import com.uno.reverse.core.EngineConfig
import com.uno.reverse.core.NativeBridge
import com.uno.reverse.core.PermissionHelper
import com.uno.reverse.core.UnoEngineService
import com.uno.reverse.databinding.ActivityLauncherBinding
import com.uno.reverse.virtual.VirtualContainer
import com.uno.reverse.virtual.VirtualCore
import com.uno.reverse.virtual.ContainerStrategy
import com.uno.reverse.virtual.VirtualEngine
import com.uno.reverse.ui.EngineLoadingActivity
import com.uno.reverse.shizuku.ShizukuBridge

class LauncherActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLauncherBinding
    private var engineRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLauncherBinding.inflate(layoutInflater)
        setContentView(binding.root)

        EngineConfig.load(this)
        bindUiFromConfig()
        setupListeners()
        updateStatus()
        updateCarromLinkStatus()
        updatePermissionHint()
    }

    private fun bindUiFromConfig() {
        binding.swAutoPlay.isChecked = EngineConfig.autoPlay
        binding.swAutoQueue.isChecked = EngineConfig.autoQueue
        binding.swAimAssist.isChecked = EngineConfig.aimAssist
        binding.swHideLine.isChecked = EngineConfig.hideLine
        binding.swHideStream.isChecked = EngineConfig.hideStream

        when (EngineConfig.speedMode) {
            0 -> binding.tgSpeed.check(R.id.btnHuman)
            1 -> binding.tgSpeed.check(R.id.btnFast)
            2 -> binding.tgSpeed.check(R.id.btnUltra)
        }
    }

    private fun setupListeners() {
        binding.swAutoPlay.setOnCheckedChangeListener { _, checked ->
            EngineConfig.autoPlay = checked
            EngineConfig.save()
            if (engineRunning) NativeBridge.setAutoPlay(checked)
            if (checked && !PermissionHelper.isAccessibilityEnabled(this)) {
                promptAccessibility()
            }
        }
        binding.swAutoQueue.setOnCheckedChangeListener { _, checked ->
            EngineConfig.autoQueue = checked
            EngineConfig.save()
            if (engineRunning) NativeBridge.setAutoQueue(checked)
        }
        binding.swAimAssist.setOnCheckedChangeListener { _, checked ->
            EngineConfig.aimAssist = checked
            EngineConfig.save()
            if (engineRunning) NativeBridge.setAimAssist(checked)
        }
        binding.swHideLine.setOnCheckedChangeListener { _, checked ->
            EngineConfig.hideLine = checked
            EngineConfig.save()
            if (engineRunning) NativeBridge.setHideLine(checked)
        }
        binding.swHideStream.setOnCheckedChangeListener { _, checked ->
            EngineConfig.hideStream = checked
            EngineConfig.save()
            if (engineRunning) NativeBridge.setHideStream(checked)
        }

        binding.tgSpeed.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val mode = when (checkedId) {
                R.id.btnHuman -> 0
                R.id.btnFast -> 1
                R.id.btnUltra -> 2
                else -> 1
            }
            EngineConfig.speedMode = mode
            EngineConfig.save()
            if (engineRunning) NativeBridge.setSpeedMode(mode)
        }

        binding.btnStart.setOnClickListener {
            if (engineRunning) stopEngine() else startEngine()
        }

        binding.btnLinkCarrom.setOnClickListener {
            if (VirtualContainer.isCarromInstalled(this)) {
                showBoardPicker()
            } else {
                try {
                    startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.miniclip.carrom"))
                    )
                } catch (_: Exception) {
                    startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://play.google.com/store/apps/details?id=com.miniclip.carrom")
                        )
                    )
                }
            }
        }
    }

    private fun promptAccessibility() {
        AlertDialog.Builder(this)
            .setTitle("AutoPlay needs Accessibility")
            .setMessage(getString(R.string.accessibility_desc))
            .setPositiveButton("Open Settings") { _, _ ->
                PermissionHelper.openAccessibilitySettings(this)
            }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun ensurePermissionsForStart(): Boolean {
        if (!PermissionHelper.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission required", Toast.LENGTH_LONG).show()
            PermissionHelper.openOverlaySettings(this)
            return false
        }
        if (EngineConfig.autoPlay && !PermissionHelper.isAccessibilityEnabled(this)) {
            promptAccessibility()
            return false
        }
        if (!PermissionHelper.isIgnoringBatteryOptimizations(this)) {
            // Non-blocking – just open once
            PermissionHelper.openBatteryOptimizationSettings(this)
        }
        return true
    }

    private fun showBoardPicker() {
        val labels = BoardSelector.OPTIONS.map { "${it.label}  (${it.stakeHint})" }.toTypedArray()
        val currentIndex = BoardSelector.OPTIONS
            .indexOfFirst { it.id == EngineConfig.boardFilter }
            .coerceAtLeast(0)

        AlertDialog.Builder(this)
            .setTitle("Board / Stake Filter")
            .setSingleChoiceItems(labels, currentIndex) { dialog, which ->
                val opt = BoardSelector.OPTIONS[which]
                EngineConfig.boardFilter = opt.id
                EngineConfig.save()
                NativeBridge.setBoardFilter(opt.id)
                updateCarromLinkStatus()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startEngine() {
        if (!ensurePermissionsForStart()) return

        if (!VirtualContainer.isCarromInstalled(this)) {
            Toast.makeText(this, "Install Carrom Pool first", Toast.LENGTH_LONG).show()
            return
        }

        engineRunning = true
        startActivity(Intent(this, EngineLoadingActivity::class.java))
        binding.btnStart.text = "STOP ENGINE"
        updateStatus()
        updatePermissionHint()
    }

    private fun stopEngine() {
        stopService(Intent(this, UnoEngineService::class.java))
        NativeBridge.stopEngine()
        engineRunning = false
        binding.btnStart.text = getString(R.string.start_engine)
        updateStatus()
    }

    private fun updateStatus() {
        val state = try {
            NativeBridge.getEngineState()
        } catch (_: Throwable) {
            0
        }

        when {
            engineRunning || state == 1 -> {
                binding.tvStatus.text = getString(R.string.status_running)
                binding.tvStatusSub.text = buildString {
                    append("AutoPlay ")
                    append(if (EngineConfig.autoPlay) "ON" else "OFF")
                    append("  •  Queue ")
                    append(if (EngineConfig.autoQueue) "ON" else "OFF")
                    append("  •  ")
                    append(BoardSelector.labelFor(EngineConfig.boardFilter))
                }
                binding.tvStatus.setTextColor(getColor(R.color.uno_success))
            }
            else -> {
                binding.tvStatus.text = getString(R.string.status_idle)
                val st = ContainerStrategy.evaluate(this)
                val bits = buildList {
                    if (st.engineModuleHint) add("engine SO")
                    if (st.clonePathReady) add("clone")
                    if (st.shizukuRunning) add("Shizuku")
                    if (st.physicsFound) add("physics")
                }.joinToString(" · ")
                binding.tvStatusSub.text = if (bits.isEmpty()) st.message else (st.message + " · " + bits)
                binding.tvStatus.setTextColor(getColor(R.color.uno_white))
            }
        }
    }

    private fun updateCarromLinkStatus() {
        val info = VirtualCore.probe(this)
        if (info.installed) {
            val board = BoardSelector.labelFor(EngineConfig.boardFilter)
            binding.btnLinkCarrom.text = "${VirtualCore.summary(info)} • Board: $board"
        } else {
            binding.btnLinkCarrom.text = getString(R.string.install_carrom)
        }
    }

    private fun updatePermissionHint() {
        val missing = PermissionHelper.missingPermissions(this)
        if (missing.isEmpty()) {
            // keep status as-is
        } else if (!engineRunning) {
            binding.tvStatusSub.text = "Need: ${missing.joinToString(", ")}"
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        updateCarromLinkStatus()
        updatePermissionHint()
    }
}
