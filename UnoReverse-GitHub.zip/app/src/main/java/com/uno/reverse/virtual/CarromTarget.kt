package com.uno.reverse.virtual

/**
 * Known package names and versions for Miniclip Carrom Pool.
 * Used by the virtual container and engine to locate the real game.
 */
object CarromTarget {

    /** Official Miniclip package on Play Store */
    const val PACKAGE = "com.miniclip.carrom"

    /** Alternate / older package names sometimes seen */
    val ALTERNATE_PACKAGES = listOf(
        "com.miniclip.carrom",
        "com.miniclip.carrompool",
        "com.miniclip.soccer" // never used, kept for safety filter
    )

    /** Main activity that launches the game lobby */
    const val LAUNCH_ACTIVITY = "com.miniclip.carrom.SplashActivity"

    /** Process name when running */
    const val PROCESS_NAME = "com.miniclip.carrom"
}
