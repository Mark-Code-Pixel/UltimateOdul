package com.uno.reverse.ui.theme

import android.content.Context
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import com.uno.reverse.R

/*
 * Typeface cache. Loads the Manrope family once and hands out
 * regular/medium/bold Typeface instances. Falls back to the system
 * sans-serif if the font resources are not present so the app never
 * crashes for a missing asset.
 */
object Typography {

    @Volatile private var regular: Typeface? = null
    @Volatile private var medium: Typeface? = null
    @Volatile private var bold: Typeface? = null

    fun regular(context: Context): Typeface {
        regular?.let { return it }
        val tf = load(context, R.font.manrope_regular) ?: Typeface.SANS_SERIF
        regular = tf
        return tf
    }

    fun medium(context: Context): Typeface {
        medium?.let { return it }
        val tf = load(context, R.font.manrope_medium) ?: Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        medium = tf
        return tf
    }

    fun bold(context: Context): Typeface {
        bold?.let { return it }
        val tf = load(context, R.font.manrope_bold) ?: Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        bold = tf
        return tf
    }

    private fun load(context: Context, resId: Int): Typeface? = try {
        ResourcesCompat.getFont(context, resId)
    } catch (_: Throwable) {
        null
    }
}