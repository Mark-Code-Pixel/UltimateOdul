package com.uno.reverse.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import com.uno.reverse.core.EngineConfig

/**
 * Aim line overlay + floating control panel (AutoPlay toggles on top of Carrom).
 */
class OverlayController(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: AimOverlayView? = null
    private var floatPanel: FloatControlPanel? = null
    private var isShowing = false

    fun show() {
        if (isShowing) return

        val view = AimOverlayView(context)
        overlayView = view

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            LayoutParams.TYPE_PHONE
        }

        val flags = LayoutParams.FLAG_NOT_FOCUSABLE or
                LayoutParams.FLAG_NOT_TOUCHABLE or
                LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                LayoutParams.FLAG_LAYOUT_NO_LIMITS

        val finalFlags = if (EngineConfig.hideStream && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            flags or LayoutParams.FLAG_SECURE
        } else {
            flags
        }

        val params = LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.MATCH_PARENT,
            type,
            finalFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }

        try {
            windowManager.addView(view, params)
            isShowing = true
        } catch (_: Throwable) {
            overlayView = null
        }

        // Floating feature panel on top of the game
        try {
            floatPanel = FloatControlPanel(context).also { it.show() }
        } catch (_: Throwable) {
            floatPanel = null
        }
    }

    fun hide() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Throwable) {
            }
        }
        overlayView = null
        floatPanel?.hide()
        floatPanel = null
        isShowing = false
    }

    fun updateAimLine(x1: Float, y1: Float, x2: Float, y2: Float, show: Boolean) {
        overlayView?.setAimLine(x1, y1, x2, y2, show)
    }

    fun clearAim() {
        overlayView?.clearAim()
    }
}
