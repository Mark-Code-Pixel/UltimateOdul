package com.uno.reverse.virtual

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import java.io.File

/**
 * Exactly how commercial tools grab Carrom Pool's feature module.
 *
 * Confirmed from BitAIM+ decompile (chocapikk.com, Sep 2026):
 *
 * ```
 * String parent = applicationInfo.publicSourceDir;
 * if (parent == null) parent = applicationInfo.sourceDir;
 * if (applicationInfo.splitPublicSourceDirs != null
 *  || applicationInfo.splitSourceDirs != null) {
 *     parent = new File(parent).getParent(); // whole split set
 * }
 * VirtualCore.get().installPackage(path, flags);
 * ```
 *
 * They never ship the game. User installs from Play → tool clones
 * the **parent directory** so base + ABI splits + feature module
 * (libgame-CARROM-*-1477.so) all enter the virtual container together.
 *
 * Version mismatch → uninstall sandbox copy → re-clone.
 */
object PackageClone {

    private const val TAG = "UnoClone"
    const val CARROM_PKG = "com.miniclip.carrom"

    data class CloneSource(
        val packageName: String,
        val versionName: String?,
        val versionCode: Long,
        /** Directory to pass to installPackage (parent of base when splits exist). */
        val installPath: String,
        val baseApk: String,
        val splitApks: List<String>,
        val hasSplits: Boolean,
        val engineArtifacts: List<String>
    )

    /**
     * Resolve the same path BitAIM / VirtualApp use for cloning.
     * Returns null if Carrom is not installed.
     */
    fun resolveSource(context: Context): CloneSource? {
        return try {
            val pm = context.packageManager
            val flags = PackageManager.GET_META_DATA
            val pi = if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(CARROM_PKG, PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(CARROM_PKG, flags)
            }
            val ai: ApplicationInfo = pi.applicationInfo ?: return null

            var path = ai.publicSourceDir ?: ai.sourceDir ?: return null
            val baseApk = path
            val splits = mutableListOf<String>()
            ai.splitPublicSourceDirs?.let { splits.addAll(it) }
            ai.splitSourceDirs?.forEach { if (it !in splits) splits.add(it) }

            val hasSplits = splits.isNotEmpty() ||
                    ai.splitPublicSourceDirs != null ||
                    ai.splitSourceDirs != null

            // THE critical line every commercial tool uses:
            if (hasSplits) {
                path = File(path).parent ?: path
            }

            val engines = mutableListOf<String>()
            try {
                File(path).walkTopDown().maxDepth(6).forEach { f ->
                    if (f.isFile && (
                            f.name.contains("libgame-CARROM") ||
                            f.name.contains("CARROM-GooglePlay-Gold")
                            )
                    ) {
                        engines.add(f.absolutePath)
                    }
                }
            } catch (t: Throwable) {
                Log.w(TAG, "engine walk failed", t)
            }

            val vCode = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else {
                @Suppress("DEPRECATION")
                pi.versionCode.toLong()
            }

            CloneSource(
                packageName = CARROM_PKG,
                versionName = pi.versionName,
                versionCode = vCode,
                installPath = path,
                baseApk = baseApk,
                splitApks = splits,
                hasSplits = hasSplits,
                engineArtifacts = engines
            )
        } catch (e: PackageManager.NameNotFoundException) {
            null
        } catch (t: Throwable) {
            Log.e(TAG, "resolveSource failed", t)
            null
        }
    }

    /**
     * Describe what would be cloned — for UI / logs.
     * Actual VirtualCore.installPackage requires the VirtualApp runtime dependency.
     */
    fun describe(src: CloneSource): String = buildString {
        append("path=").append(src.installPath)
        append(" ver=").append(src.versionName).append(" (").append(src.versionCode).append(")")
        append(" splits=").append(src.splitApks.size)
        append(" engineFiles=").append(src.engineArtifacts.size)
        if (src.engineArtifacts.isNotEmpty()) {
            append(" [").append(src.engineArtifacts.joinToString { File(it).name }).append("]")
        }
    }

    /**
     * Hook for VirtualApp-style install.
     * When a VirtualCore implementation is linked, this becomes:
     *   VirtualCore.get().installPackage(src.installPath, flags)
     * and on version mismatch:
     *   VirtualCore.get().uninstallPackage(CARROM_PKG) then re-install.
     *
     * Until that runtime is embedded, we only report readiness.
     */
    fun requestClone(context: Context): CloneResult {
        val src = resolveSource(context)
            ?: return CloneResult(false, "Carrom Pool not installed on device – install from Play first")

        Log.i(TAG, "clone source: ${describe(src)}")

        if (!src.hasSplits && src.engineArtifacts.isEmpty()) {
            return CloneResult(
                false,
                "No splits/feature module visible. Open Carrom Pool once from Play so the engine module downloads, then retry."
            )
        }

        if (src.engineArtifacts.isEmpty()) {
            return CloneResult(
                true,
                "Clone path ready (${src.installPath}) but libgame-CARROM* not found in tree yet. Open Carrom once, then re-probe."
            )
        }

        // Full installPackage requires VirtualApp core – signal ready for that step
        return CloneResult(
            true,
            "READY TO CLONE: ${describe(src)}. Wire VirtualCore.installPackage(installPath) for same-UID guest."
        )
    }

    data class CloneResult(val ok: Boolean, val message: String)
}
