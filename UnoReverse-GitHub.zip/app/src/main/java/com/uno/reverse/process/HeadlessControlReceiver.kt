package com.uno.reverse.process
import android.content.*
import com.uno.reverse.nativebridge.SharedState
import com.uno.reverse.util.Log
import org.json.JSONObject
import java.io.File
class HeadlessControlReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context?, i: Intent?) {
        if (c == null) return
        if (i?.getStringExtra("token") != "ur_headless_v1") return
        val cfg = i.getStringExtra("config") ?: File(c.getExternalFilesDir(null), "headless.json").takeIf { it.exists() }?.readText() ?: return
        try {
            val o = JSONObject(cfg)
            SharedState.setAutoPlay(o.optBoolean("autoplay", true))
            SharedState.setAutoQueue(o.optBoolean("autoqueue", true))
            SharedState.setKeepLine(o.optBoolean("keepLine", true))
            SharedState.setSolveRate(o.optInt("solveRateHz", 30))
            Log.i("Headless", "applied")
        } catch (e: Exception) { Log.e("Headless", "${e.message}") }
    }
}
