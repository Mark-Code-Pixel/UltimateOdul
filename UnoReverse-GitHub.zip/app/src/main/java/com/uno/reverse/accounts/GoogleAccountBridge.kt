package com.uno.reverse.accounts
import android.accounts.AccountManager
import android.content.Context
import com.uno.reverse.util.Log
object GoogleAccountBridge {
    fun bridge(c: Context): Boolean = try {
        val accs = AccountManager.get(c).getAccountsByType("com.google")
        accs.forEach { AccountStore.add(it.name, "com.google") }
        Log.i("GoogleBridge", "${accs.size} accounts"); accs.isNotEmpty()
    } catch (e: Exception) { Log.e("GoogleBridge", "${e.message}"); false }
}
