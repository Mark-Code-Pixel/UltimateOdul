package com.uno.reverse.accounts

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.uno.reverse.util.Log as ULog
import java.io.File

/*
 * Google Sign-In bridge.
 *
 * The container does not implement Google Sign-In itself. It exposes
 * three paths:
 *
 *   1. Guest-installed GMS. The user installs com.google.android.gms
 *      into the container, and the guest's Google API client talks to
 *      the guest GMS through the container's Binder proxy.
 *
 *   2. Host account proxy. The container reads the host device's Google
 *      account and mints a token bound to it.
 *
 *   3. Token injection. A previously captured token is stored in the
 *      guest's account directory and injected before launch.
 *
 * This class only handles the redirect capture and the on-disk store.
 * The actual account virtualization is done by the Binder proxy at the
 * account service level.
 */
object GoogleAccountBridge {

    private const val TAG = "GoogleAccountBridge"

    private const val FILE_NAME = "google_account.json"
    private const val PROVIDER = "com.google"

    @Volatile private var lastRedirect: String = ""

    fun onRedirect(uri: Uri) {
        lastRedirect = uri.toString()
        ULog.i(TAG, "redirect captured: $uri")
    }

    fun lastRedirect(): String = lastRedirect

    fun storeToken(context: Context, guestPkg: String, token: String, email: String) {
        try {
            val dir = guestAccountDir(context, guestPkg).apply { mkdirs() }
            val f = File(dir, FILE_NAME)
            val json = """
                {
                  "provider": "$PROVIDER",
                  "email": "$email",
                  "token": "$token",
                  "stored_at": ${System.currentTimeMillis()}
                }
            """.trimIndent()
            f.writeText(json)
            ULog.i(TAG, "token stored for $guestPkg ($email)")
        } catch (t: Throwable) {
            ULog.e(TAG, "storeToken failed", t)
        }
    }

    fun loadToken(context: Context, guestPkg: String): String? {
        return try {
            val f = File(guestAccountDir(context, guestPkg), FILE_NAME)
            if (f.exists() && f.length() > 0L) f.readText() else null
        } catch (_: Throwable) {
            null
        }
    }

    fun clear(context: Context, guestPkg: String) {
        try {
            File(guestAccountDir(context, guestPkg), FILE_NAME).delete()
        } catch (_: Throwable) {}
    }

    fun buildSignInIntent(): Intent? {
        // Returns null unless the container has GMS installed as a guest.
        // The caller decides what to do.
        return null
    }

    private fun guestAccountDir(context: Context, guestPkg: String): File {
        val root = File(context.filesDir, "unoreverse/virtual/$guestPkg/accounts")
        if (!root.exists()) root.mkdirs()
        return root
    }
}