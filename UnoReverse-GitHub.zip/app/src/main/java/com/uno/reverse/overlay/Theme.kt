package com.uno.reverse.overlay

import android.graphics.Color

/*
 * Single source of truth for overlay colours and dimensions. Every
 * literal lives here so the theme can be tuned in one place.
 *
 * Palette:
 *   bg      — deep black, the base of every card
 *   surface — slightly raised black for the panel body
 *   gold    — primary accent, borders and highlights
 *   goldDim — muted gold for secondary text
 *   red     — chosen shot line and destructive actions
 *   green   — success tick, pocket markers
 *   fg      — body text
 *   muted   — secondary text
 */
object Theme {

    // ---- Colours --------------------------------------------------

    const val BG        = 0xFF0A0A0F.toInt()
    const val SURFACE   = 0xE6101018.toInt()   // 90% alpha black
    const val SURFACE_2 = 0xFF16161E.toInt()
    const val GOLD      = 0xFFD4AF37.toInt()
    const val GOLD_DIM  = 0xFF8A7030.toInt()
    const val RED       = 0xFFFF3B30.toInt()
    const val GREEN     = 0xFF22C55E.toInt()
    const val FG        = 0xFFF5F5F7.toInt()
    const val MUTED     = 0xFF8A8A93.toInt()
    const val BORDER    = 0x66D4AF37.toInt()   // 40% alpha gold

    // Colour pack for lines drawn on the overlay canvas. Packed ARGB.
    const val LINE_HIGH  = 0xFFD4AF37.toInt()
    const val LINE_MID   = 0xFF8A7030.toInt()
    const val LINE_LOW   = 0xFF4A3A18.toInt()
    const val LINE_CHOSEN = 0xFFFF3B30.toInt()
    const val LINE_GHOST = 0xFFFFFFFF.toInt()
    const val LINE_POCKET = 0xFF22C55E.toInt()

    // ---- Dimensions (dp) ------------------------------------------

    const val ICON_SIZE_DP      = 56
    const val ICON_RING_DP      = 2
    const val PANEL_WIDTH_DP    = 260
    const val PANEL_RADIUS_DP   = 16
    const val PANEL_PADDING_DP  = 16
    const val ROW_HEIGHT_DP     = 44
    const val SWITCH_W_DP       = 40
    const val SWITCH_H_DP       = 22
    const val SWITCH_THUMB_DP   = 18
    const val DIVIDER_DP        = 1

    // ---- Line rendering -------------------------------------------

    const val LINE_WIDTH_CANDIDATE_PX = 3f
    const val LINE_WIDTH_CHOSEN_PX    = 6f
    const val POCKET_DOT_RADIUS_PX    = 8f
    const val GHOST_DOT_RADIUS_PX     = 6f
    const val OVERLAY_TARGET_FPS      = 60

    // ---- Text sizes (sp) ------------------------------------------

    const val TEXT_TITLE_SP = 16f
    const val TEXT_ROW_SP   = 14f
    const val TEXT_META_SP  = 11f

    fun argb(a: Int, r: Int, g: Int, b: Int): Int =
        Color.argb(a, r, g, b)
}