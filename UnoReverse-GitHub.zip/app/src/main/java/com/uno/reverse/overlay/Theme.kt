package com.uno.reverse.overlay
object Theme {
    const val BLACK = 0xFF0A0A0F.toInt()
    const val GOLD = 0xFFD4AF37.toInt()
    const val RED = 0xFFFF3B30.toInt()
}
