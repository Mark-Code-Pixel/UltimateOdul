package com.uno.reverse.core
import android.content.Context
import com.uno.reverse.accounts.AccountStore
import com.uno.reverse.util.Log
class VirtualAccountManager private constructor() {
    fun init(context: Context) { AccountStore.init(context); Log.i("VAcct", "init") }
    companion object {
        @Volatile private var I: VirtualAccountManager? = null
        fun get() = I ?: synchronized(this) { I ?: VirtualAccountManager().also { I = it } }
    }
}
