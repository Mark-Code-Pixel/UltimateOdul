package com.uno.reverse.virtual

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import com.uno.reverse.core.NativeBridge

/**
 * Process ":virtual" — Path A guest host surface.
 * Full VirtualApp core will load cloned Carrom here under host UID.
 */
class VirtualHostActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val path = intent.getStringExtra("clone_path") ?: "—"
        val vc = intent.getLongExtra("version_code", 0L)
        val pkg = intent.getStringExtra("package") ?: PackageClone.CARROM_PKG
        Log.i(TAG, "VirtualHost path=$path ver=$vc pkg=$pkg")

        val tv = TextView(this).apply {
            text = "Uno Reverse · Virtual Host\n$pkg\nv$vc\n$path"
            gravity = Gravity.CENTER
            setTextColor(0xFFE8E8E8.toInt())
            textSize = 13f
        }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(0xFF0A0A0C.toInt())
            addView(
                tv,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        })
        try {
            NativeBridge.attachCarrom()
        } catch (t: Throwable) {
            Log.w(TAG, "attach", t)
        }
    }

    companion object {
        private const val TAG = "UnoVirtualHost"
    }
}
