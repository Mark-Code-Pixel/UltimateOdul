package com.uno.reverse.overlay
import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.uno.reverse.R
import com.uno.reverse.util.Log
class OverlayService : Service() {
    override fun onCreate() {
        super.onCreate()
        isRunning = true
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("ur_overlay", "Overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        startForeground(1001, NotificationCompat.Builder(this, "ur_overlay")
            .setContentTitle("Uno Reverse").setSmallIcon(R.drawable.uno_reverse_logo).setOngoing(true).build())
        Log.i("OverlayService", "started")
    }
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
    override fun onDestroy() { isRunning = false; super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
    companion object { @Volatile var isRunning = false }
}
