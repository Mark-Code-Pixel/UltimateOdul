package com.uno.reverse.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.uno.reverse.R
import com.uno.reverse.UnoReverseApp
import com.uno.reverse.nativebridge.NativeBridge
import com.uno.reverse.nativebridge.SharedState
import com.uno.reverse.util.Log as ULog
import com.uno.reverse.util.OverlayPermission
import com.uno.reverse.util.OverlayPrefs
import java.io.File

/*
 * Foreground service that owns the overlay layer.
 *
 * Hard rule: this service refuses to start if SYSTEM_ALERT_WINDOW is
 * not granted. It calls stopSelf immediately and returns. Nothing is
 * ever added to the window manager without the permission, so the
 * container never throws a BadTokenException and never disturbs the
 * guest.
 *
 * If the user revokes the permission while the service is running, the
 * next view-add call catches the failure and the service shuts itself
 * down.
 *
 * The service maps the shared memory region created by ContainerService
 * so it can read the solver's line output and write control flags.
 */
class OverlayService : Service() {

    companion object {
        const val TAG = "OverlayService"

        const val ACTION_SHOW = "com.uno.reverse.action.SHOW_OVERLAY"
        const val ACTION_HIDE = "com.uno.reverse.action.HIDE_OVERLAY"
        const val EXTRA_GUEST_PKG = "guest_pkg"

        private const val CHANNEL_ID = "unoreverse.overlay"
        private const val NOTIFICATION_ID = 0x5502

        @Volatile private var instance: OverlayService? = null

        /*
         * Start if and only if the user enabled the overlay and the
         * permission is granted. Otherwise this is a no-op.
         *
         * Returns true when the service was requested to start.
         */
        @JvmStatic
        fun start(context: Context, guestPkg: String): Boolean {
            if (!OverlayPrefs.isEnabled(context)) {
                ULog.i(TAG, "Overlay disabled by user preference; not starting")
                return false
            }
            if (!OverlayPermission.granted(context)) {
                ULog.i(TAG, "Overlay permission not granted; not starting")
                return false
            }
            val i = Intent(context, OverlayService::class.java).apply {
                action = ACTION_SHOW
                putExtra(EXTRA_GUEST_PKG, guestPkg)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
            return true
        }

        @JvmStatic
        fun stop(context: Context) {
            try {
                val i = Intent(context, OverlayService::class.java).apply {
                    action = ACTION_HIDE
                }
                context.startService(i)
            } catch (_: Throwable) {}
        }

        @JvmStatic
        fun notifyGuestForeground(activity: android.app.Activity) {
            instance?.onGuestForeground()
        }

        @JvmStatic
        fun notifyGuestBackground(activity: android.app.Activity) {
            instance?.onGuestBackground()
        }
    }

    private lateinit var wm: WindowManager
    private var surfaceView: OverlaySurfaceView? = null
    private var icon: FloatingIcon? = null
    private var panel: PanelView? = null

    private var surfaceParams: WindowManager.LayoutParams? = null
    private var iconParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null

    private var iconBaseX = 40
    private var iconBaseY = 200

    private var panelVisible = false

    private val mainHandler = Handler(Looper.getMainLooper())

    private val syncRunnable = object : Runnable {
        override fun run() {
            if (!panelVisible) return
            if (NativeBridge.isSharedMapped() && panel != null) {
                val s = SharedState.Snapshot()
                NativeBridge.snapshot(s)
                panel?.syncFromState(s)
            }
            mainHandler.postDelayed(this, 250)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        // Guard again in case the service was restarted by the system
        // after the user revoked permission.
        if (!OverlayPermission.granted(this) || !OverlayPrefs.isEnabled(this)) {
            ULog.w(TAG, "Permission or preference missing on create; stopping")
            stopSelf()
            return
        }

        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
        startForegroundSafe(buildNotification("Overlay running"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!OverlayPermission.granted(this) || !OverlayPrefs.isEnabled(this)) {
            ULog.w(TAG, "Permission or preference missing on start; stopping")
            stopSelf()
            return START_NOT_STICKY
        }

        when (intent?.action) {
            ACTION_SHOW -> {
                val pkg = intent.getStringExtra(EXTRA_GUEST_PKG) ?: ""
                show(pkg)
            }
            ACTION_HIDE -> {
                hideAll()
                stopSelf()
            }
            else -> {
                // Idle
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        mainHandler.removeCallbacks(syncRunnable)
        hideAll()
        NativeBridge.unmapSharedRegion()
        super.onDestroy()
    }

    // ------------------------------------------------------------------

    private fun show(guestPkg: String) {
        ULog.i(TAG, "show guest=$guestPkg")

        if (guestPkg.isNotEmpty()) {
            val regionFile = File(UnoReverseApp.virtualDir(this), "$guestPkg/shared_region_path.txt")
            if (regionFile.exists()) {
                val path = regionFile.readText().trim()
                if (path.isNotEmpty()) {
                    val rc = NativeBridge.mapSharedRegion(path)
                    ULog.i(TAG, "mapSharedRegion rc=$rc path=$path")
                }
            } else {
                ULog.w(TAG, "shared_region_path.txt missing")
            }
        }

        addSurface()
        addIcon()
    }

    private fun hideAll() {
        panel?.let { if (panelVisible) {
            try { wm.removeView(it) } catch (_: Throwable) {}
        } }
        panelVisible = false
        panel = null
        icon?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        icon = null
        surfaceView?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        surfaceView = null
        mainHandler.removeCallbacks(syncRunnable)
    }

    private fun onGuestForeground() {
        // Reserved.
    }

    private fun onGuestBackground() {
        // Reserved.
    }

    // ------------------------------------------------------------------
    // Views
    // ------------------------------------------------------------------

    private fun addSurface() {
        if (surfaceView != null) return
        val v = OverlaySurfaceView(this)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        try {
            wm.addView(v, p)
            surfaceView = v
            surfaceParams = p
        } catch (t: Throwable) {
            ULog.e(TAG, "addView surface failed; stopping", t)
            stopSelf()
        }
    }

    private fun addIcon() {
        if (icon != null) return
        val ic = FloatingIcon(
            this,
            onTap = { togglePanel() },
            onLongPress = { openDashboard() }
        )
        val size = ic.desiredSizePx()
        val p = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = iconBaseX
            y = iconBaseY
        }
        ic.dragHandler = { dx, dy, end ->
            if (end) {
                iconBaseX = p.x
                iconBaseY = p.y
            } else {
                p.x = (iconBaseX + dx).toInt()
                p.y = (iconBaseY + dy).toInt()
                try { wm.updateViewLayout(ic, p) } catch (_: Throwable) {}
            }
        }

        val logo: Drawable? = try {
            ContextCompat.getDrawable(this, R.drawable.uno_reverse_logo)
        } catch (_: Throwable) { null }
        logo?.let { ic.setLogo(it) }

        try {
            wm.addView(ic, p)
            icon = ic
            iconParams = p
        } catch (t: Throwable) {
            ULog.e(TAG, "addView icon failed; stopping", t)
            stopSelf()
        }
    }

    private fun togglePanel() {
        if (panelVisible) {
            panel?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
            panel = null
            panelVisible = false
            mainHandler.removeCallbacks(syncRunnable)
            return
        }

        val v = PanelView(this, onReset = { resetDefaults() })
        val p = WindowManager.LayoutParams(
            (Theme.PANEL_WIDTH_DP * resources.displayMetrics.density).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (iconBaseX + 60).coerceAtLeast(20)
            y = iconBaseY
        }

        try {
            wm.addView(v, p)
            panel = v
            panelParams = p
            panelVisible = true

            if (NativeBridge.isSharedMapped()) {
                val s = SharedState.Snapshot()
                NativeBridge.snapshot(s)
                v.syncFromState(s)
            }
            mainHandler.post(syncRunnable)
        } catch (t: Throwable) {
            ULog.e(TAG, "addView panel failed", t)
            panel = null
            panelVisible = false
        }
    }

    private fun resetDefaults() {
        if (!NativeBridge.isSharedMapped()) return
        NativeBridge.setFlag(SharedState.Flag.AUTOPLAY, 1)
        NativeBridge.setFlag(SharedState.Flag.AUTOQUEUE, 1)
        NativeBridge.setFlag(SharedState.Flag.KEEP_LINE, 1)
        NativeBridge.setFlag(SharedState.Flag.SHOW_LINES, 1)
        NativeBridge.setFlag(SharedState.Flag.LINE_COUNT, 16)
        NativeBridge.setFlag(SharedState.Flag.SOLVE_RATE, 30)
        NativeBridge.setFlag(SharedState.Flag.PROFILE, 0)
        panel?.let {
            val s = SharedState.Snapshot()
            NativeBridge.snapshot(s)
            it.syncFromState(s)
        }
    }

    private fun openDashboard() {
        try {
            val i = Intent(this, com.uno.reverse.MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(i)
        } catch (_: Throwable) {}
    }

    // ------------------------------------------------------------------
    // Notification
    // ------------------------------------------------------------------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val mgr = getSystemService(NotificationManager::class.java) ?: return
        if (mgr.getNotificationChannel(CHANNEL_ID) != null) return
        val ch = NotificationChannel(
            CHANNEL_ID,
            "Uno Reverse overlay",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Floating overlay and controls"
            setShowBadge(false)
        }
        mgr.createNotificationChannel(ch)
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Uno Reverse")
            .setContentText(text)
            .setSmallIcon(R.drawable.uno_reverse_logo)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun startForegroundSafe(n: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, n,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }
}