package com.uno.reverse.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/** Optional auto-warm after boot — does not auto-start engine without user intent. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Log.i("UnoBoot", "event=${intent?.action}")
    }
}
