package com.uno.reverse.solver
import com.uno.reverse.util.Cpu
import com.uno.reverse.util.Ram
import com.uno.reverse.util.Log
object ProfileSelector {
    enum class Profile { FULL, LEAN, DIRECT_ONLY, AUTO }
    fun select(): Profile {
        val c = when {
            Ram.freeMb() < 300 -> Profile.DIRECT_ONLY
            Cpu.coreCount() <= 4 -> Profile.LEAN
            else -> Profile.FULL
        }
        Log.i("Profile", "$c"); return c
    }
}
