package com.uno.reverse.solver

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import com.uno.reverse.util.Cpu
import com.uno.reverse.util.Ram
import java.io.File

/*
 * Chooses the solver profile based on the device the container is
 * running on. The three profiles map one-to-one to the C++ side's
 * selected_profile() values:
 *
 *   0  Full        — 64-bit, ≥6 cores, ≥4GB RAM, NEON mandatory
 *   1  Lean        — NEON present (any core count / RAM)
 *   2  DirectOnly  — no NEON, 32-bit-only, low RAM
 *
 * Auto mode reads the device every time. Manual mode returns whatever
 * the caller stored.
 *
 * The Kotlin side never decides what the native side runs; it only
 * records the user's preference. The native `neon_dispatch.cpp`
 * independently probes and enforces a floor: even if the user asks for
 * Full on a device that cannot support it, the native side clamps
 * to Lean or DirectOnly. This class exists so the UI can display an
 * honest default.
 */
object ProfileSelector {

    const val PROFILE_AUTO        = 0
    const val PROFILE_FULL        = 1
    const val PROFILE_LEAN        = 2
    const val PROFILE_DIRECT      = 3

    private const val FILE_NAME = "solver_profile.txt"

    fun autoDetect(context: Context): Int {
        val cores = Cpu.coreCount()
        val neon = Cpu.hasNeon()
        val ramBytes = Ram.totalBytes(context)
        val is64 = Cpu.is64Bit()

        return when {
            is64 && cores >= 6 && ramBytes >= (4L shl 30) && neon -> PROFILE_FULL
            neon -> PROFILE_LEAN
            else -> PROFILE_DIRECT
        }
    }

    fun stored(context: Context): Int {
        return try {
            val f = File(context.filesDir, "unoreverse/$FILE_NAME")
            if (!f.exists()) return PROFILE_AUTO
            f.readText().trim().toIntOrNull() ?: PROFILE_AUTO
        } catch (_: Throwable) {
            PROFILE_AUTO
        }
    }

    fun store(context: Context, profile: Int) {
        try {
            val dir = File(context.filesDir, "unoreverse").apply { mkdirs() }
            File(dir, FILE_NAME).writeText(profile.toString())
        } catch (_: Throwable) {}
    }

    /*
     * Resolve a stored preference to a concrete profile for the current
     * device. Auto mode returns the detected value. A manual value that
     * exceeds what the device can support is clamped.
     */
    fun resolve(context: Context): Int {
        val stored = stored(context)
        val detected = autoDetect(context)

        if (stored == PROFILE_AUTO) return detected

        // A manual value below the device's ceiling is honored.
        // A manual value above it is clamped to the ceiling.
        return minOf(stored, detected)
    }

    fun displayName(profile: Int): String = when (profile) {
        PROFILE_FULL -> "Full"
        PROFILE_LEAN -> "Lean"
        PROFILE_DIRECT -> "Direct"
        else -> "Auto"
    }

    fun describe(context: Context, profile: Int): String {
        val cores = Cpu.coreCount()
        val neon = Cpu.hasNeon()
        val ramMb = Ram.totalBytes(context) / (1024L * 1024L)
        val is64 = Cpu.is64Bit()
        return buildString {
            append(displayName(profile))
            append("  ·  ")
            append(cores).append(" cores  ·  ")
            append(ramMb).append(" MB  ·  ")
            append(if (neon) "NEON" else "scalar")
            append(if (is64) "  ·  64-bit" else "  ·  32-bit")
        }
    }
}