package com.uno.reverse.util

import android.content.Context

/*
 * Persisted overlay preferences. Three flags:
 *
 *   enabled          — user wants the overlay, independent of perms
 *   permissionWarned — whether the "needs permission" hint has been
 *                      shown
 *   lastState        — the last true/false we saw, for UI rendering
 *
 * The container reads `enabled` before starting OverlayService. The
 * overlay service reads `enabled` to decide whether to keep running if
 * it is restarted by the system.
 */
object OverlayPrefs {

    private const val FILE = "unoreverse_overlay_prefs"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_WARNED = "warned"

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun hasWarned(context: Context): Boolean = prefs(context).getBoolean(KEY_WARNED, false)

    fun setWarned(context: Context, warned: Boolean) {
        prefs(context).edit().putBoolean(KEY_WARNED, warned).apply()
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}