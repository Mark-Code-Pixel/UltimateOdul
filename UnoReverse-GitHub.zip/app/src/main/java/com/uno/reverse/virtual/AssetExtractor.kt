package com.uno.reverse.virtual

import android.content.Context
import android.util.Log
import com.uno.reverse.shizuku.ShizukuBridge
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

/**
 * Extracts Carrom Pool native libraries + critical assets into Uno Reverse
 * private storage BEFORE launch. User sees "Loading The Main Engine".
 *
 * Source: Play install parent dir (base + splits) via PackageClone.
 * Target: filesDir/uno_engine/<versionCode>/lib/{arm64-v8a,armeabi-v7a}/
 *
 * Does not redistribute the game — only copies from the user's own install.
 */
object AssetExtractor {

    private const val TAG = "UnoExtract"

    data class Progress(
        val phase: String,
        val percent: Int,
        val detail: String
    )

    data class Result(
        val ok: Boolean,
        val versionCode: Long,
        val libDir: File?,
        val engineSoCount: Int,
        val message: String
    )

    fun needsExtract(context: Context): Boolean {
        val src = PackageClone.resolveSource(context) ?: return true
        val dest = engineRoot(context, src.versionCode)
        val marker = File(dest, ".ready")
        if (!marker.exists()) return true
        // re-extract on version change
        return marker.readText().trim() != src.versionCode.toString()
    }

    fun engineRoot(context: Context, versionCode: Long): File =
        File(context.filesDir, "uno_engine/$versionCode")

    /**
     * Blocking extract on background thread. Callbacks on same worker thread.
     */
    fun extract(
        context: Context,
        onProgress: (Progress) -> Unit
    ): Result {
        val src = PackageClone.resolveSource(context)
            ?: return Result(false, 0, null, 0, "Carrom Pool not installed")

        onProgress(Progress("Preparing", 5, "Reading install tree…"))
        val root = engineRoot(context, src.versionCode)
        if (root.exists()) root.deleteRecursively()
        root.mkdirs()
        val libArm64 = File(root, "lib/arm64-v8a").apply { mkdirs() }
        val libArmv7 = File(root, "lib/armeabi-v7a").apply { mkdirs() }

        var engineCount = 0
        val apks = mutableListOf<File>()
        // base + all splits under parent
        val parent = File(src.installPath)
        if (parent.isDirectory) {
            parent.listFiles()?.forEach { f ->
                if (f.isFile && f.name.endsWith(".apk", true)) apks.add(f)
            }
        }
        // also explicit split list
        src.splitApks.forEach { p ->
            val f = File(p)
            if (f.exists() && f !in apks) apks.add(f)
        }
        File(src.baseApk).takeIf { it.exists() }?.let { if (it !in apks) apks.add(0, it) }

        if (apks.isEmpty()) {
            return Result(false, src.versionCode, null, 0, "No APK files found in install dir")
        }

        onProgress(Progress("Scanning", 15, "${apks.size} package(s) to scan"))

        val total = apks.size
        apks.forEachIndexed { index, apk ->
            val basePct = 15 + (70 * index) / total
            onProgress(Progress("Extracting", basePct, apk.name))
            try {
                engineCount += extractNativeFromApk(apk, libArm64, libArmv7, onProgress, basePct)
            } catch (t: Throwable) {
                Log.w(TAG, "extract ${apk.name}", t)
            }
        }

        // Copy already-found engine paths if any (direct file refs)
        src.engineArtifacts.forEach { path ->
            try {
                val f = File(path)
                if (f.exists() && f.name.contains("libgame-CARROM")) {
                    val destDir = if (path.contains("arm64")) libArm64 else libArmv7
                    val out = File(destDir, f.name)
                    if (!out.exists() || out.length() != f.length()) {
                        f.copyTo(out, overwrite = true)
                        engineCount++
                    }
                }
            } catch (t: Throwable) {
                Log.w(TAG, "copy engine artifact", t)
            }
        }

        onProgress(Progress("Finalizing", 92, "Writing markers…"))
        File(root, "engines.txt").writeText(
            listOf(libArm64, libArmv7).flatMap { d ->
                d.listFiles()?.map { it.absolutePath } ?: emptyList()
            }.joinToString("\n")
        )
        File(root, "clone_path.txt").writeText(src.installPath)
        File(root, ".ready").writeText(src.versionCode.toString())

        // Shizuku: optional mirror to tmp for elevated loaders
        if (ShizukuBridge.probe(context).running) {
            onProgress(Progress("Shizuku", 96, "Staging elevated paths…"))
            ShizukuBridge.prepareVirtualDirs(src.packageName)
        }

        onProgress(Progress("Ready", 100, "Main engine loaded"))
        val ok = engineCount > 0 || File(root, ".ready").exists()
        return Result(
            ok = ok,
            versionCode = src.versionCode,
            libDir = File(root, "lib"),
            engineSoCount = engineCount,
            message = if (ok) "Extracted $engineCount engine lib(s) for v${src.versionName}" else "No libgame-CARROM found yet"
        )
    }

    private fun extractNativeFromApk(
        apk: File,
        arm64: File,
        armv7: File,
        onProgress: (Progress) -> Unit,
        basePct: Int
    ): Int {
        var count = 0
        ZipInputStream(FileInputStream(apk)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val name = entry.name
                if (!entry.isDirectory && name.startsWith("lib/") && name.endsWith(".so")) {
                    val isEngine = name.contains("libgame-CARROM") || name.contains("CARROM-GooglePlay")
                    val isImportant = isEngine ||
                            name.contains("libil2cpp") ||
                            name.contains("libunity") ||
                            name.contains("libmain")
                    if (isImportant) {
                        val destDir = when {
                            name.contains("arm64-v8a") -> arm64
                            name.contains("armeabi-v7a") -> armv7
                            else -> null
                        }
                        if (destDir != null) {
                            val outFile = File(destDir, File(name).name)
                            FileOutputStream(outFile).use { fos ->
                                zis.copyTo(fos)
                            }
                            if (isEngine) {
                                count++
                                onProgress(Progress("Engine SO", (basePct + 5).coerceAtMost(90), outFile.name))
                                Log.i(TAG, "extracted $name → ${outFile.absolutePath}")
                            }
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return count
    }
}
