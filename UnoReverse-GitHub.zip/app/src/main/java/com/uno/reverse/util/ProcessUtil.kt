package com.uno.reverse.util
object ProcessUtil {
    fun is64Bit() = android.os.Process.is64Bit()
}
