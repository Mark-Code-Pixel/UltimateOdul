package com.uno.reverse.core

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Pulls live config / feature flags from Cloudflare Worker.
 * Keeps the app open-source friendly while allowing remote updates
 * (board maps, speed presets, maintenance flags, etc.)
 */
object RemoteConfig {

    private const val TAG = "UnoRemote"
    // Will point at the Worker we deploy for Uno Reverse
    private const val ENDPOINT = "https://uno-reverse-config.cark4-sk.workers.dev/config"

    data class Config(
        val maintenance: Boolean = false,
        val minVersion: Int = 1,
        val message: String = "",
        val defaultSpeed: Int = 1,
        val enableAutoQueue: Boolean = true,
        val enableHideStream: Boolean = true
    )

    @Volatile
    var current: Config = Config()
        private set

    suspend fun fetch(): Config = withContext(Dispatchers.IO) {
        try {
            val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
            }
            val code = conn.responseCode
            if (code !in 200..299) {
                Log.w(TAG, "Remote config HTTP $code")
                return@withContext current
            }
            val body = conn.inputStream.bufferedReader().readText()
            val json = JSONObject(body)
            val cfg = Config(
                maintenance = json.optBoolean("maintenance", false),
                minVersion = json.optInt("minVersion", 1),
                message = json.optString("message", ""),
                defaultSpeed = json.optInt("defaultSpeed", 1),
                enableAutoQueue = json.optBoolean("enableAutoQueue", true),
                enableHideStream = json.optBoolean("enableHideStream", true)
            )
            current = cfg
            Log.i(TAG, "Remote config loaded")
            cfg
        } catch (t: Throwable) {
            Log.w(TAG, "Remote config failed – using local defaults", t)
            current
        }
    }
}
