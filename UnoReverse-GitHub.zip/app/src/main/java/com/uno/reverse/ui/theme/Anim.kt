package com.uno.reverse.ui.theme

/*
 * Animation timing constants and easing helpers. Kept in one place so
 * every animated widget in the app shares the same rhythm.
 */
object Anim {

    // Durations in milliseconds
    const val INSTANT   = 120L
    const val FAST      = 180L
    const val NORMAL    = 260L
    const val SLOW      = 420L
    const val EPIC      = 720L
    const val SPLASH    = 1800L
    const val PULSE     = 1600L
    const val SHIMMER   = 2400L
    const val AURORA    = 12000L

    /*
     * Ease-out cubic: fast start, gentle landing. Use for entering
     * elements and taps.
     */
    fun easeOutCubic(t: Float): Float {
        val u = 1f - t.coerceIn(0f, 1f)
        return 1f - u * u * u
    }

    /*
     * Ease-in-out cubic: symmetric. Use for continuous motion like the
     * aurora drift and pulse cycles.
     */
    fun easeInOutCubic(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return if (x < 0.5f) 4f * x * x * x
        else 1f - (-2f * x + 2f).let { it * it * it } / 2f
    }

    /*
     * Overshoot: goes past 1 briefly, then settles. Use for the tick
     * and for pop-in elements.
     */
    fun overshoot(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        val c1 = 1.70158f
        val c3 = c1 + 1f
        val u = x - 1f
        return 1f + c3 * u * u * u + c1 * u * u
    }

    /*
     * Sine wave in [0, 1]. Use for loops.
     */
    fun sineLoop(t: Float): Float {
        val x = (t.coerceIn(0f, 1f)) * (Math.PI.toFloat() * 2f)
        return (kotlin.math.sin(x) * 0.5f) + 0.5f
    }

    /*
     * Triangle wave in [0, 1]. Use for shimmers that ping-pong.
     */
    fun triangle(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return if (x < 0.5f) x * 2f else (1f - x) * 2f
    }
}