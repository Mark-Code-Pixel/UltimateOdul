package com.uno.reverse.core

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import com.uno.reverse.nativebridge.NativeBridge
import com.uno.reverse.nativebridge.SharedState
import com.uno.reverse.util.Log
import kotlinx.coroutines.*

class UnoAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var job: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Accessibility connected — gesture assist online")
        job = scope.launch {
            while (isActive) {
                if (SharedState.isAutoPlay() && SharedState.isGestureAssist()) {
                    tryFire()
                }
                delay(1000L / SharedState.getSolveRate().coerceIn(5, 30))
            }
        }
    }

    private fun tryFire() {
        if (!NativeBridge.isLoaded()) return
        val line = NativeBridge.getAimLine()
        if (line.size < 4) return
        val x0 = line[0]; val y0 = line[1]; val x1 = line[2]; val y1 = line[3]
        if (x0 == 0f && y0 == 0f && x1 == 0f && y1 == 0f) return
        if (Build.VERSION.SDK_INT < 24) return
        val path = Path().apply { moveTo(x0, y0); lineTo(x1, y1) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 160)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        job?.cancel(); scope.cancel(); instance = null
        super.onDestroy()
    }

    companion object {
        private const val TAG = "UnoA11y"
        @Volatile var instance: UnoAccessibilityService? = null
        fun isActive(): Boolean = instance != null
    }
}
