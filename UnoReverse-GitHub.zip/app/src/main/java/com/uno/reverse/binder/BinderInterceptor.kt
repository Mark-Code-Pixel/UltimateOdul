package com.uno.reverse.binder
import android.content.Context
import com.uno.reverse.util.Log
object BinderInterceptor {
    fun install(context: Context) {
        ServiceManagerProxy.install()
        Log.i("BinderInterceptor", "installed")
    }
}
