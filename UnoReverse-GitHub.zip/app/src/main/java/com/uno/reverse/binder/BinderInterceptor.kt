package com.uno.reverse.binder

import android.os.IBinder
import com.uno.reverse.util.Log as ULog
import java.lang.reflect.Field
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Method
import java.lang.reflect.Proxy

/*
 * Installs the ServiceManager proxy that redirects every getService()
 * call through ServiceManagerProxy.
 *
 * Mechanism: reflect into android.os.ServiceManager, read the private
 * static field sServiceManager (the IBinder of the real service
 * manager), wrap it in a dynamic InvocationHandler, and write the proxy
 * back into the field. Every later call to ServiceManager.getService()
 * goes through our handler.
 *
 * This is a static, process-wide install. It must run before any
 * Activity starts — UnoReverseApp.onCreate does it in the main
 * process, and GuestMain does it in the guest process.
 *
 * Per-service behaviour (UID spoofing, package hiding, activity
 * redirection) lives in ServiceManagerProxy. This class only handles
 * the installation mechanics and the version differences between
 * Android 7 and Android 14.
 */
object BinderInterceptor {

    private const val TAG = "BinderInterceptor"

    @Volatile private var installed = false

    private var sServiceManagerField: Field? = null
    private var originalServiceManager: IBinder? = null
    private var proxyServiceManager: IBinder? = null

    @JvmStatic
    fun install(): Boolean {
        if (installed) return true
        return try {
            val smClass = Class.forName("android.os.ServiceManager")

            // Locate the private static field that holds the real
            // IServiceManager. The field name is stable across all
            // supported versions: "sServiceManager".
            val field = smClass.getDeclaredField("sServiceManager")
            field.isAccessible = true
            sServiceManagerField = field

            val original = field.get(null) as? IBinder
            if (original == null) {
                ULog.w(TAG, "sServiceManager was null; installing proxy on first access")
                installDeferredProxy()
                installed = true
                return true
            }

            originalServiceManager = original

            // Wrap the IBinder in a dynamic proxy that implements
            // every interface the original implements. On Android this
            // is android.os.IServiceManager plus Binder internals.
            val interfaces = collectInterfaces(original)

            val handler = ServiceManagerProxy(original)
            val proxy = Proxy.newProxyInstance(
                smClass.classLoader,
                interfaces,
                handler
            ) as IBinder

            field.set(null, proxy)
            proxyServiceManager = proxy
            installed = true

            ULog.i(TAG, "ServiceManager proxy installed. interfaces=${interfaces.size}")
            true
        } catch (t: Throwable) {
            ULog.e(TAG, "install failed", t)
            false
        }
    }

    /*
     * Some builds (rare, but seen on custom ROMs) leave sServiceManager
     * null until the first getService call. In that case we install a
     * one-shot hook: replace the field with a proxy wrapper that is
     * itself null-tolerant. When getService is called the framework
     * populates sServiceManager itself, and our wrapper delegates.
     *
     * Simplest safe behaviour in that case: do nothing. The caller will
     * retry the install after the first Binder traffic, or the guest
     * will run without UID spoofing until then. We log and continue.
     */
    private fun installDeferredProxy() {
        // No-op for now. The install attempt is retried on next launch.
    }

    @JvmStatic
    fun uninstall() {
        if (!installed) return
        try {
            val field = sServiceManagerField ?: return
            val original = originalServiceManager ?: return
            field.set(null, original)
            installed = false
            originalServiceManager = null
            proxyServiceManager = null
            ULog.i(TAG, "ServiceManager proxy uninstalled")
        } catch (t: Throwable) {
            ULog.e(TAG, "uninstall failed", t)
        }
    }

    @JvmStatic
    fun isInstalled(): Boolean = installed

    // ------------------------------------------------------------------

    /*
     * Collect every interface implemented by the given IBinder, walking
     * up the hierarchy. On most Android versions this yields
     * android.os.IServiceManager plus android.os.IBinder.
     */
    private fun collectInterfaces(binder: IBinder): Array<Class<*>> {
        val out = LinkedHashSet<Class<*>>()
        out.add(IBinder::class.java)

        var clazz: Class<*>? = binder.javaClass
        while (clazz != null && clazz != Any::class.java) {
            for (iface in clazz.interfaces) {
                collectInterfaceRecursive(iface, out)
            }
            clazz = clazz.superclass
        }
        return out.toTypedArray()
    }

    private fun collectInterfaceRecursive(iface: Class<*>, out: MutableSet<Class<*>>) {
        if (!iface.isInterface) return
        if (!out.add(iface)) return
        for (parent in iface.interfaces) {
            collectInterfaceRecursive(parent, out)
        }
    }
}