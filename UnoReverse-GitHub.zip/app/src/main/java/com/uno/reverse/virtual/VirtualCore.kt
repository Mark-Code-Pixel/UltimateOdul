package com.uno.reverse.virtual

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import java.io.File

/**
 * Solid path used by commercial Carrom tools (confirmed via public RE):
 *
 * 1. User installs real Carrom Pool from Play (feature module SO delivered).
 * 2. Host discovers full install tree (base + splits + feature modules).
 * 3. Guest can run under host UID in a container so process_vm_readv works
 *    without root (VirtualApp-style). Until full container is wired, we still
 *    attach to the real package process when the user launches Carrom.
 * 4. Native engine scans libgame-CARROM* for physics constants 0.12/8.2/2.55.
 *
 * Does NOT redistribute Carrom Pool. Only probes the Play install.
 */
object VirtualCore {

    private const val TAG = "UnoVCore"
    const val CARROM_PKG = "com.miniclip.carrom"

    data class InstallInfo(
        val installed: Boolean,
        val versionName: String?,
        val versionCode: Long,
        val baseApk: String?,
        val installDir: String?,
        val splitApks: List<String>,
        val nativeLibDirs: List<String>,
        val hasGameModuleHint: Boolean
    )

    fun probe(context: Context): InstallInfo {
        return try {
            val pm = context.packageManager
            val pi = if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(CARROM_PKG, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(CARROM_PKG, 0)
            }
            val ai: ApplicationInfo = pi.applicationInfo ?: return emptyInfo()

            val base = ai.publicSourceDir ?: ai.sourceDir
            val parent = base?.let { File(it).parent }

            val splits = mutableListOf<String>()
            ai.splitPublicSourceDirs?.forEach { splits.add(it) }
            ai.splitSourceDirs?.forEach { if (it !in splits) splits.add(it) }

            val libDirs = mutableListOf<String>()
            ai.nativeLibraryDir?.let { libDirs.add(it) }

            var hasGame = false
            parent?.let { dir ->
                try {
                    File(dir).walkTopDown().maxDepth(5).forEach { f ->
                        val n = f.name
                        if (n.contains("libgame-CARROM") || n.contains("CARROM-GooglePlay")) {
                            hasGame = true
                            Log.i(TAG, "engine artifact: ${f.absolutePath}")
                        }
                        if (f.isDirectory && (n.startsWith("lib") || n.contains("arm"))) {
                            val p = f.absolutePath
                            if (p !in libDirs) libDirs.add(p)
                        }
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "walk install dir failed", t)
                }
            }

            val vCode = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else {
                @Suppress("DEPRECATION")
                pi.versionCode.toLong()
            }

            InstallInfo(
                installed = true,
                versionName = pi.versionName,
                versionCode = vCode,
                baseApk = base,
                installDir = parent,
                splitApks = splits,
                nativeLibDirs = libDirs,
                hasGameModuleHint = hasGame
            )
        } catch (e: PackageManager.NameNotFoundException) {
            emptyInfo()
        } catch (t: Throwable) {
            Log.e(TAG, "probe failed", t)
            emptyInfo()
        }
    }

    private fun emptyInfo() = InstallInfo(
        false, null, 0L, null, null, emptyList(), emptyList(), false
    )

    fun launch(context: Context): Boolean {
        if (!probe(context).installed) {
            Log.w(TAG, "Carrom not installed")
            return false
        }
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(CARROM_PKG)
            if (intent != null) {
                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else false
        } catch (t: Throwable) {
            Log.e(TAG, "launch failed", t)
            false
        }
    }

    fun summary(info: InstallInfo): String {
        if (!info.installed) return "Carrom Pool not installed"
        val mod = if (info.hasGameModuleHint) {
            "engine SO present"
        } else {
            "open Carrom once from Play so feature module downloads"
        }
        return "v${info.versionName} (${info.versionCode}) • ${info.splitApks.size} splits • $mod"
    }
}
