package com.uno.reverse.core

import android.content.Context
import android.os.Build
import android.util.Log

/**
 * Dual-ABI native bridge.
 * All sensitive Carrom memory / physics logic lives in C++.
 */
object NativeBridge {

    private const val TAG = "UnoNative"
    private var loaded = false

    fun init(context: Context) {
        if (loaded) return
        val names = if (Build.SUPPORTED_64_BIT_ABIS.isNotEmpty())
            listOf("unoreverse64", "unoreverse32")
        else
            listOf("unoreverse32", "unoreverse64")
        for (name in names) {
            try {
                System.loadLibrary(name)
                nativeInit(context.packageName)
                loaded = true
                Log.i(TAG, "Loaded lib$name.so")
                return
            } catch (t: Throwable) {
                Log.e(TAG, "load $name failed", t)
            }
        }
        Log.e(TAG, "No native engine loaded — UI will still run")
    }

    external fun nativeInit(hostPackage: String)
    external fun startEngine(mode: Int): Boolean
    external fun stopEngine()
    external fun setSpeedMode(mode: Int)
    external fun setHideLine(hide: Boolean)
    external fun setHideStream(hide: Boolean)
    external fun setAutoQueue(enabled: Boolean)
    external fun setAutoPlay(enabled: Boolean)
    external fun setAimAssist(enabled: Boolean)
    external fun getEngineState(): Int
    external fun setBoardFilter(boardId: Int)

    /** float[7]: valid, startX, startY, endX, endY, power, angleDeg */
    external fun getLastShot(): FloatArray

    external fun attachCarrom(): Boolean
    external fun getReaderStatus(): String

    /** float[5]: found, 0.12, 8.2, 2.55, reserved */
    external fun getPhysicsInfo(): FloatArray
    external fun registerExtractedSo(path: String): Boolean

    data class Shot(
        val valid: Boolean,
        val startX: Float,
        val startY: Float,
        val endX: Float,
        val endY: Float,
        val power: Float,
        val angleDeg: Float
    )

    data class PhysicsInfo(
        val found: Boolean,
        val c012: Float,
        val c82: Float,
        val c255: Float
    )

    fun pollShot(): Shot {
        return try {
            val a = getLastShot()
            if (a.size < 7) Shot(false, 0f, 0f, 0f, 0f, 0f, 0f)
            else Shot(a[0] >= 0.5f, a[1], a[2], a[3], a[4], a[5], a[6])
        } catch (_: Throwable) {
            Shot(false, 0f, 0f, 0f, 0f, 0f, 0f)
        }
    }

    fun pollPhysics(): PhysicsInfo {
        return try {
            val a = getPhysicsInfo()
            if (a.size < 4) PhysicsInfo(false, 0f, 0f, 0f)
            else PhysicsInfo(a[0] >= 0.5f, a[1], a[2], a[3])
        } catch (_: Throwable) {
            PhysicsInfo(false, 0f, 0f, 0f)
        }
    }

    const val MODE_IDLE = 0
    const val MODE_AIM = 1
    const val MODE_AUTOPLAY = 2
    const val MODE_FULL = 3
}
