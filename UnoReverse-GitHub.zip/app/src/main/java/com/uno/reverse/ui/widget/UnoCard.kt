package com.uno.reverse.ui.widget

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import com.uno.reverse.ui.theme.Anim
import com.uno.reverse.ui.theme.ColorPalette

/*
 * A glass card. Draws itself with:
 *   - a translucent dark fill
 *   - a hairline gold border that carries an animated highlight
 *   - a soft inner shadow at the top
 *
 * The gold highlight travels around the border on a slow loop so the
 * card never looks static. Cheap: one LinearGradient per frame.
 *
 * Cards are containers. Add child views in the layout and they will
 * sit inside the padding area this view reserves.
 */
class UnoCard @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val density = resources.displayMetrics.density

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
    }
    private val innerGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val rect = RectF()

    private var animator: ValueAnimator? = null
    private var phase = 0f

    private val cornerRadius = 18f * density

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
        setWillNotDraw(false)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startLoop()
    }

    override fun onDetachedFromWindow() {
        stopLoop()
        super.onDetachedFromWindow()
    }

    private fun startLoop() {
        if (animator != null) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = Anim.AURORA
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopLoop() {
        animator?.cancel()
        animator = null
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        rect.set(0f, 0f, w, h)

        // Base fill.
        fillPaint.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(
                ColorPalette.withAlpha(ColorPalette.SURFACE_2, 0.75f),
                ColorPalette.withAlpha(ColorPalette.SURFACE, 0.85f)
            ),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, fillPaint)

        // Top inner glow.
        innerGlowPaint.shader = LinearGradient(
            0f, 0f, 0f, h * 0.35f,
            intArrayOf(ColorPalette.GLASS_WHITE_05, 0x00FFFFFF),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(
            RectF(1f, 1f, w - 1f, h - 1f),
            cornerRadius, cornerRadius, innerGlowPaint
        )

        // Gold border with a travelling highlight.
        val travel = phase * w * 2f - w * 0.5f
        val grad = LinearGradient(
            travel - w * 0.35f, 0f, travel + w * 0.35f, 0f,
            intArrayOf(
                ColorPalette.BORDER_SOFT,
                ColorPalette.withAlpha(ColorPalette.GOLD_SOFT, 0.85f),
                ColorPalette.BORDER_SOFT
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        borderPaint.shader = grad
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, borderPaint)
    }
}