package com.uno.reverse.pipeline

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/*
 * Minimal ELF parser. Identifies which .so in the extracted guest lib
 * directory exports the IL2CPP runtime entry points, and reports its
 * base name so the runtime agent can dlopen it by name.
 *
 * This is used purely to build the module-name string that ends up in
 * offsets.json. No field offsets are derived here — those come from the
 * runtime il2cpp API call in runtime_resolver.cpp.
 *
 * Supports ELF32 and ELF64, little-endian, ARM / AArch64. Big-endian and
 * exotic machines are rejected.
 */
object ElfScanner {

    data class ScanResult(
        val fileName: String,
        val is64Bit: Boolean,
        val exportsIl2Cpp: Boolean,
        val il2cppInitPresent: Boolean,
        val il2cppDomainGetPresent: Boolean,
        val il2cppClassFromNamePresent: Boolean,
        val il2cppFieldGetOffsetPresent: Boolean,
        val il2cppClassGetMethodFromNamePresent: Boolean
    )

    private const val EI_CLASS = 4
    private const val ELFCLASS32 = 1
    private const val ELFCLASS64 = 2
    private const val ELFDATA2LSB = 1

    // Target symbols we look for in .dynsym.
    private val TARGET_EXPORTS = setOf(
        "il2cpp_init",
        "il2cpp_domain_get",
        "il2cpp_class_from_name",
        "il2cpp_class_get_field_from_name",
        "il2cpp_field_get_offset",
        "il2cpp_class_get_method_from_name",
        "il2cpp_thread_attach",
        "il2cpp_domain_get_assemblies",
        "il2cpp_assembly_get_image",
        "il2cpp_image_get_class_count",
        "il2cpp_image_get_class"
    )

    fun scan(file: File): ScanResult {
        val raf = RandomAccessFile(file, "r")
        try {
            val header = ByteArray(64)
            raf.readFully(header)

            // Magic 0x7F 'E' 'L' 'F'
            if (header[0].toInt() and 0xFF != 0x7F ||
                header[1] != 'E'.code.toByte() ||
                header[2] != 'L'.code.toByte() ||
                header[3] != 'F'.code.toByte()) {
                return emptyResult(file.name, "not ELF")
            }

            val eiClass = header[EI_CLASS].toInt() and 0xFF
            val eiData = header[5].toInt() and 0xFF
            val is64 = eiClass == ELFCLASS64
            if (eiClass != ELFCLASS32 && eiClass != ELFCLASS64) {
                return emptyResult(file.name, "unknown class $eiClass")
            }
            if (eiData != ELFDATA2LSB) {
                return emptyResult(file.name, "not little-endian")
            }

            // Read section header offset from the ELF header.
            // ELF64: e_shoff at offset 0x28 (8 bytes)
            // ELF32: e_shoff at offset 0x20 (4 bytes)
            val fileLen = raf.length()
            if (fileLen < 64) return emptyResult(file.name, "file too small")

            val eShoff: Long
            val eShentsize: Int
            val eShnum: Int
            if (is64) {
                eShoff = leLong(header, 0x28)
                eShentsize = leShort(header, 0x3A)
                eShnum = leShort(header, 0x3C)
            } else {
                eShoff = leInt(header, 0x20).toLong() and 0xFFFFFFFFL
                eShentsize = leShort(header, 0x2E)
                eShnum = leShort(header, 0x30)
            }
            if (eShoff == 0L || eShnum <= 0) {
                return emptyResult(file.name, "no section table")
            }

            // Load the entire section header table.
            val shdr = ByteArray(eShnum * eShentsize)
            raf.seek(eShoff)
            raf.readFully(shdr)
            val sh = ByteBuffer.wrap(shdr).order(ByteOrder.LITTLE_ENDIAN)

            // Find the section named ".dynsym".
            var dynsymOff = -1L
            var dynsymSize = 0L
            var dynsymLink = -1
            var dynsymEntsize = 0

            for (i in 0 until eShnum) {
                val base = i * eShentsize
                val shType = if (is64) sh.getInt(base + 4) else sh.getInt(base + 4)
                // SHT_DYNSYM = 11
                if (shType != 11) continue
                dynsymOff = if (is64) sh.getLong(base + 0x18) else sh.getInt(base + 0x10).toLong() and 0xFFFFFFFFL
                dynsymSize = if (is64) sh.getLong(base + 0x20) else sh.getInt(base + 0x14).toLong() and 0xFFFFFFFFL
                dynsymLink = if (is64) sh.getInt(base + 0x28) else sh.getInt(base + 0x18)
                dynsymEntsize = if (is64) sh.getLong(base + 0x38).toInt() else sh.getInt(base + 0x24)
                break
            }
            if (dynsymOff < 0 || dynsymEntsize <= 0) {
                return emptyResult(file.name, "no .dynsym")
            }

            // Read the linked string table (for symbol names).
            var strtabOff = -1L
            var strtabSize = 0L
            if (dynsymLink in 0 until eShnum) {
                val base = dynsymLink * eShentsize
                strtabOff = if (is64) sh.getLong(base + 0x18) else sh.getInt(base + 0x10).toLong() and 0xFFFFFFFFL
                strtabSize = if (is64) sh.getLong(base + 0x20) else sh.getInt(base + 0x14).toLong() and 0xFFFFFFFFL
            }
            if (strtabOff < 0 || strtabSize <= 0) {
                return emptyResult(file.name, "no string table")
            }

            // Load the string table into memory.
            val strtab = ByteArray(strtabSize.toInt().coerceAtMost(1 shl 22))
            raf.seek(strtabOff)
            raf.readFully(strtab)

            // Iterate symbols.
            val symCount = (dynsymSize / dynsymEntsize).toInt()
            val symbols = HashSet<String>()
            val symBuf = ByteArray(dynsymEntsize)
            for (i in 0 until symCount) {
                raf.seek(dynsymOff + i.toLong() * dynsymEntsize)
                raf.readFully(symBuf)
                val sym = ByteBuffer.wrap(symBuf).order(ByteOrder.LITTLE_ENDIAN)
                val stNameOff = sym.getInt(0)
                if (stNameOff <= 0 || stNameOff >= strtab.size) continue
                var end = stNameOff
                while (end < strtab.size && strtab[end] != 0.toByte()) end++
                val name = String(strtab, stNameOff, end - stNameOff, Charsets.UTF_8)
                if (name in TARGET_EXPORTS) symbols.add(name)
                if (name.startsWith("il2cpp_")) symbols.add(name)
            }

            val hasInit = symbols.contains("il2cpp_init") || symbols.contains("il2cpp_domain_get")
            return ScanResult(
                fileName = file.name,
                is64Bit = is64,
                exportsIl2Cpp = hasInit,
                il2cppInitPresent = symbols.contains("il2cpp_init"),
                il2cppDomainGetPresent = symbols.contains("il2cpp_domain_get"),
                il2cppClassFromNamePresent = symbols.contains("il2cpp_class_from_name"),
                il2cppFieldGetOffsetPresent = symbols.contains("il2cpp_field_get_offset"),
                il2cppClassGetMethodFromNamePresent = symbols.contains("il2cpp_class_get_method_from_name")
            )
        } finally {
            try { raf.close() } catch (_: Throwable) {}
        }
    }

    fun scanDirectory(dir: File): List<ScanResult> {
        if (!dir.isDirectory) return emptyList()
        return dir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".so") }
            ?.map { scan(it) }
            ?.sortedByDescending { it.exportsIl2Cpp }
            ?: emptyList()
    }

    // ---- Little-endian helpers --------------------------------------

    private fun leInt(b: ByteArray, off: Int): Int =
        (b[off].toInt() and 0xFF) or
        ((b[off + 1].toInt() and 0xFF) shl 8) or
        ((b[off + 2].toInt() and 0xFF) shl 16) or
        ((b[off + 3].toInt() and 0xFF) shl 24)

    private fun leShort(b: ByteArray, off: Int): Int =
        (b[off].toInt() and 0xFF) or ((b[off + 1].toInt() and 0xFF) shl 8)

    private fun leLong(b: ByteArray, off: Int): Long {
        var v = 0L
        for (i in 7 downTo 0) {
            v = (v shl 8) or (b[off + i].toLong() and 0xFF)
        }
        return v
    }

    private fun emptyResult(name: String, _why: String) = ScanResult(
        fileName = name,
        is64Bit = false,
        exportsIl2Cpp = false,
        il2cppInitPresent = false,
        il2cppDomainGetPresent = false,
        il2cppClassFromNamePresent = false,
        il2cppFieldGetOffsetPresent = false,
        il2cppClassGetMethodFromNamePresent = false
    )
}