package com.uno.reverse.pipeline
import java.io.File
import java.io.RandomAccessFile
class ElfScanner {
    data class Result(val size: Long, val is64: Boolean)
    fun scan(f: File): Result {
        RandomAccessFile(f, "r").use { raf ->
            val m = ByteArray(4); raf.readFully(m)
            if (m[0] != 0x7f.toByte()) return Result(f.length(), false)
            val is64 = raf.read() == 2
            return Result(f.length(), is64)
        }
    }
    fun hasExport(f: File, sym: String): Boolean = try {
        f.readBytes().toString(Charsets.ISO_8859_1).contains(sym)
    } catch (_: Exception) { false }
}
