package com.uno.reverse.process

/*
 * Runtime inventory produced by the agent inside the guest process,
 * 5 seconds after the process starts. Every field is real, observed data.
 * Nothing is assumed about the engine.
 */
data class GuestInventory(
    val guestPackage: String,
    val pid: Int,
    val startTimeMs: Long,
    val dumpTimeMs: Long,

    val engine: String,                    // "unity-il2cpp" | "unity-mono" |
                                           // "cocos2d" | "flutter" | "unreal" |
                                           // "react-native" | "godot" | "unknown"
    val engineConfidence: Float,           // 0.0 .. 1.0

    val loadedModules: List<LoadedModule>,
    val dexFiles: List<DexFileRecord>,
    val jniBindings: List<JniBinding>,
    val openFileDescriptors: List<FdRecord>,
    val anonymousExecRegions: Int,

    val nativeLibCount: Int,
    val dexCount: Int,
    val jniBindingCount: Int,

    val complete: Boolean,
    val failureReason: String?
) {
    data class LoadedModule(
        val path: String,
        val baseAddr: Long,
        val sizeBytes: Long,
        val sha256: String
    )

    data class DexFileRecord(
        val path: String,
        val sizeBytes: Long,
        val sha256: String,
        val fromClassLoader: Boolean
    )

    data class JniBinding(
        val className: String,
        val methodName: String,
        val signature: String,
        val fnPtr: Long,
        val module: String
    )

    data class FdRecord(
        val fd: Int,
        val path: String,
        val mode: String
    )

    fun toJson(): String = buildString {
        append("{\n")
        append("  \"guest_package\": \"").append(guestPackage).append("\",\n")
        append("  \"pid\": ").append(pid).append(",\n")
        append("  \"start_time_ms\": ").append(startTimeMs).append(",\n")
        append("  \"dump_time_ms\": ").append(dumpTimeMs).append(",\n")
        append("  \"engine\": \"").append(engine).append("\",\n")
        append("  \"engine_confidence\": ").append(engineConfidence).append(",\n")
        append("  \"native_lib_count\": ").append(nativeLibCount).append(",\n")
        append("  \"dex_count\": ").append(dexCount).append(",\n")
        append("  \"jni_binding_count\": ").append(jniBindingCount).append(",\n")
        append("  \"anonymous_exec_regions\": ").append(anonymousExecRegions).append(",\n")
        append("  \"complete\": ").append(complete).append(",\n")
        append("  \"failure_reason\": ")
        if (failureReason == null) append("null") else append('"').append(failureReason).append('"')
        append(",\n")

        append("  \"loaded_modules\": [")
        loadedModules.forEachIndexed { i, m ->
            if (i > 0) append(",")
            append("\n    {\"path\":\"").append(m.path)
                .append("\",\"base\":").append(m.baseAddr)
                .append(",\"size\":").append(m.sizeBytes)
                .append(",\"sha256\":\"").append(m.sha256).append("\"}")
        }
        append("\n  ],\n")

        append("  \"dex_files\": [")
        dexFiles.forEachIndexed { i, d ->
            if (i > 0) append(",")
            append("\n    {\"path\":\"").append(d.path)
                .append("\",\"size\":").append(d.sizeBytes)
                .append(",\"sha256\":\"").append(d.sha256)
                .append("\",\"from_classloader\":").append(d.fromClassLoader).append("}")
        }
        append("\n  ],\n")

        append("  \"jni_bindings\": [")
        jniBindings.forEachIndexed { i, b ->
            if (i > 0) append(",")
            append("\n    {\"class\":\"").append(b.className)
                .append("\",\"method\":\"").append(b.methodName)
                .append("\",\"sig\":\"").append(b.signature)
                .append("\",\"fn\":").append(b.fnPtr)
                .append(",\"module\":\"").append(b.module).append("\"}")
        }
        append("\n  ],\n")

        append("  \"open_fds\": [")
        openFileDescriptors.forEachIndexed { i, f ->
            if (i > 0) append(",")
            append("\n    {\"fd\":").append(f.fd)
                .append(",\"path\":\"").append(f.path)
                .append("\",\"mode\":\"").append(f.mode).append("\"}")
        }
        append("\n  ]\n}\n")
    }
}