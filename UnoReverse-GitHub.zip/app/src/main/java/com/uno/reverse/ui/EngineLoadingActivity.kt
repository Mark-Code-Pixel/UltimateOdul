package com.uno.reverse.ui

import android.os.Bundle
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.uno.reverse.R
import com.uno.reverse.virtual.SessionOrchestrator

/**
 * Premium "Loading The Main Engine" gate — gold brand.
 */
class EngineLoadingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_engine_loading)

        val title = findViewById<TextView>(R.id.tvTitle)
        val detail = findViewById<TextView>(R.id.tvDetail)
        val bar = findViewById<ProgressBar>(R.id.progress)
        findViewById<ImageView>(R.id.imgBrand).setImageResource(R.drawable.uno_icon_gold)
        findViewById<ImageView>(R.id.imgWordmark).setImageResource(R.drawable.uno_wordmark)

        title.text = getString(R.string.loading_engine)

        SessionOrchestrator.startFull(
            this,
            onProgress = { pct, phase, msg ->
                bar.progress = pct
                if (phase.contains("Loading", true) || phase.contains("Engine", true) || phase.contains("Detect", true)) {
                    title.text = getString(R.string.loading_engine)
                } else {
                    title.text = phase
                }
                detail.text = msg
            },
            onDone = { report ->
                if (!report.ok) {
                    Toast.makeText(this, report.message, Toast.LENGTH_LONG).show()
                    detail.text = report.message
                } else {
                    detail.text = report.message
                    finish()
                }
            }
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        SessionOrchestrator.stop(this)
        super.onBackPressed()
    }
}
