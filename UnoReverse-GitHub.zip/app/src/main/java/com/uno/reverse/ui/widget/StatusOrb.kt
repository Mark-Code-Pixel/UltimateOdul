package com.uno.reverse.ui.widget

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import com.uno.reverse.ui.theme.Anim
import com.uno.reverse.ui.theme.ColorPalette
import kotlin.math.sin

/*
 * A small status dot that can idle, breathe, or pulse. Used for
 * connection state, solver state, and hook state.
 *
 * States:
 *   Idle      — solid dot, no motion
 *   Breathing — soft sine pulse in opacity and radius
 *   Pulsing   — expanding ring that fades
 *   Danger    — red, faster breathing
 */
class StatusOrb @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class State { Idle, Breathing, Pulsing, Danger }

    var state: State = State.Idle
        set(value) {
            field = value
            if (value == State.Idle) stopLoop() else startLoop()
            invalidate()
        }

    var color: Int = ColorPalette.GREEN

    private val density = resources.displayMetrics.density
    private val dotRadius = 6f * density

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
    }

    private var animator: ValueAnimator? = null
    private var phase = 0f

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (state != State.Idle) startLoop()
    }

    override fun onDetachedFromWindow() {
        stopLoop()
        super.onDetachedFromWindow()
    }

    private fun startLoop() {
        if (animator != null) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = Anim.PULSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopLoop() {
        animator?.cancel()
        animator = null
        phase = 0f
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = (dotRadius * 4).toInt()
        setMeasuredDimension(size, size)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f

        val baseColor = when (state) {
            State.Danger -> ColorPalette.RED
            else -> color
        }

        when (state) {
            State.Idle -> {
                dotPaint.color = baseColor
                canvas.drawCircle(cx, cy, dotRadius, dotPaint)
            }
            State.Breathing -> {
                val wave = (sin(phase * Math.PI.toFloat() * 2f) * 0.5f + 0.5f)
                val alpha = (0.55f + 0.45f * wave)
                val r = dotRadius * (0.85f + 0.25f * wave)
                dotPaint.color = ColorPalette.withAlpha(baseColor, alpha)
                canvas.drawCircle(cx, cy, r, dotPaint)
            }
            State.Pulsing -> {
                dotPaint.color = baseColor
                canvas.drawCircle(cx, cy, dotRadius, dotPaint)
                val ringR = dotRadius * (1f + 1.8f * phase)
                ringPaint.color = ColorPalette.withAlpha(baseColor, 1f - phase)
                canvas.drawCircle(cx, cy, ringR, ringPaint)
            }
            State.Danger -> {
                val wave = (sin(phase * Math.PI.toFloat() * 4f) * 0.5f + 0.5f)
                dotPaint.color = ColorPalette.withAlpha(baseColor, 0.6f + 0.4f * wave)
                canvas.drawCircle(cx, cy, dotRadius, dotPaint)
            }
        }
    }
}