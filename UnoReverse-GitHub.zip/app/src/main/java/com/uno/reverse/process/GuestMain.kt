package com.uno.reverse.process
import android.os.Looper
import com.uno.reverse.nativebridge.NativeBridge
import com.uno.reverse.util.Log
object GuestMain {
    @JvmStatic fun main(args: Array<String>) {
        if (args.size < 4) return
        try {
            Looper.prepareMainLooper()
            NativeBridge.loadAgent(args[3])
            NativeBridge.installHooks()
            Log.i("GuestMain", "running ${args[0]}")
            Looper.loop()
        } catch (e: Exception) { Log.e("GuestMain", "${e.message}") }
    }
}
