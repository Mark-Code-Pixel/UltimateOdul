package com.uno.reverse.process

import android.app.Application
import android.content.Context
import android.os.Looper
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.nativebridge.NativeBridge
import com.uno.reverse.util.Log as ULog
import dalvik.system.DexClassLoader
import java.io.File

/*
 * Entry point for the guest process. Invoked as:
 *
 *     app_process /system/bin com.uno.reverse.process.GuestMain <pkg>
 *
 * Load order is critical:
 *   1. Prepare Looper.
 *   2. Set the current guest on VirtualCore so the Binder proxy knows
 *      which package and UID it is answering for.
 *   3. Load the native agent (libunoreverse.so) from the container's
 *      lib directory — BEFORE the guest's own native libs, so the
 *      agent's constructor runs first and installs the ioctl hook.
 *   4. Load the guest's native libs from the virtual lib directory.
 *   5. Build the guest's DexClassLoader from the virtual APK.
 *   6. Instantiate the guest's Application class and call onCreate.
 *   7. Signal the agent to begin its 5-second settling dump.
 */
object GuestMain {

    private const val TAG = "GuestMain"

    @JvmStatic
    fun main(args: Array<String>) {
        if (args.isEmpty()) {
            System.err.println("GuestMain: missing package argument")
            System.exit(2)
        }
        val pkg = args[0]

        if (Looper.myLooper() == null) Looper.prepareMainLooper()

        val containerRoot = System.getenv("UNOREVERSE_ROOT") ?: ""
        val libDir = System.getenv("UNOREVERSE_LIBDIR") ?: ""
        val dataDir = System.getenv("UNOREVERSE_DATADIR") ?: ""

        val logDir = File(containerRoot, "logs")
        ULog.init(logDir, prefix = "guest")

        ULog.i(TAG, "GuestMain start. pkg=$pkg libDir=$libDir dataDir=$dataDir")

        // ---- 1. Register this guest with VirtualCore -----------------
        // The Binder proxy in the guest process reads these values when
        // answering UID and package-name queries.
        val record = VirtualCore.guest(pkg)
        val originalUid = record?.originalUid ?: -1
        VirtualCore.setCurrentGuest(pkg, originalUid)

        // ---- 2. Native agent ----------------------------------------
        try {
            val agentPath = File(libDir, "libunoreverse.so").absolutePath
            System.load(agentPath)
            ULog.i(TAG, "Native agent loaded: $agentPath")
        } catch (t: Throwable) {
            ULog.e(TAG, "Native agent load failed. Container will still run.", t)
        }

        try {
            NativeBridge.load()
            val initRc = NativeBridge.nativeInit(containerRoot, "unoreverse_state")
            ULog.i(TAG, "nativeInit returned $initRc")
        } catch (t: Throwable) {
            ULog.e(TAG, "NativeBridge init failed", t)
        }

        // ---- 3. Guest native libs ------------------------------------
        try {
            File(libDir).listFiles()?.forEach { so ->
                if (!so.isFile || !so.name.endsWith(".so")) return@forEach
                try {
                    System.load(so.absolutePath)
                    ULog.i(TAG, "Loaded guest lib: ${so.name}")
                } catch (t: Throwable) {
                    ULog.w(TAG, "Failed to load ${so.name}: ${t.message}")
                }
            }
        } catch (t: Throwable) {
            ULog.e(TAG, "Guest lib enumeration failed", t)
        }

        // ---- 4. Guest ClassLoader ------------------------------------
        val apkPath = File(containerRoot, "virtual/$pkg/apk/base.apk").absolutePath
        val optDir = File(dataDir, "dalvik-cache").apply { mkdirs() }.absolutePath
        val guestClassLoader = try {
            DexClassLoader(apkPath, optDir, libDir, GuestMain::class.java.classLoader)
        } catch (t: Throwable) {
            ULog.e(TAG, "DexClassLoader failed", t)
            null
        }

        // ---- 5. Guest Application ------------------------------------
        val guestApp: Application? = try {
            val appClassName = findApplicationClassName(apkPath)
            if (appClassName == null) {
                ULog.w(TAG, "No Application class found in guest APK")
                null
            } else {
                val cls = guestClassLoader?.loadClass(appClassName)
                val inst = cls?.getDeclaredConstructor()?.newInstance() as? Application
                if (inst != null) {
                    attachBaseContext(inst, containerRoot, dataDir)
                    inst.onCreate()
                    ULog.i(TAG, "Guest Application.onCreate called: $appClassName")
                }
                inst
            }
        } catch (t: Throwable) {
            ULog.e(TAG, "Guest Application boot failed (may be packed)", t)
            null
        }

        // ---- 6. Kick the runtime dump --------------------------------
        try {
            NativeBridge.startRuntimeDump(
                pkg,
                File(containerRoot, "virtual/$pkg")
            )
        } catch (t: Throwable) {
            ULog.e(TAG, "startRuntimeDump failed", t)
        }

        // ---- 7. Keep the process alive -------------------------------
        try {
            Looper.loop()
        } catch (_: Throwable) {
            // Loop exits when the process is destroyed.
        }

        ULog.i(TAG, "GuestMain exiting")
        System.exit(0)
    }

    // ------------------------------------------------------------------

    private fun findApplicationClassName(apkPath: String): String? = try {
        val pm = Class.forName("android.app.AppGlobals")
            .getMethod("getInitialApplication")
            .invoke(null) as? Context
            ?.packageManager
        if (pm == null) null else {
            val info = pm.getPackageArchiveInfo(apkPath, 0)
            info?.applicationInfo?.className
        }
    } catch (_: Throwable) {
        null
    }

    private fun attachBaseContext(app: Application, root: String, data: String) {
        try {
            val m = Application::class.java.getDeclaredMethod("attach", Context::class.java)
            m.isAccessible = true
            m.invoke(app, null)
        } catch (_: Throwable) {}
    }
}