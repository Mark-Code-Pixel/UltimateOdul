package com.uno.reverse.util
object Cpu {
    fun coreCount() = Runtime.getRuntime().availableProcessors()
    fun hasNeon() = true
}
