package com.uno.reverse.util

import android.os.Build
import java.io.File

object Cpu {

    @Volatile private var cachedCores = -1
    @Volatile private var cachedNeon: Boolean? = null

    @JvmStatic
    fun coreCount(): Int {
        cachedCores.let { if (it > 0) return it }
        val n = try {
            val text = File("/proc/cpuinfo").readText()
            val procs = text.split("\n").count { it.startsWith("processor") }
            if (procs > 0) procs else Runtime.getRuntime().availableProcessors()
        } catch (_: Throwable) {
            Runtime.getRuntime().availableProcessors()
        }
        cachedCores = n.coerceAtLeast(1)
        return cachedCores
    }

    @JvmStatic
    fun hasNeon(): Boolean {
        cachedNeon?.let { return it }
        val abi = Build.SUPPORTED_ABIS.firstOrNull().orEmpty()
        val result = when {
            abi.startsWith("arm64") -> true          // NEON mandatory on ARMv8-A
            abi.startsWith("armeabi") -> readNeonFlag()
            else -> false                            // x86 / x86_64: not applicable
        }
        cachedNeon = result
        return result
    }

    private fun readNeonFlag(): Boolean = try {
        val text = File("/proc/cpuinfo").readText()
        text.contains("neon", ignoreCase = true)
    } catch (_: Throwable) {
        false
    }

    @JvmStatic
    fun primaryAbi(): String = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"

    @JvmStatic
    fun is64Bit(): Boolean =
        Build.SUPPORTED_64_BIT_ABIS.isNotEmpty() && primaryAbi().contains("64")
}