package com.uno.reverse.util

import android.app.ActivityManager
import android.content.Context
import java.io.File

object Ram {

    @JvmStatic
    fun totalBytes(context: Context): Long {
        val fromProc = readMemTotal()
        if (fromProc > 0) return fromProc
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            info.totalMem
        } catch (_: Throwable) {
            0L
        }
    }

    @JvmStatic
    fun availableBytes(context: Context): Long = try {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        info.availMem
    } catch (_: Throwable) {
        0L
    }

    @JvmStatic
    fun isLow(context: Context, thresholdBytes: Long = 300L * 1024L * 1024L): Boolean =
        availableBytes(context) < thresholdBytes

    private fun readMemTotal(): Long = try {
        File("/proc/meminfo").useLines { lines ->
            lines.firstOrNull { it.startsWith("MemTotal:") }
                ?.split(Regex("\\s+"))
                ?.getOrNull(1)
                ?.toLongOrNull()
                ?.times(1024L)
                ?: 0L
        }
    } catch (_: Throwable) {
        0L
    }
}