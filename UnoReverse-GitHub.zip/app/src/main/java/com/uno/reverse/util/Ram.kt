package com.uno.reverse.util
import android.app.ActivityManager
import android.content.Context
import com.uno.reverse.core.VirtualCore
object Ram {
    fun freeMb(): Long = try {
        val am = VirtualCore.get().getHostContext().getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val i = ActivityManager.MemoryInfo(); am.getMemoryInfo(i); i.availMem / 1048576
    } catch (_: Exception) { 512L }
}
