package com.uno.reverse.virtual

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.uno.reverse.core.EngineConfig
import com.uno.reverse.core.NativeBridge
import com.uno.reverse.core.UnoEngineService
import com.uno.reverse.overlay.FloatControlPanel
import com.uno.reverse.overlay.OverlayController
import com.uno.reverse.shizuku.ShizukuBridge
import java.io.File

/**
 * Full hard path Axion specified:
 *
 * 1. Detect installed Carrom (Play)
 * 2. Extract libs/assets → uno_engine/<vc>/  ("Loading The Main Engine")
 * 3. VirtualPackageManager.installPackage (version-locked clone metadata)
 * 4. Start foreground engine service
 * 5. Launch Carrom + floating Uno panel (AutoPlay etc.)
 * 6. Native attach retries until live libgame-CARROM maps + physics probe
 *
 * Virtual-container only + Shizuku assist. Dual ABI extract.
 */
object SessionOrchestrator {

    private const val TAG = "UnoSession"
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var running = false

    data class Report(
        val phase: String,
        val ok: Boolean,
        val message: String,
        val engineSoCount: Int = 0,
        val physicsFound: Boolean = false
    )

    fun isRunning(): Boolean = running

    /**
     * @param onProgress UI thread safe via main handler
     * @param onDone called on main when launch sequence finished (or failed early)
     */
    fun startFull(
        context: Context,
        onProgress: (percent: Int, title: String, detail: String) -> Unit,
        onDone: (Report) -> Unit
    ) {
        if (running) {
            onDone(Report("busy", false, "Session already running"))
            return
        }
        running = true
        Thread {
            try {
                post(onProgress, 3, "Detect", "Looking for Carrom Pool…")
                val src = PackageClone.resolveSource(context)
                if (src == null) {
                    finish(onDone, Report("detect", false, "Install Carrom Pool from Play first"))
                    return@Thread
                }
                post(onProgress, 8, "Detect", "v${src.versionName} (${src.versionCode})")

                // Extract
                post(onProgress, 12, "Loading The Main Engine", "Scanning package tree…")
                val extract = if (AssetExtractor.needsExtract(context)) {
                    AssetExtractor.extract(context) { p ->
                        post(onProgress, p.percent.coerceIn(12, 88), p.phase, p.detail)
                    }
                } else {
                    post(onProgress, 50, "Loading The Main Engine", "Using cached engine assets")
                    AssetExtractor.Result(true, src.versionCode, null, -1, "cached")
                }

                if (!extract.ok && extract.engineSoCount == 0) {
                    Log.w(TAG, "extract weak: ${extract.message}")
                }

                // Prefer ABI-matching SO path for native side
                val soPath = pickEngineSo(context, src.versionCode)
                if (soPath != null) {
                    post(onProgress, 90, "Native", "Registering ${soPath.name}")
                    try {
                        NativeBridge.registerExtractedSo(soPath.absolutePath)
                    } catch (t: Throwable) {
                        Log.w(TAG, "registerExtractedSo", t)
                    }
                }

                post(onProgress, 93, "Virtual", "installPackage + version lock")
                val inst = VirtualPackageManager.installPackage(context)
                Log.i(TAG, inst.message)

                if (ShizukuBridge.probe(context).running) {
                    post(onProgress, 95, "Shizuku", "Elevated staging")
                    ShizukuBridge.prepareVirtualDirs(PackageClone.CARROM_PKG)
                }

                post(onProgress, 97, "Launch", "Starting engine service")
                EngineConfig.applyToNative()
                main.post {
                    try {
                        context.startForegroundService(Intent(context, UnoEngineService::class.java))
                    } catch (t: Throwable) {
                        Log.e(TAG, "service", t)
                    }
                }

                post(onProgress, 99, "Launch", "Opening Carrom + Uno panel")
                main.post {
                    VirtualPackageManager.launchApp(context)
                }

                // Attach loop off main
                var phys = false
                repeat(15) { i ->
                    Thread.sleep(2000)
                    try {
                        NativeBridge.attachCarrom()
                        val p = NativeBridge.pollPhysics()
                        phys = p.found
                        Log.i(TAG, "attach $i phys=$phys ${NativeBridge.getReaderStatus()}")
                        if (phys) return@repeat
                    } catch (t: Throwable) {
                        Log.w(TAG, "attach", t)
                    }
                }

                post(onProgress, 100, "Ready", if (phys) "Physics locked" else "Running — open a table for physics")
                finish(
                    onDone,
                    Report(
                        "ready",
                        true,
                        if (phys) "Session live · physics found" else "Session live · open a board table",
                        engineSoCount = extract.engineSoCount.coerceAtLeast(0),
                        physicsFound = phys
                    )
                )
            } catch (t: Throwable) {
                Log.e(TAG, "startFull", t)
                finish(onDone, Report("error", false, t.message ?: "failed"))
            }
        }.start()
    }

    fun stop(context: Context) {
        running = false
        VirtualEngine.stop()
        try {
            context.stopService(Intent(context, UnoEngineService::class.java))
        } catch (_: Throwable) {
        }
        try {
            NativeBridge.stopEngine()
        } catch (_: Throwable) {
        }
    }

    private fun pickEngineSo(context: Context, versionCode: Long): File? {
        val root = AssetExtractor.engineRoot(context, versionCode)
        val prefer64 = Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()
        val dirs = if (prefer64) {
            listOf(File(root, "lib/arm64-v8a"), File(root, "lib/armeabi-v7a"))
        } else {
            listOf(File(root, "lib/armeabi-v7a"), File(root, "lib/arm64-v8a"))
        }
        for (d in dirs) {
            val hit = d.listFiles()?.firstOrNull {
                it.name.contains("libgame-CARROM") && it.extension == "so"
            }
            if (hit != null) return hit
        }
        return null
    }

    private fun post(
        cb: (Int, String, String) -> Unit,
        pct: Int,
        title: String,
        detail: String
    ) {
        main.post { cb(pct, title, detail) }
    }

    private fun finish(cb: (Report) -> Unit, r: Report) {
        if (!r.ok) running = false
        main.post { cb(r) }
    }
}
