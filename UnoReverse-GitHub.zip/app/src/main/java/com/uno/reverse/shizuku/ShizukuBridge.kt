package com.uno.reverse.shizuku

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Shizuku-powered elevation without full root.
 *
 * User installs: Carrom Pool + Shizuku + Uno Reverse.
 * When Shizuku is running (ADB or root starter), we can:
 *  - run shell with elevated privileges
 *  - read other apps' /proc maps more reliably
 *  - assist Path A clone / Path B attach on locked-down OEMs
 *
 * This module degrades gracefully when Shizuku is absent (Path B still works
 * for same-UID / softer devices).
 *
 * Note: Full Shizuku API requires the Shizuku API AAR at compile time.
 * Here we implement a binder-free detection + shell helper that works with
 * `shizuku_starter` / `rish` when available, and documents the full API hook.
 */
object ShizukuBridge {

    private const val TAG = "UnoShizuku"
    const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
    const val SHIZUKU_MGR = "moe.shizuku.manager"

    data class State(
        val installed: Boolean,
        val managerInstalled: Boolean,
        val running: Boolean,
        val message: String
    )

    fun probe(context: Context): State {
        val pm = context.packageManager
        val apiInstalled = isPkg(pm, SHIZUKU_PKG) || isPkg(pm, SHIZUKU_MGR)
        val mgrInstalled = isPkg(pm, SHIZUKU_MGR)
        // Best-effort: try `shizuku` or `rish` version via PATH if user granted
        val running = tryShellPing()
        val msg = when {
            !apiInstalled && !mgrInstalled ->
                "Install Shizuku from Play/GitHub, start it (ADB or root), then return."
            !running ->
                "Shizuku installed but not running. Open Shizuku and pair via wireless ADB."
            else ->
                "Shizuku active – elevated shell available for attach/clone."
        }
        return State(apiInstalled || mgrInstalled, mgrInstalled, running, msg)
    }

    private fun isPkg(pm: PackageManager, name: String): Boolean = try {
        if (Build.VERSION.SDK_INT >= 33) {
            pm.getPackageInfo(name, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(name, 0)
        }
        true
    } catch (_: Exception) {
        false
    }

    private fun tryShellPing(): Boolean {
        return try {
            // rish is Shizuku's remote shell when configured
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", "command -v rish || command -v shizuku || echo none"))
            val line = BufferedReader(InputStreamReader(p.inputStream)).readLine()?.trim()
            p.waitFor()
            line != null && line != "none" && line.isNotEmpty()
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Run a command via elevated shell when possible.
     * Fallback: normal Runtime.exec (may fail for cross-UID reads).
     */
    fun execElevated(command: String, timeoutMs: Long = 8000): ExecResult {
        val attempts = listOf(
            arrayOf("rish", "-c", command),
            arrayOf("sh", "-c", command)
        )
        for (cmd in attempts) {
            try {
                val p = Runtime.getRuntime().exec(cmd)
                val out = StringBuilder()
                val err = StringBuilder()
                BufferedReader(InputStreamReader(p.inputStream)).use { r ->
                    var line: String?
                    while (r.readLine().also { line = it } != null) out.appendLine(line)
                }
                BufferedReader(InputStreamReader(p.errorStream)).use { r ->
                    var line: String?
                    while (r.readLine().also { line = it } != null) err.appendLine(line)
                }
                val finished = p.waitFor()
                if (finished == 0 || out.isNotEmpty()) {
                    return ExecResult(true, out.toString(), err.toString(), finished)
                }
            } catch (t: Throwable) {
                Log.w(TAG, "exec attempt failed: ${cmd.joinToString()}", t)
            }
        }
        return ExecResult(false, "", "no elevated shell", -1)
    }

    data class ExecResult(
        val ok: Boolean,
        val stdout: String,
        val stderr: String,
        val code: Int
    )

    /** List Carrom PID(s) using elevated ps if needed. */
    fun findCarromPids(): List<Int> {
        val r = execElevated("ps -A 2>/dev/null | grep miniclip.carrom | grep -v grep")
        if (!r.ok && r.stdout.isBlank()) return emptyList()
        val pids = mutableListOf<Int>()
        for (line in r.stdout.lines()) {
            val parts = line.trim().split(Regex("\\s+"))
            // ps formats vary; find first integer token that looks like pid
            for (p in parts) {
                val n = p.toIntOrNull()
                if (n != null && n > 1) {
                    pids.add(n)
                    break
                }
            }
        }
        return pids.distinct()
    }

    /** Best-effort prep for virtual data dir using elevated shell. */
    fun prepareVirtualDirs(packageName: String): Boolean {
        val cmd = "mkdir -p /data/local/tmp/uno_virtual/$packageName; chmod 755 /data/local/tmp/uno_virtual; echo OK"
        val r = execElevated(cmd)
        return r.ok || r.stdout.contains("OK")
    }

}
