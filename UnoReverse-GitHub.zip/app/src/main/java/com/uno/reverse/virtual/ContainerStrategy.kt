package com.uno.reverse.virtual

import android.content.Context
import com.uno.reverse.shizuku.ShizukuBridge

/** Virtual-container only + Shizuku. */
object ContainerStrategy {

    data class ReadyState(
        val carromInstalled: Boolean,
        val versionLabel: String,
        val engineModuleHint: Boolean,
        val nativeAttached: Boolean,
        val physicsFound: Boolean,
        val clonePathReady: Boolean,
        val shizukuRunning: Boolean,
        val readerStatus: String,
        val message: String
    )

    fun evaluate(context: Context): ReadyState {
        val s = VirtualEngine.status(context)
        val sh = ShizukuBridge.probe(context)
        val src = PackageClone.resolveSource(context)
        val sandboxed = VirtualPackageManager.isAppInstalled(context)
        return ReadyState(
            carromInstalled = src != null,
            versionLabel = if (src != null) "v${src.versionName} (${src.versionCode})" else "—",
            engineModuleHint = s.engineSeen,
            nativeAttached = s.nativeOk || s.active,
            physicsFound = s.physicsFound,
            clonePathReady = sandboxed || s.clonePath != null,
            shizukuRunning = sh.running,
            readerStatus = s.detail,
            message = s.detail
        )
    }

    fun startSession(context: Context): Boolean {
        // installPackage (version-locked) then virtual launch
        val inst = VirtualPackageManager.installPackage(context)
        if (!inst.success && PackageClone.resolveSource(context)?.engineArtifacts.isNullOrEmpty()) {
            return false
        }
        return VirtualPackageManager.launchApp(context)
    }
}
