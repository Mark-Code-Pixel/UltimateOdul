package com.uno.reverse
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.uno.reverse.overlay.OverlayService
import com.uno.reverse.process.GuestProcessManager
import com.uno.reverse.process.SilentInstaller
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private val targetPkg = BuildConfig.TARGET_PACKAGE
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<Button>(R.id.btnLaunch).setOnClickListener { launchGuest() }
        findViewById<Button>(R.id.btnStop).setOnClickListener { stopGuest() }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener { toggleOverlay() }
        findViewById<Button>(R.id.btnStore).setOnClickListener { openStore() }
        checkAndImport()
    }
    private fun checkAndImport() {
        scope.launch {
            findViewById<TextView>(R.id.status).text = getString(R.string.status_importing)
            val result = withContext(Dispatchers.IO) {
                SilentInstaller.ensureImported(this@MainActivity, targetPkg)
            }
            when (result) {
                SilentInstaller.Result.IMPORTED, SilentInstaller.Result.REIMPORTED -> {
                    Toast.makeText(this@MainActivity, R.string.toast_imported, Toast.LENGTH_SHORT).show()
                    findViewById<TextView>(R.id.status).text = getString(R.string.status_ready)
                }
                SilentInstaller.Result.UP_TO_DATE -> {
                    findViewById<TextView>(R.id.status).text = getString(R.string.status_ready)
                }
                SilentInstaller.Result.MISSING -> {
                    findViewById<TextView>(R.id.status).text = getString(R.string.status_missing)
                    findViewById<Button>(R.id.btnStore).visibility = View.VISIBLE
                }
                else -> findViewById<TextView>(R.id.status).text = "Import failed"
            }
        }
    }
    private fun launchGuest() {
        scope.launch {
            val ok = withContext(Dispatchers.IO) { GuestProcessManager.get().startGuest(targetPkg) }
            if (ok) findViewById<TextView>(R.id.status).text = getString(R.string.status_running)
        }
    }
    private fun stopGuest() {
        GuestProcessManager.get().stopGuest(targetPkg)
        findViewById<TextView>(R.id.status).text = getString(R.string.status_ready)
    }
    private fun toggleOverlay() {
        val i = Intent(this, OverlayService::class.java)
        if (OverlayService.isRunning) stopService(i) else startForegroundService(i)
    }
    private fun openStore() {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$targetPkg")))
    }
    override fun onDestroy() { super.onDestroy(); scope.cancel() }
}
