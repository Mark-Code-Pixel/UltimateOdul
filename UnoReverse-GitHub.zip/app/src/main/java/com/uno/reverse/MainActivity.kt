package com.uno.reverse

import android.animation.ObjectAnimator
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.CompoundButton
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.uno.reverse.nativebridge.NativeBridge
import com.uno.reverse.overlay.OverlayService
import com.uno.reverse.process.ExtractionReport
import com.uno.reverse.process.GuestDetector
import com.uno.reverse.process.SilentInstaller
import com.uno.reverse.ui.widget.StatusOrb
import com.uno.reverse.ui.widget.UnoButton
import com.uno.reverse.util.Log as ULog
import com.uno.reverse.util.OverlayPermission
import com.uno.reverse.util.OverlayPrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/*
 * Dashboard. Full VIP theme.
 *
 * Layout:
 *   - Animated aurora background.
 *   - Centered logo + app name + version.
 *   - Status card with a StatusOrb and extraction report.
 *   - Overlay toggle card.
 *   - Primary action button (Start / Open Play Store / Retry).
 *
 * All animations are driven by the widgets themselves. This activity
 * orchestrates state changes only.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var versionText: TextView
    private lateinit var statusText: TextView
    private lateinit var detailsText: TextView
    private lateinit var statusOrb: StatusOrb
    private lateinit var statusCard: View
    private lateinit var startButton: UnoButton
    private lateinit var overlayToggle: Switch
    private lateinit var overlayOrb: StatusOrb
    private lateinit var overlayStatus: TextView

    private var report: ExtractionReport? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        versionText   = findViewById(R.id.tv_version)
        statusText    = findViewById(R.id.tv_status)
        detailsText   = findViewById(R.id.tv_details)
        statusOrb     = findViewById(R.id.orb_status)
        statusCard    = findViewById(R.id.card_status)
        startButton   = findViewById(R.id.btn_start)
        overlayToggle = findViewById(R.id.sw_overlay)
        overlayOrb    = findViewById(R.id.orb_overlay)
        overlayStatus = findViewById(R.id.tv_overlay_status)

        versionText.text = "v${BuildConfig.VERSION_NAME} · ${BuildConfig.VERSION_CODE}"

        startButton.label = "Start"
        startButton.setVariant(UnoButton.Variant.Primary)
        startButton.isEnabled = false
        startButton.onClick = { launchGuest() }

        setupOverlayToggle()
        runPipeline()
        runEntrance()
    }

    override fun onResume() {
        super.onResume()
        refreshOverlayRow()
    }

    // ------------------------------------------------------------------
    // Entrance animation
    // ------------------------------------------------------------------

    private fun runEntrance() {
        val targets = listOf<View>(
            findViewById(R.id.card_status),
            findViewById(R.id.card_overlay),
            findViewById(R.id.btn_start)
        )

        targets.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = 28f
            v.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(120L + i * 90L)
                .setDuration(420)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    // ------------------------------------------------------------------
    // Overlay toggle
    // ------------------------------------------------------------------

    private fun setupOverlayToggle() {
        overlayToggle.setOnCheckedChangeListener { _: CompoundButton, checked: Boolean ->
            val hasPerm = OverlayPermission.granted(this)
            if (checked && !hasPerm) {
                overlayToggle.isChecked = false
                OverlayPrefs.setEnabled(this, false)
                OverlayPermission.openSettings(this)
                return@setOnCheckedChangeListener
            }
            OverlayPrefs.setEnabled(this, checked)
            if (checked && report?.isComplete == true) {
                OverlayService.start(
                    this,
                    report?.guestPackage ?: GuestDetector.TARGET_PACKAGE
                )
            } else if (!checked) {
                OverlayService.stop(this)
            }
            refreshOverlayRow()
        }
    }

    private fun refreshOverlayRow() {
        val hasPerm = OverlayPermission.granted(this)
        val wanted = OverlayPrefs.isEnabled(this)

        overlayToggle.isChecked = hasPerm && wanted

        when {
            !hasPerm -> {
                overlayStatus.text = "Permission not granted — tap to open settings"
                overlayStatus.setTextColor(ContextCompat.getColor(this, R.color.uno_amber))
                overlayOrb.state = StatusOrb.State.Danger
            }
            wanted -> {
                overlayStatus.text = "Enabled — appears over the game"
                overlayStatus.setTextColor(ContextCompat.getColor(this, R.color.uno_green))
                overlayOrb.state = StatusOrb.State.Breathing
                overlayOrb.color = ContextCompat.getColor(this, R.color.uno_green)
            }
            else -> {
                overlayStatus.text = "Disabled — headless mode"
                overlayStatus.setTextColor(ContextCompat.getColor(this, R.color.uno_muted))
                overlayOrb.state = StatusOrb.State.Idle
                overlayOrb.color = ContextCompat.getColor(this, R.color.uno_muted)
            }
        }
    }

    // ------------------------------------------------------------------
    // Pipeline
    // ------------------------------------------------------------------

    private fun runPipeline() {
        lifecycleScope.launch {
            setStatus("Detecting Carrom Pool…", StatusOrb.State.Breathing,
                ContextCompat.getColor(this@MainActivity, R.color.uno_gold))

            val detected = withContext(Dispatchers.IO) {
                GuestDetector.detect(this@MainActivity)
            }

            if (detected == null) {
                onNotInstalled()
                return@launch
            }

            setStatus("Extracting ${detected.versionName}…", StatusOrb.State.Pulsing,
                ContextCompat.getColor(this@MainActivity, R.color.uno_gold))

            val r = withContext(Dispatchers.IO) {
                SilentInstaller(this@MainActivity).install(detected)
            }
            report = r

            withContext(Dispatchers.Main) {
                if (r.isComplete) onExtractionComplete(r) else onExtractionFailed(r)
            }
        }
    }

    private fun onNotInstalled() {
        statusText.text = "Carrom Pool not installed"
        detailsText.text = "Install it from the Play Store, then return here and retry."
        statusOrb.state = StatusOrb.State.Danger
        statusOrb.color = ContextCompat.getColor(this, R.color.uno_red)
        startButton.label = "Open Play Store"
        startButton.setVariant(UnoButton.Variant.Ghost)
        startButton.isEnabled = true
        startButton.onClick = {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        android.net.Uri.parse("market://details?id=${GuestDetector.TARGET_PACKAGE}")
                    )
                )
            } catch (_: Throwable) {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        android.net.Uri.parse(
                            "https://play.google.com/store/apps/details?id=${GuestDetector.TARGET_PACKAGE}"
                        )
                    )
                )
            }
        }
    }

    private fun onExtractionComplete(r: ExtractionReport) {
        statusText.text = "Carrom Pool loaded properly"
        statusText.setTextColor(ContextCompat.getColor(this, R.color.uno_green))
        statusOrb.state = StatusOrb.State.Breathing
        statusOrb.color = ContextCompat.getColor(this, R.color.uno_green)

        detailsText.text = buildString {
            append(r.nativeLibCount).append(" libs   ·   ")
            append(r.assetCount).append(" assets   ·   ")
            append(r.metadataSizeBytes / 1024).append(" KB meta\n")
            append("engine: ").append(NativeBridge.engineName())
            append("   ·   abi: ").append(NativeBridge.activeAbi())
            append("   ·   ").append(r.elapsedMs).append(" ms")
        }

        startButton.label = "Start"
        startButton.setVariant(UnoButton.Variant.Primary)
        startButton.isEnabled = true
        startButton.onClick = { launchGuest() }

        ObjectAnimator.ofFloat(statusCard, View.ALPHA, 0.7f, 1f).apply {
            duration = 320
            start()
        }.start()
    }

    private fun onExtractionFailed(r: ExtractionReport) {
        statusText.text = "Extraction incomplete"
        statusText.setTextColor(ContextCompat.getColor(this, R.color.uno_red))
        detailsText.text = r.failureReason ?: "Unknown failure"
        statusOrb.state = StatusOrb.State.Danger
        statusOrb.color = ContextCompat.getColor(this, R.color.uno_red)

        startButton.label = "Retry"
        startButton.setVariant(UnoButton.Variant.Ghost)
        startButton.isEnabled = true
        startButton.onClick = { recreate() }

        AlertDialog.Builder(this)
            .setTitle("Uno Reverse")
            .setMessage("The Carrom Pool is loaded properly restart the Uno Reverse and try again")
            .setCancelable(false)
            .setPositiveButton("Restart") { _, _ -> recreate() }
            .setNegativeButton("Exit") { _, _ -> finish() }
            .show()
    }

    // ------------------------------------------------------------------

    private fun launchGuest() {
        val r = report ?: return
        if (!r.isComplete) {
            AlertDialog.Builder(this)
                .setTitle("Uno Reverse")
                .setMessage("The Carrom Pool is loaded properly restart the Uno Reverse and try again")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        try {
            File(filesDir, "unoreverse/launch.request")
                .writeText("${r.guestPackage}:${r.guestVersionCode}")
        } catch (_: Throwable) {}

        try {
            val f = File(filesDir, "unoreverse/overlay.enabled")
            f.writeText(if (OverlayPrefs.isEnabled(this)) "1" else "0")
        } catch (_: Throwable) {}

        ULog.i("MainActivity", "Launch requested for ${r.guestPackage} v${r.guestVersionCode}")
        com.uno.reverse.core.ContainerService.startWithGuest(this, r.guestPackage)
    }

    private fun setStatus(text: String, orbState: StatusOrb.State, orbColor: Int) {
        statusText.text = text
        statusText.setTextColor(ContextCompat.getColor(this, R.color.uno_fg))
        statusOrb.state = orbState
        statusOrb.color = orbColor
    }
}