package com.uno.reverse.lifecycle

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import com.uno.reverse.classloader.VirtualClassLoader
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.util.Log as ULog
import java.io.File

/*
 * Base for the eight StubActivity slots declared in the manifest.
 *
 * On onCreate:
 *   1. Read the original component and guest package from the intent.
 *   2. Build a VirtualClassLoader for the guest.
 *   3. Instantiate the guest's Activity class.
 *   4. Attach it to the framework via ActivityThreadCompat.
 *   5. Forward every lifecycle callback to the guest.
 *
 * The stub host itself keeps the framework happy — the manifest declares
 * it, the framework launches it, and everything the guest sees is real
 * because the guest's own Activity is a live object inside the same
 * process.
 *
 * If the guest class cannot be resolved, the stub finishes cleanly.
 * Nothing crashes.
 */
abstract class StubActivityBase : Activity() {

    protected var guestActivity: Activity? = null
    private var guestClassLoader: VirtualClassLoader? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val originalComponent = intent?.getStringExtra(EXTRA_ORIGINAL_COMPONENT)
        val guestPkg = intent?.getStringExtra(EXTRA_GUEST_PKG)

        if (originalComponent.isNullOrEmpty() || guestPkg.isNullOrEmpty()) {
            ULog.w(TAG, "StubActivity launched without guest metadata; finishing")
            finish()
            return
        }

        val record = VirtualCore.guest(guestPkg)
        if (record == null) {
            ULog.w(TAG, "Guest $guestPkg is not registered; finishing")
            finish()
            return
        }

        // Build the classloader.
        val loader = try {
            VirtualClassLoader(
                guestPackage = guestPkg,
                apkPath = File(record.virtualRoot, "apk/base.apk").absolutePath,
                splitApkPaths = emptyList(),
                optimizedDir = File(record.virtualRoot, "data/dalvik-cache").apply { mkdirs() }.absolutePath,
                nativeLibDir = File(record.virtualRoot, "lib/${record.primaryAbi}").absolutePath,
                hostParent = classLoader
            )
        } catch (t: Throwable) {
            ULog.e(TAG, "ClassLoader build failed", t)
            finish()
            return
        }
        guestClassLoader = loader

        // Extract the guest class name from the flattened component.
        val className = parseClassFromComponent(originalComponent)
        if (className.isNullOrEmpty()) {
            ULog.w(TAG, "Could not parse class from $originalComponent")
            finish()
            return
        }

        // Instantiate the guest Activity.
        val guest = try {
            val cls = Class.forName(className, true, loader.getDelegate() ?: classLoader)
            val inst = cls.getDeclaredConstructor().newInstance() as Activity
            ActivityThreadCompat.attachGuestActivity(inst, this)
            inst
        } catch (t: Throwable) {
            ULog.e(TAG, "Guest Activity boot failed for $className", t)
            finish()
            return
        }

        guestActivity = guest

        // Forward the initial lifecycle.
        try {
            guest.onCreate(savedInstanceState)
        } catch (t: Throwable) {
            ULog.e(TAG, "guest.onCreate threw", t)
            finish()
        }
    }

    // ------------------------------------------------------------------
    // Lifecycle forwarding
    // ------------------------------------------------------------------

    override fun onStart() {
        super.onStart()
        guestActivity?.let {
            try { it.onStart() } catch (t: Throwable) { ULog.e(TAG, "guest.onStart", t) }
        }
    }

    override fun onResume() {
        super.onResume()
        guestActivity?.let {
            try { it.onResume() } catch (t: Throwable) { ULog.e(TAG, "guest.onResume", t) }
        }
    }

    override fun onPause() {
        guestActivity?.let {
            try { it.onPause() } catch (t: Throwable) { ULog.e(TAG, "guest.onPause", t) }
        }
        super.onPause()
    }

    override fun onStop() {
        guestActivity?.let {
            try { it.onStop() } catch (t: Throwable) { ULog.e(TAG, "guest.onStop", t) }
        }
        super.onStop()
    }

    override fun onDestroy() {
        guestActivity?.let {
            try { it.onDestroy() } catch (t: Throwable) { ULog.e(TAG, "guest.onDestroy", t) }
        }
        guestActivity = null
        super.onDestroy()
    }

    override fun onRestart() {
        super.onRestart()
        guestActivity?.let {
            try { it.onRestart() } catch (t: Throwable) { ULog.e(TAG, "guest.onRestart", t) }
        }
    }

    override fun onNewIntent(newIntent: Intent) {
        super.onNewIntent(newIntent)
        guestActivity?.let {
            try { it.onNewIntent(newIntent) } catch (t: Throwable) { ULog.e(TAG, "guest.onNewIntent", t) }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        guestActivity?.let {
            try { it.onActivityResult(requestCode, resultCode, data) } catch (_: Throwable) {}
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        guestActivity?.let {
            try { it.onSaveInstanceState(outState) } catch (_: Throwable) {}
        }
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        guestActivity?.let {
            try { it.onRestoreInstanceState(savedInstanceState) } catch (_: Throwable) {}
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        guestActivity?.let {
            try { it.onConfigurationChanged(newConfig) } catch (_: Throwable) {}
        }
    }

    override fun onBackPressed() {
        val guest = guestActivity
        if (guest != null) {
            try {
                if (guest.onBackPressedDispatcher.hasEnabledCallbacks()) {
                    guest.onBackPressedDispatcher.onBackPressed()
                    return
                }
            } catch (_: Throwable) {}
            try { guest.onBackPressed() } catch (_: Throwable) {}
        }
        super.onBackPressed()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        return guestActivity?.onKeyDown(keyCode, event) ?: super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        return guestActivity?.onKeyUp(keyCode, event) ?: super.onKeyUp(keyCode, event)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        return guestActivity?.onTouchEvent(event) ?: super.onTouchEvent(event)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        guestActivity?.let {
            try { it.onWindowFocusChanged(hasFocus) } catch (_: Throwable) {}
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        guestActivity?.let {
            try { it.onLowMemory() } catch (_: Throwable) {}
        }
    }

    // ------------------------------------------------------------------

    private fun parseClassFromComponent(flat: String): String? {
        val slash = flat.indexOf('/')
        if (slash < 0) return null
        val tail = flat.substring(slash + 1)
        val hash = tail.indexOf('#')
        return if (hash >= 0) tail.substring(0, hash) else tail
    }

    companion object {
        private const val TAG = "StubActivity"
        const val EXTRA_ORIGINAL_COMPONENT = "_unoreverse_original_component"
        const val EXTRA_GUEST_PKG = "_unoreverse_guest_pkg"
    }
}

/*
 * Eight concrete slots. The manifest declares each. They exist so the
 * container can match a guest Activity's launch mode without the
 * framework complaining about reusing the same stub name with different
 * task affinities.
 */
class StubActivity {
    class P0 : StubActivityBase()
    class P1 : StubActivityBase()
    class P2 : StubActivityBase()
    class P3 : StubActivityBase()
    class P4 : StubActivityBase()
    class P5 : StubActivityBase()
    class P6 : StubActivityBase()
    class P7 : StubActivityBase()
}