package com.uno.reverse.lifecycle
import android.app.Activity
import android.os.Bundle
import com.uno.reverse.util.Log
class StubActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Log.i("StubActivity", "onCreate " + intent?.getStringExtra("_ur_target_pkg"))
    }
}
