package com.uno.reverse.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.uno.reverse.core.EngineConfig
import com.uno.reverse.core.NativeBridge

/**
 * Floating advanced HUD on top of Carrom Pool.
 * AutoPlay / AutoQueue / Aim / HideLine toggles — draggable, semi-transparent.
 */
class FloatControlPanel(private val context: Context) {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null

    fun show() {
        if (root != null) return
        val density = context.resources.displayMetrics.density
        val pad = (10 * density).toInt()

        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                setColor(0xCC121212.toInt())
                cornerRadius = 16 * density
                setStroke((1 * density).toInt(), 0xFFD4AF37.toInt())
            }
            elevation = 12f
        }

        val header = TextView(context).apply {
            text = "UNO REVERSE"
            setTextColor(0xFFD4AF37.toInt())
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad / 2)
        }
        panel.addView(header)

        fun addSwitch(label: String, initial: Boolean, onChange: (Boolean) -> Unit) {
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(context).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val sw = Switch(context).apply {
                isChecked = initial
                setOnCheckedChangeListener { _, c -> onChange(c) }
            }
            row.addView(tv)
            row.addView(sw)
            panel.addView(row)
        }

        addSwitch("AutoPlay", EngineConfig.autoPlay) {
            EngineConfig.autoPlay = it
            EngineConfig.save()
            NativeBridge.setAutoPlay(it)
        }
        addSwitch("AutoQueue", EngineConfig.autoQueue) {
            EngineConfig.autoQueue = it
            EngineConfig.save()
            NativeBridge.setAutoQueue(it)
        }
        addSwitch("Aim Assist", EngineConfig.aimAssist) {
            EngineConfig.aimAssist = it
            EngineConfig.save()
            NativeBridge.setAimAssist(it)
        }
        addSwitch("Hide Line", EngineConfig.hideLine) {
            EngineConfig.hideLine = it
            EngineConfig.save()
            NativeBridge.setHideLine(it)
        }
        addSwitch("Hide Stream", EngineConfig.hideStream) {
            EngineConfig.hideStream = it
            EngineConfig.save()
            NativeBridge.setHideStream(it)
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            (168 * density).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (8 * density).toInt()
            y = (80 * density).toInt()
        }

        // drag
        var lastX = 0f
        var lastY = 0f
        panel.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = e.rawX
                    lastY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - lastX).toInt()
                    val dy = (e.rawY - lastY).toInt()
                    lastX = e.rawX
                    lastY = e.rawY
                    lp.x = (lp.x - dx).coerceAtLeast(0)
                    lp.y = (lp.y + dy).coerceAtLeast(0)
                    try {
                        wm.updateViewLayout(v, lp)
                    } catch (_: Throwable) {
                    }
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(panel, lp)
            root = panel
            params = lp
        } catch (t: Throwable) {
            root = null
        }
    }

    fun hide() {
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: Throwable) {
            }
        }
        root = null
        params = null
    }
}
