package com.uno.reverse.classloader

import com.uno.reverse.util.Log as ULog
import dalvik.system.BaseDexClassLoader
import dalvik.system.DexClassLoader
import dalvik.system.PathClassLoader
import java.io.File
import java.net.URL
import java.util.Enumeration

/*
 * ClassLoader for a single guest.
 *
 * Resolution order:
 *   1. Guest's own classes (from the virtual APK's classes.dex).
 *   2. Host's classes (for framework and container classes the guest
 *      asks for reflectively).
 *
 * This ordering is what lets a guest's Application, Activity, Service,
 * Provider, and Receiver classes be loaded from the APK while the
 * framework classes they use resolve to the platform versions the
 * container already has loaded.
 *
 * The loader also handles:
 *   - split APKs (splitSourceDirs)
 *   - native library lookup via findLibrary()
 *   - resource lookup via findResource()
 *   - the parent-last delegation that lets the guest override its own
 *     classes without leaking host classes into the guest
 */
class VirtualClassLoader(
    private val guestPackage: String,
    private val apkPath: String,
    private val splitApkPaths: List<String>,
    private val optimizedDir: String,
    private val nativeLibDir: String,
    private val hostParent: ClassLoader
) {

    @Volatile private var delegate: BaseDexClassLoader? = null

    init {
        delegate = buildDelegate()
    }

    private fun buildDelegate(): BaseDexClassLoader? {
        return try {
            val allPaths = buildString {
                append(apkPath)
                for (s in splitApkPaths) {
                    if (s.isNotEmpty() && s != apkPath) {
                        append(File.pathSeparator).append(s)
                    }
                }
            }
            val opt = File(optimizedDir).apply { mkdirs() }.absolutePath
            DexClassLoader(allPaths, opt, nativeLibDir, hostParent)
        } catch (t: Throwable) {
            ULog.e(TAG, "buildDelegate failed for $guestPackage", t)
            null
        }
    }

    // ---- Public API -------------------------------------------------

    fun loadClass(name: String, resolve: Boolean = false): Class<*>? {
        // Avoid the container's own classes leaking into the guest.
        if (name.startsWith("com.uno.reverse.")) {
            return null
        }

        // Try the guest first.
        val d = delegate
        if (d != null) {
            try {
                return d.loadClass(name)
            } catch (_: ClassNotFoundException) {
                // Fall through to host.
            }
        }

        // Host fallback for framework classes.
        return try {
            Class.forName(name, resolve, hostParent)
        } catch (_: ClassNotFoundException) {
            null
        }
    }

    fun loadClassRequired(name: String): Class<*> =
        loadClass(name, true) ?: throw ClassNotFoundException(name)

    fun findResource(name: String): URL? {
        return delegate?.getResource(name)
    }

    fun findResources(name: String): Enumeration<URL>? {
        return delegate?.getResources(name)
    }

    fun findLibrary(name: String): String? {
        return try {
            val candidate = File(nativeLibDir, "lib$name.so")
            if (candidate.exists()) candidate.absolutePath else null
        } catch (_: Throwable) {
            null
        }
    }

    fun getDelegate(): ClassLoader? = delegate

    fun getNativeLibDir(): String = nativeLibDir

    fun getApkPath(): String = apkPath

    fun getGuestPackage(): String = guestPackage

    // ---- ClassLoader surface for duck-typed callers ----------------

    /*
     * Some framework code calls through ClassLoader.loadClass directly.
     * We provide a proxy-shaped API: the caller holds a ClassLoader
     * instance that we expose via `asClassLoader`.
     */
    fun asClassLoader(): ClassLoader {
        return object : ClassLoader(hostParent) {
            override fun findClass(name: String): Class<*> {
                return loadClassRequired(name)
            }
            override fun findResource(name: String): URL? = findResource(name)
            override fun findLibrary(name: String): String? = this@VirtualClassLoader.findLibrary(name)
        }
    }

    companion object {
        private const val TAG = "VirtualClassLoader"
    }
}