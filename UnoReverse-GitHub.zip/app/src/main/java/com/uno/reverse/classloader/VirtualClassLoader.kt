package com.uno.reverse.classloader
import dalvik.system.DexClassLoader
import com.uno.reverse.util.Log
import java.io.File
class VirtualClassLoader(dexPath: String, opt: String?, lib: String?, parent: ClassLoader) :
    DexClassLoader(dexPath, opt, lib, parent) {
    override fun loadClass(name: String, resolve: Boolean): Class<*> {
        try { val c = findClass(name); if (resolve) resolveClass(c); return c } catch (_: ClassNotFoundException) {}
        return super.loadClass(name, resolve)
    }
    companion object {
        fun create(apk: String, lib: String, odex: String, parent: ClassLoader): VirtualClassLoader {
            File(odex).mkdirs()
            return VirtualClassLoader(apk, odex, lib, parent).also { Log.i("VCL", "created") }
        }
    }
}
