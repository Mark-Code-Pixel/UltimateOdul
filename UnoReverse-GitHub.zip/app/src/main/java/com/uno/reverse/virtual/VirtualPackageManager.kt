package com.uno.reverse.virtual

import android.content.Context
import android.util.Log
import com.uno.reverse.shizuku.ShizukuBridge
import java.io.File

/**
 * API surface matching commercial VirtualApp-style installPackage flow.
 *
 * Real VirtualCore binary (VirtualApp / fork) would implement:
 *   VirtualCore.get().installPackage(path, flags)
 *   VirtualCore.get().isAppInstalled(pkg)
 *   VirtualCore.get().uninstallPackage(pkg)
 *   VirtualCore.get().launchApp(pkg)
 *
 * Until that native/Java core is linked, this manager:
 *  - resolves the exact clone path BitAIM uses
 *  - stages metadata under app files / Shizuku tmp
 *  - tracks installed version for mismatch re-clone
 *  - launches via virtual host + system package as bridge
 *
 * No invented offsets. No redistribution of Carrom binaries.
 */
object VirtualPackageManager {

    private const val TAG = "UnoVPkg"
    private const val PREFS = "uno_virtual_pkg"
    private const val KEY_INSTALLED_VC = "installed_version_code"
    private const val KEY_CLONE_PATH = "clone_path"

    data class InstallResult(
        val success: Boolean,
        val versionCode: Long,
        val path: String?,
        val message: String
    )

    fun isAppInstalled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getLong(KEY_INSTALLED_VC, 0L) > 0L
    }

    fun installedVersionCode(context: Context): Long {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(KEY_INSTALLED_VC, 0L)
    }

    /**
     * Clone Play install into virtual bookkeeping (parent-dir algorithm).
     * Re-clones when device versionCode != sandbox versionCode.
     */
    fun installPackage(context: Context): InstallResult {
        val src = PackageClone.resolveSource(context)
            ?: return InstallResult(false, 0, null, "Carrom not installed on device")

        if (src.engineArtifacts.isEmpty()) {
            return InstallResult(
                false, src.versionCode, src.installPath,
                "Feature module missing — open Carrom once from Play"
            )
        }

        val current = installedVersionCode(context)
        if (current != 0L && current != src.versionCode) {
            Log.i(TAG, "version mismatch device=${src.versionCode} sandbox=$current → re-clone")
            uninstallPackage(context)
        }

        // Stage clone marker + path list (full VirtualCore would unpack APKs here)
        val stage = File(context.filesDir, "virtual_clone/${src.packageName}").apply { mkdirs() }
        try {
            File(stage, "clone_path.txt").writeText(src.installPath)
            File(stage, "version_code.txt").writeText(src.versionCode.toString())
            File(stage, "splits.txt").writeText(src.splitApks.joinToString("\n"))
            File(stage, "engines.txt").writeText(src.engineArtifacts.joinToString("\n"))
        } catch (t: Throwable) {
            Log.e(TAG, "stage write failed", t)
            return InstallResult(false, src.versionCode, src.installPath, "stage failed: ${t.message}")
        }

        if (ShizukuBridge.probe(context).running) {
            ShizukuBridge.prepareVirtualDirs(src.packageName)
            ShizukuBridge.execElevated(
                "cp -f ${src.installPath}/base.apk /data/local/tmp/uno_virtual/${src.packageName}/ 2>/dev/null; echo STAGED"
            )
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(KEY_INSTALLED_VC, src.versionCode)
            .putString(KEY_CLONE_PATH, src.installPath)
            .apply()

        Log.i(TAG, "installPackage OK ver=${src.versionCode} path=${src.installPath}")
        return InstallResult(
            true, src.versionCode, src.installPath,
            "Cloned metadata v${src.versionName} (${src.versionCode}) · ${src.engineArtifacts.size} engine file(s)"
        )
    }

    fun uninstallPackage(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        try {
            File(context.filesDir, "virtual_clone").deleteRecursively()
        } catch (_: Throwable) {
        }
        Log.i(TAG, "uninstallPackage cleared")
    }

    fun launchApp(context: Context): Boolean {
        if (!isAppInstalled(context)) {
            val r = installPackage(context)
            if (!r.success) return false
        }
        return VirtualEngine.start(context)
    }
}
