package com.uno.reverse.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.uno.reverse.nativebridge.SharedState
import com.uno.reverse.nativebridge.NativeBridge

/*
 * The control panel. Built programmatically so the theme lives in one
 * place and every row shares the same shape.
 *
 * Rows:
 *   AutoPlay          toggle
 *   AutoQueue         toggle
 *   KeepLine          toggle
 *   PredictionLines   toggle
 *   LineCount         stepper (8 / 16 / 24 / 64)
 *   SolveRate         stepper (60 / 30 / 15 Hz)
 *   Profile           stepper (Auto / Full / Lean / Direct)
 *   Accounts          Google / Facebook status rows
 *   Reset             button
 */
@SuppressLint("ViewConstructor")
class PanelView(
    context: Context,
    private val onReset: () -> Unit
) : LinearLayout(context) {

    private val density = resources.displayMetrics.density

    private val toggles = HashMap<Int, ToggleRow>()
    private val steppers = HashMap<Int, StepperRow>()

    init {
        orientation = VERTICAL
        background = cardBackground()
        padding = dp(Theme.PANEL_PADDING_DP)

        // Title row
        addView(titleRow())

        // Toggles
        addView(toggleRow(SharedState.Flag.AUTOPLAY, "AutoPlay"))
        addView(toggleRow(SharedState.Flag.AUTOQUEUE, "AutoQueue"))
        addView(toggleRow(SharedState.Flag.KEEP_LINE, "KeepLine"))
        addView(toggleRow(SharedState.Flag.SHOW_LINES, "PredictionLines"))

        // Steppers
        addView(stepperRow(
            SharedState.Flag.LINE_COUNT, "Line Count",
            intArrayOf(8, 16, 24, 64),
            intArrayOf(16, 16, 24, 64),
            listOf("8", "16", "24", "64")
        ))
        addView(stepperRow(
            SharedState.Flag.SOLVE_RATE, "Solve Rate",
            intArrayOf(60, 30, 15, 5),
            intArrayOf(30, 30, 15, 5),
            listOf("60 Hz", "30 Hz", "15 Hz", "5 Hz")
        ))
        addView(stepperRow(
            SharedState.Flag.PROFILE, "Profile",
            intArrayOf(0, 1, 2, 3),
            intArrayOf(0, 0, 2, 3),
            listOf("Auto", "Full", "Lean", "Direct")
        ))

        // Accounts section
        addView(sectionTitle("Accounts"))
        addView(accountRow("Google", "google"))
        addView(accountRow("Facebook", "facebook"))

        // Divider + Reset
        addView(divider())
        addView(resetButton())
    }

    // ------------------------------------------------------------------
    // Row builders
    // ------------------------------------------------------------------

    private fun titleRow(): View {
        val tv = TextView(context).apply {
            text = "Uno Reverse"
            setTextColor(Theme.GOLD)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, Theme.TEXT_TITLE_SP)
            typeface = android.graphics.Typeface.create(
                "sans-serif-medium",
                android.graphics.Typeface.BOLD
            )
            letterSpacing = 0.04f
        }
        val lp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        tv.layoutParams = lp
        return tv
    }

    private fun sectionTitle(text: String): View {
        val tv = TextView(context).apply {
            this.text = text.uppercase()
            setTextColor(Theme.GOLD_DIM)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, Theme.TEXT_META_SP)
            letterSpacing = 0.12f
            typeface = android.graphics.Typeface.create(
                "sans-serif-medium",
                android.graphics.Typeface.BOLD
            )
        }
        val lp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        lp.bottomMargin = dp(6)
        tv.layoutParams = lp
        return tv
    }

    private fun toggleRow(flag: Int, label: String): View {
        val row = ToggleRow(context, label, flag)
        row.valueChanged = { f, v ->
            NativeBridge.setFlag(f, if (v) 1 else 0)
        }
        val lp = LayoutParams(LayoutParams.MATCH_PARENT, dp(Theme.ROW_HEIGHT_DP))
        row.layoutParams = lp
        toggles[flag] = row
        return row
    }

    private fun stepperRow(
        flag: Int,
        label: String,
        values: IntArray,
        defaults: IntArray,
        display: List<String>
    ): View {
        val row = StepperRow(context, label, values, defaults, display)
        row.valueChanged = { f, v ->
            NativeBridge.setFlag(f, v)
        }
        val lp = LayoutParams(LayoutParams.MATCH_PARENT, dp(Theme.ROW_HEIGHT_DP))
        row.layoutParams = lp
        steppers[flag] = row
        return row
    }

    private fun accountRow(label: String, providerKey: String): View {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        val name = TextView(context).apply {
            text = label
            setTextColor(Theme.FG)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, Theme.TEXT_ROW_SP)
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        }
        val status = TextView(context).apply {
            text = "Checking…"
            setTextColor(Theme.MUTED)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, Theme.TEXT_META_SP)
        }
        row.addView(name)
        row.addView(status)
        return row
    }

    private fun divider(): View {
        val v = View(context)
        v.setBackgroundColor(Theme.BORDER)
        val lp = LayoutParams(LayoutParams.MATCH_PARENT, dp(Theme.DIVIDER_DP))
        lp.topMargin = dp(12)
        lp.bottomMargin = dp(12)
        v.layoutParams = lp
        return v
    }

    private fun resetButton(): View {
        val b = Button(context).apply {
            text = "Reset to defaults"
            isAllCaps = false
            setTextColor(Theme.BG)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, Theme.TEXT_ROW_SP)
            background = pillBackground()
            setOnClickListener { onReset() }
        }
        b.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(44))
        return b
    }

    // ------------------------------------------------------------------
    // External state sync
    // ------------------------------------------------------------------

    fun syncFromState(s: SharedState.Snapshot) {
        toggles[SharedState.Flag.AUTOPLAY]?.setChecked(s.autoplay)
        toggles[SharedState.Flag.AUTOQUEUE]?.setChecked(s.autoqueue)
        toggles[SharedState.Flag.KEEP_LINE]?.setChecked(s.keepLine)
        toggles[SharedState.Flag.SHOW_LINES]?.setChecked(s.showLines)

        steppers[SharedState.Flag.LINE_COUNT]?.setCurrent(s.lineCount)
        steppers[SharedState.Flag.SOLVE_RATE]?.setCurrent(s.solveRateHz)
        steppers[SharedState.Flag.PROFILE]?.setCurrent(s.profile)
    }

    // ------------------------------------------------------------------
    // Backgrounds
    // ------------------------------------------------------------------

    private fun cardBackground(): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(Theme.PANEL_RADIUS_DP).toFloat()
        setColor(Theme.SURFACE)
        setStroke(dp(1), Theme.BORDER)
    }

    private fun pillBackground(): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(22).toFloat()
        setColor(Theme.GOLD)
    }

    private fun dp(v: Int): Int = (v * density).toInt()
}

// =====================================================================
// ToggleRow
// =====================================================================

@SuppressLint("ViewConstructor")
private class ToggleRow(
    context: Context,
    label: String,
    private val flag: Int
) : LinearLayout(context) {

    var valueChanged: ((Int, Boolean) -> Unit)? = null

    private val density = resources.displayMetrics.density
    private val labelView = TextView(context).apply {
        text = label
        setTextColor(Theme.FG)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
    }
    private val switchView = PillSwitch(context)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL

        switchView.setOnCheckedChangeListener { checked ->
            valueChanged?.invoke(flag, checked)
        }

        addView(labelView)
        addView(switchView)
    }

    fun setChecked(v: Boolean) {
        switchView.setCheckedQuiet(v)
    }
}

// =====================================================================
// StepperRow — cycles through a fixed list of values
// =====================================================================

@SuppressLint("ViewConstructor")
private class StepperRow(
    context: Context,
    label: String,
    private val values: IntArray,
    private val defaults: IntArray,
    private val display: List<String>
) : LinearLayout(context) {

    var valueChanged: ((Int, Int) -> Unit)? = null

    private var index = 0
    private val density = resources.displayMetrics.density

    private val labelView = TextView(context).apply {
        text = label
        setTextColor(Theme.FG)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
    }
    private val valueView = TextView(context).apply {
        setTextColor(Theme.GOLD)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        typeface = android.graphics.Typeface.create(
            "sans-serif-medium",
            android.graphics.Typeface.BOLD
        )
        setPadding(dp(12), 0, 0, 0)
        setOnClickListener { next() }
    }

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(labelView)
        addView(valueView)
        applyDefault()
    }

    private fun applyDefault() {
        index = values.indexOfFirst { it == defaults[0] }.coerceAtLeast(0)
        valueView.text = display.getOrElse(index) { "" }
    }

    private fun next() {
        index = (index + 1) % values.size
        valueView.text = display.getOrElse(index) { "" }
        valueChanged?.invoke(defaults[0], values[index])
    }

    fun setCurrent(value: Int) {
        val i = values.indexOfFirst { it == value }
        if (i >= 0) {
            index = i
            valueView.text = display.getOrElse(index) { "" }
        }
    }

    private fun dp(v: Int): Int = (v * density).toInt()
}

// =====================================================================
// PillSwitch — custom gold/black pill toggle
// =====================================================================

private class PillSwitch(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private val wPx = (40 * density).toInt()
    private val hPx = (22 * density).toInt()
    private val thumbPx = 18 * density

    private var checked = false
    private var anim = 0f

    private val trackPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        style = android.graphics.Paint.Style.FILL
    }
    private val thumbPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        style = android.graphics.Paint.Style.FILL
        color = Theme.FG
    }

    var onCheckedChangeListener: ((Boolean) -> Unit)? = null
    private var suppressCallback = false

    init {
        setOnClickListener {
            checked = !checked
            animateTo(if (checked) 1f else 0f)
            if (!suppressCallback) onCheckedChangeListener?.invoke(checked)
        }
    }

    fun setCheckedQuiet(v: Boolean) {
        if (checked == v) return
        suppressCallback = true
        checked = v
        animateTo(if (checked) 1f else 0f)
        suppressCallback = false
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(wPx, hPx)
    }

    private fun animateTo(target: Float) {
        val start = anim
        val delta = target - start
        val duration = 140L
        val t0 = System.currentTimeMillis()
        val runnable = object : Runnable {
            override fun run() {
                val elapsed = System.currentTimeMillis() - t0
                val t = (elapsed.toFloat() / duration).coerceIn(0f, 1f)
                anim = start + delta * t
                invalidate()
                if (t < 1f) postDelayed(this, 16)
            }
        }
        post(runnable)
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val r = hPx / 2f
        trackPaint.color = blend(Theme.BG, Theme.GOLD, anim)
        canvas.drawRoundRect(0f, 0f, wPx.toFloat(), hPx.toFloat(), r, r, trackPaint)

        val thumbCx = r + (wPx - 2 * r) * anim
        thumbPaint.color = if (checked) Theme.BG else Theme.MUTED
        canvas.drawCircle(thumbCx, r, thumbPx / 2f, thumbPaint)
    }

    private fun blend(a: Int, b: Int, t: Float): Int {
        val ar = (a shr 16) and 0xFF
        val ag = (a shr 8) and 0xFF
        val ab = a and 0xFF
        val br = (b shr 16) and 0xFF
        val bg = (b shr 8) and 0xFF
        val bb = b and 0xFF
        val r = (ar + (br - ar) * t).toInt()
        val g = (ag + (bg - ag) * t).toInt()
        val bl = (ab + (bb - ab) * t).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }

    private fun dp(v: Int): Int = (v * density).toInt()
}