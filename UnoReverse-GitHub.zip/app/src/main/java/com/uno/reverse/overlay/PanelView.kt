package com.uno.reverse.overlay
import android.content.Context
class PanelView(c: Context) {
    fun show() {}
    fun hide() {}
    fun toggle() {}
}
