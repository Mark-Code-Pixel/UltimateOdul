package com.uno.reverse
import android.app.Application
import android.content.Context
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.util.Log
class UnoReverseApp : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        Log.i("UnoReverseApp", "starting")
        VirtualCore.get().initialize(this)
    }
    companion object {
        @Volatile private var instance: UnoReverseApp? = null
        fun get(): UnoReverseApp = instance!!
        fun context(): Context = get().applicationContext
    }
}
