package com.uno.reverse

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Build
import android.os.Bundle
import com.uno.reverse.core.ContainerService
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.nativebridge.NativeBridge
import com.uno.reverse.util.Cpu
import com.uno.reverse.util.Log as ULog
import com.uno.reverse.util.Ram
import java.io.File

class UnoReverseApp : Application() {

    companion object {
        private const val TAG = "UnoReverseApp"

        @Volatile
        @JvmStatic
        lateinit var instance: UnoReverseApp
            private set

        @JvmStatic
        fun rootDir(context: Context): File {
            val dir = File(context.filesDir, "unoreverse")
            if (!dir.exists()) dir.mkdirs()
            return dir
        }

        @JvmStatic
        fun virtualDir(context: Context): File {
            val dir = File(rootDir(context), "virtual")
            if (!dir.exists()) dir.mkdirs()
            return dir
        }

        @JvmStatic
        fun logDir(context: Context): File {
            val dir = File(rootDir(context), "logs")
            if (!dir.exists()) dir.mkdirs()
            return dir
        }
    }

    private var isMainProcess: Boolean = false

    override fun onCreate() {
        super.onCreate()
        instance = this

        isMainProcess = detectMainProcess()

        if (!isMainProcess) {
            return
        }

        ULog.init(logDir(this))
        ULog.i(TAG, "Uno Reverse starting. Version=${BuildConfig.VERSION_NAME} " +
                "code=${BuildConfig.VERSION_CODE} abi=${Build.SUPPORTED_ABIS.firstOrNull()}")

        seedDefaultProfileIfNeeded()
        recordDeviceProfile()

        try {
            VirtualCore.init(this)
            ULog.i(TAG, "VirtualCore initialized. Registered guests: " +
                    "${VirtualCore.registeredGuestCount()}")
        } catch (t: Throwable) {
            ULog.e(TAG, "VirtualCore init failed", t)
        }

        try {
            NativeBridge.load()
            ULog.i(TAG, "Native bridge loaded. abi=${NativeBridge.activeAbi()} " +
                    "profile=${NativeBridge.defaultProfile()}")
        } catch (t: Throwable) {
            ULog.e(TAG, "Native bridge load failed", t)
        }

        registerActivityLifecycleCallbacks(lifecycleCallbacks)

        ContainerService.start(this)
    }

    override fun onTerminate() {
        if (isMainProcess) {
            try {
                VirtualCore.shutdown()
            } catch (t: Throwable) {
                ULog.e(TAG, "VirtualCore shutdown failed", t)
            }
        }
        super.onTerminate()
    }

    // ------------------------------------------------------------------

    private fun detectMainProcess(): Boolean {
        val procName = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            processName
        } else {
            try {
                File("/proc/self/cmdline").readText().trimEnd('\u0000')
            } catch (_: Throwable) {
                packageName
            }
        }
        return procName == packageName
    }

    private fun seedDefaultProfileIfNeeded() {
        val marker = File(rootDir(this), ".profile_seeded")
        if (marker.exists()) return

        val profile = """
            {
              "autoplay": true,
              "autoqueue": true,
              "keep_line": true,
              "show_lines": false,
              "table_preference": "highest_affordable",
              "line_count": 16,
              "solve_rate_hz": 30,
              "profile": "auto",
              "randomize_shot_selection": true,
              "top_k_randomize": 3
            }
        """.trimIndent()

        try {
            File(rootDir(this), "headless.json").writeText(profile)
            marker.writeText(System.currentTimeMillis().toString())
            ULog.i(TAG, "Default headless profile written")
        } catch (t: Throwable) {
            ULog.e(TAG, "Failed to seed headless profile", t)
        }
    }

    private fun recordDeviceProfile() {
        val cores = Cpu.coreCount()
        val ramBytes = Ram.totalBytes(this)
        val neon = Cpu.hasNeon()
        val is64 = Build.SUPPORTED_64_BIT_ABIS.isNotEmpty() &&
                Build.SUPPORTED_ABIS.firstOrNull()?.contains("64") == true

        val json = """
            {
              "cores": $cores,
              "ram_bytes": $ramBytes,
              "neon": $neon,
              "is_64bit": $is64,
              "primary_abi": "${Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"}",
              "sdk": ${Build.VERSION.SDK_INT},
              "manufacturer": "${Build.MANUFACTURER}",
              "model": "${Build.MODEL}"
            }
        """.trimIndent()

        try {
            File(rootDir(this), "device.json").writeText(json)
        } catch (t: Throwable) {
            ULog.e(TAG, "Failed to record device profile", t)
        }
    }

    // ------------------------------------------------------------------
    // Activity lifecycle
    // ------------------------------------------------------------------

    private val lifecycleCallbacks = object : ActivityLifecycleCallbacks {

        override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
            if (activity.javaClass.name.startsWith("com.uno.reverse.lifecycle.Stub")) {
                try {
                    com.uno.reverse.overlay.OverlayService.notifyGuestForeground(activity)
                } catch (_: Throwable) {}
            }
        }

        override fun onActivityStarted(activity: Activity) {}
        override fun onActivityResumed(activity: Activity) {}
        override fun onActivityPaused(activity: Activity) {}
        override fun onActivityStopped(activity: Activity) {}
        override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

        override fun onActivityDestroyed(activity: Activity) {
            if (activity.javaClass.name.startsWith("com.uno.reverse.lifecycle.Stub")) {
                try {
                    com.uno.reverse.overlay.OverlayService.notifyGuestBackground(activity)
                } catch (_: Throwable) {}
            }
        }
    }
}