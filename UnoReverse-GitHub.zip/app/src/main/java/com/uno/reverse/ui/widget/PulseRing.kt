package com.uno.reverse.ui.widget

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import com.uno.reverse.ui.theme.Anim
import com.uno.reverse.ui.theme.ColorPalette

/*
 * Two concentric gold rings that expand outward from a centre point
 * and fade. Used behind the tick, the splash logo, and the connect
 * action.
 *
 * Cheap: two arcs per frame.
 */
class PulseRing @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var color: Int = ColorPalette.GOLD
    var active: Boolean = true
        set(value) {
            field = value
            if (value) startLoop() else stopLoop()
            invalidate()
        }

    private val density = resources.displayMetrics.density

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
    }

    private val rect = RectF()

    private var animator: ValueAnimator? = null
    private var phase = 0f

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (active) startLoop()
    }

    override fun onDetachedFromWindow() {
        stopLoop()
        super.onDetachedFromWindow()
    }

    private fun startLoop() {
        if (animator != null) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = Anim.PULSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopLoop() {
        animator?.cancel()
        animator = null
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val cx = width / 2f
        val cy = height / 2f
        val maxR = minOf(width, height) / 2f - 4f * density

        // Two rings, offset in phase by half a cycle.
        for (i in 0..1) {
            val t = (phase + i * 0.5f) % 1f
            val r = maxR * (0.45f + 0.55f * t)
            val alpha = (1f - t) * 0.65f
            ringPaint.color = ColorPalette.withAlpha(color, alpha)
            rect.set(cx - r, cy - r, cx + r, cy + r)
            canvas.drawArc(rect, 0f, 360f, false, ringPaint)
        }
    }
}