package com.uno.reverse.core
import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.Bundle
class VirtualContentProvider : ContentProvider() {
    override fun onCreate() = true
    override fun query(uri: Uri, p: Array<out String>?, s: String?, a: Array<out String>?, o: String?): Cursor? {
        val c = MatrixCursor(arrayOf("key", "value"))
        VirtualCore.get().getAllGuests().forEach { c.addRow(arrayOf(it.packageName, it.versionCode.toString())) }
        return c
    }
    override fun getType(uri: Uri) = null
    override fun insert(uri: Uri, v: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<out String>?) = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<out String>?) = 0
    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        val b = Bundle()
        if (method == "isGuest") b.putBoolean("result", arg != null && VirtualCore.get().isGuestInstalled(arg))
        return b
    }
}
