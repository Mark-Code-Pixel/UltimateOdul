package com.uno.reverse.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.uno.reverse.MainActivity
import com.uno.reverse.R
import com.uno.reverse.nativebridge.NativeBridge
import com.uno.reverse.pipeline.OffsetPipeline
import com.uno.reverse.process.GuestInventory
import com.uno.reverse.util.Log as ULog
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/*
 * Owns the container lifecycle. Starts the guest, waits for the runtime
 * agent to complete its 5-second settling dump, runs the static offset
 * pipeline if needed, resolves runtime offsets, installs hooks, starts
 * the solver.
 *
 * Order of operations before spawn:
 *   1. Load native bridge.
 *   2. Create the shared memory region.
 *   3. Persist the /proc path into the virtual root.
 *   4. Spawn the guest with UNOREVERSE_SHM_PATH pointing at that path.
 *
 * Order of operations after inventory:
 *   1. Static pipeline (metadata_report.json) — once.
 *   2. Runtime resolver (offsets.json) — once.
 *   3. Install hooks.
 *   4. Start solver.
 */
class ContainerService : Service() {

    companion object {
        const val TAG = "ContainerService"

        const val ACTION_LAUNCH   = "com.uno.reverse.action.LAUNCH"
        const val ACTION_SHUTDOWN = "com.uno.reverse.action.SHUTDOWN"
        const val EXTRA_PKG       = "pkg"

        const val BROADCAST_LAUNCH_OK   = "com.uno.reverse.broadcast.LAUNCH_OK"
        const val BROADCAST_LAUNCH_FAIL = "com.uno.reverse.broadcast.LAUNCH_FAIL"
        const val EXTRA_REASON          = "reason"

        private const val CHANNEL_ID      = "unoreverse.container"
        private const val NOTIFICATION_ID = 0x5501

        private const val SETTLE_MS = 5000L
        private const val HARD_DEADLINE_MS = 8000L
        private const val POLL_INTERVAL_MS = 200L

        @JvmStatic
        fun start(context: Context) {
            val i = Intent(context, ContainerService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }

        @JvmStatic
        fun startWithGuest(context: Context, pkg: String) {
            val i = Intent(context, ContainerService::class.java).apply {
                action = ACTION_LAUNCH
                putExtra(EXTRA_PKG, pkg)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val guestRunning = AtomicBoolean(false)
    private var guestProcess: Process? = null
    private var currentGuestPkg: String = ""
    private var settleStartMs: Long = 0L
    private var pollRunnable: Runnable? = null
    private var sharedRegionPath: String = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_LAUNCH -> {
                val pkg = intent.getStringExtra(EXTRA_PKG) ?: ""
                if (pkg.isEmpty()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForegroundSafe(buildNotification("Preparing container…", indeterminate = true))
                beginGuestLaunch(pkg)
            }
            ACTION_SHUTDOWN -> {
                shutdownGuest("user_request")
                stopSelf()
            }
            else -> {
                startForegroundSafe(buildNotification("Container idle", indeterminate = false))
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        pollRunnable?.let { mainHandler.removeCallbacks(it) }
        shutdownGuest("service_destroyed")
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // Launch flow
    // ------------------------------------------------------------------

    private fun beginGuestLaunch(pkg: String) {
        if (guestRunning.get()) {
            ULog.w(TAG, "Guest already running: $currentGuestPkg")
            return
        }
        currentGuestPkg = pkg

        val guestRecord = VirtualCore.guest(pkg)
        if (guestRecord == null) {
            failLaunch("Guest not registered: $pkg")
            return
        }

        ULog.i(TAG, "Preparing guest $pkg")

        // ---- 1. Load native bridge ----------------------------------
        NativeBridge.load()

        // ---- 2. Create the shared memory region ---------------------
        val path = try {
            NativeBridge.createSharedRegion()
        } catch (t: Throwable) {
            ULog.e(TAG, "createSharedRegion threw", t)
            ""
        }

        if (path.isNotEmpty()) {
            sharedRegionPath = path
            ULog.i(TAG, "Shared region at $path")
            // Persist the path so GuestSpawner and OverlayService can
            // both read it. The file lives inside the guest's virtual
            // directory so a single cleanup removes it with the guest.
            try {
                File(guestRecord.virtualRoot, "shared_region_path.txt")
                    .writeText(path)
            } catch (t: Throwable) {
                ULog.e(TAG, "Failed to write shared_region_path.txt", t)
            }
        } else {
            ULog.w(TAG, "Shared region creation failed; guest will run without overlay sync")
            try {
                val f = File(guestRecord.virtualRoot, "shared_region_path.txt")
                if (f.exists()) f.delete()
            } catch (_: Throwable) {}
        }

        // ---- 3. Spawn the guest -------------------------------------
        val proc = try {
            com.uno.reverse.process.GuestSpawner.spawn(this, guestRecord)
        } catch (t: Throwable) {
            failLaunch("Spawn failed: ${t.message}")
            return
        }

        guestProcess = proc
        guestRunning.set(true)
        settleStartMs = System.currentTimeMillis()

        updateNotification("Waiting for runtime agent…")

        schedulePolling(guestRecord)
    }

    private fun schedulePolling(guestRecord: VirtualCore.GuestRecord) {
        val inventoryFile = File(guestRecord.virtualRoot, "runtime_inventory.json")

        val runnable = object : Runnable {
            override fun run() {
                val elapsed = System.currentTimeMillis() - settleStartMs

                if (inventoryFile.exists() && inventoryFile.length() > 0L) {
                    val inv = parseInventory(inventoryFile)
                    if (inv != null && inv.complete) {
                        onLaunchOk(inv, guestRecord)
                        return
                    }
                }

                if (elapsed >= HARD_DEADLINE_MS) {
                    onLaunchTimeout(elapsed)
                    return
                }

                if (elapsed >= SETTLE_MS) {
                    updateNotification("Finalizing inventory…")
                } else {
                    val remaining = (SETTLE_MS - elapsed) / 1000 + 1
                    updateNotification("Settling… ${remaining}s")
                }

                mainHandler.postDelayed(this, POLL_INTERVAL_MS)
            }
        }
        pollRunnable = runnable
        mainHandler.postDelayed(runnable, POLL_INTERVAL_MS)
    }

    private fun onLaunchOk(inv: GuestInventory,
                           guestRecord: VirtualCore.GuestRecord) {
        ULog.i(TAG, "Launch OK. engine=${inv.engine} modules=${inv.nativeLibCount} " +
                "dex=${inv.dexCount} jni=${inv.jniBindingCount}")

        val virtualRoot  = guestRecord.virtualRoot
        val reportFile   = File(virtualRoot, "metadata_report.json")
        val offsetsFile  = File(virtualRoot, "offsets.json")
        val reasonFile   = File(virtualRoot, "offsets.json.reason")

        // ---- Stage 1: static pipeline -------------------------------
        if (!reportFile.exists() || reportFile.length() == 0L) {
            ULog.i(TAG, "Running static offset pipeline…")
            try {
                val report = OffsetPipeline(this).run(guestRecord.packageName)
                if (!report.complete) {
                    ULog.w(TAG, "Pipeline incomplete: ${report.failureReason}")
                } else {
                    ULog.i(TAG, "Pipeline wrote report: " +
                            "module=${report.il2cppModule} " +
                            "targets=${report.targetClasses.size} " +
                            "metadata=v${report.metadataVersion}")
                }
            } catch (t: Throwable) {
                ULog.e(TAG, "Pipeline threw", t)
            }
        } else {
            ULog.i(TAG, "Reusing existing metadata_report.json")
        }

        // ---- Stage 2: runtime resolver ------------------------------
        if (!offsetsFile.exists() || offsetsFile.length() == 0L) {
            if (reportFile.exists() && reportFile.length() > 0L) {
                ULog.i(TAG, "Resolving runtime offsets…")
                try {
                    val (ok, reason) = NativeBridge.resolveOffsets(
                        reportFile.absolutePath,
                        offsetsFile.absolutePath
                    )
                    if (!ok) {
                        val detail = readReason(reasonFile) ?: reason
                        ULog.w(TAG, "Runtime resolve failed: $detail")
                    } else {
                        ULog.i(TAG, "Runtime resolve OK. offsets.json written " +
                                "(${offsetsFile.length()} bytes)")
                    }
                } catch (t: Throwable) {
                    ULog.e(TAG, "resolveOffsets threw", t)
                }
            } else {
                ULog.w(TAG, "Skipping resolve: no metadata_report.json")
            }
        } else {
            ULog.i(TAG, "Reusing existing offsets.json")
        }

        // ---- Stage 3: install hooks ---------------------------------
        var hooksOk = false
        if (offsetsFile.exists() && offsetsFile.length() > 0L) {
            try {
                hooksOk = NativeBridge.installHooks(offsetsFile.absolutePath)
                if (hooksOk) {
                    ULog.i(TAG, "Hooks installed")
                } else {
                    ULog.w(TAG, "Hook install returned false")
                }
            } catch (t: Throwable) {
                ULog.e(TAG, "installHooks threw", t)
            }
        } else {
            ULog.w(TAG, "Skipping hooks: no offsets.json")
        }

        // ---- Stage 4: solver ----------------------------------------
        if (hooksOk) {
            try {
                val solverOk = NativeBridge.startSolver()
                ULog.i(TAG, "Solver start=$solverOk")
            } catch (t: Throwable) {
                ULog.e(TAG, "startSolver threw", t)
            }
        }

        // ---- Stage 5: launch overlay if enabled ---------------------
        if (isOverlayEnabled()) {
            try {
                com.uno.reverse.overlay.OverlayService.start(this, guestRecord.packageName)
                ULog.i(TAG, "Overlay started")
            } catch (t: Throwable) {
                ULog.e(TAG, "Overlay start threw", t)
            }
        }

        // ---- Stage 6: notify UI -------------------------------------
        updateNotification(
            if (hooksOk) "Running (${inv.engine})"
            else "Running (no instrumentation)"
        )

        sendBroadcast(Intent(BROADCAST_LAUNCH_OK).apply {
            setPackage(packageName)
            putExtra("engine", inv.engine)
            putExtra("modules", inv.nativeLibCount)
            putExtra("dex", inv.dexCount)
            putExtra("instrumented", hooksOk)
        })
    }

    private fun onLaunchTimeout(elapsedMs: Long) {
        ULog.e(TAG, "Launch timeout after ${elapsedMs}ms")
        failLaunch("Runtime inventory incomplete after ${elapsedMs}ms")
    }

    private fun failLaunch(reason: String) {
        ULog.e(TAG, "Launch failed: $reason")
        shutdownGuest("launch_failed")
        sendBroadcast(Intent(BROADCAST_LAUNCH_FAIL).apply {
            setPackage(packageName)
            putExtra(EXTRA_REASON, reason)
        })
        updateNotification("Launch failed")
    }

    private fun shutdownGuest(reason: String) {
        pollRunnable?.let { mainHandler.removeCallbacks(it) }
        pollRunnable = null
        val p = guestProcess
        guestProcess = null
        guestRunning.set(false)
        if (p != null) {
            ULog.i(TAG, "Killing guest: $reason")
            try { p.destroy() } catch (_: Throwable) {}
        }
        try { com.uno.reverse.overlay.OverlayService.stop(this) } catch (_: Throwable) {}
        try { NativeBridge.stopSolver() } catch (_: Throwable) {}
        try { NativeBridge.shutdown() } catch (_: Throwable) {}
        sharedRegionPath = ""
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private fun isOverlayEnabled(): Boolean {
        return try {
            val f = File(filesDir, "unoreverse/overlay.enabled")
            f.exists() && f.readText().trim() == "1"
        } catch (_: Throwable) {
            false
        }
    }

    private fun readReason(f: File): String? = try {
        if (f.exists() && f.length() > 0L) f.readText().trim().ifEmpty { null } else null
    } catch (_: Throwable) {
        null
    }

    private fun parseInventory(f: File): GuestInventory? = try {
        val text = f.readText()
        if (text.isBlank()) return null

        val complete = jsonBool(text, "complete")
        val engine = jsonString(text, "engine") ?: "unknown"
        val pid = jsonLong(text, "pid").toInt()
        val startTime = jsonLong(text, "start_time_ms")
        val dumpTime = jsonLong(text, "dump_time_ms")
        val nativeLibCount = jsonLong(text, "native_lib_count").toInt()
        val dexCount = jsonLong(text, "dex_count").toInt()
        val jniCount = jsonLong(text, "jni_binding_count").toInt()
        val anonExec = jsonLong(text, "anonymous_exec_regions").toInt()
        val confidence = jsonDouble(text, "engine_confidence").toFloat()
        val reason = jsonString(text, "failure_reason")

        GuestInventory(
            guestPackage = currentGuestPkg,
            pid = pid,
            startTimeMs = startTime,
            dumpTimeMs = dumpTime,
            engine = engine,
            engineConfidence = confidence,
            loadedModules = emptyList(),
            dexFiles = emptyList(),
            jniBindings = emptyList(),
            openFileDescriptors = emptyList(),
            anonymousExecRegions = anonExec,
            nativeLibCount = nativeLibCount,
            dexCount = dexCount,
            jniBindingCount = jniCount,
            complete = complete,
            failureReason = reason
        )
    } catch (t: Throwable) {
        ULog.e(TAG, "Inventory parse failed", t)
        null
    }

    private fun jsonString(s: String, key: String): String? {
        val needle = "\"$key\":"
        val i = s.indexOf(needle)
        if (i < 0) return null
        var j = i + needle.length
        while (j < s.length && s[j].isWhitespace()) j++
        if (j >= s.length) return null
        if (s[j] == '"') {
            val start = j + 1
            val end = s.indexOf('"', start)
            if (end < 0) return null
            return s.substring(start, end)
        }
        var k = j
        while (k < s.length && s[k] != ',' && s[k] != '}' && s[k] != '\n') k++
        return s.substring(j, k).trim()
    }

    private fun jsonLong(s: String, key: String): Long =
        jsonString(s, key)?.toLongOrNull() ?: 0L

    private fun jsonDouble(s: String, key: String): Double =
        jsonString(s, key)?.toDoubleOrNull() ?: 0.0

    private fun jsonBool(s: String, key: String): Boolean =
        jsonString(s, key)?.equals("true", ignoreCase = true) == true

    // ------------------------------------------------------------------
    // Notification
    // ------------------------------------------------------------------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val mgr = getSystemService(NotificationManager::class.java) ?: return
        if (mgr.getNotificationChannel(CHANNEL_ID) != null) return
        val ch = NotificationChannel(
            CHANNEL_ID,
            "Uno Reverse container",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Virtual container runtime status"
            setShowBadge(false)
        }
        mgr.createNotificationChannel(ch)
    }

    private fun buildNotification(text: String, indeterminate: Boolean): Notification {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Uno Reverse")
            .setContentText(text)
            .setSmallIcon(R.drawable.uno_reverse_logo)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(
                android.app.PendingIntent.getActivity(
                    this, 0,
                    Intent(this, MainActivity::class.java),
                    android.app.PendingIntent.FLAG_IMMUTABLE
                )
            )
        if (indeterminate) builder.setProgress(0, 0, true)
        return builder.build()
    }

    private fun startForegroundSafe(n: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, n,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    private fun updateNotification(text: String) {
        val mgr = getSystemService(NotificationManager::class.java) ?: return
        mgr.notify(NOTIFICATION_ID, buildNotification(text, indeterminate = true))
    }
}