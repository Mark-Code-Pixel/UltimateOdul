package com.uno.reverse.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/*
 * SYSTEM_ALERT_WINDOW helpers. The overlay only runs when the user has
 * explicitly granted the permission. If not granted, the container
 * runs headless and the overlay is skipped.
 */
object OverlayPermission {

    @JvmStatic
    fun granted(context: Context): Boolean {
        return try {
            Settings.canDrawOverlays(context)
        } catch (_: Throwable) {
            false
        }
    }

    @JvmStatic
    fun openSettings(context: Context) {
        try {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            i.data = Uri.parse("package:${context.packageName}")
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
        } catch (t: Throwable) {
            // Fallback: open the general app details page.
            try {
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                i.data = Uri.parse("package:${context.packageName}")
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
            } catch (_: Throwable) {}
        }
    }
}