package com.uno.reverse.pipeline

import android.content.Context
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.util.Log as ULog
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile

/*
 * Static offset pipeline.
 *
 * Runs once on first launch after the guest is imported. Produces a
 * target spec (metadata_report.json) that the runtime agent consumes at
 * hook time. No byte offsets are written by the pipeline — the runtime
 * resolver obtains those from the game's own IL2CPP API.
 *
 * The static analysis does:
 *   1. Extract global-metadata.dat from the imported APK.
 *   2. Parse it with MetadataParser.
 *   3. Heuristically locate target classes by field/method patterns.
 *   4. Scan every native .so for the IL2CPP runtime.
 *   5. Write metadata_report.json.
 *
 * The report is small (< 4KB) and text. It records class names, field
 * names, method names, and the IL2CPP module basename. Nothing else.
 */
class OffsetPipeline(private val context: Context) {

    data class TargetClass(
        val className: String,
        val namespace: String,
        val fields: List<String>,
        val methods: List<String>
    )

    data class PipelineReport(
        val metadataVersion: Int,
        val il2cppModule: String,
        val targetClasses: List<TargetClass>,
        val complete: Boolean,
        val failureReason: String?
    )

    fun run(guestPackage: String): PipelineReport {
        val virtualRoot = File(VirtualCore.guest(guestPackage)?.virtualRoot
            ?: return fail("guest not registered", 0, ""))
        val apk = File(virtualRoot, "apk/base.apk")
        if (!apk.exists()) return fail("guest APK missing", 0, "")

        // ---- 1. Extract metadata ------------------------------------
        val metaDir = File(virtualRoot, "metadata").apply { mkdirs() }
        val metaFile = File(metaDir, "global-metadata.dat")

        if (!metaFile.exists() || metaFile.length() == 0L) {
            val ok = extractMetadata(apk, metaFile)
            if (!ok) return fail("global-metadata.dat not in APK (packed or stripped)", 0, "")
        }

        // ---- 2. Parse metadata --------------------------------------
        val parser = try {
            MetadataParser.parse(metaFile)
        } catch (t: Throwable) {
            return fail("metadata parse failed: ${t.message}", 0, "")
        }

        ULog.i(TAG, "Metadata parsed: v${parser.version()} " +
                "types=${parser.typeCount()} fields=${parser.fieldCount()} methods=${parser.methodCount()}")

        // ---- 3. Identify target classes -----------------------------
        val targets = identifyTargets(parser)
        if (targets.isEmpty()) {
            return fail("no target classes identified in metadata", parser.version(), "")
        }

        // ---- 4. Find IL2CPP module ----------------------------------
        val abi = VirtualCore.guest(guestPackage)?.primaryAbi ?: "arm64-v8a"
        val libDir = File(virtualRoot, "lib/$abi")
        val scans = ElfScanner.scanDirectory(libDir)
        val il2cppModule = scans.firstOrNull { it.exportsIl2Cpp }?.fileName
            ?: return fail("no IL2CPP module found in $abi libs", parser.version(), "")

        ULog.i(TAG, "IL2CPP module: $il2cppModule " +
                "(init=${scans.first { it.fileName == il2cppModule }.il2cppInitPresent})")

        // ---- 5. Write report ----------------------------------------
        val report = PipelineReport(
            metadataVersion = parser.version(),
            il2cppModule = il2cppModule,
            targetClasses = targets,
            complete = true,
            failureReason = null
        )
        writeReport(File(virtualRoot, "metadata_report.json"), report)
        ULog.i(TAG, "Pipeline complete. targets=${targets.size}")

        return report
    }

    // ------------------------------------------------------------------

    private fun extractMetadata(apk: File, out: File): Boolean {
        return try {
            ZipFile(apk).use { zip ->
                val entry = zip.entries().asSequence()
                    .firstOrNull {
                        it.name.endsWith("global-metadata.dat") &&
                        it.name.contains("Metadata")
                    }
                    ?: return false
                zip.getInputStream(entry).use { input ->
                    out.outputStream().use { output -> input.copyTo(output) }
                }
                out.length() > 0L
            }
        } catch (t: Throwable) {
            ULog.e(TAG, "extractMetadata failed", t)
            false
        }
    }

    /*
     * Heuristic target identification. Carrom Pool's exact class names
     * are unknown, so the pipeline searches for classes whose field
     * sets match the shape of the objects we need to read.
     *
     * A "coin" class: has fields named position/velocity/mass/friction.
     * A "striker" class: has fields position + aim, no mass, matches the
     * same namespace as the coin class.
     * A "physics manager": has gravity, fixedDeltaTime.
     * A "turn manager": has currentPlayer / isMyTurn / isAnimating.
     *
     * Matching is case-insensitive on field names. The pipeline keeps
     * every candidate so the runtime resolver can try them in order and
     * take the first that resolves.
     */
    private fun identifyTargets(parser: MetadataParser): List<TargetClass> {
        val out = ArrayList<TargetClass>()

        val coinFieldHints = setOf("position", "velocity", "mass", "friction", "ispocketed", "type")
        val strikerFieldHints = setOf("position", "aimdirection", "aimpower", "rigidbody", "rb")
        val physicsHints = setOf("gravity", "fixeddeltatime", "fixedtimestep", "solveriterations",
            "bounciness", "dynamicfriction", "staticfriction")
        val turnHints = setOf("currentplayer", "ismyturn", "animating", "isanimating", "turn")

        val typeCount = parser.typeCount()
        val cap = minOf(typeCount, 60_000)

        for (ti in 0 until cap) {
            val t = parser.type(ti)
            if (t.fieldCount == 0 || t.fieldCount > 200) continue

            // Gather all field names for this class (lowercased).
            val fieldNames = ArrayList<String>(t.fieldCount)
            for (fi in t.fieldStart until t.fieldStart + t.fieldCount) {
                if (fi < 0 || fi >= parser.fieldCount()) break
                fieldNames.add(parser.field(fi).name.lowercase())
            }

            val lowerSet = fieldNames.toSet()
            val score = when {
                matchesAny(lowerSet, physicsHints) >= 2 -> "physics"
                matchesAny(lowerSet, turnHints) >= 2 -> "turn"
                matchesAny(lowerSet, coinFieldHints) >= 4 &&
                    t.fieldCount in 6..24 -> "coin"
                matchesAny(lowerSet, strikerFieldHints) >= 2 &&
                    t.fieldCount in 4..16 -> "striker"
                else -> null
            } ?: continue

            // Gather method names too — useful for disambiguating
            // multiple candidates at runtime.
            val methodNames = ArrayList<String>(t.methodCount)
            for (mi in t.methodStart until t.methodStart + t.methodCount) {
                if (mi < 0 || mi >= parser.methodCount()) break
                methodNames.add(parser.method(mi).name)
            }

            out.add(TargetClass(
                className = t.name,
                namespace = t.namespace,
                fields = fieldNames,
                methods = methodNames
            ))
        }

        return out
    }

    private fun matchesAny(set: Set<String>, hints: Set<String>): Int {
        var n = 0
        for (h in hints) if (set.contains(h)) n++
        return n
    }

    private fun writeReport(file: File, report: PipelineReport) {
        try {
            val root = JSONObject()
            root.put("metadata_version", report.metadataVersion)
            root.put("il2cpp_module", report.il2cppModule)
            root.put("complete", report.complete)
            root.put("failure_reason", report.failureReason ?: JSONObject.NULL)
            val arr = JSONArray()
            for (t in report.targetClasses) {
                val o = JSONObject()
                o.put("class", t.className)
                o.put("namespace", t.namespace)
                o.put("fields", JSONArray(t.fields))
                o.put("methods", JSONArray(t.methods))
                arr.put(o)
            }
            root.put("targets", arr)
            file.writeText(root.toString(2))
        } catch (t: Throwable) {
            ULog.e(TAG, "writeReport failed", t)
        }
    }

    private fun fail(reason: String, version: Int, module: String) = PipelineReport(
        metadataVersion = version,
        il2cppModule = module,
        targetClasses = emptyList(),
        complete = false,
        failureReason = reason
    ).also { ULog.w(TAG, "Pipeline incomplete: $reason") }

    companion object {
        private const val TAG = "OffsetPipeline"
    }
}