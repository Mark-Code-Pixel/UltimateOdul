package com.uno.reverse.pipeline
import android.content.Context
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.util.Log
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile
object OffsetPipeline {
    fun run(context: Context, pkg: String) {
        try {
            val g = VirtualCore.get().getGuest(pkg) ?: return
            val apk = File(g.sourceDir)
            val meta = extractMeta(apk) ?: run { Log.w("Pipeline", "no metadata"); return }
            val parser = MetadataParser()
            val offsets = parser.parse(meta)
            val out = File(VirtualCore.get().guestDir(pkg), "offsets.json")
            out.writeText(offsets.toString(2))
            Log.i("Pipeline", "offsets written")
        } catch (e: Exception) { Log.e("Pipeline", "${e.message}") }
    }
    private fun extractMeta(apk: File): ByteArray? {
        ZipFile(apk).use { z ->
            val e = z.getEntry("assets/bin/Data/Managed/Metadata/global-metadata.dat") ?: return null
            return z.getInputStream(e).readBytes()
        }
    }
}
