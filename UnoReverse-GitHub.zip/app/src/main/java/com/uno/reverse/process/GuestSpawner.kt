package com.uno.reverse.process
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.util.Log
object GuestSpawner {
    fun spawn(pkg: String): Int {
        val g = VirtualCore.get().getGuest(pkg) ?: return -1
        Log.i("GuestSpawner", "spawn $pkg")
        return 0
    }
}
