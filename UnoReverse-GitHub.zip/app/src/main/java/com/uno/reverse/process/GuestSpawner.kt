package com.uno.reverse.process

import android.content.Context
import android.os.Build
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.util.Log as ULog
import java.io.File

/*
 * Forks the guest process. The guest runs under the container's UID in a
 * separate PID, with libunoreverse.so preloaded by GuestMain before the
 * guest's own native libraries.
 *
 * Every environment variable the guest needs is set here. Nothing is
 * inherited implicitly that could leak the container's identity into the
 * guest.
 *
 * The shared memory region path is passed via UNOREVERSE_SHM_PATH. The
 * container creates the region before calling spawn() and writes the
 * path to a file inside the virtual directory; this function reads it
 * and forwards it into the environment. If the file is missing the
 * guest falls back to creating its own region — a degraded but working
 * path.
 */
object GuestSpawner {

    private const val TAG = "GuestSpawner"
    private const val APP_PROCESS = "/system/bin/app_process"

    @JvmStatic
    fun spawn(context: Context, guest: VirtualCore.GuestRecord): Process {
        val apk = File(guest.virtualRoot, "apk/base.apk")
        require(apk.exists() && apk.length() > 0L) {
            "Guest APK missing: ${apk.absolutePath}"
        }

        val libDir  = File(guest.virtualRoot, "lib/${guest.primaryAbi}")
        val dataDir = File(guest.virtualRoot, "data").apply { mkdirs() }
        val optDir  = File(dataDir, "dalvik-cache").apply { mkdirs() }
        val rootDir = guest.virtualRoot.absolutePath

        val agentLibDir = context.applicationInfo.nativeLibraryDir

        // ---- Read the shared region path (written by ContainerService) --
        val shmPathFile = File(guest.virtualRoot, "shared_region_path.txt")
        val shmPath = if (shmPathFile.exists() && shmPathFile.length() > 0L) {
            try {
                shmPathFile.readText().trim()
            } catch (_: Throwable) {
                ""
            }
        } else ""

        if (shmPath.isNotEmpty()) {
            ULog.i(TAG, "Guest will open shared region at $shmPath")
        } else {
            ULog.w(TAG, "No shared_region_path.txt — guest will create its own region")
        }

        val env = HashMap<String, String>()
        env["UNOREVERSE_ROOT"]     = rootDir
        env["UNOREVERSE_PKG"]      = guest.packageName
        env["UNOREVERSE_LIBDIR"]   = libDir.absolutePath
        env["UNOREVERSE_DATADIR"]  = dataDir.absolutePath
        env["UNOREVERSE_APKDIR"]   = apk.parentFile!!.absolutePath
        env["UNOREVERSE_AGENTDIR"] = agentLibDir
        env["UNOREVERSE_PROFILE"]  = "auto"
        if (shmPath.isNotEmpty()) {
            env["UNOREVERSE_SHM_PATH"] = shmPath
        }

        env["ANDROID_DEBUGGABLE"] = "0"
        env["ANDROID_ROOT"]       = "/system"
        env["ANDROID_DATA"]       = "/data"
        env["DALVIK_CACHE_DIR"]   = optDir.absolutePath
        env["CLASSPATH"]          = apk.absolutePath
        env["LOG_TAG"]            = "UnoReverseGuest"

        val cmd = listOf(
            APP_PROCESS,
            "-Djava.class.path=${apk.absolutePath}",
            "--runtime-arg", "-Djava.library.path=${agentLibDir}:${libDir.absolutePath}",
            "com.uno.reverse.process.GuestMain",
            guest.packageName
        )

        ULog.i(TAG, "Spawning: pkg=${guest.packageName} abi=${guest.primaryAbi}")

        val pb = ProcessBuilder(cmd)
            .directory(File("/"))
            .redirectErrorStream(true)

        val merged = pb.environment().apply {
            putAll(env)
            val existing = get("LD_LIBRARY_PATH") ?: ""
            val combined = if (existing.isEmpty())
                "$agentLibDir:${libDir.absolutePath}"
            else
                "$agentLibDir:${libDir.absolutePath}:$existing"
            put("LD_LIBRARY_PATH", combined)
        }
        @Suppress("UNUSED_EXPRESSION")
        merged

        val proc = try {
            pb.start()
        } catch (t: Throwable) {
            ULog.e(TAG, "ProcessBuilder.start failed", t)
            throw t
        }

        ULog.i(TAG, "Spawned guest pid=${pidOf(proc)}")

        Thread({ drainOutput(proc, guest.packageName) },
            "guest-stdout-${guest.packageName}").apply {
            isDaemon = true
            priority = Thread.MIN_PRIORITY
        }.start()

        return proc
    }

    // ------------------------------------------------------------------

    private fun pidOf(p: Process): Long = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) p.pid()
        else {
            val f = p.javaClass.getDeclaredField("pid")
            f.isAccessible = true
            (f.get(p) as Int).toLong()
        }
    } catch (_: Throwable) {
        -1L
    }

    private fun drainOutput(p: Process, pkg: String) {
        try {
            p.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    if (line.isNotBlank()) {
                        ULog.d("Guest[$pkg]", line)
                    }
                }
            }
        } catch (_: Throwable) {
            /* Guest exited. Pipe closed. */
        }
    }
}