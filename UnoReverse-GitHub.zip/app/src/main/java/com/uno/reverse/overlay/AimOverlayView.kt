package com.uno.reverse.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import com.uno.reverse.R

/**
 * Full-screen transparent view that draws the aim line / prediction.
 * Designed to be added as a system overlay.
 */
class AimOverlayView(context: Context) : View(context) {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.getColor(R.color.uno_red_bright)
        strokeWidth = 4f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.getColor(R.color.uno_red)
        strokeWidth = 12f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        alpha = 60
    }

    private var startX = 0f
    private var startY = 0f
    private var endX = 0f
    private var endY = 0f
    private var lineVisible = false

    fun setAimLine(sx: Float, sy: Float, ex: Float, ey: Float, visible: Boolean) {
        startX = sx
        startY = sy
        endX = ex
        endY = ey
        lineVisible = visible
        postInvalidateOnAnimation()
    }

    fun clearAim() {
        lineVisible = false
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!lineVisible) return

        // Soft glow then sharp line
        canvas.drawLine(startX, startY, endX, endY, glowPaint)
        canvas.drawLine(startX, startY, endX, endY, linePaint)

        // Small reverse-card style tip
        val path = Path()
        path.moveTo(endX, endY)
        path.lineTo(endX - 10f, endY - 6f)
        path.lineTo(endX - 10f, endY + 6f)
        path.close()
        canvas.drawPath(path, linePaint)
    }
}
