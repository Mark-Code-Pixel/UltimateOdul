package com.uno.reverse.pipeline

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/*
 * IL2CPP global-metadata.dat parser.
 *
 * Scope: reads exactly what Uno Reverse needs to build a target spec —
 * class names, field names, method names, and their declaration indices.
 * It does NOT resolve byte offsets. Those are resolved at runtime by the
 * agent calling the game's own IL2CPP API, which is version-stable and
 * exact.
 *
 * Supports metadata versions 24.0 through 29.x. Versions 16–23 are
 * detected and rejected (their layouts differ enough that reusing this
 * parser would silently corrupt results). Version 31+ is detected but
 * parsed best-effort.
 *
 * Format references:
 *   - GlobalMetadataHeader: 264+ bytes of int32 (offset, count) pairs
 *     after a uint32 sanity and an int32 version.
 *   - String table: null-terminated UTF-8 blob. String at index N is
 *     read from stringOffset + N until the next 0x00.
 *   - TypeDefinition: 0x5C bytes. Contains nameIndex, namespaceIndex,
 *     fieldStart, methodStart, field_count, method_count.
 *   - FieldDefinition: 12 bytes. nameIndex, typeIndex, token.
 *   - MethodDefinition: 28 bytes (v24–v27). nameIndex, returnType,
 *     parameterStart, genericContainerIndex, token, flags, iflags,
 *     slot, parameterCount.
 */
class MetadataParser private constructor(
    private val buf: ByteBuffer,
    private val version: Int,
    private val sections: Map<String, Int>
) {

    data class TypeDef(
        val index: Int,
        val name: String,
        val namespace: String,
        val fieldStart: Int,
        val fieldCount: Int,
        val methodStart: Int,
        val methodCount: Int,
        val parentIndex: Int
    )

    data class FieldDef(
        val index: Int,
        val name: String,
        val typeIndex: Int
    )

    data class MethodDef(
        val index: Int,
        val name: String,
        val parameterCount: Int,
        val returnType: Int
    )

    // ---- Public queries ---------------------------------------------

    fun version(): Int = version

    fun typeCount(): Int = (sections["typeDefinitionsCount"] ?: 0) / TYPE_DEF_SIZE

    fun fieldCount(): Int = (sections["fieldsCount"] ?: 0) / FIELD_DEF_SIZE

    fun methodCount(): Int = (sections["methodsCount"] ?: 0) / methodDefSize()

    fun type(index: Int): TypeDef {
        val base = sections["typeDefinitionsOffset"]
            ?: error("typeDefinitionsOffset missing")
        val off = base + index * TYPE_DEF_SIZE
        val nameIdx  = buf.getInt(off)
        val nsIdx    = buf.getInt(off + 4)
        val parentIx = buf.getInt(off + 0x14)
        val fieldStart = buf.getInt(off + 0x24)
        val methodStart = buf.getInt(off + 0x28)
        val fieldCount  = buf.getShort(off + 0x4C).toInt() and 0xFFFF
        val methodCount = buf.getShort(off + 0x48).toInt() and 0xFFFF
        return TypeDef(
            index = index,
            name = string(nameIdx),
            namespace = string(nsIdx),
            fieldStart = fieldStart,
            fieldCount = fieldCount,
            methodStart = methodStart,
            methodCount = methodCount,
            parentIndex = parentIx
        )
    }

    fun field(index: Int): FieldDef {
        val base = sections["fieldsOffset"] ?: error("fieldsOffset missing")
        val off = base + index * FIELD_DEF_SIZE
        val nameIdx = buf.getInt(off)
        val typeIdx = buf.getInt(off + 4)
        return FieldDef(index, string(nameIdx), typeIdx)
    }

    fun method(index: Int): MethodDef {
        val base = sections["methodsOffset"] ?: error("methodsOffset missing")
        val off = base + index * methodDefSize()
        val nameIdx = buf.getInt(off)
        val returnType = buf.getInt(off + 4)
        // v24–v27: nameIndex(4) returnType(4) parameterStart(4)
        //          genericContainerIndex(4) token(4) flags(2) iflags(2)
        //          slot(2) parameterCount(2)
        val paramCount = buf.getShort(off + 26).toInt() and 0xFFFF
        return MethodDef(index, string(nameIdx), paramCount, returnType)
    }

    // Read the UTF-8 string at the given index in the string table.
    fun string(index: Int): String {
        val base = sections["stringOffset"] ?: error("stringOffset missing")
        val limit = sections["stringCount"] ?: 0
        if (index < 0 || index >= limit) return ""
        var p = base + index
        val start = p
        while (p < buf.capacity() && buf.get(p) != 0.toByte()) p++
        val bytes = ByteArray(p - start)
        for (i in bytes.indices) bytes[i] = buf.get(start + i)
        return String(bytes, Charsets.UTF_8)
    }

    // ------------------------------------------------------------------
    // Construction
    // ------------------------------------------------------------------

    companion object {
        private const val SANITY = 0xFAB11BAFu.toInt()
        private const val TYPE_DEF_SIZE = 0x5C
        private const val FIELD_DEF_SIZE = 12

        private fun methodDefSize(): Int = 28   // v24–v27

        fun parse(file: File): MetadataParser {
            require(file.exists() && file.length() > 0) {
                "Metadata file missing or empty: ${file.absolutePath}"
            }
            val channel = FileChannel.open(file.toPath())
            val buf = channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length())
                .order(ByteOrder.LITTLE_ENDIAN)

            val sanity = buf.getInt(0)
            require(sanity == SANITY) {
                "Bad IL2CPP metadata magic: 0x${Integer.toHexString(sanity)}"
            }
            val version = buf.getInt(4)
            require(version in 24..31) {
                "Unsupported IL2CPP metadata version $version (need 24–31)"
            }

            // Walk the header sequentially: pairs of (offset, count) as
            // int32. Stop when we run past the known header size for the
            // version, or when the values stop looking like offsets.
            val knownKeys = listOf(
                "stringLiteralOffset", "stringLiteralCount",
                "stringLiteralDataOffset", "stringLiteralDataCount",
                "stringOffset", "stringCount",
                "eventsOffset", "eventsCount",
                "propertiesOffset", "propertiesCount",
                "methodsOffset", "methodsCount",
                "parameterDefaultValuesOffset", "parameterDefaultValuesCount",
                "fieldDefaultValuesOffset", "fieldDefaultValuesCount",
                "fieldAndParameterDefaultValueDataOffset", "fieldAndParameterDefaultValueDataCount",
                "fieldMarshaledSizesOffset", "fieldMarshaledSizesCount",
                "parametersOffset", "parametersCount",
                "fieldsOffset", "fieldsCount",
                "genericParametersOffset", "genericParametersCount",
                "genericParameterConstraintsOffset", "genericParameterConstraintsCount",
                "genericContainersOffset", "genericContainersCount",
                "nestedTypesOffset", "nestedTypesCount",
                "interfacesOffset", "interfacesCount",
                "vtableMethodsOffset", "vtableMethodsCount",
                "interfaceOffsetsOffset", "interfaceOffsetsCount",
                "typeDefinitionsOffset", "typeDefinitionsCount",
                "imagesOffset", "imagesCount",
                "assembliesOffset", "assembliesCount",
                "fieldRefsOffset", "fieldRefsCount",
                "referencedAssembliesOffset", "referencedAssembliesCount",
                "attributeDataOffset", "attributeDataCount",
                "attributeDataRangeOffset", "attributeDataRangeCount",
                "unresolvedVirtualCallParameterTypesOffset", "unresolvedVirtualCallParameterTypesCount",
                "unresolvedVirtualCallParameterRangesOffset", "unresolvedVirtualCallParameterRangesCount",
                "windowsRuntimeTypeNamesOffset", "windowsRuntimeTypeNamesCount",
                "windowsRuntimeStringsOffset", "windowsRuntimeStringsCount",
                "exportedTypeDefinitionsOffset", "exportedTypeDefinitionsCount"
            )

            val sections = HashMap<String, Int>(knownKeys.size)
            var p = 8
            for (key in knownKeys) {
                if (p + 8 > buf.capacity()) break
                sections[key] = buf.getInt(p)
                p += 4
            }

            require(sections.containsKey("stringOffset")) { "Header parse failed: no stringOffset" }
            require(sections.containsKey("typeDefinitionsOffset")) { "Header parse failed: no typeDefinitionsOffset" }
            require(sections.containsKey("fieldsOffset")) { "Header parse failed: no fieldsOffset" }
            require(sections.containsKey("methodsOffset")) { "Header parse failed: no methodsOffset" }

            return MetadataParser(buf, version, sections)
        }
    }
}