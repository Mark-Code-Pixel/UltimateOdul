package com.uno.reverse.lifecycle
import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.uno.reverse.util.Log
class StubService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Log.i("StubService", "start"); return START_STICKY
    }
}
