package com.uno.reverse.lifecycle

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.uno.reverse.classloader.VirtualClassLoader
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.util.Log as ULog
import java.io.File

/*
 * Base for the four StubService slots. Mirrors StubActivityBase.
 */
abstract class StubServiceBase : Service() {

    protected var guestService: Service? = null

    override fun onCreate() {
        super.onCreate()

        val originalComponent = readOriginal()
        val guestPkg = readGuestPkg()
        if (originalComponent.isNullOrEmpty() || guestPkg.isNullOrEmpty()) return

        val record = VirtualCore.guest(guestPkg) ?: return

        val loader = try {
            VirtualClassLoader(
                guestPackage = guestPkg,
                apkPath = File(record.virtualRoot, "apk/base.apk").absolutePath,
                splitApkPaths = emptyList(),
                optimizedDir = File(record.virtualRoot, "data/dalvik-cache").apply { mkdirs() }.absolutePath,
                nativeLibDir = File(record.virtualRoot, "lib/${record.primaryAbi}").absolutePath,
                hostParent = classLoader
            )
        } catch (t: Throwable) {
            ULog.e(TAG, "ClassLoader build failed", t)
            return
        }

        val className = parseClass(originalComponent) ?: return

        guestService = try {
            val cls = Class.forName(className, true, loader.getDelegate() ?: classLoader)
            cls.getDeclaredConstructor().newInstance() as Service
        } catch (t: Throwable) {
            ULog.e(TAG, "Guest Service boot failed", t)
            null
        }

        try {
            guestService?.onCreate()
        } catch (t: Throwable) {
            ULog.e(TAG, "guestService.onCreate", t)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return try {
            guestService?.onStartCommand(intent, flags, startId) ?: START_NOT_STICKY
        } catch (t: Throwable) {
            ULog.e(TAG, "guestService.onStartCommand", t)
            START_NOT_STICKY
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return try {
            guestService?.onBind(intent)
        } catch (_: Throwable) {
            null
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        return try {
            guestService?.onUnbind(intent) ?: super.onUnbind(intent)
        } catch (_: Throwable) {
            super.onUnbind(intent)
        }
    }

    override fun onDestroy() {
        guestService?.let {
            try { it.onDestroy() } catch (_: Throwable) {}
        }
        guestService = null
        super.onDestroy()
    }

    private fun readOriginal(): String? = intent?.getStringExtra("_unoreverse_original_component")
    private fun readGuestPkg(): String? = intent?.getStringExtra("_unoreverse_guest_pkg")

    private fun parseClass(flat: String): String? {
        val slash = flat.indexOf('/')
        if (slash < 0) return null
        val tail = flat.substring(slash + 1)
        val hash = tail.indexOf('#')
        return if (hash >= 0) tail.substring(0, hash) else tail
    }

    companion object {
        private const val TAG = "StubService"
    }
}

class StubService {
    class P0 : StubServiceBase()
    class P1 : StubServiceBase()
    class P2 : StubServiceBase()
    class P3 : StubServiceBase()
}