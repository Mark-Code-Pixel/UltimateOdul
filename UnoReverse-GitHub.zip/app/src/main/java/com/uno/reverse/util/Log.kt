/*
 * Uno Reverse — unified logger.
 *
 * Two sinks:
 *   1. logcat, tag-prefixed, for live debugging via `adb logcat`.
 *   2. rolling files under <app files>/unoreverse/logs/, one per day,
 *      capped at 2MB each, 7 files retained. Files are the source of
 *      truth when the app is running headless and no one is watching
 *      logcat.
 *
 * Rules:
 *   - Never throw. A logging failure must not take down the container.
 *   - Never block the caller for more than a few milliseconds. The file
 *     write happens on a single background thread fed by an unbounded
 *     queue that drops oldest entries when it grows past a hard cap.
 *   - Guest-process logs and host-process logs go to the same directory,
 *     differentiated by a per-process prefix so a single `adb pull`
 *     captures everything.
 *
 * Callers use the top-level `ULog` object. No instantiation.
 */

package com.uno.reverse.util

import android.util.Log as AndroidLog
import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

object ULog {

    private const val LOGCAT_TAG = "UnoReverse"
    private const val MAX_FILE_BYTES = 2L * 1024L * 1024L
    private const val MAX_FILES_RETAINED = 7
    private const val QUEUE_CAPACITY = 4096
    private const val FLUSH_TIMEOUT_MS = 200L

    @Volatile
    private var logDir: File? = null

    @Volatile
    private var processPrefix: String = "host"

    @Volatile
    private var minLevel: Int = LEVEL_DEBUG

    private val queue = ArrayBlockingQueue<String>(QUEUE_CAPACITY)
    private val started = AtomicBoolean(false)
    private val writerThread = AtomicBoolean(false)

    private val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    // ------------------------------------------------------------------
    // Level constants. Ordered so a numeric comparison works.
    // ------------------------------------------------------------------

    const val LEVEL_VERBOSE = 0
    const val LEVEL_DEBUG = 1
    const val LEVEL_INFO = 2
    const val LEVEL_WARN = 3
    const val LEVEL_ERROR = 4

    // ------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------

    /*
     * Initialize the logger. Called once from UnoReverseApp.onCreate in the
     * main process, and once from GuestMain in each guest process. Safe to
     * call multiple times — subsequent calls update the directory and
     * prefix but do not restart the writer thread.
     *
     * `dir` may be null if storage is unavailable. In that case only
     * logcat receives output and the file sink stays off.
     */
    @JvmStatic
    fun init(dir: File?, prefix: String = defaultPrefix()) {
        logDir = dir
        processPrefix = prefix
        if (dir != null && !dir.exists()) {
            try {
                dir.mkdirs()
            } catch (_: Throwable) {
                logDir = null
            }
        }
        if (started.compareAndSet(false, true)) {
            startWriterThread()
        }
    }

    @JvmStatic
    fun setMinLevel(level: Int) {
        minLevel = level
    }

    @JvmStatic
    fun v(tag: String, msg: String) = log(LEVEL_VERBOSE, tag, msg, null)

    @JvmStatic
    fun d(tag: String, msg: String) = log(LEVEL_DEBUG, tag, msg, null)

    @JvmStatic
    fun i(tag: String, msg: String) = log(LEVEL_INFO, tag, msg, null)

    @JvmStatic
    fun w(tag: String, msg: String) = log(LEVEL_WARN, tag, msg, null)

    @JvmStatic
    fun e(tag: String, msg: String) = log(LEVEL_ERROR, tag, msg, null)

    @JvmStatic
    fun e(tag: String, msg: String, t: Throwable) = log(LEVEL_ERROR, tag, msg, t)

    @JvmStatic
    fun w(tag: String, msg: String, t: Throwable) = log(LEVEL_WARN, tag, msg, t)

    /*
     * Force a flush of the queue to disk. Used by the solver daemon before
     * it exits and by crash handlers before rethrowing. Bounded — never
     * blocks forever.
     */
    @JvmStatic
    fun flush() {
        val deadline = System.currentTimeMillis() + FLUSH_TIMEOUT_MS
        while (!queue.isEmpty() && System.currentTimeMillis() < deadline) {
            try {
                Thread.sleep(5)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                return
            }
        }
    }

    /*
     * Returns the current log directory, or null if the file sink is off.
     * The overlay's "Share logs" action uses this.
     */
    @JvmStatic
    fun currentDir(): File? = logDir

    // ------------------------------------------------------------------
    // Internal
    // ------------------------------------------------------------------

    private fun log(level: Int, tag: String, msg: String, t: Throwable?) {
        if (level < minLevel) return

        val line = buildLine(level, tag, msg, t)

        // Logcat first — it is cheap and always available.
        try {
            when (level) {
                LEVEL_VERBOSE -> AndroidLog.v(LOGCAT_TAG, line)
                LEVEL_DEBUG -> AndroidLog.d(LOGCAT_TAG, line)
                LEVEL_INFO -> AndroidLog.i(LOGCAT_TAG, line)
                LEVEL_WARN -> AndroidLog.w(LOGCAT_TAG, line)
                else -> AndroidLog.e(LOGCAT_TAG, line)
            }
        } catch (_: Throwable) {
            /* logcat can fail if the buffer is full. Ignore. */
        }

        if (logDir == null) return

        // File sink. Enqueue without blocking the caller. If the queue is
        // full, drop the oldest entry to make room — losing a log line is
        // better than stalling the container.
        val stamped = buildFileLine(line)
        if (!queue.offer(stamped)) {
            queue.poll()
            queue.offer(stamped)
        }
    }

    private fun buildLine(level: Int, tag: String, msg: String, t: Throwable?): String {
        val levelChar = when (level) {
            LEVEL_VERBOSE -> "V"
            LEVEL_DEBUG -> "D"
            LEVEL_INFO -> "I"
            LEVEL_WARN -> "W"
            else -> "E"
        }
        val sb = StringBuilder(msg.length + 64)
        sb.append('[').append(processPrefix).append(']')
        sb.append(' ').append(levelChar).append('/').append(tag)
        sb.append(": ").append(msg)
        if (t != null) {
            sb.append('\n').append(stackTraceToString(t))
        }
        return sb.toString()
    }

    private fun buildFileLine(line: String): String {
        val ts = synchronized(timeFormat) { timeFormat.format(Date()) }
        return "$ts $line\n"
    }

    private fun stackTraceToString(t: Throwable): String {
        val sw = java.io.StringWriter()
        val pw = java.io.PrintWriter(sw)
        t.printStackTrace(pw)
        pw.flush()
        return sw.toString()
    }

    private fun startWriterThread() {
        if (!writerThread.compareAndSet(false, true)) return
        val t = Thread({ writerLoop() }, "unoreverse-log-writer")
        t.isDaemon = true
        t.priority = Thread.MIN_PRIORITY + 1
        t.start()
    }

    private fun writerLoop() {
        var writer: FileWriter? = null
        var currentFile: File? = null
        var currentDay: String = ""

        while (true) {
            try {
                val line = queue.poll(1, TimeUnit.SECONDS)
                if (line != null) {
                    val dir = logDir ?: continue
                    val today = synchronized(dateFormat) { dateFormat.format(Date()) }

                    if (currentDay != today || writer == null || currentFile == null) {
                        try {
                            writer?.flush()
                            writer?.close()
                        } catch (_: Throwable) {}
                        rotateOldFiles(dir)
                        currentDay = today
                        currentFile = File(dir, "unoreverse-$today.log")
                        writer = try {
                            FileWriter(currentFile, true)
                        } catch (_: IOException) {
                            null
                        }
                    }

                    val w = writer
                    val f = currentFile
                    if (w != null && f != null) {
                        try {
                            w.write(line)
                            w.flush()
                        } catch (_: IOException) {
                            try { w.close() } catch (_: Throwable) {}
                            writer = null
                            currentFile = null
                        }
                        if (f.length() > MAX_FILE_BYTES) {
                            try { w.close() } catch (_: Throwable) {}
                            writer = null
                            currentFile = null
                        }
                    }
                }
            } catch (_: InterruptedException) {
                try {
                    writer?.flush()
                    writer?.close()
                } catch (_: Throwable) {}
                return
            } catch (_: Throwable) {
                // Never let the writer thread die. Sleep briefly and retry.
                try { Thread.sleep(100) } catch (_: InterruptedException) { return }
            }
        }
    }

    private fun rotateOldFiles(dir: File) {
        try {
            val files = dir.listFiles { f -> f.isFile && f.name.startsWith("unoreverse-") }
                ?: return
            if (files.size <= MAX_FILES_RETAINED) return
            val sorted = files.sortedBy { it.lastModified() }
            val toDelete = sorted.size - MAX_FILES_RETAINED
            for (i in 0 until toDelete) {
                try { sorted[i].delete() } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {
            /* Rotation failure is not fatal. */
        }
    }

    private fun defaultPrefix(): String {
        return try {
            val cmdline = File("/proc/self/cmdline").readText().trimEnd('\u0000')
            val short = cmdline.substringAfterLast('.', cmdline)
            short.ifEmpty { "host" }
        } catch (_: Throwable) {
            "host"
        }
    }
}