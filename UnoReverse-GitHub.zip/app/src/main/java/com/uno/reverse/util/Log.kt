package com.uno.reverse.util
import android.util.Log as ALog
object Log {
    private const val G = "UnoReverse"
    fun i(t: String, m: String) = ALog.i("$G/$t", m)
    fun d(t: String, m: String) = ALog.d("$G/$t", m)
    fun w(t: String, m: String) = ALog.w("$G/$t", m)
    fun e(t: String, m: String) = ALog.e("$G/$t", m)
}
