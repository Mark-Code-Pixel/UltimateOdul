package com.uno.reverse.core

import android.content.Context
import android.content.SharedPreferences

/**
 * Persistent user settings for Uno Reverse engine.
 * Open for now – no license gate.
 */
object EngineConfig {

    private const val PREF = "uno_reverse_cfg"

    private lateinit var prefs: SharedPreferences

    var autoPlay: Boolean = true
    var autoQueue: Boolean = true
    var aimAssist: Boolean = true
    var hideLine: Boolean = false
    var hideStream: Boolean = true
    var speedMode: Int = 1          // 0 Human, 1 Fast, 2 Ultra
    var boardFilter: Int = 0        // 0 = random

    fun load(context: Context) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        autoPlay = prefs.getBoolean("autoPlay", true)
        autoQueue = prefs.getBoolean("autoQueue", true)
        aimAssist = prefs.getBoolean("aimAssist", true)
        hideLine = prefs.getBoolean("hideLine", false)
        hideStream = prefs.getBoolean("hideStream", true)
        speedMode = prefs.getInt("speedMode", 1)
        boardFilter = prefs.getInt("boardFilter", 0)
    }

    fun save() {
        if (!::prefs.isInitialized) return
        prefs.edit()
            .putBoolean("autoPlay", autoPlay)
            .putBoolean("autoQueue", autoQueue)
            .putBoolean("aimAssist", aimAssist)
            .putBoolean("hideLine", hideLine)
            .putBoolean("hideStream", hideStream)
            .putInt("speedMode", speedMode)
            .putInt("boardFilter", boardFilter)
            .apply()
    }

    fun applyToNative() {
        NativeBridge.setAutoPlay(autoPlay)
        NativeBridge.setAutoQueue(autoQueue)
        NativeBridge.setAimAssist(aimAssist)
        NativeBridge.setHideLine(hideLine)
        NativeBridge.setHideStream(hideStream)
        NativeBridge.setSpeedMode(speedMode)
        NativeBridge.setBoardFilter(boardFilter)
    }
}
