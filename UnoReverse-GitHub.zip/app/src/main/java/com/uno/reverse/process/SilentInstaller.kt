package com.uno.reverse.process
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.uno.reverse.classloader.VirtualClassLoader
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.pipeline.OffsetPipeline
import com.uno.reverse.util.Log
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

object SilentInstaller {
    enum class Result { IMPORTED, UP_TO_DATE, REIMPORTED, MISSING, FAILED }
    fun ensureImported(context: Context, packageName: String): Result {
        return try {
            val pm = context.packageManager
            val info = try { pm.getPackageInfo(packageName, 0) } catch (_: Exception) { return Result.MISSING }
            val sourceDir = info.applicationInfo?.sourceDir ?: return Result.MISSING
            val versionCode = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
            val guestRoot = VirtualCore.get().guestDir(packageName)
            val baseApk = File(guestRoot, "apk/base.apk")
            val versionFile = File(guestRoot, "version")
            val existing = versionFile.takeIf { it.exists() }?.readText()?.toLongOrNull()
            if (baseApk.exists() && existing == versionCode) {
                register(packageName, versionCode, baseApk, File(guestRoot, "lib"), File(guestRoot, "data"), info.applicationInfo?.uid ?: 0)
                return Result.UP_TO_DATE
            }
            val re = baseApk.exists()
            if (!re) guestRoot.deleteRecursively()
            else { File(guestRoot, "apk").deleteRecursively(); File(guestRoot, "lib").deleteRecursively(); File(guestRoot, "offsets.json").delete() }
            File(guestRoot, "apk").mkdirs(); File(guestRoot, "data").mkdirs()
            File(sourceDir).inputStream().use { inp -> FileOutputStream(baseApk).use { out -> inp.copyTo(out) } }
            extractLibs(baseApk, File(guestRoot, "lib"))
            versionFile.writeText(versionCode.toString())
            register(packageName, versionCode, baseApk, File(guestRoot, "lib"), File(guestRoot, "data"), info.applicationInfo?.uid ?: 0)
            OffsetPipeline.run(context, packageName)
            if (re) Result.REIMPORTED else Result.IMPORTED
        } catch (e: Exception) { Log.e("SilentInstaller", "${e.message}"); Result.FAILED }
    }
    private fun register(pkg: String, vc: Long, apk: File, libRoot: File, data: File, uid: Int) {
        val abi = if (android.os.Process.is64Bit()) "arm64-v8a" else "armeabi-v7a"
        val libDir = File(libRoot, abi).absolutePath
        val odex = File(VirtualCore.get().guestDir(pkg), "odex"); odex.mkdirs()
        val cl = VirtualClassLoader.create(apk.absolutePath, libDir, odex.absolutePath, VirtualCore.get().getHostContext().classLoader)
        VirtualCore.get().registerGuest(VirtualCore.GuestInfo(pkg, vc, apk.absolutePath, libDir, data.absolutePath, uid, cl))
    }
    private fun extractLibs(apk: File, libRoot: File) {
        ZipFile(apk).use { zip ->
            val e = zip.entries()
            while (e.hasMoreElements()) {
                val entry = e.nextElement()
                if (entry.name.startsWith("lib/") && entry.name.endsWith(".so")) {
                    val out = File(libRoot, entry.name.removePrefix("lib/"))
                    out.parentFile?.mkdirs()
                    zip.getInputStream(entry).use { i -> FileOutputStream(out).use { o -> i.copyTo(o) } }
                }
            }
        }
    }
}
