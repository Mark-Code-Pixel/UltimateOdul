package com.uno.reverse.process

import android.content.Context
import android.os.Build
import com.uno.reverse.UnoReverseApp
import com.uno.reverse.util.Log as ULog
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.zip.ZipFile

/*
 * Fully synchronous silent import. Every step is verified. Returns an
 * ExtractionReport whose `isComplete` decides whether the app may launch
 * the guest.
 *
 * Rules:
 *   - Every extracted file is checked for size > 0.
 *   - The APK's SHA-256 is computed while copying.
 *   - global-metadata.dat MUST exist and be non-empty. If absent, the
 *     game is packed or restructured; extraction is marked incomplete.
 *   - The assets index MUST contain at least one entry.
 *   - The native libs directory MUST contain at least one .so for the
 *     primary ABI.
 *   - Data dir is created and must be writable.
 *   - On any failure the report carries a human-readable failureReason.
 *
 * No UI. No dialog. Caller runs this on a background thread.
 */
class SilentInstaller(private val context: Context) {

    fun install(guest: GuestDetector.DetectedGuest): ExtractionReport {
        val t0 = System.currentTimeMillis()
        val log = { m: String -> ULog.i(TAG, m) }

        val virtualRoot = File(UnoReverseApp.virtualDir(context), guest.packageName)
        val apkDir      = File(virtualRoot, "apk").apply { mkdirs() }
        val libRoot     = File(virtualRoot, "lib").apply { mkdirs() }
        val assetsDir   = File(virtualRoot, "assets").apply { mkdirs() }
        val dataDir     = File(virtualRoot, "data").apply { mkdirs() }
        val metaDir     = File(virtualRoot, "metadata").apply { mkdirs() }

        val destApk = File(apkDir, "base.apk")

        // ---- 1. Copy APK + hash -------------------------------------
        var apkSha = ""
        var apkOk = false
        try {
            apkSha = copyAndHash(File(guest.sourceDir), destApk)
            apkOk = destApk.length() > 0L
        } catch (t: Throwable) {
            return fail(guest, t0, "APK copy failed: ${t.message}", apkSha)
        }
        log("APK copied. size=${destApk.length()} sha256=${apkSha.take(16)}…")

        // ---- 2. Open the copied APK and extract ---------------------
        val primaryAbi = when {
            guest.primaryCpuAbi.isNotEmpty() -> guest.primaryCpuAbi
            else -> Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        }
        val libDir = File(libRoot, primaryAbi).apply { mkdirs() }
        val nativeLibs = mutableListOf<String>()
        var metadataFound = false
        var metadataSize = 0L
        var assetCount = 0

        try {
            ZipFile(destApk).use { zip ->
                val libPrefix = "lib/$primaryAbi/"
                val entries = zip.entries()

                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    val name = entry.name

                    if (entry.isDirectory) continue

                    when {
                        name.startsWith(libPrefix) && name.endsWith(".so") -> {
                            val fileName = name.substringAfterLast('/')
                            val out = File(libDir, fileName)
                            zip.getInputStream(entry).use { copyVerified(it, out) }
                            if (out.length() > 0L) nativeLibs += fileName
                        }

                        name.endsWith("/global-metadata.dat") ||
                        name == "assets/bin/Data/Managed/Metadata/global-metadata.dat" -> {
                            val out = File(metaDir, "global-metadata.dat")
                            zip.getInputStream(entry).use { copyVerified(it, out) }
                            if (out.length() > 0L) {
                                metadataFound = true
                                metadataSize = out.length()
                            }
                        }

                        name.startsWith("assets/") -> {
                            // Index only — assets are read from the APK at
                            // runtime. Extracting the whole tree would waste
                            // hundreds of MB on a 2GB device.
                            assetCount++
                        }
                    }
                }
            }
        } catch (t: Throwable) {
            return fail(guest, t0, "APK extraction failed: ${t.message}", apkSha)
        }

        // ---- 3. Verify every required piece -------------------------
        val libsOk = nativeLibs.isNotEmpty()
        val metadataOk = metadataFound && metadataSize > 0L
        val assetsOk = assetCount > 0
        val dataOk = writableOrCreate(dataDir)

        // Persist the report so a re-entry after process death can resume
        // without re-extracting.
        val reportPath = File(virtualRoot, "extraction_report.json")

        val failure = when {
            !apkOk          -> "APK missing or empty"
            !libsOk         -> "No native libraries for ABI $primaryAbi"
            !metadataOk     -> "global-metadata.dat not found or empty"
            !assetsOk       -> "No assets in APK"
            !dataOk         -> "Virtual data directory is not writable"
            else            -> null
        }

        val report = ExtractionReport(
            guestPackage = guest.packageName,
            guestVersionName = guest.versionName,
            guestVersionCode = guest.versionCode,
            apkPath = destApk.absolutePath,
            apkSizeBytes = destApk.length(),
            apkSha256 = apkSha,
            apkOk = apkOk,
            nativeLibDir = libDir.absolutePath,
            nativeLibCount = nativeLibs.size,
            nativeLibs = nativeLibs,
            libsOk = libsOk,
            metadataPath = File(metaDir, "global-metadata.dat").absolutePath,
            metadataSizeBytes = metadataSize,
            metadataOk = metadataOk,
            assetsDir = assetsDir.absolutePath,
            assetCount = assetCount,
            assetsOk = assetsOk,
            dataDir = dataDir.absolutePath,
            dataDirOk = dataOk,
            originalUid = guest.installedUid,
            elapsedMs = System.currentTimeMillis() - t0,
            failureReason = failure
        )

        try { reportPath.writeText(report.toJson()) } catch (_: Throwable) {}

        log(
            "Install finished. complete=${report.isComplete} " +
            "libs=${nativeLibs.size} assets=$assetCount " +
            "meta=${metadataSize}B elapsed=${report.elapsedMs}ms " +
            "reason=${failure ?: "-"}"
        )

        return report
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private fun fail(
        guest: GuestDetector.DetectedGuest,
        t0: Long,
        reason: String,
        apkSha: String
    ): ExtractionReport = ExtractionReport(
        guestPackage = guest.packageName,
        guestVersionName = guest.versionName,
        guestVersionCode = guest.versionCode,
        apkPath = "",
        apkSizeBytes = 0L,
        apkSha256 = apkSha,
        apkOk = false,
        nativeLibDir = "",
        nativeLibCount = 0,
        nativeLibs = emptyList(),
        libsOk = false,
        metadataPath = "",
        metadataSizeBytes = 0L,
        metadataOk = false,
        assetsDir = "",
        assetCount = 0,
        assetsOk = false,
        dataDir = "",
        dataDirOk = false,
        originalUid = guest.installedUid,
        elapsedMs = System.currentTimeMillis() - t0,
        failureReason = reason
    ).also { ULog.e(TAG, "Install failed: $reason") }

    private fun copyAndHash(src: File, dst: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        src.inputStream().use { input ->
            dst.outputStream().use { output ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n <= 0) break
                    md.update(buf, 0, n)
                    output.write(buf, 0, n)
                }
                output.flush()
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun copyVerified(input: InputStream, out: File) {
        out.parentFile?.mkdirs()
        out.outputStream().use { output -> input.copyTo(output) }
        if (out.length() == 0L) {
            throw IllegalStateException("Extracted file is empty: ${out.name}")
        }
        out.setReadable(true, true)
        if (out.name.endsWith(".so")) out.setExecutable(true, true)
    }

    private fun writableOrCreate(dir: File): Boolean = try {
        if (!dir.exists()) dir.mkdirs()
        val probe = File(dir, ".write_probe")
        probe.writeText("ok")
        val ok = probe.readText() == "ok"
        probe.delete()
        ok
    } catch (_: Throwable) {
        false
    }

    companion object {
        private const val TAG = "SilentInstaller"
    }
}