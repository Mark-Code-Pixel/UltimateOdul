package com.uno.reverse.virtual

import android.content.Context
import android.util.Log
import com.uno.reverse.core.NativeBridge

/**
 * Facade used by the engine service.
 * Delegates discovery to VirtualCore and attach to native.
 */
object VirtualContainer {

    private const val TAG = "UnoVirtual"

    fun isCarromInstalled(context: Context): Boolean =
        VirtualCore.probe(context).installed

    fun getCarromVersion(context: Context): String? =
        VirtualCore.probe(context).versionName

    fun getInstallSummary(context: Context): String =
        VirtualCore.summary(VirtualCore.probe(context))

    fun launchCarrom(context: Context): Boolean =
        VirtualCore.launch(context)

    fun notifyEngineTargetReady() {
        try {
            val ok = NativeBridge.attachCarrom()
            Log.i(TAG, "native attach=$ok status=${NativeBridge.getReaderStatus()}")
        } catch (t: Throwable) {
            Log.e(TAG, "native attach failed", t)
        }
    }

    fun evaluate(context: Context) = ContainerStrategy.evaluate(context)
}
