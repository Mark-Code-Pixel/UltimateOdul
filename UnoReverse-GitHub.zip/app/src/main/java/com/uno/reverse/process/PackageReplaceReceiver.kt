package com.uno.reverse.process
import android.content.*
import com.uno.reverse.BuildConfig
import com.uno.reverse.util.Log
class PackageReplaceReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context?, i: Intent?) {
        if (i?.action != Intent.ACTION_PACKAGE_REPLACED) return
        val pkg = i.data?.schemeSpecificPart ?: return
        if (pkg == BuildConfig.TARGET_PACKAGE) {
            Log.i("PkgReplace", "re-import"); SilentInstaller.ensureImported(c!!, pkg)
        }
    }
}
