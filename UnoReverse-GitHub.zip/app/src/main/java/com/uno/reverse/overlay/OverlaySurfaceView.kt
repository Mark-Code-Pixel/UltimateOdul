package com.uno.reverse.overlay
import android.content.Context
import android.view.SurfaceView
class OverlaySurfaceView(c: Context) : SurfaceView(c) {
    fun attach() {}
    fun detach() {}
}
