package com.uno.reverse.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.uno.reverse.nativebridge.NativeBridge
import com.uno.reverse.nativebridge.SharedState
import com.uno.reverse.util.Log as ULog

/*
 * Full-screen transparent SurfaceView that renders candidate trajectory
 * lines, the chosen shot, and pocket markers.
 *
 * Runs a dedicated render thread. Uses lockCanvas / unlockCanvasAndPost
 * so the drawing is not tied to the UI thread's invalidate loop. The
 * loop naturally throttles at the display refresh rate.
 *
 * Board coordinates from the guest (0..W, 0..H) are mapped to screen
 * pixels via a WorldTransform. The transform is set once on first
 * successful frame using the SurfaceView's measured size and the board
 * dimensions from shared memory, then refined by a four-point
 * calibration when the user opens the calibration dialog.
 */
class OverlaySurfaceView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {

    data class WorldTransform(
        val boardW: Float,
        val boardH: Float,
        val offsetX: Float,
        val offsetY: Float,
        val scale: Float
    ) {
        fun toScreenX(bx: Float): Float = offsetX + bx * scale
        fun toScreenY(by: Float): Float = offsetY + by * scale
    }

    private var renderThread: Thread? = null
    @Volatile private var running = false
    @Volatile private var transform: WorldTransform? = null

    private val density = resources.displayMetrics.density

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val lineBuf = FloatArray(5)
    private val snapshot = SharedState.Snapshot()

    init {
        holder.addCallback(this)
        setZOrderOnTop(true)
        holder.setFormat(android.graphics.PixelFormat.TRANSLUCENT)
        setWillNotDraw(false)
    }

    // ---- SurfaceHolder.Callback ------------------------------------

    override fun surfaceCreated(holder: SurfaceHolder) {
        ULog.i(TAG, "surfaceCreated")
        running = true
        renderThread = Thread({ renderLoop() }, "unoreverse-overlay-render").apply {
            isDaemon = true
            start()
        }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        ULog.i(TAG, "surfaceChanged ${width}x${height}")
        recomputeTransform(width.toFloat(), height.toFloat())
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        ULog.i(TAG, "surfaceDestroyed")
        running = false
        renderThread?.join(500)
        renderThread = null
    }

    // ---- Public API ------------------------------------------------

    fun setManualTransform(t: WorldTransform) {
        transform = t
    }

    // ---- Render loop -----------------------------------------------

    private fun renderLoop() {
        while (running) {
            val h = holder
            if (!h.surface.isValid) {
                Thread.sleep(16)
                continue
            }
            var canvas: Canvas? = null
            try {
                canvas = h.lockCanvas()
                if (canvas != null) {
                    canvas.drawColor(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR)
                    drawFrame(canvas)
                }
            } catch (t: Throwable) {
                ULog.w(TAG, "render frame failed: ${t.message}")
            } finally {
                if (canvas != null) {
                    try { h.unlockCanvasAndPost(canvas) } catch (_: Throwable) {}
                }
            }
            // lockCanvas already throttles to vsync.
        }
    }

    private fun drawFrame(canvas: Canvas) {
        if (!NativeBridge.isSharedMapped()) return
        val tf = transform ?: return

        NativeBridge.snapshot(snapshot)
        if (!snapshot.showLines) {
            // Still draw the chosen shot when autoplay is running.
            if (!snapshot.autoplay) return
        }

        // Candidate lines
        val count = if (snapshot.showLines) snapshot.lineCount else 0
        for (i in 0 until count) {
            if (!NativeBridge.getLine(i, lineBuf)) continue
            val x0 = tf.toScreenX(lineBuf[0])
            val y0 = tf.toScreenY(lineBuf[1])
            val x1 = tf.toScreenX(lineBuf[2])
            val y1 = tf.toScreenY(lineBuf[3])
            val color = lineBuf[4].toLong().toInt()
            val isChosen = color == Theme.LINE_CHOSEN
            val isDot = (x0 == x1 && y0 == y1)

            if (isDot) {
                dotPaint.color = color
                val radius = when (color) {
                    Theme.LINE_POCKET -> Theme.POCKET_DOT_RADIUS_PX * density
                    Theme.LINE_GHOST  -> Theme.GHOST_DOT_RADIUS_PX * density
                    else -> 4f
                }
                canvas.drawCircle(x0, y0, radius, dotPaint)
            } else {
                linePaint.color = color
                linePaint.strokeWidth = if (isChosen)
                    Theme.LINE_WIDTH_CHOSEN_PX * density
                else
                    Theme.LINE_WIDTH_CANDIDATE_PX * density
                canvas.drawLine(x0, y0, x1, y1, linePaint)
            }
        }
    }

    // ---- Transform ------------------------------------------------

    private fun recomputeTransform(w: Float, h: Float) {
        // Read the board dimensions from shared memory if available,
        // otherwise fall back to a square board filling the width.
        var boardW = 0f
        var boardH = 0f
        if (NativeBridge.isSharedMapped()) {
            NativeBridge.snapshot(snapshot)
            if (snapshot.boardW > 0f && snapshot.boardH > 0f) {
                boardW = snapshot.boardW
                boardH = snapshot.boardH
            }
        }
        if (boardW <= 0f || boardH <= 0f) {
            boardW = 1000f
            boardH = 1000f
        }

        // Assume the board is centered, aspect-preserved.
        val availW = w * 0.94f
        val availH = h * 0.72f
        val scale = minOf(availW / boardW, availH / boardH)
        val drawnW = boardW * scale
        val drawnH = boardH * scale
        val offsetX = (w - drawnW) / 2f
        val offsetY = (h - drawnH) / 2f - h * 0.05f

        transform = WorldTransform(boardW, boardH, offsetX, offsetY, scale)
        ULog.i(TAG, "transform set scale=$scale offX=$offsetX offY=$offsetY")
    }

    companion object {
        private const val TAG = "OverlaySurface"
    }
}