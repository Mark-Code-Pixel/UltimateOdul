package com.uno.reverse.core

import android.os.IBinder
import java.lang.reflect.Method

/*
 * Intercepts the user service.
 *
 * Responsibilities:
 *   1. Return the container's UID for getCallingUserId when the guest
 *      is asking, so framework UID checks succeed.
 *   2. Pass through everything else.
 */
object VirtualUserManager {

    @JvmStatic
    fun invoke(original: IBinder, method: Method, args: Array<out Any?>): Any? {
        return when (method.name) {
            "getCallingUserId", "getCallingUid" -> {
                val uid = VirtualCore.currentGuestUid()
                if (uid > 0) uid else method.invoke(original, *args)
            }
            else -> method.invoke(original, *args)
        }
    }
}