package com.uno.reverse.core
import android.content.Context
import com.uno.reverse.util.Log
class VirtualUserManager private constructor() {
    fun init(context: Context) { Log.i("VUM", "init") }
    fun mapUid(guestUid: Int) = VirtualCore.get().hostUid()
    companion object {
        @Volatile private var I: VirtualUserManager? = null
        fun get() = I ?: synchronized(this) { I ?: VirtualUserManager().also { I = it } }
    }
}
