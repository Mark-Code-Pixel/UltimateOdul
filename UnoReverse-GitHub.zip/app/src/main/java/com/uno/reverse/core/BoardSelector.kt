package com.uno.reverse.core

/**
 * Board / stake filters used by AutoQueue.
 * 0 = random (engine decides).
 * Positive values map to common Carrom Pool stakes.
 */
object BoardSelector {

    data class BoardOption(
        val id: Int,
        val label: String,
        val stakeHint: String
    )

    val OPTIONS = listOf(
        BoardOption(0, "Random", "Any table"),
        BoardOption(1, "10K", "Low stakes"),
        BoardOption(2, "50K", "Mid"),
        BoardOption(3, "100K", "Popular"),
        BoardOption(4, "250K", "High"),
        BoardOption(5, "500K", "Very high"),
        BoardOption(6, "1M", "Elite"),
        BoardOption(7, "Disc Pool", "Mode filter"),
        BoardOption(8, "Freestyle", "Mode filter")
    )

    fun labelFor(id: Int): String =
        OPTIONS.find { it.id == id }?.label ?: "Random"
}
