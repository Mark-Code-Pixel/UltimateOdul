package com.uno.reverse.inject

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.util.Log

/**
 * Accessibility-based shot injection for AutoPlay.
 */
class InputInjector : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "accessibility connected")
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        private const val TAG = "UnoInject"
        @Volatile
        private var instance: InputInjector? = null

        fun dispatchSwipe(
            startX: Float,
            startY: Float,
            endX: Float,
            endY: Float,
            power: Float
        ): Boolean {
            val svc = instance ?: return false
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
            val path = Path().apply {
                moveTo(startX, startY)
                lineTo(endX, endY)
            }
            val duration = (180 + (1f - power.coerceIn(0f, 1f)) * 420).toLong()
            val stroke = GestureDescription.StrokeDescription(path, 0, duration)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            return try {
                svc.dispatchGesture(gesture, null, null)
            } catch (t: Throwable) {
                Log.w(TAG, "dispatchGesture", t)
                false
            }
        }
    }
}
