package com.uno.reverse.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.uno.reverse.R

/**
 * Secondary activity – reserved for future settings / stats screens.
 * Launcher is the main entry.
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launcher) // reuse for now
    }
}
