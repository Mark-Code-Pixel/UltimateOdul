package com.uno.reverse.lifecycle

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.uno.reverse.core.ContainerService
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.util.Log as ULog

/*
 * Static BroadcastReceiver declared in the manifest.
 *
 * Handles two categories of broadcasts:
 *   - System events the container cares about (PACKAGE_REPLACED for the
 *     target guest, BOOT_COMPLETED to warm the container).
 *   - Guest-declared broadcasts forwarded by the framework.
 *
 * Guest broadcasts are forwarded by loading the guest's receiver class
 * through the guest's ClassLoader and calling onReceive. That requires
 * the guest process to be alive; if it is not, the broadcast is dropped
 * silently.
 */
class StubReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        ULog.d(TAG, "received $action")

        when (action) {
            Intent.ACTION_PACKAGE_REPLACED,
            Intent.ACTION_PACKAGE_ADDED,
            Intent.ACTION_PACKAGE_REMOVED -> {
                val data = intent.data ?: return
                val pkg = data.schemeSpecificPart ?: return
                if (pkg == com.uno.reverse.process.GuestDetector.TARGET_PACKAGE) {
                    ULog.i(TAG, "Target package changed: $action $pkg")
                    // The import + pipeline reruns on next app launch.
                }
            }

            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_USER_PRESENT -> {
                // Warm the container service so it reaps stale state.
                try {
                    ContainerService.start(context)
                } catch (t: Throwable) {
                    ULog.e(TAG, "Failed to start container on $action", t)
                }
            }
        }
    }

    companion object {
        private const val TAG = "StubReceiver"
    }
}