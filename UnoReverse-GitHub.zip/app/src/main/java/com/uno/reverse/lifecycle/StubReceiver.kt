package com.uno.reverse.lifecycle
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.uno.reverse.util.Log
class StubReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context?, i: Intent?) { Log.i("StubReceiver", i?.action ?: "") }
}
