package com.uno.reverse.accounts
import android.content.Intent
import com.uno.reverse.util.Log
object FacebookAccountBridge {
    fun captureRedirect(i: Intent?): String? {
        val d = i?.data ?: return null
        if (d.scheme?.startsWith("fb") == true) {
            val t = d.getQueryParameter("access_token")
            if (t != null) { Log.i("FBBridge", "token"); return t }
        }
        return null
    }
}
