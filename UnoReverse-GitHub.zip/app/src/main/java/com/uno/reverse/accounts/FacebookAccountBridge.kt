package com.uno.reverse.accounts

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.uno.reverse.util.Log as ULog
import java.io.File

/*
 * Facebook Login bridge. Same shape as the Google bridge.
 */
object FacebookAccountBridge {

    private const val TAG = "FacebookAccountBridge"

    private const val FILE_NAME = "facebook_account.json"
    private const val PROVIDER = "facebook"

    @Volatile private var lastRedirect: String = ""

    fun onRedirect(uri: Uri) {
        lastRedirect = uri.toString()
        ULog.i(TAG, "redirect captured: $uri")
    }

    fun lastRedirect(): String = lastRedirect

    fun storeToken(context: Context, guestPkg: String, token: String, userId: String) {
        try {
            val dir = guestAccountDir(context, guestPkg).apply { mkdirs() }
            val f = File(dir, FILE_NAME)
            val json = """
                {
                  "provider": "$PROVIDER",
                  "user_id": "$userId",
                  "token": "$token",
                  "stored_at": ${System.currentTimeMillis()}
                }
            """.trimIndent()
            f.writeText(json)
            ULog.i(TAG, "token stored for $guestPkg ($userId)")
        } catch (t: Throwable) {
            ULog.e(TAG, "storeToken failed", t)
        }
    }

    fun loadToken(context: Context, guestPkg: String): String? {
        return try {
            val f = File(guestAccountDir(context, guestPkg), FILE_NAME)
            if (f.exists() && f.length() > 0L) f.readText() else null
        } catch (_: Throwable) {
            null
        }
    }

    fun clear(context: Context, guestPkg: String) {
        try {
            File(guestAccountDir(context, guestPkg), FILE_NAME).delete()
        } catch (_: Throwable) {}
    }

    fun buildLoginIntent(): Intent? {
        return null
    }

    private fun guestAccountDir(context: Context, guestPkg: String): File {
        val root = File(context.filesDir, "unoreverse/virtual/$guestPkg/accounts")
        if (!root.exists()) root.mkdirs()
        return root
    }
}