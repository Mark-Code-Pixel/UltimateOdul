package com.uno.reverse.core

import android.content.Context
import com.uno.reverse.UnoReverseApp
import com.uno.reverse.util.Log as ULog
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/*
 * Central registry for the virtual container. Owns:
 *   - the guest registry (package -> virtual directory)
 *   - the engine fingerprint learned at runtime
 *   - the Java-level Binder proxy installer
 *   - lifecycle coordination for guest spawn/shutdown
 *   - the current guest's package and UID for the service proxies
 *
 * Engine-agnostic. Does not name Unity, IL2CPP, Cocos, Flutter, Unreal,
 * React Native, Godot, or any other engine. It records what it sees
 * and specializes by observation.
 */
object VirtualCore {

    private const val TAG = "VirtualCore"

    @Volatile private var appContext: Context? = null
    private val initialized = AtomicBoolean(false)

    data class GuestRecord(
        val packageName: String,
        val virtualRoot: File,
        val versionCode: Long,
        val originalUid: Int,
        val primaryAbi: String
    )

    private val guests = ConcurrentHashMap<String, GuestRecord>()

    @Volatile private var engineFingerprint: String = "unknown"
    @Volatile private var runtimeManifestPath: String = ""

    private val currentGuestPkg = java.util.concurrent.atomic.AtomicReference<String?>(null)
    private val currentGuestUid = AtomicInteger(0)

    // ------------------------------------------------------------------

    @JvmStatic
    fun init(context: Context) {
        if (!initialized.compareAndSet(false, true)) return
        appContext = context.applicationContext
        ULog.i(TAG, "VirtualCore init")

        try {
            val virtualDir = UnoReverseApp.virtualDir(context)
            virtualDir.listFiles()?.forEach { pkgDir ->
                if (!pkgDir.isDirectory) return@forEach
                val apk = File(pkgDir, "apk/base.apk")
                if (!apk.exists() || apk.length() == 0L) return@forEach
                val report = File(pkgDir, "extraction_report.json")
                var versionCode = 0L
                var originalUid = 0
                var abi = ""
                if (report.exists()) {
                    try {
                        val text = report.readText()
                        versionCode = extractLong(text, "guest_version_code")
                        originalUid = extractLong(text, "original_uid").toInt()
                    } catch (_: Throwable) {}
                }
                val libRoot = File(pkgDir, "lib")
                libRoot.listFiles()?.firstOrNull {
                    it.isDirectory && it.listFiles()?.any { f -> f.name.endsWith(".so") } == true
                }?.let { abi = it.name }

                guests[pkgDir.name] = GuestRecord(
                    packageName = pkgDir.name,
                    virtualRoot = pkgDir,
                    versionCode = versionCode,
                    originalUid = originalUid,
                    primaryAbi = abi
                )
            }
            ULog.i(TAG, "Guest registry warmed: ${guests.size} entr${if (guests.size == 1) "y" else "ies"}")
        } catch (t: Throwable) {
            ULog.e(TAG, "Registry warm failed", t)
        }

        try {
            com.uno.reverse.binder.BinderInterceptor.install()
            ULog.i(TAG, "Java Binder interceptor installed")
        } catch (t: Throwable) {
            ULog.e(TAG, "Binder interceptor install failed", t)
        }

        VirtualPackageManager.init()
    }

    @JvmStatic
    fun shutdown() {
        ULog.i(TAG, "VirtualCore shutdown")
        try {
            com.uno.reverse.binder.BinderInterceptor.uninstall()
        } catch (_: Throwable) {}
    }

    @JvmStatic
    fun registeredGuestCount(): Int = guests.size

    @JvmStatic
    fun guest(pkg: String): GuestRecord? = guests[pkg]

    @JvmStatic
    fun isRegistered(pkg: String): Boolean = guests.containsKey(pkg)

    @JvmStatic
    fun registerGuest(record: GuestRecord) {
        guests[record.packageName] = record
    }

    @JvmStatic
    fun engine(): String = engineFingerprint

    @JvmStatic
    fun runtimeManifest(): String = runtimeManifestPath

    @JvmStatic
    fun containerPackage(): String = appContext?.packageName ?: "com.uno.reverse"

    @JvmStatic
    fun currentGuestPackage(): String? = currentGuestPkg.get()

    @JvmStatic
    fun currentGuestUid(): Int = currentGuestUid.get()

    @JvmStatic
    fun setCurrentGuest(pkg: String?, uid: Int) {
        currentGuestPkg.set(pkg)
        currentGuestUid.set(uid)
    }

    @JvmStatic
    fun onRuntimeManifestReady(engine: String, manifestPath: String) {
        engineFingerprint = engine
        runtimeManifestPath = manifestPath
        ULog.i(TAG, "Runtime manifest ready. engine=$engine path=$manifestPath")
    }

    // ------------------------------------------------------------------

    private fun extractLong(json: String, key: String): Long {
        val needle = "\"$key\":"
        val i = json.indexOf(needle)
        if (i < 0) return 0L
        val start = i + needle.length
        var j = start
        while (j < json.length && (json[j].isDigit() || json[j] == '-')) j++
        return json.substring(start, j).toLongOrNull() ?: 0L
    }
}