package com.uno.reverse.core
import android.content.Context
import com.uno.reverse.binder.BinderInterceptor
import com.uno.reverse.classloader.VirtualClassLoader
import com.uno.reverse.util.Log
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class VirtualCore private constructor() {
    private lateinit var hostContext: Context
    private val guests = ConcurrentHashMap<String, GuestInfo>()
    private val running = ConcurrentHashMap<String, Int>()
    data class GuestInfo(val packageName: String, val versionCode: Long, val sourceDir: String,
        val libDir: String, val dataDir: String, val originalUid: Int, val classLoader: VirtualClassLoader?)
    fun initialize(context: Context) {
        hostContext = context.applicationContext
        BinderInterceptor.install(hostContext)
        VirtualPackageManager.get().init(hostContext)
        VirtualActivityManager.get().init(hostContext)
        VirtualUserManager.get().init(hostContext)
        VirtualAccountManager.get().init(hostContext)
        virtualRoot().mkdirs()
        Log.i("VirtualCore", "initialized")
    }
    fun getHostContext() = hostContext
    fun virtualRoot() = File(hostContext.filesDir, "virtual")
    fun guestDir(pkg: String) = File(virtualRoot(), pkg)
    fun registerGuest(info: GuestInfo) { guests[info.packageName] = info }
    fun getGuest(pkg: String) = guests[pkg]
    fun isGuestInstalled(pkg: String) = guests.containsKey(pkg)
    fun markRunning(pkg: String, pid: Int) { running[pkg] = pid }
    fun markStopped(pkg: String) { running.remove(pkg) }
    fun isRunning(pkg: String) = running.containsKey(pkg)
    fun getRunningPid(pkg: String) = running[pkg]
    fun getAllGuests() = guests.values
    fun hostUid() = android.os.Process.myUid()
    companion object {
        @Volatile private var INSTANCE: VirtualCore? = null
        fun get() = INSTANCE ?: synchronized(this) { INSTANCE ?: VirtualCore().also { INSTANCE = it } }
    }
}
