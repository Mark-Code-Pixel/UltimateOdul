package com.uno.reverse.process

import android.app.ActivityManager
import android.content.Context
import com.uno.reverse.util.Log as ULog
import com.uno.reverse.util.Ram
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/*
 * Tracks every guest process the container has spawned. Handles:
 *   - zombie reaping
 *   - low-memory eviction
 *   - crash detection and reporting
 *   - PID -> package index for the native layer to find its target
 *   - lifecycle hooks for the overlay to follow the foreground guest
 *
 * VirtualApp spreads this across three separate classes and a service
 * binder. We do it in one manager with a single scheduler thread and a
 * concurrent map. Cheaper, faster, no binder round-trips for state.
 */
object GuestProcessManager {

    private const val TAG = "GuestProcessManager"
    private const val REAP_INTERVAL_MS = 1000L
    private const val LOW_MEM_THRESHOLD_BYTES = 250L * 1024L * 1024L

    data class GuestHandle(
        val packageName: String,
        val process: Process,
        val pid: Long,
        val startedAtMs: Long,
        val versionCode: Long,
        @Volatile var foreground: Boolean = false,
        @Volatile var exitCode: Int = Int.MIN_VALUE,
        @Volatile var exitedAtMs: Long = 0L
    )

    private val handles = ConcurrentHashMap<String, GuestHandle>()
    private val pidIndex = ConcurrentHashMap<Long, String>()
    private val nextId = AtomicInteger(0)
    private var scheduler: ScheduledExecutorService? = null

    // ------------------------------------------------------------------

    @JvmStatic
    fun start(context: Context) {
        if (scheduler != null) return
        scheduler = Executors.newSingleThreadScheduledExecutor { r ->
            Thread(r, "guest-process-reaper").apply { isDaemon = true }
        }.also {
            it.scheduleWithFixedDelay(
                { reap(context) },
                REAP_INTERVAL_MS, REAP_INTERVAL_MS, TimeUnit.MILLISECONDS
            )
        }
        ULog.i(TAG, "Process manager started")
    }

    @JvmStatic
    fun stop() {
        scheduler?.shutdownNow()
        scheduler = null
    }

    @JvmStatic
    fun register(pkg: String, proc: Process, pid: Long, versionCode: Long): GuestHandle {
        val h = GuestHandle(
            packageName = pkg,
            process = proc,
            pid = pid,
            startedAtMs = System.currentTimeMillis(),
            versionCode = versionCode
        )
        handles[pkg] = h
        if (pid > 0) pidIndex[pid] = pkg
        ULog.i(TAG, "Registered $pkg pid=$pid")
        return h
    }

    @JvmStatic
    fun unregister(pkg: String) {
        handles.remove(pkg)?.let { h ->
            if (h.pid > 0) pidIndex.remove(h.pid)
            ULog.i(TAG, "Unregistered $pkg")
        }
    }

    @JvmStatic
    fun handle(pkg: String): GuestHandle? = handles[pkg]

    @JvmStatic
    fun pidFor(pkg: String): Long = handles[pkg]?.pid ?: -1L

    @JvmStatic
    fun packageFor(pid: Long): String? = pidIndex[pid]

    @JvmStatic
    fun activeCount(): Int = handles.size

    @JvmStatic
    fun killAll(reason: String) {
        ULog.w(TAG, "Killing all guests: $reason")
        handles.keys.toList().forEach { pkg ->
            handles[pkg]?.process?.destroy()
            unregister(pkg)
        }
    }

    @JvmStatic
    fun setForeground(pkg: String, foreground: Boolean) {
        handles[pkg]?.foreground = foreground
    }

    @JvmStatic
    fun currentForeground(): String? =
        handles.values.firstOrNull { it.foreground }?.packageName

    // ------------------------------------------------------------------

    private fun reap(context: Context) {
        try {
            val iter = handles.entries.iterator()
            while (iter.hasNext()) {
                val (pkg, h) = iter.next()
                if (!h.process.isAlive) {
                    val code = try { h.process.exitValue() } catch (_: Throwable) { Int.MIN_VALUE }
                    h.exitCode = code
                    h.exitedAtMs = System.currentTimeMillis()
                    ULog.w(TAG, "Guest $pkg exited code=$code after " +
                            "${(h.exitedAtMs - h.startedAtMs)}ms")
                    if (h.pid > 0) pidIndex.remove(h.pid)
                    iter.remove()
                }
            }

            // Low-memory eviction. If the device is starved and we have
            // more than one guest, kill the least-recently-foregrounded.
            if (handles.size > 1 && Ram.isLow(context, LOW_MEM_THRESHOLD_BYTES)) {
                val victim = handles.values
                    .filter { !it.foreground }
                    .minByOrNull { it.startedAtMs }
                if (victim != null) {
                    ULog.w(TAG, "Low memory eviction: ${victim.packageName}")
                    victim.process.destroy()
                    unregister(victim.packageName)
                }
            }

            // Force GC on the host if the device is critically low so the
            // guest has headroom for its next allocation burst.
            if (Ram.isLow(context, 150L * 1024L * 1024L)) {
                Runtime.getRuntime().gc()
            }
        } catch (t: Throwable) {
            ULog.e(TAG, "reap failed", t)
        }
    }
}