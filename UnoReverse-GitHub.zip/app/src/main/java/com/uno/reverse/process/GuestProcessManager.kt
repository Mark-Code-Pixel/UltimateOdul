package com.uno.reverse.process
import android.content.Intent
import android.os.Process
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.nativebridge.NativeBridge
import com.uno.reverse.util.Log
class GuestProcessManager private constructor() {
    fun startGuest(pkg: String): Boolean {
        val g = VirtualCore.get().getGuest(pkg) ?: return false
        if (VirtualCore.get().isRunning(pkg)) return true
        return try {
            val ctx = VirtualCore.get().getHostContext()
            ctx.startActivity(Intent().setClassName(ctx.packageName, "com.uno.reverse.lifecycle.StubActivity")
                .putExtra("_ur_target_pkg", pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            NativeBridge.loadAgent(g.libDir)
            VirtualCore.get().markRunning(pkg, Process.myPid())
            true
        } catch (e: Exception) { Log.e("GPM", "${e.message}"); false }
    }
    fun stopGuest(pkg: String) { VirtualCore.get().markStopped(pkg) }
    companion object {
        @Volatile private var I: GuestProcessManager? = null
        fun get() = I ?: synchronized(this) { I ?: GuestProcessManager().also { I = it } }
    }
}
