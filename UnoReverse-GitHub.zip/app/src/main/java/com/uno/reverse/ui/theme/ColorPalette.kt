package com.uno.reverse.ui.theme

import android.graphics.Color

/*
 * Kotlin mirror of the colour palette in res/values/colors.xml.
 * Used by custom View code that paints directly on a Canvas. The XML
 * version is the source of truth for layouts; this object is the source
 * of truth for programmatic drawing.
 *
 * Do not define colours anywhere else. If a colour is not here, add it
 * here first.
 */
object ColorPalette {

    // Surfaces
    const val BG          = 0xFF07070B.toInt()
    const val BG_2        = 0xFF0A0A0F.toInt()
    const val SURFACE     = 0xE6101018.toInt()
    const val SURFACE_2   = 0xFF16161E.toInt()
    const val SURFACE_3   = 0xFF1C1C26.toInt()

    // Foreground
    const val FG          = 0xFFF5F5F7.toInt()
    const val MUTED       = 0xFF8A8A93.toInt()
    const val MUTED_2     = 0xFF5C5C66.toInt()

    // Gold
    const val GOLD        = 0xFFD4AF37.toInt()
    const val GOLD_SOFT   = 0xFFE8C56A.toInt()
    const val GOLD_DIM    = 0xFF8A7030.toInt()
    const val GOLD_DEEP   = 0xFF4A3A18.toInt()
    const val GOLD_GLOW   = 0x33D4AF37.toInt()
    const val BORDER      = 0x66D4AF37.toInt()
    const val BORDER_SOFT = 0x33D4AF37.toInt()

    // Semantic
    const val RED         = 0xFFFF3B30.toInt()
    const val RED_SOFT    = 0xFFFF6B62.toInt()
    const val GREEN       = 0xFF22C55E.toInt()
    const val GREEN_SOFT  = 0xFF4ADE80.toInt()
    const val BLUE        = 0xFF3B82F6.toInt()
    const val AMBER       = 0xFFF59E0B.toInt()

    // Glass
    const val GLASS_WHITE_10 = 0x1AFFFFFF.toInt()
    const val GLASS_WHITE_05 = 0x0DFFFFFF.toInt()
    const val GLASS_BLACK_40 = 0x66000000.toInt()
    const val GLASS_BLACK_60 = 0x99000000.toInt()

    // Line rendering
    const val LINE_HIGH   = GOLD
    const val LINE_MID    = GOLD_DIM
    const val LINE_LOW    = GOLD_DEEP
    const val LINE_CHOSEN = RED
    const val LINE_GHOST  = 0xFFFFFFFF.toInt()
    const val LINE_POCKET = GREEN

    fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

    fun withAlpha(color: Int, fraction: Float): Int =
        withAlpha(color, (fraction.coerceIn(0f, 1f) * 255f).toInt())

    fun lerp(a: Int, b: Int, t: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        val ar = Color.red(a);   val ag = Color.green(a);   val ab = Color.blue(a)
        val br = Color.red(b);   val bg = Color.green(b);   val bb = Color.blue(b)
        return Color.argb(
            255,
            (ar + (br - ar) * tt).toInt(),
            (ag + (bg - ag) * tt).toInt(),
            (ab + (bb - ab) * tt).toInt()
        )
    }
}