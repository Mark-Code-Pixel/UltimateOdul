package com.uno.reverse.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator

/*
 * Green tick that draws itself when `play()` is called.
 * Stroke dash offset animates the tick path from 0 to 1 over 480ms,
 * the ring fades in behind it, and a subtle pulse loops forever.
 */
class AnimatedCheckView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#22C55E")
        strokeWidth = 6f
    }
    private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#22C55E")
        strokeWidth = 4f
        alpha = 0
    }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.parseColor("#22C55E")
        strokeWidth = 10f
    }

    private val tickPath = Path()
    private var tickLength = 0f
    private var drawnFraction = 0f
    private var pulseFraction = 0f

    private var tickAnimator: ValueAnimator? = null
    private var pulseAnimator: ValueAnimator? = null

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        buildTick(w.toFloat(), h.toFloat())
    }

    private fun buildTick(w: Float, h: Float) {
        tickPath.reset()
        tickPath.moveTo(w * 0.24f, h * 0.52f)
        tickPath.lineTo(w * 0.43f, h * 0.70f)
        tickPath.lineTo(w * 0.78f, h * 0.30f)
        val pm = PathMeasure(tickPath, false)
        tickLength = pm.length
    }

    fun play() {
        tickAnimator?.cancel()
        tickAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 480
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                drawnFraction = it.animatedValue as Float
                invalidate()
            }
            start()
        }
        startPulse()
    }

    fun reset() {
        tickAnimator?.cancel()
        pulseAnimator?.cancel()
        drawnFraction = 0f
        pulseFraction = 0f
        pulsePaint.alpha = 0
        invalidate()
    }

    private fun startPulse() {
        pulseAnimator?.cancel()
        pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1200
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                pulseFraction = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - 12f

        if (pulseFraction > 0f) {
            pulsePaint.alpha = ((1f - pulseFraction) * 180).toInt()
            canvas.drawCircle(cx, cy, r * (0.85f + 0.25f * pulseFraction), pulsePaint)
        }

        ringPaint.alpha = (drawnFraction * 255).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, r, ringPaint)

        if (drawnFraction > 0f && tickLength > 0f) {
            val partial = Path()
            val pm = PathMeasure(tickPath, false)
            pm.getSegment(0f, tickLength * drawnFraction, partial, true)
            canvas.drawPath(partial, tickPaint)
        }
    }
}