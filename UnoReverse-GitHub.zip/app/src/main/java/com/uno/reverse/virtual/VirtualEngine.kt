package com.uno.reverse.virtual

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.uno.reverse.core.NativeBridge
import com.uno.reverse.shizuku.ShizukuBridge

/**
 * Virtual-container-only engine (Path A exclusively).
 *
 * Flow (same family as commercial dual-app tools):
 * 1. Probe Play install of Carrom (base + splits + feature module).
 * 2. Resolve parent install dir via PackageClone (getParent when splits).
 * 3. With Shizuku: elevated ops for clone assist / process visibility.
 * 4. Launch guest through virtual host activity (same-UID target design).
 * 5. Native attaches inside shared UID world and scans live physics block.
 *
 * Full VirtualApp binary is a drop-in; until linked, we still use the clone
 * path resolution + virtual host process + Shizuku so architecture stays pure Path A.
 */
object VirtualEngine {

    private const val TAG = "UnoVirtualEngine"
    private val mainHandler = Handler(Looper.getMainLooper())

    data class Session(
        val active: Boolean,
        val clonePath: String?,
        val versionCode: Long,
        val engineSeen: Boolean,
        val shizuku: Boolean,
        val nativeOk: Boolean,
        val physicsFound: Boolean,
        val detail: String
    )

    @Volatile
    private var sessionActive = false

    fun status(context: Context): Session {
        val src = PackageClone.resolveSource(context)
        val sh = ShizukuBridge.probe(context)
        val phys = try {
            NativeBridge.pollPhysics()
        } catch (_: Throwable) {
            NativeBridge.PhysicsInfo(false, 0f, 0f, 0f)
        }
        val nativeOk = try {
            NativeBridge.getEngineState() >= 0
        } catch (_: Throwable) {
            false
        }
        val detail = when {
            src == null -> "Install Carrom Pool from Play Store first"
            src.engineArtifacts.isEmpty() ->
                "Open Carrom once so feature module (libgame-CARROM*1477) downloads"
            !sh.running ->
                "Clone path ready. Start Shizuku (wireless ADB) for elevated container ops"
            !sessionActive ->
                "Ready — START launches virtual host + native attach"
            !phys.found ->
                "Virtual session active — waiting for live physics block in guest"
            else ->
                "Physics locked inside virtual session"
        }
        return Session(
            active = sessionActive,
            clonePath = src?.installPath,
            versionCode = src?.versionCode ?: 0L,
            engineSeen = src?.engineArtifacts?.isNotEmpty() == true,
            shizuku = sh.running,
            nativeOk = nativeOk,
            physicsFound = phys.found,
            detail = detail
        )
    }

    /**
     * Start virtual-container session only (no external-only path).
     */
    fun start(context: Context): Boolean {
        val src = PackageClone.resolveSource(context)
        if (src == null) {
            Log.w(TAG, "no Carrom install to clone")
            return false
        }
        val inst = VirtualPackageManager.installPackage(context)
        Log.i(TAG, "installPackage: ${inst.message}")
        if (!inst.success && src.engineArtifacts.isEmpty()) {
            return false
        }
        Log.i(TAG, "clone source: ${PackageClone.describe(src)}")

        // Shizuku assist: ensure we can see processes / prepare sandbox dir
        val sh = ShizukuBridge.probe(context)
        if (sh.running) {
            val r = ShizukuBridge.execElevated("id; echo UNO_SHIZUKU_OK")
            Log.i(TAG, "shizuku id: ${r.stdout.trim()}")
            ShizukuBridge.prepareVirtualDirs(PackageClone.CARROM_PKG)
        } else {
            Log.w(TAG, "Shizuku not running — container still starts; elevation limited")
        }

        // Launch virtual host (own process :virtual) — guest surface
        try {
            val i = Intent(context, VirtualHostActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("clone_path", src.installPath)
                putExtra("version_code", src.versionCode)
                putExtra("package", PackageClone.CARROM_PKG)
            }
            context.startActivity(i)
        } catch (t: Throwable) {
            Log.e(TAG, "VirtualHostActivity failed", t)
            return false
        }

        // Also bring Play package up so feature SO maps (until full installPackage)
        VirtualCore.launch(context)

        sessionActive = true
        mainHandler.postDelayed({
            try {
                NativeBridge.attachCarrom()
                Log.i(TAG, "native attach: ${NativeBridge.getReaderStatus()}")
            } catch (t: Throwable) {
                Log.e(TAG, "native attach", t)
            }
        }, 3000)
        return true
    }

    fun stop() {
        sessionActive = false
        try {
            NativeBridge.stopEngine()
        } catch (_: Throwable) {
        }
    }
}
