package com.uno.reverse.nativebridge

/**
 * Kotlin-side control plane. Native agent also maintains C++ SharedLayout;
 * UI and Accessibility read/write these flags for reliable control.
 */
object SharedState {
    object Flag {
        const val AUTOPLAY = 1
        const val AUTOQUEUE = 2
        const val KEEP_LINE = 3
        const val SHOW_LINES = 4
        const val LINE_COUNT = 5
        const val SOLVE_RATE = 6
        const val PROFILE = 7
    }

    class Snapshot {
        @JvmField var mapped: Boolean = false
        @JvmField var seq: Int = 0
        @JvmField var autoplay: Boolean = false
        @JvmField var autoqueue: Boolean = false
        @JvmField var keepLine: Boolean = false
        @JvmField var showLines: Boolean = false
        @JvmField var isMyTurn: Boolean = false
        @JvmField var readyToFire: Boolean = false
        @JvmField var lineCount: Int = 0
        @JvmField var solveRateHz: Int = 30
        @JvmField var profile: Int = 0
        @JvmField var bestAngle: Float = 0f
        @JvmField var bestPower: Float = 1f
        @JvmField var bestCoinIdx: Int = -1
        @JvmField var bestPocketIdx: Int = -1
        @JvmField var solveTimeUs: Int = 0
        @JvmField var candidateCount: Int = 0
        @JvmField var boardW: Float = 0f
        @JvmField var boardH: Float = 0f
    }

    @Volatile private var autoPlay = false
    @Volatile private var autoQueue = true
    @Volatile private var keepLine = true
    @Volatile private var showLines = true
    @Volatile private var solveRate = 20
    @Volatile private var gestureAssist = true
    @Volatile private var headless = false
    @Volatile private var vipOverlay = true

    private val snap = Snapshot()

    fun isAutoPlay() = autoPlay
    fun setAutoPlay(v: Boolean) { autoPlay = v; snap.autoplay = v }
    fun isAutoQueue() = autoQueue
    fun setAutoQueue(v: Boolean) { autoQueue = v; snap.autoqueue = v }
    fun isKeepLine() = keepLine
    fun setKeepLine(v: Boolean) { keepLine = v; snap.keepLine = v }
    fun isShowLines() = showLines
    fun setShowLines(v: Boolean) { showLines = v; snap.showLines = v }
    fun getSolveRate() = solveRate
    fun setSolveRate(v: Int) { solveRate = v.coerceIn(5, 60); snap.solveRateHz = solveRate }
    fun isGestureAssist() = gestureAssist
    fun setGestureAssist(v: Boolean) { gestureAssist = v }
    fun isHeadless() = headless
    fun setHeadless(v: Boolean) { headless = v }
    fun isVipOverlay() = vipOverlay
    fun setVipOverlay(v: Boolean) { vipOverlay = v }
    fun snapshot(): Snapshot = snap
}
