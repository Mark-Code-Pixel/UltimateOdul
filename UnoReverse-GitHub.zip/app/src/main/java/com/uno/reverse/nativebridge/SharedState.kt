package com.uno.reverse.nativebridge
import java.util.concurrent.atomic.*
object SharedState {
    private val autoPlay = AtomicBoolean(true)
    private val autoQueue = AtomicBoolean(true)
    private val keepLine = AtomicBoolean(true)
    private val prediction = AtomicBoolean(false)
    private val rate = AtomicInteger(30)
    private val profile = AtomicReference("Auto")
    private val chosen = AtomicReference<FloatArray?>(null)
    private val candidates = AtomicReference<List<FloatArray>>(emptyList())
    fun isAutoPlay() = autoPlay.get(); fun setAutoPlay(v: Boolean) = autoPlay.set(v)
    fun isAutoQueue() = autoQueue.get(); fun setAutoQueue(v: Boolean) = autoQueue.set(v)
    fun isKeepLine() = keepLine.get(); fun setKeepLine(v: Boolean) = keepLine.set(v)
    fun isPredictionLines() = prediction.get(); fun setPredictionLines(v: Boolean) = prediction.set(v)
    fun getSolveRate() = rate.get(); fun setSolveRate(v: Int) = rate.set(v)
    fun getProfile() = profile.get(); fun setProfile(v: String) = profile.set(v)
    fun getChosenLine() = chosen.get(); fun setChosenLine(l: FloatArray?) = chosen.set(l)
    fun getCandidateLines() = candidates.get(); fun setCandidateLines(l: List<FloatArray>) = candidates.set(l)
}
