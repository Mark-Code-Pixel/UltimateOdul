package com.uno.reverse.binder
import android.os.IBinder
import com.uno.reverse.util.Log
object ServiceManagerProxy {
    fun install() { Log.i("ServiceManagerProxy", "ready (native path)") }
    fun getService(name: String): IBinder? = try {
        val sm = Class.forName("android.os.ServiceManager")
        sm.getMethod("getService", String::class.java).invoke(null, name) as? IBinder
    } catch (_: Exception) { null }
}
