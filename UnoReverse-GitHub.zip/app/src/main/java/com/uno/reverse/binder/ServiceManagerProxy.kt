package com.uno.reverse.binder

import android.os.IBinder
import com.uno.reverse.util.Log as ULog
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Method
import java.lang.reflect.Proxy

/*
 * Invocation handler for the ServiceManager proxy installed by
 * BinderInterceptor.
 *
 * On getService(name), the real IBinder is returned to the caller
 * wrapped in a ServiceProxy specific to that service name. Each
 * ServiceProxy intercepts the calls that matter to a virtual container:
 *
 *   activity           -> UID spoof, startActivity rewrite
 *   package            -> hide container, resolve guest packages
 *   user               -> UID virtualization
 *   account            -> account isolation per guest
 *   window             -> nothing yet, pass through
 *   input              -> pass through
 *
 * getCallingUid spoofing is done by hooking the Binder transaction at
 * the native layer (see binder_hook.cpp). This Java-level proxy only
 * handles the calls that can be intercepted through the dynamic proxy
 * mechanism without native surgery.
 */
class ServiceManagerProxy(
    private val original: IBinder
) : InvocationHandler {

    private val serviceCache = HashMap<String, IBinder>()

    override fun invoke(proxy: Any?, method: Method, args: Array<out Any?>?): Any? {
        val name = method.name

        if (name == "getService" && args != null && args.isNotEmpty()) {
            val serviceName = args[0] as? String ?: return null

            // Cache per service name so we do not rebuild the proxy on
            // every lookup.
            serviceCache[serviceName]?.let { return it }

            val real: IBinder? = try {
                method.invoke(original, *args) as? IBinder
            } catch (t: Throwable) {
                ULog.w(TAG, "getService($serviceName) failed: ${t.message}")
                null
            } ?: return null

            val wrapped = wrapService(serviceName, real)
            serviceCache[serviceName] = wrapped
            return wrapped
        }

        if (name == "addService" && args != null && args.size >= 2) {
            val serviceName = args[0] as? String
            if (serviceName != null) {
                // Invalidate cache for this name.
                serviceCache.remove(serviceName)
            }
        }

        return try {
            method.invoke(original, *(args ?: emptyArray()))
        } catch (t: Throwable) {
            throw t.cause ?: t
        }
    }

    // ------------------------------------------------------------------

    private fun wrapService(serviceName: String, real: IBinder): IBinder {
        val interfaces = collectInterfaces(real)
        if (interfaces.isEmpty()) return real

        val handler = ServiceCallHandler(serviceName, real)
        return try {
            Proxy.newProxyInstance(
                javaClass.classLoader,
                interfaces,
                handler
            ) as IBinder
        } catch (t: Throwable) {
            ULog.w(TAG, "wrapService($serviceName) failed: ${t.message}")
            real
        }
    }

    private fun collectInterfaces(binder: IBinder): Array<Class<*>> {
        val out = LinkedHashSet<Class<*>>()
        out.add(IBinder::class.java)
        var clazz: Class<*>? = binder.javaClass
        while (clazz != null && clazz != Any::class.java) {
            for (iface in clazz.interfaces) collectRecursive(iface, out)
            clazz = clazz.superclass
        }
        return out.toTypedArray()
    }

    private fun collectRecursive(iface: Class<*>, out: MutableSet<Class<*>>) {
        if (!iface.isInterface || !out.add(iface)) return
        for (p in iface.interfaces) collectRecursive(p, out)
    }

    companion object {
        private const val TAG = "ServiceManagerProxy"
    }
}