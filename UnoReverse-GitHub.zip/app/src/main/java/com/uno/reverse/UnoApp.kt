package com.uno.reverse

import android.app.Application
import android.content.Context
import com.uno.reverse.core.EngineConfig
import com.uno.reverse.core.NativeBridge
import com.uno.reverse.core.RemoteConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class UnoApp : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreate() {
        super.onCreate()
        instance = this
        NativeBridge.init(this)
        EngineConfig.load(this)

        // Pull live flags from Cloudflare Worker
        appScope.launch {
            val cfg = RemoteConfig.fetch()
            if (cfg.defaultSpeed in 0..2) {
                EngineConfig.speedMode = cfg.defaultSpeed
                EngineConfig.save()
            }
        }
    }

    companion object {
        lateinit var instance: UnoApp
            private set

        val appContext: Context
            get() = instance.applicationContext
    }
}
