package com.uno.reverse

import android.app.Application
import android.content.Context
import android.util.Log
import com.uno.reverse.core.EngineConfig
import com.uno.reverse.core.NativeBridge
import com.uno.reverse.core.RemoteConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class UnoApp : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreate() {
        super.onCreate()
        instance = this
        try {
            EngineConfig.load(this)
        } catch (t: Throwable) {
            Log.e(TAG, "EngineConfig.load", t)
        }
        // Defer native load so a bad SO cannot kill process before first frame
        try {
            NativeBridge.init(this)
        } catch (t: Throwable) {
            Log.e(TAG, "NativeBridge.init deferred fail", t)
        }
        appScope.launch {
            try {
                val cfg = RemoteConfig.fetch()
                if (cfg.defaultSpeed in 0..2) {
                    EngineConfig.speedMode = cfg.defaultSpeed
                    EngineConfig.save()
                }
            } catch (t: Throwable) {
                Log.w(TAG, "RemoteConfig", t)
            }
        }
    }

    companion object {
        private const val TAG = "UnoApp"
        lateinit var instance: UnoApp
            private set

        val appContext: Context
            get() = instance.applicationContext
    }
}
