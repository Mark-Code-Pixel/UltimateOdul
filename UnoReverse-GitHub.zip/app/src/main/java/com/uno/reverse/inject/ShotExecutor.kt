package com.uno.reverse.inject

import android.util.Log
import com.uno.reverse.overlay.OverlayController

/**
 * Bridges native shot plan → overlay aim line + accessibility gesture.
 */
object ShotExecutor {
    private const val TAG = "UnoShot"

    fun execute(
        overlay: OverlayController?,
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        power: Float
    ) {
        try {
            overlay?.updateAimLine(startX, startY, endX, endY, true)
            InputInjector.dispatchSwipe(startX, startY, endX, endY, power)
        } catch (t: Throwable) {
            Log.w(TAG, "execute", t)
        }
    }

    fun clear(overlay: OverlayController?) {
        try {
            overlay?.clearAim()
        } catch (_: Throwable) {
        }
    }
}
