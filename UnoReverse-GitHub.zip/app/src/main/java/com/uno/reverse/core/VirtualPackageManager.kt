package com.uno.reverse.core
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.*
import android.os.Build
import com.uno.reverse.util.Log
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Method
import java.lang.reflect.Proxy

class VirtualPackageManager private constructor() {
    private lateinit var hostPm: PackageManager
    private lateinit var hostContext: Context
    fun init(context: Context) {
        hostContext = context; hostPm = context.packageManager; installProxy()
    }
    private fun installProxy() {
        try {
            val at = Class.forName("android.app.ActivityThread")
            val current = at.getMethod("currentActivityThread").invoke(null)
            val f = at.getDeclaredField("sPackageManager"); f.isAccessible = true
            val original = f.get(current)
            val handler = InvocationHandler { _, method, args -> handle(method, args, original) }
            val proxy = Proxy.newProxyInstance(original.javaClass.classLoader, original.javaClass.interfaces, handler)
            f.set(current, proxy)
            Log.i("VPM", "proxy installed")
        } catch (e: Exception) { Log.e("VPM", "${e.message}") }
    }
    private fun handle(method: Method, args: Array<Any>?, original: Any): Any? {
        return try {
            when (method.name) {
                "getPackageInfo" -> {
                    val pkg = args?.getOrNull(0) as? String
                    val g = pkg?.let { VirtualCore.get().getGuest(it) }
                    if (g != null) buildGuestPi(g) else method.invoke(original, *(args ?: emptyArray()))
                }
                "getInstalledPackages" -> {
                    val list = method.invoke(original, *(args ?: emptyArray())) as? List<*> ?: emptyList<Any>()
                    list.filter { (it as? PackageInfo)?.packageName != hostContext.packageName }
                }
                else -> method.invoke(original, *(args ?: emptyArray()))
            }
        } catch (e: Exception) { method.invoke(original, *(args ?: emptyArray())) }
    }
    private fun buildGuestPi(g: VirtualCore.GuestInfo): PackageInfo {
        val pi = hostPm.getPackageArchiveInfo(g.sourceDir, PackageManager.GET_ACTIVITIES) ?: PackageInfo()
        pi.packageName = g.packageName
        pi.applicationInfo = ApplicationInfo().apply {
            packageName = g.packageName; sourceDir = g.sourceDir; dataDir = g.dataDir
            nativeLibraryDir = g.libDir; uid = g.originalUid
        }
        return pi
    }
    companion object {
        @Volatile private var I: VirtualPackageManager? = null
        fun get() = I ?: synchronized(this) { I ?: VirtualPackageManager().also { I = it } }
    }
}
