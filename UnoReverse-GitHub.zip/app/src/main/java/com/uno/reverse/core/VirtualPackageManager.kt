package com.uno.reverse.core

import android.os.IBinder
import com.uno.reverse.util.Log as ULog
import java.lang.reflect.Method

/*
 * Intercepts the package service.
 *
 * Responsibilities:
 *   1. Hide the container package and other guests from
 *      getInstalledPackages / getInstalledApplications.
 *   2. Resolve guest package queries correctly. When the guest asks
 *      about itself, the answer must be the guest's own package info,
 *      not the container's.
 *   3. Redirect getLaunchIntentForPackage for guest-internal packages
 *      to the corresponding stub.
 *
 * This class does not create proxies; it is called from
 * ServiceCallHandler for every invocation on the "package" service.
 */
object VirtualPackageManager {

    private const val TAG = "VirtualPackageManager"

    @Volatile private var installTimeMs: Long = 0

    @JvmStatic
    fun init() {
        installTimeMs = System.currentTimeMillis()
    }

    @JvmStatic
    fun invoke(original: IBinder, method: Method, args: Array<out Any?>): Any? {
        return when (method.name) {
            "getInstalledPackages" -> getInstalledPackages(original, method, args)
            "getInstalledApplications" -> getInstalledApplications(original, method, args)
            "getPackageInfo" -> getPackageInfo(original, method, args)
            "getApplicationInfo" -> getApplicationInfo(original, method, args)
            else -> method.invoke(original, *args)
        }
    }

    // ------------------------------------------------------------------

    private fun getInstalledPackages(original: IBinder, method: Method, args: Array<out Any?>): Any? {
        val result = method.invoke(original, *args)
        return filterList(result, original)
    }

    private fun getInstalledApplications(original: IBinder, method: Method, args: Array<out Any?>): Any? {
        val result = method.invoke(original, *args)
        return filterList(result, original)
    }

    private fun getPackageInfo(original: IBinder, method: Method, args: Array<out Any?>): Any? {
        val pkgName = args.getOrNull(0) as? String
        if (pkgName == null) {
            return method.invoke(original, *args)
        }

        // Hide the container itself from guest queries.
        if (pkgName == VirtualCore.containerPackage()) {
            return null
        }

        return method.invoke(original, *args)
    }

    private fun getApplicationInfo(original: IBinder, method: Method, args: Array<out Any?>): Any? {
        val pkgName = args.getOrNull(0) as? String
        if (pkgName == VirtualCore.containerPackage()) {
            return null
        }
        return method.invoke(original, *args)
    }

    // ------------------------------------------------------------------

    /*
     * Filter the container package out of the list response. Lists come
     * back either as a single ParceledListSlice or as a raw List. We
     * only handle the raw List case at the Java level; the Parceled
     * variants are rewritten at the Binder transaction level.
     */
    private fun filterList(result: Any?, original: IBinder): Any? {
        if (result !is List<*>) return result
        val out = ArrayList<Any?>(result.size)
        for (item in result) {
            if (item == null) continue
            val name = try {
                item.javaClass.getField("packageName").get(item) as? String
            } catch (_: Throwable) {
                null
            }
            if (name == VirtualCore.containerPackage()) continue
            out.add(item)
        }
        return out
    }
}