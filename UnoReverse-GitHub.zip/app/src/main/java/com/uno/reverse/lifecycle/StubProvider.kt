package com.uno.reverse.lifecycle

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import com.uno.reverse.core.VirtualCore
import com.uno.reverse.util.Log as ULog

/*
 * Stub ContentProvider. Registered in the container's manifest so the
 * framework can install a provider entry. Real guest providers are
 * proxied through this entry: queries, inserts, deletes, and updates
 * are forwarded to the guest's provider via VirtualCore.
 *
 * The actual forwarding requires the guest's provider to be resolvable
 * through the guest's ClassLoader. If it is not (guest still booting),
 * the call returns null / 0 and is logged.
 */
class StubProvider : ContentProvider() {

    override fun onCreate(): Boolean {
        ULog.i(TAG, "StubProvider created")
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? = null

    override fun getType(uri: Uri): String? = null

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?
    ): Int = 0

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        // Forward control calls into VirtualCore.
        val out = Bundle()
        when (method) {
            "ping" -> out.putBoolean("ok", true)
            "current_guest" -> {
                out.putString("pkg", VirtualCore.currentGuestPackage() ?: "")
                out.putInt("uid", VirtualCore.currentGuestUid())
            }
            else -> out.putBoolean("ok", false)
        }
        return out
    }

    companion object {
        private const val TAG = "StubProvider"
    }
}