package com.uno.reverse.core
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.uno.reverse.util.Log
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Method
import java.lang.reflect.Proxy

class VirtualActivityManager private constructor() {
    private lateinit var hostContext: Context
    fun init(context: Context) { hostContext = context; installProxy() }
    private fun installProxy() {
        try {
            val am = Class.forName("android.app.ActivityManager")
            val getService = am.getDeclaredMethod("getService"); getService.isAccessible = true
            val original = getService.invoke(null)
            val handler = InvocationHandler { _, method, args ->
                if (method.name == "startActivity" && args != null) {
                    for (i in args.indices) {
                        val a = args[i]
                        if (a is Intent) {
                            val pkg = a.`package` ?: a.component?.packageName
                            if (pkg != null && VirtualCore.get().isGuestInstalled(pkg)) {
                                a.component = ComponentName(hostContext.packageName, "com.uno.reverse.lifecycle.StubActivity")
                                a.putExtra("_ur_target_pkg", pkg)
                            }
                        }
                    }
                }
                method.invoke(original, *(args ?: emptyArray()))
            }
            val proxy = Proxy.newProxyInstance(original.javaClass.classLoader, original.javaClass.interfaces, handler)
            try {
                val f = am.getDeclaredField("IActivityManagerSingleton"); f.isAccessible = true
                val singleton = f.get(null)
                val mInstance = Class.forName("android.util.Singleton").getDeclaredField("mInstance")
                mInstance.isAccessible = true; mInstance.set(singleton, proxy)
            } catch (_: Exception) {}
            Log.i("VAM", "proxy installed")
        } catch (e: Exception) { Log.e("VAM", "${e.message}") }
    }
    companion object {
        @Volatile private var I: VirtualActivityManager? = null
        fun get() = I ?: synchronized(this) { I ?: VirtualActivityManager().also { I = it } }
    }
}
