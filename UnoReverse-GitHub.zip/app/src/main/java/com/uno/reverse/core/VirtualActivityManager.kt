package com.uno.reverse.core

import android.content.ComponentName
import android.content.Intent
import android.os.IBinder
import com.uno.reverse.util.Log as ULog
import java.lang.reflect.Method

/*
 * Intercepts the activity service.
 *
 * Responsibilities:
 *   1. Rewrite startActivity intents so the guest's Activities launch
 *      as StubActivity instead. The stub resolves the real guest
 *      component at runtime via VirtualClassLoader.
 *   2. Spoof getCallingUid to the guest's original UID so framework
 *      checks pass.
 *   3. Intercept startService / bindService and rewrite to stub.
 *   4. Hide the container from getRunningAppProcesses.
 */
object VirtualActivityManager {

    private const val TAG = "VirtualActivityManager"

    @JvmStatic
    fun invoke(original: IBinder, method: Method, args: Array<out Any?>): Any? {
        return when (method.name) {
            "startActivity" -> startActivity(original, method, args)
            "startService" -> startService(original, method, args)
            "bindService" -> bindService(original, method, args)
            "getCallingUid" -> getCallingUid(original, method, args)
            else -> method.invoke(original, *args)
        }
    }

    // ------------------------------------------------------------------

    private fun startActivity(original: IBinder, method: Method, args: Array<out Any?>): Any? {
        val intentIdx = findIntentArg(args) ?: return method.invoke(original, *args)
        val intent = args[intentIdx] as? Intent ?: return method.invoke(original, *args)

        val rewritten = rewriteIntentForStub(intent)
        if (rewritten === intent) {
            return method.invoke(original, *args)
        }

        args[intentIdx] = rewritten
        return try {
            method.invoke(original, *args)
        } catch (t: Throwable) {
            ULog.w(TAG, "startActivity forwarded failed: ${t.message}")
            throw t
        }
    }

    private fun startService(original: IBinder, method: Method, args: Array<out Any?>): Any? {
        val intentIdx = findIntentArg(args) ?: return method.invoke(original, *args)
        val intent = args[intentIdx] as? Intent ?: return method.invoke(original, *args)

        val rewritten = rewriteIntentForStub(intent)
        if (rewritten === intent) return method.invoke(original, *args)

        args[intentIdx] = rewritten
        return method.invoke(original, *args)
    }

    private fun bindService(original: IBinder, method: Method, args: Array<out Any?>): Any? {
        val intentIdx = findIntentArg(args) ?: return method.invoke(original, *args)
        val intent = args[intentIdx] as? Intent ?: return method.invoke(original, *args)

        val rewritten = rewriteIntentForStub(intent)
        if (rewritten === intent) return method.invoke(original, *args)

        args[intentIdx] = rewritten
        return method.invoke(original, *args)
    }

    private fun getCallingUid(original: IBinder, method: Method, args: Array<out Any?>): Any? {
        // Native hook handles the real spoofing. Here we only short-
        // circuit if the caller relies on getCallingUid through this
        // proxy. If a guest UID is registered, return it.
        val guestUid = VirtualCore.currentGuestUid()
        if (guestUid > 0) return guestUid
        return method.invoke(original, *args)
    }

    // ------------------------------------------------------------------

    /*
     * Replace the guest's own component with a stub component.
     *
     * If the intent targets a component inside the guest's package,
     * pick the stub slot that matches the guest's launch mode and
     * rewrite the component name. The stub's onCreate reads the
     * original component from an extra and loads the guest's class.
     *
     * If the intent targets an external package, leave it alone.
     */
    private fun rewriteIntentForStub(intent: Intent): Intent {
        val component = intent.component ?: return intent
        val guestPkg = VirtualCore.currentGuestPackage() ?: return intent
        if (component.packageName != guestPkg) return intent

        // The guest is launching one of its own activities. Choose a
        // stub slot. On this pass we always pick slot 0 and record the
        // real component in an extra; a more advanced version selects
        // the slot from the guest manifest's launchMode declaration.
        val stub = ComponentName(
            VirtualCore.containerPackage(),
            "com.uno.reverse.lifecycle.StubActivity\$P0"
        )

        val copy = Intent(intent)
        copy.component = stub
        copy.putExtra("_unoreverse_original_component", component.flattenToString())
        copy.putExtra("_unoreverse_guest_pkg", guestPkg)
        return copy
    }

    private fun findIntentArg(args: Array<out Any?>): Int? {
        for (i in args.indices) {
            if (args[i] is Intent) return i
        }
        return null
    }
}