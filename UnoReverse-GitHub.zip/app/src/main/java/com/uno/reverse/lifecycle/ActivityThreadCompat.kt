package com.uno.reverse.lifecycle

import android.app.Activity
import android.app.ActivityThread
import android.app.Instrumentation
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.IBinder
import com.uno.reverse.util.Log as ULog
import java.lang.reflect.Method

/*
 * Reflection helper that attaches a guest Activity instance to the
 * framework so its Context, Instrumentation, IBinder token, and
 * ActivityInfo are populated.
 *
 * The framework's Activity.attach signature has changed across Android
 * versions:
 *
 *   API 24-27:  attach(Context, ActivityThread, Instrumentation,
 *                     IBinder, int, Application, Intent, ActivityInfo,
 *                     CharSequence, Activity, String, Object, Application)
 *
 *   API 28-34:  same signature (13 arguments) with minor type changes on
 *               the last parameter.
 *
 * We discover the method by name and argument count, then fill the
 * arguments from the host Activity's already-populated fields. Anything
 * the host does not expose is passed as null.
 */
object ActivityThreadCompat {

    private const val TAG = "ActivityThreadCompat"

    fun attachGuestActivity(guest: Activity, host: Activity): Boolean {
        return try {
            val baseContext = readBaseContext(host)
            val mainThread = readField(host, Activity::class.java, "mMainThread")
            val instrumentation = readField(host, Activity::class.java, "mInstrumentation") as? Instrumentation
            val token = readField(host, Activity::class.java, "mToken") as? IBinder
            val activityInfo = readField(host, Activity::class.java, "mActivityInfo") as? ActivityInfo
            val application = host.application

            val attach = findAttachMethod() ?: run {
                ULog.w(TAG, "Activity.attach not found")
                return false
            }

            val args = buildAttachArgs(
                baseContext = baseContext,
                mainThread = mainThread,
                instrumentation = instrumentation,
                token = token,
                activityInfo = activityInfo,
                application = application,
                host = host
            )
            if (args.size != attach.parameterCount) {
                ULog.w(TAG, "attach arg count mismatch: ${args.size} vs ${attach.parameterCount}")
                return false
            }
            attach.invoke(guest, *args.toTypedArray())
            true
        } catch (t: Throwable) {
            ULog.e(TAG, "attachGuestActivity failed", t)
            false
        }
    }

    // ------------------------------------------------------------------

    private fun findAttachMethod(): Method? {
        return Activity::class.java.declaredMethods.firstOrNull {
            it.name == "attach" && it.parameterCount >= 10
        }
    }

    private fun buildAttachArgs(
        baseContext: Context?,
        mainThread: Any?,
        instrumentation: Instrumentation?,
        token: IBinder?,
        activityInfo: ActivityInfo?,
        application: android.app.Application?,
        host: Activity
    ): List<Any?> {
        // Order of parameters in the framework's attach():
        //   0 Context
        //   1 ActivityThread
        //   2 Instrumentation
        //   3 IBinder (token)
        //   4 int (ident)
        //   5 Application
        //   6 Intent
        //   7 ActivityInfo
        //   8 CharSequence (title)
        //   9 Activity (parent)
        //  10 String (id)
        //  11 Object (lastNonConfigurationInstances)
        //  12 Application (config)
        return listOf(
            baseContext ?: host,
            mainThread,
            instrumentation,
            token,
            0,
            application,
            host.intent,
            activityInfo,
            host.title ?: "",
            null,
            host.toString(),
            null,
            application
        )
    }

    private fun readBaseContext(activity: Activity): Context? {
        return try {
            val f = ContextWrapper::class.java.getDeclaredField("mBase")
            f.isAccessible = true
            f.get(activity) as? Context
        } catch (t: Throwable) {
            ULog.w(TAG, "readBaseContext failed: ${t.message}")
            null
        }
    }

    private fun readField(target: Any, clazz: Class<*>, name: String): Any? {
        return try {
            val f = clazz.getDeclaredField(name)
            f.isAccessible = true
            f.get(target)
        } catch (t: Throwable) {
            null
        }
    }
}