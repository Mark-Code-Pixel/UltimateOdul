package com.uno.reverse.process

/*
 * Result of a guest install attempt. Every field is real data, never a
 * placeholder. MainActivity decides whether to enable the Start button
 * solely from `isComplete`.
 */
data class ExtractionReport(
    val guestPackage: String,
    val guestVersionName: String,
    val guestVersionCode: Long,

    val apkPath: String,
    val apkSizeBytes: Long,
    val apkSha256: String,
    val apkOk: Boolean,

    val nativeLibDir: String,
    val nativeLibCount: Int,
    val nativeLibs: List<String>,          // file names only
    val libsOk: Boolean,

    val metadataPath: String,
    val metadataSizeBytes: Long,
    val metadataOk: Boolean,

    val assetsDir: String,
    val assetCount: Int,
    val assetsOk: Boolean,

    val dataDir: String,
    val dataDirOk: Boolean,

    val originalUid: Int,
    val elapsedMs: Long,

    val failureReason: String?             // null when complete
) {
    val isComplete: Boolean
        get() = apkOk && libsOk && metadataOk && assetsOk && dataDirOk &&
                failureReason == null

    fun toJson(): String = buildString {
        append("{\n")
        append("  \"guest_package\": \"").append(guestPackage).append("\",\n")
        append("  \"guest_version_name\": \"").append(guestVersionName).append("\",\n")
        append("  \"guest_version_code\": ").append(guestVersionCode).append(",\n")
        append("  \"apk_path\": \"").append(apkPath).append("\",\n")
        append("  \"apk_size\": ").append(apkSizeBytes).append(",\n")
        append("  \"apk_sha256\": \"").append(apkSha256).append("\",\n")
        append("  \"apk_ok\": ").append(apkOk).append(",\n")
        append("  \"native_lib_count\": ").append(nativeLibCount).append(",\n")
        append("  \"native_libs\": [")
        nativeLibs.forEachIndexed { i, n ->
            if (i > 0) append(", ")
            append('"').append(n).append('"')
        }
        append("],\n")
        append("  \"libs_ok\": ").append(libsOk).append(",\n")
        append("  \"metadata_size\": ").append(metadataSizeBytes).append(",\n")
        append("  \"metadata_ok\": ").append(metadataOk).append(",\n")
        append("  \"asset_count\": ").append(assetCount).append(",\n")
        append("  \"assets_ok\": ").append(assetsOk).append(",\n")
        append("  \"data_dir_ok\": ").append(dataDirOk).append(",\n")
        append("  \"original_uid\": ").append(originalUid).append(",\n")
        append("  \"elapsed_ms\": ").append(elapsedMs).append(",\n")
        append("  \"complete\": ").append(isComplete).append(",\n")
        append("  \"failure_reason\": ")
        if (failureReason == null) append("null") else append('"').append(failureReason).append('"')
        append("\n}\n")
    }
}