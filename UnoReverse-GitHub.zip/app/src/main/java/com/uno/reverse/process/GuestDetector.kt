package com.uno.reverse.process

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/*
 * Detects whether the target guest (Carrom Pool) is installed, and returns
 * everything the installer needs to silently import it: source APK path,
 * version, and the guest's installed UID.
 */
object GuestDetector {

    const val TARGET_PACKAGE = "com.miniclip.carrom"

    data class DetectedGuest(
        val packageName: String,
        val versionName: String,
        val versionCode: Long,
        val sourceDir: String,
        val splitSourceDirs: List<String>,
        val nativeLibraryDir: String,
        val primaryCpuAbi: String,
        val installedUid: Int
    )

    /*
     * Returns the guest if installed and readable, null if not installed.
     * Throws nothing — all errors are folded into a null return plus a log
     * line so MainActivity can branch on presence only.
     */
    @JvmStatic
    fun detect(context: Context): DetectedGuest? {
        val pm = context.packageManager
        return try {
            @Suppress("DEPRECATION")
            val flags = PackageManager.GET_META_DATA or
                    PackageManager.GET_SHARED_LIBRARY_FILES or
                    PackageManager.GET_PERMISSIONS
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(
                    TARGET_PACKAGE,
                    PackageManager.PackageInfoFlags.of(flags.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(TARGET_PACKAGE, flags)
            }

            val appInfo = info.applicationInfo ?: return null
            val splits = try {
                appInfo.splitSourceDirs?.toList().orEmpty()
            } catch (_: Throwable) {
                emptyList()
            }

            DetectedGuest(
                packageName = info.packageName,
                versionName = info.versionName ?: "unknown",
                versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                    info.longVersionCode else @Suppress("DEPRECATION") info.versionCode.toLong(),
                sourceDir = appInfo.sourceDir ?: return null,
                splitSourceDirs = splits,
                nativeLibraryDir = appInfo.nativeLibraryDir ?: "",
                primaryCpuAbi = appInfo.primaryCpuAbi ?: "",
                installedUid = appInfo.uid
            )
        } catch (_: PackageManager.NameNotFoundException) {
            null
        } catch (_: Throwable) {
            null
        }
    }
}