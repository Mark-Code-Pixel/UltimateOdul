package com.uno.reverse.lifecycle

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.uno.reverse.accounts.FacebookAccountBridge
import com.uno.reverse.accounts.GoogleAccountBridge
import com.uno.reverse.util.Log as ULog

/*
 * Transparent activity declared in the manifest to catch OAuth
 * redirects from Custom Tabs and the Facebook app.
 *
 * Registered intent filters:
 *   fbconnect://cct.com.miniclip.carrom
 *   unoreverse://oauth
 *
 * On receive, the URI is forwarded to the appropriate bridge. The
 * activity never shows UI.
 */
class RedirectCaptureActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uri = intent?.data
        if (uri == null) {
            finish()
            return
        }

        val scheme = uri.scheme?.lowercase()
        val host = uri.host?.lowercase()

        try {
            when {
                scheme == "fbconnect" -> FacebookAccountBridge.onRedirect(uri)
                scheme == "unoreverse" && host == "oauth" -> {
                    // Could be Google or Facebook. Route by the presence
                    // of a state marker in the query.
                    val marker = uri.getQueryParameter("provider")
                    when (marker) {
                        "google" -> GoogleAccountBridge.onRedirect(uri)
                        "facebook" -> FacebookAccountBridge.onRedirect(uri)
                        else -> {
                            GoogleAccountBridge.onRedirect(uri)
                            FacebookAccountBridge.onRedirect(uri)
                        }
                    }
                }
                else -> ULog.w(TAG, "Unhandled redirect: $uri")
            }
        } catch (t: Throwable) {
            ULog.e(TAG, "Redirect handling failed", t)
        }

        finish()
    }

    companion object {
        private const val TAG = "RedirectCaptureActivity"
    }
}