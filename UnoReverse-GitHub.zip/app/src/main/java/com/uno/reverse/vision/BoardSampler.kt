package com.uno.reverse.vision

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

/**
 * Screen capture sampler for Carrom Pool board state.
 * Uses MediaProjection (user grants once) to grab frames.
 * Downstream BoardAnalyzer turns pixels into disc positions + striker.
 *
 * This is the vision path – works without root / memory attach.
 */
class BoardSampler(private val context: Context) {

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null

    var latestFrame: Bitmap? = null
        private set

    var onFrame: ((Bitmap) -> Unit)? = null

    fun start(resultCode: Int, data: Intent) {
        stop()
        val mpm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(resultCode, data)

        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        workerThread = HandlerThread("UnoBoardSampler").also { it.start() }
        workerHandler = Handler(workerThread!!.looper)

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width

                val bitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride,
                    height,
                    Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)
                val cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height)
                if (bitmap != cropped) bitmap.recycle()

                latestFrame = cropped
                onFrame?.invoke(cropped)
            } catch (t: Throwable) {
                Log.e(TAG, "Frame process failed", t)
            } finally {
                image.close()
            }
        }, workerHandler)

        virtualDisplay = projection?.createVirtualDisplay(
            "UnoBoard",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null, workerHandler
        )

        Log.i(TAG, "Board sampler started ${width}x${height}")
    }

    fun stop() {
        try {
            virtualDisplay?.release()
        } catch (_: Throwable) {}
        virtualDisplay = null
        try {
            imageReader?.close()
        } catch (_: Throwable) {}
        imageReader = null
        try {
            projection?.stop()
        } catch (_: Throwable) {}
        projection = null
        workerThread?.quitSafely()
        workerThread = null
        workerHandler = null
        latestFrame = null
        Log.i(TAG, "Board sampler stopped")
    }

    companion object {
        private const val TAG = "UnoSampler"

        fun createPermissionIntent(context: Context): Intent {
            val mpm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            return mpm.createScreenCaptureIntent()
        }
    }
}
