#include "physics_scan.h"
#include <android/log.h>
#include <cstring>
#include <cmath>
#include <vector>

#define LOG_TAG "UnoPhys"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)

namespace uno {

// Confirmed float constants from public RE (BitAIM memory scanner)
static constexpr float kPhysA = 0.12f;
static constexpr float kPhysB = 8.2f;
static constexpr float kPhysC = 2.55f;

// Primary anchor bit pattern documented in the same analysis
static constexpr uint32_t kAnchorBits = 0xC0787970u; // ≈ -3.882412f

static bool floatNear(float a, float b, float eps = 1e-4f) {
    return std::fabs(a - b) <= eps;
}

bool findCarromEngineModule(pid_t pid, uintptr_t* outBase, uintptr_t* outEnd, std::string* outPath) {
    auto mods = listModules(pid, "libgame-CARROM");
    if (mods.empty()) {
        // broader fallback – still name-based, not assumed
        mods = listModules(pid, "CARROM");
    }
    if (mods.empty()) {
        mods = listModules(pid, "libgame");
    }
    for (const auto& m : mods) {
        // Prefer the Gold-Release module string shape
        if (m.path.find("libgame-CARROM") != std::string::npos ||
            m.name.find("libgame-CARROM") != std::string::npos) {
            if (outBase) *outBase = m.base;
            if (outEnd) *outEnd = m.end;
            if (outPath) *outPath = m.path.empty() ? m.name : m.path;
            LOGI("Engine module 0x%lx-0x%lx %s",
                 (unsigned long)m.base, (unsigned long)m.end, m.name.c_str());
            return true;
        }
    }
    // If only generic libgame matched, take first readable
    if (!mods.empty()) {
        const auto& m = mods[0];
        if (outBase) *outBase = m.base;
        if (outEnd) *outEnd = m.end;
        if (outPath) *outPath = m.path.empty() ? m.name : m.path;
        LOGI("Fallback module 0x%lx %s", (unsigned long)m.base, m.name.c_str());
        return true;
    }
    return false;
}

bool scanPhysicsBlock(pid_t pid, uintptr_t modBase, uintptr_t modEnd, PhysicsAnchor* out) {
    if (!out || modEnd <= modBase) return false;
    out->found = false;

    const size_t page = 0x1000;
    std::vector<uint8_t> buf(page);

    // Relative word offsets from the documented signature triple
    // around the primary anchor (see BitAIM RE):
    //   word -1 / 0  -> 0.12
    //   word -3 / -2 -> 8.2
    //   word -25/-24 -> 2.55
    // We treat the position of 0.12 as the reference word index 0 for clarity
    // and verify neighbours.

    for (uintptr_t addr = modBase; addr + page <= modEnd; addr += page) {
        if (!readMemory(pid, addr, buf.data(), page)) continue;

        for (size_t off = 0; off + 4 <= page; off += 4) {
            uint32_t bits;
            memcpy(&bits, buf.data() + off, 4);

            // Fast path: primary anchor bit pattern
            bool anchorHit = (bits == kAnchorBits);

            // Also accept direct hit on 0.12 as secondary entry
            float asF;
            memcpy(&asF, buf.data() + off, 4);
            bool constHit = floatNear(asF, kPhysA);

            if (!anchorHit && !constHit) continue;

            // Verify the triple relative to this word
            // Layout from RE: pairs of words hold the doubles/floats
            auto readWordFloat = [&](int wordDelta, float* v) -> bool {
                long byteOff = static_cast<long>(off) + wordDelta * 4;
                if (byteOff < 0 || static_cast<size_t>(byteOff) + 4 > page) {
                    // cross-page – read remote
                    uintptr_t remote = addr + static_cast<uintptr_t>(byteOff);
                    return readMemory(pid, remote, v, sizeof(float));
                }
                memcpy(v, buf.data() + byteOff, 4);
                return true;
            };

            float f12 = 0, f82 = 0, f255 = 0;
            // Using the documented relative offsets from the anchor discussion:
            // when sitting on the 0.12 pair, check 8.2 and 2.55 at fixed deltas
            if (constHit) {
                if (!readWordFloat(0, &f12)) continue;
                if (!readWordFloat(-2, &f82) && !readWordFloat(2, &f82)) continue;
                if (!readWordFloat(-24, &f255) && !readWordFloat(24, &f255)) continue;
            } else {
                // anchor-centered: RE listed pairs (-1,0)=0.12, (-3,-2)=8.2, (-25,-24)=2.55
                if (!readWordFloat(-1, &f12) && !readWordFloat(0, &f12)) continue;
                if (!readWordFloat(-3, &f82) && !readWordFloat(-2, &f82)) continue;
                if (!readWordFloat(-25, &f255) && !readWordFloat(-24, &f255)) continue;
            }

            if (!floatNear(f12, kPhysA)) continue;
            if (!floatNear(f82, kPhysB)) continue;
            if (!floatNear(f255, kPhysC)) continue;

            out->found = true;
            out->pid = pid;
            out->moduleBase = modBase;
            out->moduleEnd = modEnd;
            out->blockAddr = addr + off;
            out->sample0 = f12;
            out->sample1 = f82;
            out->sample2 = f255;
            LOGI("Physics block @ 0x%lx  (0.12=%f 8.2=%f 2.55=%f)",
                 (unsigned long)out->blockAddr, f12, f82, f255);
            return true;
        }
    }
    return false;
}

PhysicsAnchor locatePhysics(pid_t pid) {
    PhysicsAnchor a;
    a.pid = pid;
    if (pid <= 0) return a;

    uintptr_t base = 0, end = 0;
    std::string path;
    if (findCarromEngineModule(pid, &base, &end, &path)) {
        a.moduleBase = base;
        a.moduleEnd = end;
        a.modulePath = path;
        if (scanPhysicsBlock(pid, base, end, &a)) return a;
        LOGW("Physics signature not in named module – trying readable maps");
    } else {
        LOGW("libgame-CARROM module not mapped – maps-wide constant scan");
    }

    // Fallback: scan all readable anonymous/named regions (same technique family as public RE)
    auto mods = listModules(pid, nullptr);
    for (const auto& m : mods) {
        if (m.end <= m.base) continue;
        // skip huge filesystems mappings
        if ((m.end - m.base) > 0x2000000ULL) continue;
        if (scanPhysicsBlock(pid, m.base, m.end, &a)) {
            a.moduleBase = m.base;
            a.moduleEnd = m.end;
            a.modulePath = m.path.empty() ? m.name : m.path;
            return a;
        }
    }
    LOGW("Physics constant signature not found");
    return a;
}

} // namespace uno
