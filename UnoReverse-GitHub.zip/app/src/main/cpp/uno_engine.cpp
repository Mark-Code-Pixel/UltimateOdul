#include <jni.h>
#pragma GCC visibility push(default)

#include <android/log.h>
#include <atomic>
#include <thread>
#include <chrono>
#include <mutex>
#include <string>

#include "carrom_reader.h"
#include "so_loader.h"
#include "board_state.h"

#define LOG_TAG "UnoEngine"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::atomic<bool> g_running{false};
static std::atomic<int>  g_speed{1};
static std::atomic<bool> g_hideLine{false};
static std::atomic<bool> g_hideStream{true};
static std::atomic<bool> g_autoQueue{true};
static std::atomic<bool> g_autoPlay{true};
static std::atomic<bool> g_aimAssist{true};
static std::atomic<int>  g_boardFilter{0};
static std::atomic<int>  g_state{0};

static JavaVM* g_jvm = nullptr;
static std::string g_hostPackage;

static uno::CarromReader g_reader;
static uno::ShotSolver   g_solver;
static std::mutex        g_shotMu;
static uno::ShotPlan     g_lastShot;

// ─── Last shot exposed to Java for overlay / injection ───────────────
static void publishShot(const uno::ShotPlan& plan) {
    std::lock_guard<std::mutex> lock(g_shotMu);
    g_lastShot = plan;
}

static void engineLoop() {
    LOGI("Engine loop started");
    g_state = 1;

    int tick = 0;
    while (g_running.load()) {
        int delayMs = 120;
        switch (g_speed.load()) {
            case 0: delayMs = 260; break;
            case 1: delayMs = 100; break;
            case 2: delayMs = 40;  break;
        }

        if (g_autoPlay.load() || g_aimAssist.load()) {
            if (!g_reader.isAttached()) {
                g_reader.attach();
            }

            uno::BoardSnapshot board = g_reader.readBoard(false); // never invent pieces
            if (board.valid) {
                // preferColor 0 = any for now; later map from turn side
                uno::ShotPlan plan = g_solver.solve(board, 0);
                if (plan.valid) {
                    publishShot(plan);
                    if ((tick % 15) == 0) {
                        LOGI("Shot score=%.3f angle=%.1f power=%.2f target=%d [%s]",
                             plan.score, plan.angleDeg, plan.power, plan.targetPieceId,
                             g_reader.status().c_str());
                    }
                }
            }
        }

        if (g_autoQueue.load() && (tick % 40) == 0) {
            LOGI("AutoQueue heartbeat boardFilter=%d", g_boardFilter.load());
        }

        tick++;
        std::this_thread::sleep_for(std::chrono::milliseconds(delayMs));
    }

    g_state = 0;
    LOGI("Engine loop stopped");
}

extern "C" {

JNIEXPORT void JNICALL
Java_com_uno_reverse_core_NativeBridge_nativeInit(JNIEnv* env, jobject, jstring hostPkg) {
    env->GetJavaVM(&g_jvm);
    const char* pkg = env->GetStringUTFChars(hostPkg, nullptr);
    g_hostPackage = pkg ? pkg : "";
    env->ReleaseStringUTFChars(hostPkg, pkg);
    LOGI("Native init host=%s", g_hostPackage.c_str());
}

JNIEXPORT jboolean JNICALL
Java_com_uno_reverse_core_NativeBridge_startEngine(JNIEnv*, jobject, jint) {
    if (g_running.load()) return JNI_TRUE;
    g_running = true;
    std::thread(engineLoop).detach();
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_uno_reverse_core_NativeBridge_stopEngine(JNIEnv*, jobject) {
    g_running = false;
}

JNIEXPORT void JNICALL
Java_com_uno_reverse_core_NativeBridge_setSpeedMode(JNIEnv*, jobject, jint mode) {
    g_speed = mode;
}

JNIEXPORT void JNICALL
Java_com_uno_reverse_core_NativeBridge_setHideLine(JNIEnv*, jobject, jboolean v) {
    g_hideLine = v;
}

JNIEXPORT void JNICALL
Java_com_uno_reverse_core_NativeBridge_setHideStream(JNIEnv*, jobject, jboolean v) {
    g_hideStream = v;
}

JNIEXPORT void JNICALL
Java_com_uno_reverse_core_NativeBridge_setAutoQueue(JNIEnv*, jobject, jboolean v) {
    g_autoQueue = v;
}

JNIEXPORT void JNICALL
Java_com_uno_reverse_core_NativeBridge_setAutoPlay(JNIEnv*, jobject, jboolean v) {
    g_autoPlay = v;
}

JNIEXPORT void JNICALL
Java_com_uno_reverse_core_NativeBridge_setAimAssist(JNIEnv*, jobject, jboolean v) {
    g_aimAssist = v;
}

JNIEXPORT jint JNICALL
Java_com_uno_reverse_core_NativeBridge_getEngineState(JNIEnv*, jobject) {
    return g_state.load();
}

JNIEXPORT void JNICALL
Java_com_uno_reverse_core_NativeBridge_setBoardFilter(JNIEnv*, jobject, jint id) {
    g_boardFilter = id;
}

/** Returns last shot as float[7]: valid, startX, startY, endX, endY, power, angle */
JNIEXPORT jfloatArray JNICALL
Java_com_uno_reverse_core_NativeBridge_getLastShot(JNIEnv* env, jobject) {
    uno::ShotPlan plan;
    {
        std::lock_guard<std::mutex> lock(g_shotMu);
        plan = g_lastShot;
    }
    jfloatArray arr = env->NewFloatArray(7);
    float data[7] = {
        plan.valid ? 1.f : 0.f,
        plan.aimStart.x,
        plan.aimStart.y,
        plan.aimEnd.x,
        plan.aimEnd.y,
        plan.power,
        plan.angleDeg
    };
    env->SetFloatArrayRegion(arr, 0, 7, data);
    return arr;
}

JNIEXPORT jboolean JNICALL
Java_com_uno_reverse_core_NativeBridge_attachCarrom(JNIEnv*, jobject) {
    return g_reader.attach() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_uno_reverse_core_NativeBridge_getReaderStatus(JNIEnv* env, jobject) {
    return env->NewStringUTF(g_reader.status().c_str());
}

JNIEXPORT jfloatArray JNICALL
Java_com_uno_reverse_core_NativeBridge_getPhysicsInfo(JNIEnv* env, jobject) {
    // [0]=found  [1]=moduleBase_lo as float bits via int  — simpler: return status floats
    // Layout: found, blockAddr(as float bits not reliable on 64). Use string status instead.
    // Provide: found, sample0, sample1, sample2, moduleBase high/low not needed
    const uno::PhysicsAnchor& a = g_reader.physics();
    jfloatArray arr = env->NewFloatArray(5);
    float data[5] = {
        a.found ? 1.f : 0.f,
        a.sample0,
        a.sample1,
        a.sample2,
        a.found ? 1.f : 0.f
    };
    env->SetFloatArrayRegion(arr, 0, 5, data);
    return arr;
}

JNIEXPORT jboolean JNICALL
Java_com_uno_reverse_core_NativeBridge_registerExtractedSo(JNIEnv* env, jobject, jstring path) {
    if (!path) return JNI_FALSE;
    const char* p = env->GetStringUTFChars(path, nullptr);
    uno::LoadedSo so = uno::loadExtractedEngine(p);
    env->ReleaseStringUTFChars(path, p);
    // Keep handle process-lifetime for optional local analysis; do not unload
    return so.ok ? JNI_TRUE : JNI_FALSE;
}



} // extern "C"
