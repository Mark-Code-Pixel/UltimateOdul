#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <sys/types.h>

namespace uno {

struct ModuleInfo {
    uintptr_t base;
    uintptr_t end;
    std::string path;
    std::string name;
};

/** Find PID of process by package / cmdline name. Returns -1 if not found. */
pid_t findPidByName(const char* name);

/** Read /proc/<pid>/maps and collect modules matching name filter (e.g. "libil2cpp", "libunity", "carrom"). */
std::vector<ModuleInfo> listModules(pid_t pid, const char* nameFilter = nullptr);

/** Read remote process memory. Uses process_vm_readv when available, falls back to /proc/pid/mem. */
bool readMemory(pid_t pid, uintptr_t address, void* buffer, size_t size);

/** Write remote process memory (requires ptrace or same-app context). */
bool writeMemory(pid_t pid, uintptr_t address, const void* buffer, size_t size);

/** Pattern scan inside a module. pattern uses ?? for wildcards. Returns first match or 0. */
uintptr_t patternScan(pid_t pid, uintptr_t start, uintptr_t end,
                      const char* pattern, const char* mask);

/** Read little-endian helpers */
uint32_t readU32(pid_t pid, uintptr_t addr);
uint64_t readU64(pid_t pid, uintptr_t addr);
float    readFloat(pid_t pid, uintptr_t addr);

} // namespace uno
