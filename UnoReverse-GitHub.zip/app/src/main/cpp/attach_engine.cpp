#include "carrom_reader.h"
#include "process_util.h"
#include "physics_scan.h"
#include "memory.h"
#include <android/log.h>
#include <cstring>
#include <vector>

#define LOG_TAG "UnoAttach"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)

/**
 * Dual-path attach used by both Path A (same-UID virtual) and Path B (external).
 * 32-bit and 64-bit safe: pure C++, no architecture-specific assumptions beyond
 * pointer width handled by uintptr_t.
 *
 * Real module name from dump (armeabi-v7a split, versionCode 1477):
 *   libgame-CARROM-GooglePlay-Gold-Release-Module-1477.so
 *
 * Note: static float constants 0.12/8.2/2.55 were NOT present as raw .float
 * in the 32-bit SO image (likely runtime-init or computed). Scanner still
 * searches process memory (BSS/heap) after the module is mapped — that is
 * where commercial tools find them.
 */

namespace uno {

static bool nameLooksLikeEngine(const std::string& n) {
    return n.find("libgame-CARROM") != std::string::npos ||
           n.find("CARROM-GooglePlay-Gold") != std::string::npos ||
           n.find("Module-1477") != std::string::npos ||
           n.find("Module-147") != std::string::npos;
}

bool attachToCarromProcess(pid_t preferredPid, PhysicsAnchor* outPhys, std::string* outStatus) {
    pid_t pid = preferredPid;
    if (pid <= 0) {
        pid = findPidByName("com.miniclip.carrom");
        if (pid <= 0) pid = findPidByName("miniclip.carrom");
        if (pid <= 0) pid = findPidByName("carrom");
    }
    if (pid <= 0 || !processAlive(pid)) {
        if (outStatus) *outStatus = "carrom process not found";
        return false;
    }

    auto mods = listModules(pid, nullptr);
    uintptr_t engineBase = 0, engineEnd = 0;
    std::string enginePath;
    for (const auto& m : mods) {
        if (nameLooksLikeEngine(m.name) || nameLooksLikeEngine(m.path)) {
            engineBase = m.base;
            engineEnd = m.end;
            enginePath = m.path.empty() ? m.name : m.path;
            LOGI("engine mapped 0x%lx-0x%lx %s",
                 (unsigned long)m.base, (unsigned long)m.end, m.name.c_str());
            break;
        }
    }

    if (!engineBase) {
        // Module may load late — still allow physics maps-wide scan
        if (outStatus) *outStatus = "process live – engine SO not mapped yet (open a table)";
        LOGW("%s", outStatus ? outStatus->c_str() : "");
    }

    PhysicsAnchor phys = locatePhysics(pid);
    if (outPhys) *outPhys = phys;

    if (phys.found) {
        if (outStatus) *outStatus = "physics block found in live memory";
        return true;
    }
    if (engineBase) {
        if (outStatus) *outStatus = "engine mapped – physics constants not in image (need live BSS/heap)";
        return true; // attached to engine even if const block not yet resolved
    }
    if (outStatus) *outStatus = "attached to process – waiting for engine map";
    return true;
}

} // namespace uno
