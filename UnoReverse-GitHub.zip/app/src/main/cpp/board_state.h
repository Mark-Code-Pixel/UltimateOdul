#pragma once
#include <cstdint>
#include <vector>
#include <cmath>

namespace uno {

struct Vec2 {
    float x = 0.f;
    float y = 0.f;

    Vec2() = default;
    Vec2(float x_, float y_) : x(x_), y(y_) {}

    Vec2 operator+(const Vec2& o) const { return {x + o.x, y + o.y}; }
    Vec2 operator-(const Vec2& o) const { return {x - o.x, y - o.y}; }
    Vec2 operator*(float s) const { return {x * s, y * s}; }

    float length() const { return std::sqrt(x * x + y * y); }
    Vec2 normalized() const {
        float l = length();
        if (l < 1e-6f) return {0, 0};
        return {x / l, y / l};
    }
    float dot(const Vec2& o) const { return x * o.x + y * o.y; }
};

struct Piece {
    Vec2 pos;
    int  id = 0;       // 0 queen, 1 white, 2 black, etc.
    bool pocketed = false;
};

struct BoardSnapshot {
    bool valid = false;
    Vec2 striker;
    std::vector<Piece> pieces;
    float boardMinX = 0, boardMaxX = 0, boardMinY = 0, boardMaxY = 0;
    int turnSide = 0;
};

struct ShotPlan {
    bool  valid = false;
    float angleDeg = 0.f;
    float power = 0.f;       // 0..1
    Vec2  aimStart;
    Vec2  aimEnd;
    int   targetPieceId = -1;
    float score = 0.f;       // higher = better
};

/** Physics + aim solver for Carrom-like table. Pure native, no Java. */
class ShotSolver {
public:
    // Table dimensions in abstract units (will map to screen later)
    float tableW = 1080.f;
    float tableH = 1920.f;
    float pocketRadius = 42.f;
    float pieceRadius = 28.f;
    float strikerRadius = 32.f;

    Vec2 pockets[4];

    ShotSolver();

    /** Compute best shot from a board snapshot. */
    ShotPlan solve(const BoardSnapshot& board, int preferColor /*1 white 2 black 0 any*/);

private:
    float scoreShot(const BoardSnapshot& board, const Vec2& dir, float power, int preferColor,
                    int* outTargetId);
    bool  rayHitsPiece(const Vec2& origin, const Vec2& dir, const Piece& p, float radius,
                       float* outT) const;
    bool  wouldPocket(const Vec2& pos) const;
};

} // namespace uno
