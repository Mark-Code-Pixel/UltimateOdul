#include "board_state.h"
#include <algorithm>
#include <limits>

namespace uno {

ShotSolver::ShotSolver() {
    pockets[0] = {0.f, 0.f};
    pockets[1] = {tableW, 0.f};
    pockets[2] = {0.f, tableH};
    pockets[3] = {tableW, tableH};
}

bool ShotSolver::wouldPocket(const Vec2& pos) const {
    for (int i = 0; i < 4; ++i) {
        float dx = pos.x - pockets[i].x;
        float dy = pos.y - pockets[i].y;
        if (dx * dx + dy * dy <= pocketRadius * pocketRadius) return true;
    }
    return false;
}

bool ShotSolver::rayHitsPiece(const Vec2& origin, const Vec2& dir, const Piece& p,
                              float radius, float* outT) const {
    Vec2 f = origin - p.pos;
    float a = dir.dot(dir);
    if (a < 1e-8f) return false;
    float b = 2.f * f.dot(dir);
    float c = f.dot(f) - radius * radius;
    float disc = b * b - 4.f * a * c;
    if (disc < 0.f) return false;
    float s = std::sqrt(disc);
    float t0 = (-b - s) / (2.f * a);
    float t1 = (-b + s) / (2.f * a);
    float t = (t0 > 1e-3f) ? t0 : t1;
    if (t <= 1e-3f) return false;
    if (outT) *outT = t;
    return true;
}

float ShotSolver::scoreShot(const BoardSnapshot& board, const Vec2& dir, float power,
                            int preferColor, int* outTargetId) {
    float bestT = std::numeric_limits<float>::max();
    int hitId = -1;
    Vec2 hitPos;
    const float r = pieceRadius + strikerRadius;

    for (const auto& p : board.pieces) {
        if (p.pocketed) continue;
        float t = 0.f;
        if (rayHitsPiece(board.striker, dir, p, r, &t) && t < bestT) {
            bestT = t;
            hitId = p.id;
            hitPos = p.pos;
        }
    }
    if (hitId < 0) return -1.f;

    // Nearest pocket from impact
    float bestPocketDist = 1e9f;
    Vec2 bestPocket;
    for (int i = 0; i < 4; ++i) {
        float d = (hitPos - pockets[i]).length();
        if (d < bestPocketDist) {
            bestPocketDist = d;
            bestPocket = pockets[i];
        }
    }

    // Alignment: striker → piece → pocket
    Vec2 toPiece = (hitPos - board.striker).normalized();
    Vec2 toPocket = (bestPocket - hitPos).normalized();
    float align = toPiece.dot(toPocket); // -1..1
    float alignScore = (align + 1.f) * 0.5f; // 0..1

    float colorBonus = 1.f;
    if (hitId == 0) colorBonus = 1.55f; // queen
    else if (preferColor != 0 && hitId == preferColor) colorBonus = 1.3f;
    else if (preferColor != 0) colorBonus = 0.75f;

    float distScore = 1.f / (1.f + bestPocketDist * 0.0018f);
    float powerScore = 1.f - std::fabs(power - 0.62f);
    // Prefer shorter first-leg when alignment is high
    float legScore = 1.f / (1.f + bestT * 0.001f);

    float score = distScore * colorBonus * (0.35f + 0.35f * alignScore + 0.15f * powerScore + 0.15f * legScore);
    if (outTargetId) *outTargetId = hitId;
    return score;
}

ShotPlan ShotSolver::solve(const BoardSnapshot& board, int preferColor) {
    ShotPlan best;
    if (!board.valid || board.pieces.empty()) return best;

    const int angleSteps = 96;
    const int powerSteps = 6;
    const float baseAngle = -90.f;
    const float spread = 85.f;

    for (int ai = 0; ai < angleSteps; ++ai) {
        float deg = baseAngle - spread + (2.f * spread) * (ai / float(angleSteps - 1));
        float rad = deg * 3.14159265f / 180.f;
        Vec2 dir{ std::cos(rad), std::sin(rad) };

        for (int pi = 0; pi < powerSteps; ++pi) {
            float power = 0.32f + 0.11f * pi;
            int targetId = -1;
            float sc = scoreShot(board, dir, power, preferColor, &targetId);
            if (sc > best.score) {
                best.valid = true;
                best.score = sc;
                best.angleDeg = deg;
                best.power = power;
                best.targetPieceId = targetId;
                best.aimStart = board.striker;
                float visual = 360.f + power * 260.f;
                best.aimEnd = board.striker + dir * visual;
            }
        }
    }
    return best;
}

} // namespace uno
