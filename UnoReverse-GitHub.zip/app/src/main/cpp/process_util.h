#pragma once
#include <sys/types.h>
#include <vector>
#include <string>

namespace uno {

struct ThreadInfo {
    pid_t tid;
    std::string name;
};

/** List threads under /proc/<pid>/task */
std::vector<ThreadInfo> listThreads(pid_t pid);

/** True if /proc/<pid> still exists */
bool processAlive(pid_t pid);

/** Read first line of /proc/<pid>/status (Name, State, PPid, etc.) */
bool readStatusField(pid_t pid, const char* field, char* out, size_t outLen);

/** Best-effort: check if package appears in dumpsys-like cmdline still */
bool isPackageRunning(const char* packageName);

} // namespace uno
