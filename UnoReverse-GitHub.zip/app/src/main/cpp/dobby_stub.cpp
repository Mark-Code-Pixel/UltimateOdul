// Lightweight placeholder for future Dobby / inline-hook integration.
// Real Dobby sources will be added when we wire the actual Carrom Pool hooks.
// Keeping a separate translation unit so the build already links correctly.

#include <android/log.h>

#define LOG_TAG "UnoDobby"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" void uno_dobby_placeholder() {
    LOGI("Dobby stub ready – real hooks will be injected here");
}
