#pragma once
#include "board_state.h"
#include "physics_scan.h"
#include <sys/types.h>
#include <cstdint>

namespace uno {

/**
 * Adaptive piece cluster finder.
 * After physics block is located in live memory, scan nearby heap/BSS for
 * clusters of plausible table coordinates (float pairs in board range).
 *
 * This does NOT invent a fixed offset table. It scores candidate arrays
 * at runtime. Only high-confidence clusters set BoardSnapshot.valid.
 */
struct PieceScanConfig {
    float boardMin = -120.f;
    float boardMax =  120.f;
    float minPieceSep = 1.5f;
    float maxPieceSep = 80.f;
    int   minPieces = 6;
    int   maxPieces = 20;
    size_t searchRadius = 0x200000; // bytes around physics block
};

bool scanPieceCluster(
    pid_t pid,
    const PhysicsAnchor& phys,
    const PieceScanConfig& cfg,
    BoardSnapshot* out
);

} // namespace uno
