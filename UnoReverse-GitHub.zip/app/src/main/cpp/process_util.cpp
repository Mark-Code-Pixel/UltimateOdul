#include "process_util.h"
#include "memory.h"
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <unistd.h>
#include <cstdlib>

namespace uno {

std::vector<ThreadInfo> listThreads(pid_t pid) {
    std::vector<ThreadInfo> out;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/task", pid);
    DIR* d = opendir(path);
    if (!d) return out;
    struct dirent* ent;
    while ((ent = readdir(d)) != nullptr) {
        if (ent->d_name[0] == '.') continue;
        char* end = nullptr;
        long tid = strtol(ent->d_name, &end, 10);
        if (!end || *end || tid <= 0) continue;
        ThreadInfo t;
        t.tid = static_cast<pid_t>(tid);
        char cpath[96];
        snprintf(cpath, sizeof(cpath), "/proc/%d/task/%ld/comm", pid, tid);
        FILE* f = fopen(cpath, "r");
        if (f) {
            char name[64] = {0};
            if (fgets(name, sizeof(name), f)) {
                size_t n = strlen(name);
                while (n && (name[n-1] == '\n' || name[n-1] == '\r')) name[--n] = 0;
                t.name = name;
            }
            fclose(f);
        }
        out.push_back(t);
    }
    closedir(d);
    return out;
}

bool processAlive(pid_t pid) {
    if (pid <= 0) return false;
    char path[32];
    snprintf(path, sizeof(path), "/proc/%d", pid);
    return access(path, F_OK) == 0;
}

bool readStatusField(pid_t pid, const char* field, char* out, size_t outLen) {
    char path[48];
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    FILE* f = fopen(path, "r");
    if (!f) return false;
    char line[256];
    size_t flen = strlen(field);
    bool ok = false;
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, field, flen) == 0 && line[flen] == ':') {
            const char* p = line + flen + 1;
            while (*p == ' ' || *p == '\t') ++p;
            snprintf(out, outLen, "%s", p);
            size_t n = strlen(out);
            while (n && (out[n-1] == '\n' || out[n-1] == '\r')) out[--n] = 0;
            ok = true;
            break;
        }
    }
    fclose(f);
    return ok;
}

bool isPackageRunning(const char* packageName) {
    return findPidByName(packageName) > 0;
}

} // namespace uno
