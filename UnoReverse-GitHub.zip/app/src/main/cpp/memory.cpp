#include "memory.h"
#include <android/log.h>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/uio.h>
#include <errno.h>
#include <cstdlib>

#define LOG_TAG "UnoMem"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace uno {

pid_t findPidByName(const char* name) {
    DIR* dir = opendir("/proc");
    if (!dir) return -1;

    pid_t found = -1;
    struct dirent* ent;
    while ((ent = readdir(dir)) != nullptr) {
        if (ent->d_type != DT_DIR) continue;
        char* end = nullptr;
        long pid = strtol(ent->d_name, &end, 10);
        if (end == ent->d_name || *end != '\0' || pid <= 0) continue;

        char path[64];
        snprintf(path, sizeof(path), "/proc/%ld/cmdline", pid);
        FILE* f = fopen(path, "r");
        if (!f) continue;
        char cmd[256] = {0};
        size_t n = fread(cmd, 1, sizeof(cmd) - 1, f);
        fclose(f);
        if (n == 0) continue;
        // cmdline is null-separated; first token is process name / package
        if (strstr(cmd, name) != nullptr) {
            found = static_cast<pid_t>(pid);
            break;
        }
    }
    closedir(dir);
    return found;
}

std::vector<ModuleInfo> listModules(pid_t pid, const char* nameFilter) {
    std::vector<ModuleInfo> out;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* f = fopen(path, "r");
    if (!f) return out;

    char line[512];
    while (fgets(line, sizeof(line), f)) {
        uintptr_t start = 0, end = 0;
        char perms[8] = {0};
        char mapname[256] = {0};
        // format: start-end perms offset dev inode pathname
        if (sscanf(line, "%lx-%lx %7s %*s %*s %*s %255[^\n]", &start, &end, perms, mapname) < 3)
            continue;
        if (perms[0] != 'r') continue; // need readable
        if (nameFilter && nameFilter[0]) {
            if (!strstr(mapname, nameFilter)) continue;
        }
        ModuleInfo m;
        m.base = start;
        m.end = end;
        m.path = mapname;
        // short name
        const char* slash = strrchr(mapname, '/');
        m.name = slash ? (slash + 1) : mapname;
        out.push_back(m);
    }
    fclose(f);
    return out;
}

bool readMemory(pid_t pid, uintptr_t address, void* buffer, size_t size) {
    if (pid <= 0 || !buffer || size == 0) return false;

#if defined(__NR_process_vm_readv) || defined(__linux__)
    struct iovec local{ buffer, size };
    struct iovec remote{ reinterpret_cast<void*>(address), size };
    ssize_t n = process_vm_readv(pid, &local, 1, &remote, 1, 0);
    if (n == static_cast<ssize_t>(size)) return true;
#endif

    // fallback: /proc/pid/mem
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/mem", pid);
    int fd = open(path, O_RDONLY);
    if (fd < 0) return false;
    ssize_t n2 = pread(fd, buffer, size, static_cast<off_t>(address));
    close(fd);
    return n2 == static_cast<ssize_t>(size);
}

bool writeMemory(pid_t pid, uintptr_t address, const void* buffer, size_t size) {
    if (pid <= 0 || !buffer || size == 0) return false;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/mem", pid);
    int fd = open(path, O_RDWR);
    if (fd < 0) return false;
    ssize_t n = pwrite(fd, buffer, size, static_cast<off_t>(address));
    close(fd);
    return n == static_cast<ssize_t>(size);
}

uintptr_t patternScan(pid_t pid, uintptr_t start, uintptr_t end,
                      const char* pattern, const char* mask) {
    if (end <= start) return 0;
    const size_t len = strlen(mask);
    if (len == 0) return 0;

    const size_t chunk = 0x1000;
    std::vector<uint8_t> buf(chunk + len);

    for (uintptr_t addr = start; addr < end; addr += chunk) {
        size_t toRead = chunk + len;
        if (addr + toRead > end) toRead = end - addr;
        if (toRead < len) break;
        if (!readMemory(pid, addr, buf.data(), toRead)) continue;

        for (size_t i = 0; i + len <= toRead; ++i) {
            bool ok = true;
            for (size_t j = 0; j < len; ++j) {
                if (mask[j] == 'x' && buf[i + j] != static_cast<uint8_t>(pattern[j])) {
                    ok = false;
                    break;
                }
            }
            if (ok) return addr + i;
        }
    }
    return 0;
}

uint32_t readU32(pid_t pid, uintptr_t addr) {
    uint32_t v = 0;
    readMemory(pid, addr, &v, sizeof(v));
    return v;
}

uint64_t readU64(pid_t pid, uintptr_t addr) {
    uint64_t v = 0;
    readMemory(pid, addr, &v, sizeof(v));
    return v;
}

float readFloat(pid_t pid, uintptr_t addr) {
    float v = 0.f;
    readMemory(pid, addr, &v, sizeof(v));
    return v;
}

} // namespace uno
