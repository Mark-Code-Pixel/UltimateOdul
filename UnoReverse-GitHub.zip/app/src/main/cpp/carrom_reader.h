#pragma once
#include "board_state.h"
#include "memory.h"
#include "physics_scan.h"
#include <sys/types.h>
#include <string>

namespace uno {

/**
 * Attaches to Carrom Pool and locates the real physics engine module.
 *
 * Confirmed (public RE, not assumed):
 *  - Package com.miniclip.carrom
 *  - Engine SO: libgame-CARROM-GooglePlay-Gold-Release-Module-<versionCode>.so
 *  - Physics constants 0.12 / 8.2 / 2.55 used as signature anchors
 *
 * Board disc arrays are ONLY returned when a confirmed layout is available.
 * Until then, readBoard() reports physics-block status but does not invent piece data.
 */
class CarromReader {
public:
    static constexpr const char* kPackage = "com.miniclip.carrom";

    CarromReader() = default;

    bool attach();
    bool isAttached() const { return pid_ > 0; }
    pid_t pid() const { return pid_; }

    /** Locate physics block via confirmed constants. */
    bool locatePhysicsBlock();

    const PhysicsAnchor& physics() const { return physics_; }

    /**
     * Attempt board snapshot.
     * Returns valid=false unless a real disc layout has been confirmed.
     * Demo board is disabled by default (set allowDemo for pipeline tests only).
     */
    BoardSnapshot readBoard(bool allowDemo = false);

    const std::string& status() const { return status_; }

private:
    pid_t pid_ = -1;
    uintptr_t il2cppBase_ = 0;
    uintptr_t unityBase_ = 0;
    PhysicsAnchor physics_;
    std::string status_;

    bool resolveModules();
};

} // namespace uno
