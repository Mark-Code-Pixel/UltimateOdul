#include "carrom_reader.h"
#include "piece_scan.h"
#include "process_util.h"
#include <android/log.h>
#include <cstring>

#define LOG_TAG "UnoCarrom"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)

namespace uno {

bool CarromReader::attach() {
    if (pid_ > 0 && processAlive(pid_)) {
        status_ = "already attached";
        return true;
    }
    pid_ = findPidByName(kPackage);
    if (pid_ <= 0) pid_ = findPidByName("carrom");
    if (pid_ <= 0) {
        status_ = "carrom process not found";
        LOGW("%s", status_.c_str());
        return false;
    }
    char state[32] = {0};
    readStatusField(pid_, "State", state, sizeof(state));
    LOGI("Attached pid=%d state=%s", pid_, state);
    resolveModules();
    locatePhysicsBlock();
    return true;
}

bool CarromReader::resolveModules() {
    il2cppBase_ = 0;
    unityBase_ = 0;
    auto mods = listModules(pid_, nullptr);
    for (const auto& m : mods) {
        if (m.path.find("libil2cpp") != std::string::npos) {
            if (!il2cppBase_) il2cppBase_ = m.base;
            LOGI("il2cpp 0x%lx", (unsigned long)m.base);
        }
        if (m.path.find("libunity") != std::string::npos) {
            if (!unityBase_) unityBase_ = m.base;
        }
        if (m.path.find("libgame-CARROM") != std::string::npos ||
            m.name.find("libgame-CARROM") != std::string::npos) {
            LOGI("engine SO 0x%lx %s", (unsigned long)m.base, m.name.c_str());
        }
    }
    return true;
}

bool CarromReader::locatePhysicsBlock() {
    physics_ = locatePhysics(pid_);
    if (physics_.found) {
        status_ = "physics block found @ module";
        LOGI("Physics OK base=0x%lx block=0x%lx path=%s",
             (unsigned long)physics_.moduleBase,
             (unsigned long)physics_.blockAddr,
             physics_.modulePath.c_str());
        return true;
    }
    status_ = physics_.moduleBase
        ? "engine module mapped – physics signature not matched"
        : "engine module not mapped (need feature SO / live process)";
    LOGW("%s", status_.c_str());
    return false;
}

BoardSnapshot CarromReader::readBoard(bool allowDemo) {
    BoardSnapshot snap;
    snap.valid = false;
    if (pid_ <= 0) {
        if (!attach()) {
            return snap;
        }
    }
    if (!physics_.found) {
        locatePhysicsBlock();
    }

    // Adaptive runtime cluster scan — no hardcoded offsets
    if (physics_.found) {
        PieceScanConfig cfg;
        if (scanPieceCluster(pid_, physics_, cfg, &snap) && snap.valid) {
            return snap;
        }
    }

    // Demo only if explicitly requested (UI pipeline test)
    if (allowDemo) {
        snap.valid = true;
        snap.striker = {0.f, -80.f};
        for (int i = 0; i < 9; i++) {
            Piece p;
            p.pos = { (float)((i % 3) - 1) * 20.f, (float)((i / 3) - 1) * 20.f };
            p.id = i == 4 ? 0 : (i % 2) + 1;
            snap.pieces.push_back(p);
        }
        return snap;
    }
    return snap;
}

} // namespace uno
