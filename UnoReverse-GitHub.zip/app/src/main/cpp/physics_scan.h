#pragma once
/**
 * Physics-block locator for Carrom Pool engine module.
 *
 * Based ONLY on publicly documented reverse-engineering of commercial tools
 * (BitAIM+ analysis, chocapikk.com, Sep 2026) — not invented offsets.
 *
 * Confirmed facts used:
 *  - Engine SO name: libgame-CARROM-GooglePlay-Gold-Release-Module-<versionCode>.so
 *  - Anchor search uses engine float constants 0.12, 8.2, 2.55 at fixed
 *    relative word offsets from a primary anchor float.
 *  - Primary anchor example in that write-up: bit pattern 0xC0787970 ≈ -3.882412
 *  - Relative word offsets for the triple: (-1,0)->0.12, (-3,-2)->8.2, (-25,-24)->2.55
 *  - Module found via /proc/pid/maps name match + optional signature
 *
 * We do NOT invent piece-array layouts. After locating the physics parameter
 * block we only report the block address; board disc extraction requires a
 * further confirmed layout dump.
 */

#include "memory.h"
#include <cstdint>
#include <string>
#include <vector>

namespace uno {

struct PhysicsAnchor {
    bool      found = false;
    pid_t     pid = -1;
    uintptr_t moduleBase = 0;
    uintptr_t moduleEnd = 0;
    std::string modulePath;
    uintptr_t blockAddr = 0;   // address of the matched physics parameter region
    float     sample0 = 0.f;   // 0.12 region
    float     sample1 = 0.f;   // 8.2
    float     sample2 = 0.f;   // 2.55
};

/** Find libgame-CARROM* module bounds in target process. */
bool findCarromEngineModule(pid_t pid, uintptr_t* outBase, uintptr_t* outEnd, std::string* outPath);

/**
 * Scan module pages for the documented physics constant signature.
 * Returns true only when the full relative float triple matches.
 */
bool scanPhysicsBlock(pid_t pid, uintptr_t modBase, uintptr_t modEnd, PhysicsAnchor* out);

/** High-level: attach-ready scan. */
PhysicsAnchor locatePhysics(pid_t pid);

} // namespace uno
