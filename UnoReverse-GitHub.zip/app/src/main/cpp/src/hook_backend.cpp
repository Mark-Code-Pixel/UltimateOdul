#include "hook_backend.h"
#include "mini_hook.h"
bool hook_install(void* target, void* replace, void** original) {
    return mini_hook::install(target, replace, original);
}
