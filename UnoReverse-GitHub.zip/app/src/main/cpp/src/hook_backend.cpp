// Uno Reverse — hook backend dispatcher implementation.

#include "hook_backend.h"
#include "mini_hook.h"

#include <atomic>
#include <cstring>
#include <dlfcn.h>
#include <mutex>
#include <unordered_map>

namespace unoreverse {

namespace {

std::mutex g_lock;
HookBackendKind g_backend = HookBackendKind::None;
std::unordered_map<void*, void*> g_originals; // target -> trampoline

// Dobby ABI. We resolve symbols at runtime so we don't hard-link Dobby.
typedef int  (*DobbyHookFn)(void* target, void* replace, void** origin);
typedef int  (*DobbyDestroyFn)(void* target);

DobbyHookFn    g_dobby_hook    = nullptr;
DobbyDestroyFn g_dobby_destroy = nullptr;

bool try_dobby() {
    // The Dobby static lib may have been linked directly or the shared
    // lib may have been loaded. Try both.
    void* h = dlopen("libdobby.so", RTLD_NOW | RTLD_NOLOAD);
    if (!h) h = dlopen("libdobby.so", RTLD_NOW);
    if (!h) {
        // Static-linked: look up the symbol in the global namespace.
        void* sym = dlsym(RTLD_DEFAULT, "DobbyHook");
        if (sym) {
            g_dobby_hook = (DobbyHookFn)sym;
            g_dobby_destroy = (DobbyDestroyFn)dlsym(RTLD_DEFAULT, "DobbyDestroy");
            return g_dobby_hook != nullptr;
        }
        return false;
    }
    g_dobby_hook = (DobbyHookFn)dlsym(h, "DobbyHook");
    g_dobby_destroy = (DobbyDestroyFn)dlsym(h, "DobbyDestroy");
    return g_dobby_hook != nullptr && g_dobby_destroy != nullptr;
}

void select_backend() {
    if (g_backend != HookBackendKind::None) return;
    if (try_dobby()) {
        g_backend = HookBackendKind::Dobby;
        return;
    }
    if (mini_hook_init()) {
        g_backend = HookBackendKind::Mini;
        return;
    }
    g_backend = HookBackendKind::None;
}

} // namespace

bool hook_install(void* target, void* handler, void** out_original) {
    std::lock_guard<std::mutex> lk(g_lock);
    select_backend();
    if (g_backend == HookBackendKind::None) return false;

    if (out_original) *out_original = nullptr;

    if (g_backend == HookBackendKind::Dobby) {
        void* origin = nullptr;
        int rc = g_dobby_hook(target, handler, &origin);
        if (rc != 0) return false;
        g_originals[target] = origin;
        if (out_original) *out_original = origin;
        return true;
    }

    if (g_backend == HookBackendKind::Mini) {
        void* origin = nullptr;
        if (!mini_hook_install(target, handler, &origin)) return false;
        g_originals[target] = origin;
        if (out_original) *out_original = origin;
        return true;
    }

    return false;
}

bool hook_uninstall(void* target) {
    std::lock_guard<std::mutex> lk(g_lock);
    if (g_backend == HookBackendKind::None) return false;

    if (g_backend == HookBackendKind::Dobby) {
        if (g_dobby_destroy(target) != 0) return false;
        g_originals.erase(target);
        return true;
    }

    if (g_backend == HookBackendKind::Mini) {
        bool ok = mini_hook_uninstall(target);
        g_originals.erase(target);
        return ok;
    }

    return false;
}

HookBackendKind hook_backend_kind() {
    std::lock_guard<std::mutex> lk(g_lock);
    return g_backend;
}

const char* hook_backend_name() {
    switch (hook_backend_kind()) {
        case HookBackendKind::Dobby: return "dobby";
        case HookBackendKind::Mini:  return "mini";
        default:                     return "none";
    }
}

} // namespace unoreverse