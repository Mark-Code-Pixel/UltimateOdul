// Uno Reverse — filesystem redirect implementation.

#include "file_redirect.h"

#include <atomic>
#include <cstdarg>
#include <cstring>
#include <fcntl.h>
#include <mutex>
#include <string>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include <dlfcn.h>

#include "hook_backend.h"

namespace unoreverse {

namespace {

std::mutex g_lock;
std::string g_guest_pkg;
std::string g_virtual_root;
bool g_ready = false;
bool g_installed = false;

// Original function pointers. Filled in by hook_install.
typedef int  (*OpenFn)(const char*, int, ...);
typedef int  (*OpenAtFn)(int, const char*, int, ...);
typedef FILE* (*FopenFn)(const char*, const char*);
typedef int  (*StatFn)(const char*, struct stat*);
typedef int  (*LstatFn)(const char*, struct stat*);
typedef int  (*AccessFn)(const char*, int);
typedef int  (*MkdirFn)(const char*, mode_t);
typedef int  (*RmdirFn)(const char*);
typedef int  (*UnlinkFn)(const char*);

static OpenFn   g_orig_open   = nullptr;
static OpenAtFn g_orig_openat = nullptr;
static FopenFn  g_orig_fopen  = nullptr;
static StatFn   g_orig_stat   = nullptr;
static LstatFn  g_orig_lstat  = nullptr;
static AccessFn g_orig_access = nullptr;
static MkdirFn  g_orig_mkdir  = nullptr;
static RmdirFn  g_orig_rmdir  = nullptr;
static UnlinkFn g_orig_unlink = nullptr;

// ---- Path rewrite --------------------------------------------------

bool path_has_prefix(const std::string& p, const std::string& prefix) {
    if (p.size() < prefix.size()) return false;
    return std::memcmp(p.data(), prefix.data(), prefix.size()) == 0;
}

// Create parent directories recursively. Best effort.
void make_parents(const std::string& path) {
    size_t pos = 0;
    while ((pos = path.find('/', pos + 1)) != std::string::npos) {
        std::string dir = path.substr(0, pos);
        if (dir.empty()) continue;
        ::mkdir(dir.c_str(), 0700);
    }
}

} // namespace

// ---------------------------------------------------------------------

bool file_redirect_init(const std::string& guest_package,
                        const std::string& virtual_root) {
    std::lock_guard<std::mutex> lk(g_lock);
    g_guest_pkg = guest_package;
    g_virtual_root = virtual_root;
    g_ready = !guest_package.empty() && !virtual_root.empty();
    return g_ready;
}

bool file_redirect_ready() {
    std::lock_guard<std::mutex> lk(g_lock);
    return g_ready;
}

std::string file_redirect_rewrite(const std::string& path) {
    if (!g_ready) return path;
    if (path.empty()) return path;

    // Candidate prefixes that belong to the guest.
    const std::string pkg_data = "/data/data/" + g_guest_pkg;
    const std::string pkg_user = "/data/user/0/" + g_guest_pkg;
    const std::string pkg_misc = "/data/misc/" + g_guest_pkg;

    auto rewrite = [&](const std::string& prefix) -> std::string {
        if (!path_has_prefix(path, prefix)) return "";
        std::string suffix = path.substr(prefix.size());
        return g_virtual_root + "/data" + suffix;
    };

    std::string out;
    out = rewrite(pkg_data);
    if (!out.empty()) return out;
    out = rewrite(pkg_user);
    if (!out.empty()) return out;
    out = rewrite(pkg_misc);
    if (!out.empty()) return out;

    return path;
}

// ---------------------------------------------------------------------
// Hooked functions
// ---------------------------------------------------------------------

static int hooked_open(const char* path, int flags, ...) {
    mode_t mode = 0;
    if (flags & O_CREAT) {
        va_list args;
        va_start(args, flags);
        mode = (mode_t)va_arg(args, int);
        va_end(args);
    }

    std::string rewritten = file_redirect_rewrite(path ? path : "");
    if (!rewritten.empty() && rewritten != (path ? path : "")) {
        make_parents(rewritten);
        if (g_orig_open) return g_orig_open(rewritten.c_str(), flags, mode);
    }
    if (g_orig_open) return g_orig_open(path, flags, mode);
    return -1;
}

static int hooked_openat(int dirfd, const char* path, int flags, ...) {
    mode_t mode = 0;
    if (flags & O_CREAT) {
        va_list args;
        va_start(args, flags);
        mode = (mode_t)va_arg(args, int);
        va_end(args);
    }

    // Only redirect absolute paths. Relative paths depend on dirfd and
    // we leave them to the caller.
    std::string in = path ? path : "";
    if (!in.empty() && in[0] == '/') {
        std::string rewritten = file_redirect_rewrite(in);
        if (rewritten != in) {
            make_parents(rewritten);
            if (g_orig_openat) return g_orig_openat(AT_FDCWD, rewritten.c_str(), flags, mode);
        }
    }
    if (g_orig_openat) return g_orig_openat(dirfd, path, flags, mode);
    return -1;
}

static FILE* hooked_fopen(const char* path, const char* mode) {
    std::string rewritten = file_redirect_rewrite(path ? path : "");
    if (!rewritten.empty() && rewritten != (path ? path : "")) {
        make_parents(rewritten);
        if (g_orig_fopen) return g_orig_fopen(rewritten.c_str(), mode);
    }
    if (g_orig_fopen) return g_orig_fopen(path, mode);
    return nullptr;
}

static int hooked_stat(const char* path, struct stat* st) {
    std::string rewritten = file_redirect_rewrite(path ? path : "");
    if (!rewritten.empty() && rewritten != (path ? path : "")) {
        if (g_orig_stat) return g_orig_stat(rewritten.c_str(), st);
    }
    if (g_orig_stat) return g_orig_stat(path, st);
    return -1;
}

static int hooked_lstat(const char* path, struct stat* st) {
    std::string rewritten = file_redirect_rewrite(path ? path : "");
    if (!rewritten.empty() && rewritten != (path ? path : "")) {
        if (g_orig_lstat) return g_orig_lstat(rewritten.c_str(), st);
    }
    if (g_orig_lstat) return g_orig_lstat(path, st);
    return -1;
}

static int hooked_access(const char* path, int mode) {
    std::string rewritten = file_redirect_rewrite(path ? path : "");
    if (!rewritten.empty() && rewritten != (path ? path : "")) {
        if (g_orig_access) return g_orig_access(rewritten.c_str(), mode);
    }
    if (g_orig_access) return g_orig_access(path, mode);
    return -1;
}

static int hooked_mkdir(const char* path, mode_t mode) {
    std::string rewritten = file_redirect_rewrite(path ? path : "");
    if (!rewritten.empty() && rewritten != (path ? path : "")) {
        make_parents(rewritten);
        if (g_orig_mkdir) return g_orig_mkdir(rewritten.c_str(), mode);
    }
    if (g_orig_mkdir) return g_orig_mkdir(path, mode);
    return -1;
}

static int hooked_rmdir(const char* path) {
    std::string rewritten = file_redirect_rewrite(path ? path : "");
    if (!rewritten.empty() && rewritten != (path ? path : "")) {
        if (g_orig_rmdir) return g_orig_rmdir(rewritten.c_str());
    }
    if (g_orig_rmdir) return g_orig_rmdir(path);
    return -1;
}

static int hooked_unlink(const char* path) {
    std::string rewritten = file_redirect_rewrite(path ? path : "");
    if (!rewritten.empty() && rewritten != (path ? path : "")) {
        if (g_orig_unlink) return g_orig_unlink(rewritten.c_str());
    }
    if (g_orig_unlink) return g_orig_unlink(path);
    return -1;
}

// ---------------------------------------------------------------------

bool file_redirect_install() {
    std::lock_guard<std::mutex> lk(g_lock);
    if (g_installed) return true;
    if (!g_ready) return false;

    void* libc = dlopen("libc.so", RTLD_NOW | RTLD_NOLOAD);
    if (!libc) libc = dlopen("libc.so", RTLD_NOW);
    if (!libc) return false;

    struct Binding {
        const char* name;
        void* hook;
        void** orig;
    };

    Binding bindings[] = {
        { "open",    (void*)hooked_open,   (void**)&g_orig_open },
        { "openat",  (void*)hooked_openat, (void**)&g_orig_openat },
        { "fopen",   (void*)hooked_fopen,  (void**)&g_orig_fopen },
        { "stat",    (void*)hooked_stat,   (void**)&g_orig_stat },
        { "lstat",   (void*)hooked_lstat,  (void**)&g_orig_lstat },
        { "access",  (void*)hooked_access, (void**)&g_orig_access },
        { "mkdir",   (void*)hooked_mkdir,  (void**)&g_orig_mkdir },
        { "rmdir",   (void*)hooked_rmdir,  (void**)&g_orig_rmdir },
        { "unlink",  (void*)hooked_unlink, (void**)&g_orig_unlink },
    };

    bool any_installed = false;
    for (auto& b : bindings) {
        void* target = dlsym(libc, b.name);
        if (!target) continue;
        if (hook_install(target, b.hook, b.orig)) {
            any_installed = true;
        }
    }

    dlclose(libc);
    g_installed = any_installed;
    return any_installed;
}

void file_redirect_uninstall() {
    std::lock_guard<std::mutex> lk(g_lock);
    if (!g_installed) return;

    void* libc = dlopen("libc.so", RTLD_NOW | RTLD_NOLOAD);
    if (libc) {
        const char* names[] = {
            "open", "openat", "fopen", "stat", "lstat",
            "access", "mkdir", "rmdir", "unlink"
        };
        for (auto n : names) {
            void* target = dlsym(libc, n);
            if (target) hook_uninstall(target);
        }
        dlclose(libc);
    }

    g_orig_open = nullptr;
    g_orig_openat = nullptr;
    g_orig_fopen = nullptr;
    g_orig_stat = nullptr;
    g_orig_lstat = nullptr;
    g_orig_access = nullptr;
    g_orig_mkdir = nullptr;
    g_orig_rmdir = nullptr;
    g_orig_unlink = nullptr;
    g_installed = false;
}

} // namespace unoreverse