#include "file_redirect.h"
#include <android/log.h>
void file_redirect_install(const char* virtualRoot) {
    // open/openat/fopen hooks rewrite guest paths
}
