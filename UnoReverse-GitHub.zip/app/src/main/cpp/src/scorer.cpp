#include "scorer.h"
#include "unoreverse.h"
float score_result(const StepResult* r) {
    if (!r || r->scratched) return -1e6f;
    if (!r->valid) return -1e5f;
    return 1.f;
}
