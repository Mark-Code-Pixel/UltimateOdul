// Uno Reverse — JNI surface.
//
// Wires the Kotlin NativeBridge object to the C++ agent and overlay
// bridge. Every function here is safe to call before init — they return
// safe defaults and never throw across the JNI boundary.

#include "agent.h"
#include "hooks.h"
#include "offsets_runtime.h"
#include "overlay_bridge.h"
#include "shared_mem.h"

#include <android/log.h>
#include <cstring>
#include <jni.h>
#include <mutex>

#define LOG_TAG "UnoReverseJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern int  unoreverse_agent_start_solver();
extern void unoreverse_agent_stop_solver();
extern int  unoreverse_runtime_resolve(const char* report_path,
                                       const char* output_path,
                                       char* reason_buf,
                                       int reason_buf_len);

namespace {

JavaVM* g_vm = nullptr;
jclass  g_virtual_core_class = nullptr;
jmethodID g_on_manifest_ready = nullptr;
jclass  g_snapshot_class = nullptr;
jfieldID g_snap_mapped = nullptr;
jfieldID g_snap_seq = nullptr;
jfieldID g_snap_autoplay = nullptr;
jfieldID g_snap_autoqueue = nullptr;
jfieldID g_snap_keep_line = nullptr;
jfieldID g_snap_show_lines = nullptr;
jfieldID g_snap_is_my_turn = nullptr;
jfieldID g_snap_ready_to_fire = nullptr;
jfieldID g_snap_line_count = nullptr;
jfieldID g_snap_solve_rate = nullptr;
jfieldID g_snap_profile = nullptr;
jfieldID g_snap_best_angle = nullptr;
jfieldID g_snap_best_power = nullptr;
jfieldID g_snap_best_coin = nullptr;
jfieldID g_snap_best_pocket = nullptr;
jfieldID g_snap_solve_time = nullptr;
jfieldID g_snap_candidate_count = nullptr;
jfieldID g_snap_board_w = nullptr;
jfieldID g_snap_board_h = nullptr;

std::once_flag g_class_cache_flag;

std::string jstring_to_std(JNIEnv* env, jstring s) {
    if (!s) return "";
    const char* c = env->GetStringUTFChars(s, nullptr);
    if (!c) return "";
    std::string out(c);
    env->ReleaseStringUTFChars(s, c);
    return out;
}

jstring std_to_jstring(JNIEnv* env, const std::string& s) {
    return env->NewStringUTF(s.c_str());
}

void cache_kotlin_refs(JNIEnv* env) {
    std::call_once(g_class_cache_flag, [env]() {
        // VirtualCore static callback
        jclass vc = env->FindClass("com/uno/reverse/core/VirtualCore");
        if (vc) {
            g_virtual_core_class = (jclass)env->NewGlobalRef(vc);
            env->DeleteLocalRef(vc);
            if (g_virtual_core_class) {
                g_on_manifest_ready = env->GetStaticMethodID(
                    g_virtual_core_class,
                    "onRuntimeManifestReady",
                    "(Ljava/lang/String;Ljava/lang/String;)V");
            }
        }

        // SharedState.Snapshot field handles
        jclass sc = env->FindClass("com/uno/reverse/nativebridge/SharedState$Snapshot");
        if (sc) {
            g_snapshot_class = (jclass)env->NewGlobalRef(sc);
            env->DeleteLocalRef(sc);
            if (g_snapshot_class) {
                g_snap_mapped          = env->GetFieldID(g_snapshot_class, "mapped",         "Z");
                g_snap_seq             = env->GetFieldID(g_snapshot_class, "seq",            "I");
                g_snap_autoplay        = env->GetFieldID(g_snapshot_class, "autoplay",       "Z");
                g_snap_autoqueue       = env->GetFieldID(g_snapshot_class, "autoqueue",      "Z");
                g_snap_keep_line       = env->GetFieldID(g_snapshot_class, "keepLine",       "Z");
                g_snap_show_lines      = env->GetFieldID(g_snapshot_class, "showLines",      "Z");
                g_snap_is_my_turn      = env->GetFieldID(g_snapshot_class, "isMyTurn",       "Z");
                g_snap_ready_to_fire   = env->GetFieldID(g_snapshot_class, "readyToFire",    "Z");
                g_snap_line_count      = env->GetFieldID(g_snapshot_class, "lineCount",      "I");
                g_snap_solve_rate      = env->GetFieldID(g_snapshot_class, "solveRateHz",    "I");
                g_snap_profile         = env->GetFieldID(g_snapshot_class, "profile",        "I");
                g_snap_best_angle      = env->GetFieldID(g_snapshot_class, "bestAngle",      "F");
                g_snap_best_power      = env->GetFieldID(g_snapshot_class, "bestPower",      "F");
                g_snap_best_coin       = env->GetFieldID(g_snapshot_class, "bestCoinIdx",    "I");
                g_snap_best_pocket     = env->GetFieldID(g_snapshot_class, "bestPocketIdx",  "I");
                g_snap_solve_time      = env->GetFieldID(g_snapshot_class, "solveTimeUs",    "I");
                g_snap_candidate_count = env->GetFieldID(g_snapshot_class, "candidateCount", "I");
                g_snap_board_w         = env->GetFieldID(g_snapshot_class, "boardW",         "F");
                g_snap_board_h         = env->GetFieldID(g_snapshot_class, "boardH",         "F");
            }
        }
    });
}

} // namespace

extern "C" void unoreverse_notify_kotlin(const char* engine, const char* path) {
    if (!g_vm || !g_virtual_core_class || !g_on_manifest_ready) return;

    JNIEnv* env = nullptr;
    bool attached = false;

    jint rc = g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);
    if (rc == JNI_EDETACHED) {
        if (g_vm->AttachCurrentThread(&env, nullptr) == JNI_OK) {
            attached = true;
        } else {
            return;
        }
    } else if (rc != JNI_OK) {
        return;
    }

    jstring j_engine = std_to_jstring(env, engine ? engine : "unknown");
    jstring j_path   = std_to_jstring(env, path ? path : "");
    env->CallStaticVoidMethod(g_virtual_core_class, g_on_manifest_ready, j_engine, j_path);

    if (env->ExceptionCheck()) {
        env->ExceptionDescribe();
        env->ExceptionClear();
    }

    env->DeleteLocalRef(j_engine);
    env->DeleteLocalRef(j_path);

    if (attached) g_vm->DetachCurrentThread();
}

extern "C" JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    LOGI("JNI_OnLoad");
    return JNI_VERSION_1_6;
}

// ---------------------------------------------------------------------
// Container side
// ---------------------------------------------------------------------

extern "C" JNIEXPORT jint JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeInit(
    JNIEnv* env, jclass, jstring agentDir, jstring ashmemName)
{
    cache_kotlin_refs(env);

    std::string dir = jstring_to_std(env, agentDir);
    std::string name = jstring_to_std(env, ashmemName);

    LOGI("nativeInit dir=%s name=%s", dir.c_str(), name.c_str());

    if (!unoreverse::agent_init(dir, name)) {
        LOGE("agent_init failed");
        return -1;
    }

    std::string offsets_path = dir + "/offsets.json";
    if (!unoreverse::offsets_load(offsets_path)) {
        LOGW("offsets not loaded from %s; hooks deferred", offsets_path.c_str());
    }

    return 0;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeAgentReady(
    JNIEnv*, jclass)
{
    return unoreverse::agent_inventory_complete() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeInventoryComplete(
    JNIEnv*, jclass)
{
    return unoreverse::agent_inventory_complete() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeEngineName(
    JNIEnv* env, jclass)
{
    return std_to_jstring(env, unoreverse::agent_engine_name());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeActiveAbi(
    JNIEnv* env, jclass)
{
    return std_to_jstring(env, unoreverse::agent_active_abi());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeDefaultProfile(
    JNIEnv* env, jclass)
{
    return std_to_jstring(env, unoreverse::agent_default_profile());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeStartRuntimeDump(
    JNIEnv* env, jclass, jstring guestPkg, jstring outputPath)
{
    std::string pkg = jstring_to_std(env, guestPkg);
    std::string out = jstring_to_std(env, outputPath);

    LOGI("startRuntimeDump pkg=%s out=%s", pkg.c_str(), out.c_str());

    if (!unoreverse::agent_start_runtime_dump(pkg, out)) {
        return -1;
    }
    return 0;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeInstallHooks(
    JNIEnv* env, jclass, jstring offsetsPath)
{
    std::string path = jstring_to_std(env, offsetsPath);
    if (!unoreverse::offsets_load(path)) {
        LOGW("offsets_load failed: %s", path.c_str());
        return -1;
    }
    if (!unoreverse::hooks_install_all()) {
        LOGW("hooks_install_all failed");
        return -2;
    }
    return 0;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeStartSolver(
    JNIEnv*, jclass)
{
    return unoreverse_agent_start_solver();
}

extern "C" JNIEXPORT void JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeStopSolver(
    JNIEnv*, jclass)
{
    unoreverse_agent_stop_solver();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeResolveOffsets(
    JNIEnv* env, jclass, jstring reportPath, jstring outputPath, jstring /*reasonHolder*/)
{
    std::string rp = jstring_to_std(env, reportPath);
    std::string op = jstring_to_std(env, outputPath);

    char reason[256] = {0};
    int rc = unoreverse_runtime_resolve(rp.c_str(), op.c_str(), reason, sizeof(reason));

    LOGI("nativeResolveOffsets rc=%d reason=%s", rc, reason);
    return rc;
}

extern "C" JNIEXPORT void JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeShutdown(
    JNIEnv*, jclass)
{
    LOGI("nativeShutdown");
    unoreverse_agent_stop_solver();
    unoreverse::hooks_uninstall_all();
    unoreverse::agent_shutdown();
}

// ---------------------------------------------------------------------
// Overlay side
// ---------------------------------------------------------------------

extern "C" JNIEXPORT jstring JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeCreateSharedRegion(
    JNIEnv* env, jclass)
{
    std::string path = unoreverse::overlay_create_region();
    if (path.empty()) {
        LOGW("createSharedRegion returned empty");
        return env->NewStringUTF("");
    }
    LOGI("createSharedRegion path=%s", path.c_str());
    return std_to_jstring(env, path);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeMapSharedRegion(
    JNIEnv* env, jclass, jstring path)
{
    std::string p = jstring_to_std(env, path);
    if (p.empty()) return -1;
    bool ok = unoreverse::overlay_map_region(p);
    LOGI("mapSharedRegion path=%s ok=%d", p.c_str(), ok ? 1 : 0);
    return ok ? 0 : -1;
}

extern "C" JNIEXPORT void JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeUnmapSharedRegion(
    JNIEnv*, jclass)
{
    unoreverse::overlay_unmap_region();
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeIsSharedMapped(
    JNIEnv*, jclass)
{
    return unoreverse::overlay_is_mapped() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeSnapshot(
    JNIEnv* env, jclass, jobject out)
{
    if (!out || !g_snapshot_class) return;
    using namespace unoreverse;
    SharedLayout* sh = overlay_layout();
    if (!sh) {
        env->SetBooleanField(out, g_snap_mapped, JNI_FALSE);
        return;
    }

    env->SetBooleanField(out, g_snap_mapped,      JNI_TRUE);
    env->SetIntField(out, g_snap_seq,             (jint)sh->header.seq.load(std::memory_order_acquire));
    env->SetBooleanField(out, g_snap_autoplay,    sh->header.autoplay.load(std::memory_order_acquire) != 0);
    env->SetBooleanField(out, g_snap_autoqueue,   sh->header.autoqueue.load(std::memory_order_acquire) != 0);
    env->SetBooleanField(out, g_snap_keep_line,   sh->header.keep_line.load(std::memory_order_acquire) != 0);
    env->SetBooleanField(out, g_snap_show_lines,  sh->header.show_lines.load(std::memory_order_acquire) != 0);
    env->SetBooleanField(out, g_snap_is_my_turn,  sh->header.is_my_turn.load(std::memory_order_acquire) != 0);
    env->SetBooleanField(out, g_snap_ready_to_fire, sh->header.ready_to_fire.load(std::memory_order_acquire) != 0);
    env->SetIntField(out, g_snap_line_count,      sh->header.line_count.load(std::memory_order_acquire));
    env->SetIntField(out, g_snap_solve_rate,      sh->header.solve_rate_hz.load(std::memory_order_acquire));
    env->SetIntField(out, g_snap_profile,         sh->header.profile.load(std::memory_order_acquire));
    env->SetFloatField(out, g_snap_best_angle,    sh->header.best_angle.load(std::memory_order_acquire));
    env->SetFloatField(out, g_snap_best_power,    sh->header.best_power.load(std::memory_order_acquire));
    env->SetIntField(out, g_snap_best_coin,       sh->header.best_coin_idx.load(std::memory_order_acquire));
    env->SetIntField(out, g_snap_best_pocket,     sh->header.best_pocket_idx.load(std::memory_order_acquire));
    env->SetIntField(out, g_snap_solve_time,      sh->header.solve_time_us.load(std::memory_order_acquire));
    env->SetIntField(out, g_snap_candidate_count, sh->header.candidate_count.load(std::memory_order_acquire));

    env->SetFloatField(out, g_snap_board_w,       sh->board.W);
    env->SetFloatField(out, g_snap_board_h,       sh->board.H);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeSetFlag(
    JNIEnv*, jclass, jint flag, jint value)
{
    using namespace unoreverse;
    SharedLayout* sh = overlay_layout();
    if (!sh) return JNI_FALSE;
    switch (flag) {
        case 1: sh->header.autoplay.store(value, std::memory_order_release); return JNI_TRUE;
        case 2: sh->header.autoqueue.store(value, std::memory_order_release); return JNI_TRUE;
        case 3: sh->header.keep_line.store(value, std::memory_order_release); return JNI_TRUE;
        case 4: sh->header.show_lines.store(value, std::memory_order_release); return JNI_TRUE;
        case 5: sh->header.line_count.store(value, std::memory_order_release); return JNI_TRUE;
        case 6: sh->header.solve_rate_hz.store(value, std::memory_order_release); return JNI_TRUE;
        case 7: sh->header.profile.store(value, std::memory_order_release); return JNI_TRUE;
        default: return JNI_FALSE;
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeGetLine(
    JNIEnv* env, jclass, jint index, jfloatArray out)
{
    using namespace unoreverse;
    SharedLayout* sh = overlay_layout();
    if (!sh || !out) return JNI_FALSE;
    if (index < 0 || index >= MAX_LINES) return JNI_FALSE;

    jfloat buf[5];
    const Line& l = sh->lines[index];
    buf[0] = l.x0;
    buf[1] = l.y0;
    buf[2] = l.x1;
    buf[3] = l.y1;
    buf[4] = (jfloat)(int32_t)l.color;

    env->SetFloatArrayRegion(out, 0, 5, buf);
    return JNI_TRUE;
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeGetAimLine(JNIEnv* env, jclass) {
    jfloatArray arr = env->NewFloatArray(4);
    float line[4] = {0.f, 0.f, 0.f, 0.f};
    env->SetFloatArrayRegion(arr, 0, 4, line);
    return arr;
}

