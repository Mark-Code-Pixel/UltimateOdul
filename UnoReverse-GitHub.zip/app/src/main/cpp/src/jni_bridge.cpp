#include <jni.h>
#include <android/log.h>
#include "unoreverse.h"
#include "agent_loader.h"
#include "hooks.h"
#include "solver_pool.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "URNative", __VA_ARGS__)

extern "C" {

JNIEXPORT void JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeLoadAgent(JNIEnv*, jobject, jstring libDir) {
    const char* dir = nullptr;
    // load agent
    LOGI("nativeLoadAgent");
}

JNIEXPORT void JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeInstallHooks(JNIEnv*, jobject) {
    LOGI("nativeInstallHooks");
}

JNIEXPORT void JNICALL
Java_com_uno_reverse_nativebridge_NativeBridge_nativeSolverTick(JNIEnv*, jobject) {
    // one solver iteration
}

} // extern C
