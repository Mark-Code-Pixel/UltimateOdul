// Uno Reverse — shared memory channel implementation.
// Uses ashmem on Android. Falls back to POSIX shm if ashmem is absent.

#include "shared_mem.h"

#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>

#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#if defined(__ANDROID__)
  #include <sys/system_properties.h>
  #include <linux/ashmem.h>
  #include <sys/ioctl.h>
#endif

namespace unoreverse {

namespace {

std::mutex    g_lock;
int           g_fd      = -1;
SharedLayout* g_layout  = nullptr;
bool          g_owner   = false;

#if defined(__ANDROID__)
static int ashmem_create(const char* name, size_t size) {
    int fd = open("/dev/ashmem", O_RDWR | O_CLOEXEC);
    if (fd < 0) return -1;
    if (ioctl(fd, ASHMEM_SET_NAME, name) < 0) { close(fd); return -1; }
    if (ioctl(fd, ASHMEM_SET_SIZE, (unsigned long)size) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}
#endif

void init_header_defaults(SharedLayout* l) {
    if (!l) return;
    std::memset(&l->header, 0, sizeof(StateHeader));
    l->header.running.store(1, std::memory_order_release);
    l->header.line_count.store(16, std::memory_order_release);
    l->header.solve_rate_hz.store(30, std::memory_order_release);
    l->header.agent_pid.store((int32_t)getpid(), std::memory_order_release);
}

} // namespace

bool shared_mem_open(const char* name) {
    std::lock_guard<std::mutex> lk(g_lock);
    if (g_layout) return true;

    const size_t size = sizeof(SharedLayout);

#if defined(__ANDROID__)
    g_fd = ashmem_create(name, size);
    if (g_fd < 0) return false;
#else
    shm_unlink(name);
    g_fd = shm_open(name, O_CREAT | O_RDWR, 0600);
    if (g_fd < 0) return false;
    if (ftruncate(g_fd, size) != 0) { close(g_fd); g_fd = -1; return false; }
#endif

    void* p = mmap(nullptr, size, PROT_READ | PROT_WRITE, MAP_SHARED, g_fd, 0);
    if (p == MAP_FAILED) {
        close(g_fd);
        g_fd = -1;
        return false;
    }

    g_layout = (SharedLayout*)p;
    g_owner = true;
    init_header_defaults(g_layout);
    return true;
}

bool shared_mem_open_path(const std::string& path) {
    std::lock_guard<std::mutex> lk(g_lock);
    if (g_layout) return true;
    if (path.empty()) return false;

    const size_t size = sizeof(SharedLayout);

    int fd = open(path.c_str(), O_RDWR | O_CLOEXEC);
    if (fd < 0) return false;

    void* p = mmap(nullptr, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) {
        close(fd);
        return false;
    }

    g_fd = fd;
    g_layout = (SharedLayout*)p;
    g_owner = false;
    return true;
}

bool shared_mem_open_auto(const char* name) {
    // Path-first. This is the canonical route in Uno Reverse: the
    // container creates the region, writes its /proc path to a file,
    // and both the guest and the overlay open by that path.
    const char* path_env = getenv("UNOREVERSE_SHM_PATH");
    if (path_env && path_env[0] != '\0') {
        if (shared_mem_open_path(std::string(path_env))) {
            return true;
        }
    }

    // Inherited fd fallback for cases where the path is not available.
    const char* fd_env = getenv("UNOREVERSE_SHM_FD");
    if (fd_env && fd_env[0] != '\0') {
        int fd = atoi(fd_env);
        if (fd > 0) {
            std::lock_guard<std::mutex> lk(g_lock);
            if (g_layout) return true;
            void* p = mmap(nullptr, sizeof(SharedLayout),
                           PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
            if (p != MAP_FAILED) {
                g_fd = fd;
                g_layout = (SharedLayout*)p;
                g_owner = false;
                return true;
            }
        }
    }

    // No inherited region. Create one.
    return shared_mem_open(name ? name : "unoreverse_state");
}

void shared_mem_close() {
    std::lock_guard<std::mutex> lk(g_lock);
    if (g_layout) {
        munmap(g_layout, sizeof(SharedLayout));
        g_layout = nullptr;
    }
    if (g_fd >= 0) {
        close(g_fd);
        g_fd = -1;
    }
    g_owner = false;
}

SharedLayout* shared_mem_layout() {
    return g_layout;
}

void shared_mem_publish() {
    if (!g_layout) return;
    g_layout->header.seq.fetch_add(1, std::memory_order_release);
}

// ---- Command ring ---------------------------------------------------

bool shared_mem_push_command(CmdKind kind, int64_t arg) {
    if (!g_layout) return false;
    auto& h = g_layout->header;

    const uint32_t head = h.cmd_head.load(std::memory_order_relaxed);
    const uint32_t tail = h.cmd_tail.load(std::memory_order_acquire);

    if ((head - tail) >= (uint32_t)RING_CAPACITY) return false;

    auto& c = g_layout->commands[head % RING_CAPACITY];
    c.seq.store((int32_t)head, std::memory_order_relaxed);
    c.kind.store((int32_t)kind, std::memory_order_relaxed);
    c.arg.store(arg, std::memory_order_relaxed);
    c.ack.store(0, std::memory_order_relaxed);

    h.cmd_head.store(head + 1, std::memory_order_release);
    return true;
}

bool shared_mem_pop_command(Command* out) {
    if (!g_layout || !out) return false;
    auto& h = g_layout->header;

    const uint32_t tail = h.cmd_tail.load(std::memory_order_relaxed);
    const uint32_t head = h.cmd_head.load(std::memory_order_acquire);

    if (head == tail) return false;

    auto& c = g_layout->commands[tail % RING_CAPACITY];
    out->seq.store(c.seq.load(std::memory_order_relaxed), std::memory_order_relaxed);
    out->kind.store(c.kind.load(std::memory_order_relaxed), std::memory_order_relaxed);
    out->arg.store(c.arg.load(std::memory_order_relaxed), std::memory_order_relaxed);
    out->ack.store(0, std::memory_order_relaxed);

    h.cmd_tail.store(tail + 1, std::memory_order_release);
    return true;
}

// ---- Response ring --------------------------------------------------

bool shared_mem_push_response(int32_t code, int64_t value) {
    if (!g_layout) return false;
    auto& h = g_layout->header;

    const uint32_t head = h.rsp_head.load(std::memory_order_relaxed);
    const uint32_t tail = h.rsp_tail.load(std::memory_order_acquire);

    if ((head - tail) >= (uint32_t)RING_CAPACITY) return false;

    auto& r = g_layout->responses[head % RING_CAPACITY];
    r.seq.store((int32_t)head, std::memory_order_relaxed);
    r.code.store(code, std::memory_order_relaxed);
    r.value.store(value, std::memory_order_relaxed);

    h.rsp_head.store(head + 1, std::memory_order_release);
    return true;
}

bool shared_mem_pop_response(Response* out) {
    if (!g_layout || !out) return false;
    auto& h = g_layout->header;

    const uint32_t tail = h.rsp_tail.load(std::memory_order_relaxed);
    const uint32_t head = h.rsp_head.load(std::memory_order_acquire);

    if (head == tail) return false;

    auto& r = g_layout->responses[tail % RING_CAPACITY];
    out->seq.store(r.seq.load(std::memory_order_relaxed), std::memory_order_relaxed);
    out->code.store(r.code.load(std::memory_order_relaxed), std::memory_order_relaxed);
    out->value.store(r.value.load(std::memory_order_relaxed), std::memory_order_relaxed);

    h.rsp_tail.store(tail + 1, std::memory_order_release);
    return true;
}

std::string shared_mem_owner_path() {
    std::lock_guard<std::mutex> lk(g_lock);
    if (g_fd < 0) return "";
    char buf[128];
    snprintf(buf, sizeof(buf), "/proc/%d/fd/%d", getpid(), g_fd);
    return std::string(buf);
}

} // namespace unoreverse