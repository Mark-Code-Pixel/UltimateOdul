#include "shared_mem.h"
#include "unoreverse.h"
#include <sys/mman.h>
#include <cstdlib>
#include <cstring>
#include <new>
SharedState* shared_create() {
    void* p = mmap(nullptr, sizeof(SharedState), PROT_READ | PROT_WRITE,
                   MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) {
        p = std::calloc(1, sizeof(SharedState));
        if (!p) return nullptr;
        return new (p) SharedState();
    }
    std::memset(p, 0, sizeof(SharedState));
    return new (p) SharedState();
}
