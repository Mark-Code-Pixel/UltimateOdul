#include "shared_mem.h"
#include "unoreverse.h"
#include <sys/mman.h>
#include <linux/ashmem.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
SharedState* shared_create() {
    int fd = open("/dev/ashmem", O_RDWR);
    if (fd < 0) return nullptr;
    ioctl(fd, ASHMEM_SET_NAME, "unoreverse_state");
    ioctl(fd, ASHMEM_SET_SIZE, sizeof(SharedState));
    void* p = mmap(nullptr, sizeof(SharedState), PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);
    if (p == MAP_FAILED) return nullptr;
    return new (p) SharedState();
}
