// Uno Reverse — guest agent loader implementation.

#include "agent_loader.h"
#include "hook_backend.h"
#include "shared_mem.h"

#include <atomic>
#include <cstring>
#include <dlfcn.h>
#include <mutex>
#include <string>
#include <unistd.h>

#include <android/log.h>

#define LOG_TAG "UnoReverseLoader"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace unoreverse {

namespace {

std::mutex g_lock;
std::string g_dt_needed_agent;
std::atomic<bool> g_dt_needed_armed{false};
std::atomic<bool> g_loaded{false};

// Function the agent's constructor must expose so the loader can
// confirm the load. It is defined in agent.cpp.
typedef int (*AgentInitFn)(const char*, const char*);

constexpr const char* kAgentInitSymbol = "unoreverse_agent_init_from_loader";

bool try_dlopen(const std::string& path, std::string* detail) {
    void* handle = dlopen(path.c_str(), RTLD_NOW | RTLD_GLOBAL);
    if (!handle) {
        if (detail) *detail = dlerror() ? dlerror() : "dlopen returned null";
        return false;
    }
    // Verify the entry symbol exists.
    void* sym = dlsym(handle, kAgentInitSymbol);
    if (!sym) {
        if (detail) *detail = "agent init symbol not found";
        return false;
    }
    // Call it. The symbol takes (agent_dir, ashmem_name). The loader
    // passes empty strings — agent.cpp fills them from the environment.
    AgentInitFn init = (AgentInitFn)sym;
    init("", "");
    return true;
}

} // namespace

LoadReport agent_loader_load(const std::string& agent_path,
                             const std::string& guest_lib_dir,
                             const std::string& guest_pkg) {
    LoadReport report;
    report.agent_path = agent_path;

    if (agent_path.empty()) {
        report.result = LoadResult::LibraryNotFound;
        report.detail = "empty agent path";
        return report;
    }

    // If the agent is already loaded (constructor ran because of a
    // DT_NEEDED entry), there is nothing to do.
    if (g_loaded.load(std::memory_order_acquire)) {
        report.result = LoadResult::Success;
        report.method = "already_loaded";
        return report;
    }

    // ---- Path 1: DT_NEEDED (already handled by the linker) ---------
    {
        std::lock_guard<std::mutex> lk(g_lock);
        if (g_dt_needed_armed.load(std::memory_order_acquire)) {
            // The linker already loaded the agent when it loaded the
            // guest's primary library. Confirm the entry symbol exists
            // and call it if the constructor did not.
            void* handle = dlopen(agent_path.c_str(), RTLD_NOW | RTLD_NOLOAD);
            if (handle) {
                void* sym = dlsym(handle, kAgentInitSymbol);
                if (sym) {
                    AgentInitFn init = (AgentInitFn)sym;
                    init("", "");
                    dlclose(handle);
                    g_loaded.store(true, std::memory_order_release);
                    report.result = LoadResult::Success;
                    report.method = "dt_needed";
                    report.detail = "loaded by linker before guest libs";
                    return report;
                }
                dlclose(handle);
            }
        }
    }

    // ---- Path 2: preload via LD_LIBRARY_PATH -----------------------
    // The environment is set by GuestSpawner. We just attempt a
    // dlopen with the bare basename and let the linker search.
    {
        const char* basename = strrchr(agent_path.c_str(), '/');
        std::string short_name = basename ? (basename + 1) : agent_path;

        std::string detail;
        if (try_dlopen(short_name, &detail)) {
            g_loaded.store(true, std::memory_order_release);
            report.result = LoadResult::Success;
            report.method = "preload";
            report.detail = "loaded from LD_LIBRARY_PATH";
            return report;
        }
        report.detail = detail;
    }

    // ---- Path 3: direct absolute dlopen ----------------------------
    {
        std::string detail;
        if (try_dlopen(agent_path, &detail)) {
            g_loaded.store(true, std::memory_order_release);
            report.result = LoadResult::Success;
            report.method = "dlopen";
            report.detail = "loaded by absolute path";
            return report;
        }
        report.detail = detail;
    }

    report.result = LoadResult::DlopenFailed;
    LOGW("agent load failed for %s: %s", guest_pkg.c_str(), report.detail.c_str());
    return report;
}

void agent_loader_mark_dt_needed(const std::string& agent_basename) {
    std::lock_guard<std::mutex> lk(g_lock);
    g_dt_needed_agent = agent_basename;
    g_dt_needed_armed.store(true, std::memory_order_release);
    LOGI("DT_NEEDED armed for %s", agent_basename.c_str());
}

bool agent_loader_dt_needed_armed() {
    return g_dt_needed_armed.load(std::memory_order_acquire);
}

} // namespace unoreverse

// ---------------------------------------------------------------------
// C entry point the agent exports so the loader can find it.
// ---------------------------------------------------------------------

extern "C" int unoreverse_agent_init_from_loader(const char* agent_dir,
                                                 const char* ashmem_name) {
    // Delegate to the real init in agent.cpp.
    extern int unoreverse_agent_init(const char*, const char*);
    return unoreverse_agent_init(agent_dir, ashmem_name);
}