#include "agent_loader.h"
void agent_load(const char* libDir) {
    // DT_NEEDED patch or linker namespace
}
