// Uno Reverse — mini_hook implementation.

#include "mini_hook.h"

#include <atomic>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <unordered_map>
#include <vector>

#include <sys/mman.h>
#include <unistd.h>

#if defined(__aarch64__) || defined(__arm__)
  #include <sys/cachectl.h>
#endif

namespace unoreverse {

namespace {

constexpr size_t POOL_PAGE_SIZE  = 4096;
constexpr size_t POOL_MAX_PAGES  = 64;
constexpr size_t TRAMPOLINE_MAX  = 128;   // each trampoline fits in a page slot

struct HookEntry {
    void* target;
    void* trampoline;
    std::vector<uint8_t> saved_bytes; // original bytes overwritten
    bool  thumb;                      // ARM32 Thumb mode
};

std::mutex g_lock;
std::atomic<bool> g_initialized{false};
void* g_pool = nullptr;
size_t g_pool_used = 0;
std::unordered_map<void*, HookEntry> g_hooks;

// ---- Helpers --------------------------------------------------------

static size_t page_size() {
    static size_t ps = (size_t)sysconf(_SC_PAGESIZE);
    return ps == 0 ? 4096 : ps;
}

static void flush_icache(void* addr, size_t len) {
#if defined(__aarch64__)
    __builtin___clear_cache((char*)addr, (char*)addr + len);
#elif defined(__arm__)
    // On 32-bit ARM we need both the data cache flush and the instruction
    // cache invalidate. The builtin covers both on modern NDK.
    __builtin___clear_cache((char*)addr, (char*)addr + len);
#else
    __builtin___clear_cache((char*)addr, (char*)addr + len);
#endif
}

static bool make_writable(void* addr, size_t len, int* out_old_prot) {
    uintptr_t page = (uintptr_t)addr & ~(page_size() - 1);
    uintptr_t end  = ((uintptr_t)addr + len + page_size() - 1) & ~(page_size() - 1);
    // Read current protection
    // We do not have a portable way to read it, so we assume RX and set RWX.
    if (mprotect((void*)page, end - page, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
        return false;
    }
    if (out_old_prot) *out_old_prot = PROT_READ | PROT_EXEC;
    return true;
}

static void restore_prot(void* addr, size_t len, int prot) {
    uintptr_t page = (uintptr_t)addr & ~(page_size() - 1);
    uintptr_t end  = ((uintptr_t)addr + len + page_size() - 1) & ~(page_size() - 1);
    mprotect((void*)page, end - page, prot);
}

// Allocate executable memory from the pool.
static void* pool_alloc(size_t size) {
    size = (size + 15) & ~15ULL; // 16-byte align
    if (!g_pool) {
        g_pool = mmap(nullptr, POOL_PAGE_SIZE * POOL_MAX_PAGES,
                      PROT_READ | PROT_WRITE | PROT_EXEC,
                      MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (g_pool == MAP_FAILED) { g_pool = nullptr; return nullptr; }
        g_pool_used = 0;
    }
    if (g_pool_used + size > POOL_PAGE_SIZE * POOL_MAX_PAGES) return nullptr;
    void* p = (uint8_t*)g_pool + g_pool_used;
    g_pool_used += size;
    return p;
}

// ---- ARM64 ---------------------------------------------------------

#if defined(__aarch64__)

static bool install_arm64(void* target, void* handler,
                          HookEntry& entry) {
    // 16 bytes: LDR X17, #8 ; BR X17 ; <handler>
    // Encoding:
    //   LDR X17, #8   = 0x58000051
    //   BR  X17       = 0xD61F0220
    const uint32_t ldr_x17 = 0x58000051u;
    const uint32_t br_x17  = 0xD61F0220u;
    const size_t   patch_len = 16;

    // Save original bytes.
    entry.saved_bytes.assign((uint8_t*)target, (uint8_t*)target + patch_len);

    // Build the patch.
    uint8_t patch[patch_len];
    std::memcpy(patch,     &ldr_x17, 4);
    std::memcpy(patch + 4, &br_x17,  4);
    std::memcpy(patch + 8, &handler, sizeof(void*));

    // Build the trampoline: saved 16 bytes (4 instructions) + jump back.
    uint8_t* tramp = (uint8_t*)pool_alloc(TRAMPOLINE_MAX);
    if (!tramp) return false;

    std::memcpy(tramp, entry.saved_bytes.data(), patch_len);

    // Jump back to target + patch_len with another LDR/BR pair.
    uint8_t* back = tramp + patch_len;
    uint64_t ret_addr = (uint64_t)((uint8_t*)target + patch_len);
    std::memcpy(back,     &ldr_x17, 4);
    std::memcpy(back + 4, &br_x17,  4);
    std::memcpy(back + 8, &ret_addr, sizeof(uint64_t));

    flush_icache(tramp, patch_len + 16);

    // Patch the target.
    int old_prot = 0;
    if (!make_writable(target, patch_len, &old_prot)) return false;
    std::memcpy(target, patch, patch_len);
    flush_icache(target, patch_len);
    restore_prot(target, patch_len, old_prot);

    entry.target = target;
    entry.trampoline = tramp;
    entry.thumb = false;
    return true;
}

static bool uninstall_arm64(HookEntry& entry) {
    int old_prot = 0;
    if (!make_writable(entry.target, entry.saved_bytes.size(), &old_prot)) return false;
    std::memcpy(entry.target, entry.saved_bytes.data(), entry.saved_bytes.size());
    flush_icache(entry.target, entry.saved_bytes.size());
    restore_prot(entry.target, entry.saved_bytes.size(), old_prot);
    return true;
}

#endif // __aarch64__

// ---- ARM32 ---------------------------------------------------------

#if defined(__arm__)

// Detect ARM vs Thumb: on ARM32, bit 0 of the function pointer is the
// Thumb selector. In practice, we look at the target address.
static bool is_thumb(void* target) {
    return ((uintptr_t)target & 1) != 0;
}

static void* align_arm_target(void* target) {
    return (void*)((uintptr_t)target & ~1ULL);
}

static bool install_arm(void* target, void* handler, HookEntry& entry) {
    void* aligned = align_arm_target(target);
    const bool thumb = is_thumb(target);
    entry.thumb = thumb;

    if (thumb) {
        // 8 bytes: LDR.W PC, [PC, #0] ; <handler>
        // Encoding: 0xF8DF F000
        const uint32_t ldr_pc = 0xF8DFF000u;
        const size_t patch_len = 8;

        entry.saved_bytes.assign((uint8_t*)aligned,
                                 (uint8_t*)aligned + patch_len);

        // Trampoline: saved 8 bytes + jump back using the same pattern.
        uint8_t* tramp = (uint8_t*)pool_alloc(TRAMPOLINE_MAX);
        if (!tramp) return false;

        std::memcpy(tramp, entry.saved_bytes.data(), patch_len);
        uint8_t* back = tramp + patch_len;
        uint32_t ret = (uint32_t)((uint8_t*)aligned + patch_len) | 1u; // thumb bit
        std::memcpy(back,     &ldr_pc, 4);
        std::memcpy(back + 4, &ret,    4);

        flush_icache(tramp, patch_len + 8);

        uint8_t patch[patch_len];
        std::memcpy(patch,     &ldr_pc, 4);
        uint32_t h = (uint32_t)handler | 1u; // keep thumb bit
        std::memcpy(patch + 4, &h,      4);

        int old_prot = 0;
        if (!make_writable(aligned, patch_len, &old_prot)) return false;
        std::memcpy(aligned, patch, patch_len);
        flush_icache(aligned, patch_len);
        restore_prot(aligned, patch_len, old_prot);

        entry.target = aligned;
        entry.trampoline = (void*)((uintptr_t)tramp | 1u); // thumb
        return true;
    } else {
        // ARM mode: 8 bytes: LDR PC, [PC, #-4] ; <handler>
        // Encoding: 0xE51FF004
        const uint32_t ldr_pc = 0xE51FF004u;
        const size_t patch_len = 8;

        entry.saved_bytes.assign((uint8_t*)aligned,
                                 (uint8_t*)aligned + patch_len);

        uint8_t* tramp = (uint8_t*)pool_alloc(TRAMPOLINE_MAX);
        if (!tramp) return false;

        std::memcpy(tramp, entry.saved_bytes.data(), patch_len);
        uint8_t* back = tramp + patch_len;
        uint32_t ret = (uint32_t)((uint8_t*)aligned + patch_len);
        std::memcpy(back,     &ldr_pc, 4);
        std::memcpy(back + 4, &ret,    4);

        flush_icache(tramp, patch_len + 8);

        uint8_t patch[patch_len];
        std::memcpy(patch,     &ldr_pc, 4);
        uint32_t h = (uint32_t)handler;
        std::memcpy(patch + 4, &h,      4);

        int old_prot = 0;
        if (!make_writable(aligned, patch_len, &old_prot)) return false;
        std::memcpy(aligned, patch, patch_len);
        flush_icache(aligned, patch_len);
        restore_prot(aligned, patch_len, old_prot);

        entry.target = aligned;
        entry.trampoline = tramp;
        return true;
    }
}

static bool uninstall_arm(HookEntry& entry) {
    int old_prot = 0;
    if (!make_writable(entry.target, entry.saved_bytes.size(), &old_prot)) return false;
    std::memcpy(entry.target, entry.saved_bytes.data(), entry.saved_bytes.size());
    flush_icache(entry.target, entry.saved_bytes.size());
    restore_prot(entry.target, entry.saved_bytes.size(), old_prot);
    return true;
}

#endif // __arm__

} // namespace

// ---- Public API -----------------------------------------------------

bool mini_hook_init() {
    bool expected = false;
    if (!g_initialized.compare_exchange_strong(expected, true)) return true;

    // Pre-allocate the executable page pool so the first hook install
    // does not fail on a device with a hardened mmap policy.
    void* p = mmap(nullptr, POOL_PAGE_SIZE * POOL_MAX_PAGES,
                   PROT_READ | PROT_WRITE | PROT_EXEC,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) {
        g_initialized.store(false);
        return false;
    }
    g_pool = p;
    g_pool_used = 0;
    return true;
}

bool mini_hook_install(void* target, void* handler, void** out_original) {
    if (!mini_hook_init()) return false;
    if (!target || !handler || !out_original) return false;

    std::lock_guard<std::mutex> lk(g_lock);
    if (g_hooks.count(target)) return false;

    HookEntry entry{};
#if defined(__aarch64__)
    if (!install_arm64(target, handler, entry)) return false;
#elif defined(__arm__)
    if (!install_arm(target, handler, entry)) return false;
#else
    return false;
#endif

    *out_original = entry.trampoline;
    g_hooks[target] = entry;
    return true;
}

bool mini_hook_uninstall(void* target) {
    std::lock_guard<std::mutex> lk(g_lock);
    auto it = g_hooks.find(target);
    if (it == g_hooks.end()) return false;

#if defined(__aarch64__)
    if (!uninstall_arm64(it->second)) return false;
#elif defined(__arm__)
    if (!uninstall_arm(it->second)) return false;
#else
    return false;
#endif

    g_hooks.erase(it);
    return true;
}

void mini_hook_shutdown() {
    std::lock_guard<std::mutex> lk(g_lock);
    for (auto& kv : g_hooks) {
#if defined(__aarch64__)
        uninstall_arm64(kv.second);
#elif defined(__arm__)
        uninstall_arm(kv.second);
#endif
    }
    g_hooks.clear();
    if (g_pool) {
        munmap(g_pool, POOL_PAGE_SIZE * POOL_MAX_PAGES);
        g_pool = nullptr;
        g_pool_used = 0;
    }
    g_initialized.store(false);
}

} // namespace unoreverse