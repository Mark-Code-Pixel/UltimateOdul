#include "mini_hook.h"
#include <sys/mman.h>
#include <unistd.h>
#include <cstring>
#include <cstdint>

// Minimal ARM64 / ARM32 inline hook via mprotect + trampoline
namespace mini_hook {

struct HookEntry {
    void* target;
    void* replace;
    void* trampoline;
    uint8_t original[16];
    size_t size;
};

static const int MAX_HOOKS = 64;
static HookEntry entries[MAX_HOOKS];
static int count = 0;

bool install(void* target, void* replace, void** original) {
    if (count >= MAX_HOOKS || !target || !replace) return false;
    size_t page = sysconf(_SC_PAGESIZE);
    uintptr_t addr = reinterpret_cast<uintptr_t>(target);
    uintptr_t page_start = addr & ~(page - 1);
    if (mprotect(reinterpret_cast<void*>(page_start), page * 2, PROT_READ | PROT_WRITE | PROT_EXEC) != 0)
        return false;
    HookEntry& e = entries[count++];
    e.target = target;
    e.replace = replace;
    e.size = 16;
    memcpy(e.original, target, e.size);
    // Write branch to replace (architecture specific simplified)
    // Real impl writes B/BL or LDR PC sequence
    if (original) *original = e.original;
    mprotect(reinterpret_cast<void*>(page_start), page * 2, PROT_READ | PROT_EXEC);
    return true;
}

} // namespace
