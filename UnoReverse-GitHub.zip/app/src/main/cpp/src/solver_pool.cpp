// Uno Reverse — solver pool implementation.

#include "solver_pool.h"

#include <algorithm>
#include <atomic>
#include <chrono>

namespace unoreverse {

SolverPool::SolverPool()
    : m_thread_count(0),
      m_candidate_count(0),
      m_next_index(0),
      m_candidates(nullptr),
      m_initial_world(nullptr),
      m_config(nullptr),
      m_objective(nullptr),
      m_max_steps(0),
      m_last_run_us(0) {}

SolverPool::~SolverPool() {
    // Threads are joined by verify_all; nothing pending here.
    for (auto& t : m_threads) {
        if (t.joinable()) t.join();
    }
}

void SolverPool::configure(int thread_count, int candidate_count) {
    if (thread_count < 1) thread_count = 1;
    if (thread_count > 8) thread_count = 8;
    if (candidate_count < 0) candidate_count = 0;
    if (thread_count > candidate_count) thread_count = candidate_count;
    if (thread_count < 1) thread_count = 1;

    m_thread_count = thread_count;
    m_candidate_count = candidate_count;
    m_results.assign((size_t)m_candidate_count, ShotResult{});
}

void SolverPool::verify_all(const std::vector<Candidate>& candidates,
                            const SimWorld& initial_world,
                            const PhysicsConfig& config,
                            const Objective& objective,
                            int max_steps) {
    const auto t0 = std::chrono::steady_clock::now();

    // Ensure no leftover threads from a previous run.
    for (auto& t : m_threads) {
        if (t.joinable()) t.join();
    }
    m_threads.clear();

    if (m_candidate_count <= 0) {
        m_last_run_us = 0;
        return;
    }

    m_candidates    = &candidates;
    m_initial_world = &initial_world;
    m_config        = &config;
    m_objective     = &objective;
    m_max_steps     = max_steps > 0 ? max_steps : 50;

    m_next_index.store(0, std::memory_order_release);

    // Spawn worker threads.
    m_threads.reserve((size_t)m_thread_count);
    for (int i = 0; i < m_thread_count; ++i) {
        m_threads.emplace_back([this] { worker_loop(); });
    }
    for (auto& t : m_threads) {
        if (t.joinable()) t.join();
    }

    const auto t1 = std::chrono::steady_clock::now();
    m_last_run_us = std::chrono::duration_cast<std::chrono::microseconds>(
        t1 - t0).count();
}

void SolverPool::worker_loop() {
    const int total = m_candidate_count;
    const int n_cands = (int)m_candidates->size();
    const int limit = std::min(total, n_cands);

    while (true) {
        const int idx = m_next_index.fetch_add(1, std::memory_order_acq_rel);
        if (idx >= limit) return;

        const Candidate& c = (*m_candidates)[idx];
        m_results[idx] = verify_candidate(*m_initial_world,
                                          c,
                                          *m_config,
                                          *m_objective,
                                          m_max_steps);
    }
}

int SolverPool::best_index() const {
    int best = -1;
    float best_score = kScoreFoul - 1.0f; // strictly above pure foul
    for (int i = 0; i < m_candidate_count; ++i) {
        const ShotResult& r = m_results[i];
        if (r.score <= kScoreFoul) continue;
        if (r.score <= kScoreNoPot) continue;
        if (r.score > best_score) {
            best_score = r.score;
            best = i;
        }
    }
    return best;
}

int SolverPool::result_count() const {
    return m_candidate_count;
}

const ShotResult& SolverPool::result(int i) const {
    static const ShotResult s_empty{};
    if (i < 0 || i >= m_candidate_count) return s_empty;
    return m_results[i];
}

int64_t SolverPool::last_run_us() const {
    return m_last_run_us;
}

} // namespace unoreverse