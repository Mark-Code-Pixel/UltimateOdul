#include "solver_pool.h"
#include "candidate_builder.h"
#include "physics_sim.h"
#include "scorer.h"
Candidate solve_best(const BoardState* board, const PhysicsConfig* cfg) {
    Candidate cands[32];
    int n = build_candidates(board, cands, 32);
    Candidate best{}; best.score = -1e9f;
    for (int i = 0; i < n; i++) {
        auto step = simulate(board, cands[i].angle, cands[i].power, cfg);
        float s = score_result(&step);
        if (s > best.score) { best = cands[i]; best.score = s; }
    }
    return best;
}
