// Uno Reverse — simulator implementation.

#include "physics_sim.h"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace unoreverse {

namespace {

// Unity 2D's default position correction slop. Below this the overlap
// is left as-is; the game does the same so we match its residual state.
constexpr float kPosSlop = 0.005f;

// A body is considered stopped below this kinetic energy.
constexpr float kRestThreshold = 0.0005f;

// Fraction of the overlap resolved per iteration. 1.0 means full
// separation each pass. Non-negotiable at 1.0 for stack stability.
constexpr float kPosCorrection = 1.0f;

// ---- Impulse resolution between two dynamic bodies -----------------

inline void resolve_ball_ball(SimBody& a, SimBody& b, float restitution) {
    float dx = b.x - a.x;
    float dy = b.y - a.y;
    float r_sum = a.radius + b.radius;
    float dist2 = dx * dx + dy * dy;
    if (dist2 >= r_sum * r_sum) return;

    float dist = std::sqrt(dist2);
    float nx, ny;
    if (dist < 1e-6f) {
        // Perfectly coincident — pick an arbitrary normal.
        nx = 1.0f; ny = 0.0f;
        dist = 1e-6f;
    } else {
        nx = dx / dist;
        ny = dy / dist;
    }

    float total_inv = a.inv_mass + b.inv_mass;
    if (total_inv < 1e-9f) return;

    // Position correction.
    float overlap = r_sum - dist;
    float correction = std::max(overlap - kPosSlop, 0.0f) * kPosCorrection / total_inv;
    a.x -= nx * correction * a.inv_mass;
    a.y -= ny * correction * a.inv_mass;
    b.x += nx * correction * b.inv_mass;
    b.y += ny * correction * b.inv_mass;

    // Velocity impulse.
    float rvx = b.vx - a.vx;
    float rvy = b.vy - a.vy;
    float vn = rvx * nx + rvy * ny;
    if (vn > 0.0f) return;

    float j = -(1.0f + restitution) * vn / total_inv;
    a.vx -= j * nx * a.inv_mass;
    a.vy -= j * ny * a.inv_mass;
    b.vx += j * nx * b.inv_mass;
    b.vy += j * ny * b.inv_mass;
}

// ---- Cushion resolution --------------------------------------------
//
// The board is a rectangle from (0,0) to (W,H). A body in contact with
// a cushion has its center at radius from the wall. Velocity is flipped
// along the contact normal with restitution.

inline void resolve_cushion(SimBody& b, float W, float H, float e) {
    // Left wall.
    if (b.x < b.radius) {
        b.x = b.radius;
        if (b.vx < 0.0f) b.vx = -b.vx * e;
    } else if (b.x > W - b.radius) {
        b.x = W - b.radius;
        if (b.vx > 0.0f) b.vx = -b.vx * e;
    }
    if (b.y < b.radius) {
        b.y = b.radius;
        if (b.vy < 0.0f) b.vy = -b.vy * e;
    } else if (b.y > H - b.radius) {
        b.y = H - b.radius;
        if (b.vy > 0.0f) b.vy = -b.vy * e;
    }
}

// ---- Pocket detection ----------------------------------------------

inline bool in_pocket(const SimBody& b, const SimWorld& w) {
    const float r2 = w.pocket_capture_radius * w.pocket_capture_radius;
    for (int i = 0; i < 4; ++i) {
        float dx = b.x - w.pockets[i][0];
        float dy = b.y - w.pockets[i][1];
        if (dx * dx + dy * dy < r2) return true;
    }
    return false;
}

} // namespace

// ---------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------

void sim_init(SimWorld& w,
              const BoardSnapshot& board,
              const PhysicsConfig& config) {
    std::memset(&w, 0, sizeof(SimWorld));

    w.W = board.board_width;
    w.H = board.board_height;
    w.coin_count = board.coin_count;
    w.body_count = board.coin_count + 1;

    for (int i = 0; i < 4; ++i) {
        w.pockets[i][0] = board.pockets[i][0];
        w.pockets[i][1] = board.pockets[i][1];
    }

    // Pocket capture radius. A coin falls in when its center is within
    // this distance of the pocket center. Slightly larger than the
    // coin radius so a graze over the cup edge counts as a pot.
    w.pocket_capture_radius = board.coin_radius * 1.15f;

    w.gravity_x = config.gravity_x;
    w.gravity_y = config.gravity_y;
    w.fixed_dt  = config.fixed_dt > 0.0f ? config.fixed_dt : 0.016667f;
    w.solver_iterations = config.solver_iterations > 0
        ? config.solver_iterations
        : 8;
    w.restitution         = config.coin_restitution;
    w.friction            = config.coin_friction;
    w.cushion_restitution = config.cushion_restitution;
    w.cushion_friction    = config.cushion_friction;
    w.linear_drag         = config.linear_drag;
    w.angular_drag        = config.angular_drag;

    // Coins.
    for (int i = 0; i < board.coin_count; ++i) {
        SimBody& b = w.bodies[i];
        b.x = board.coins[i].x;
        b.y = board.coins[i].y;
        b.vx = board.coins[i].vx;
        b.vy = board.coins[i].vy;
        b.mass = config.coin_mass > 0.0f ? config.coin_mass : 1.0f;
        b.inv_mass = 1.0f / b.mass;
        b.radius = board.coin_radius;
        b.type = i;
        b.is_pocketed = board.coins[i].is_pocketed ? 1 : 0;
        w.initial_x[i] = b.x;
        w.initial_y[i] = b.y;
    }

    // Striker is the last body.
    SimBody& s = w.bodies[board.coin_count];
    s.x = board.striker_x;
    s.y = board.striker_y;
    s.vx = 0.0f;
    s.vy = 0.0f;
    s.mass = config.striker_mass > 0.0f ? config.striker_mass : 1.5f;
    s.inv_mass = 1.0f / s.mass;
    s.radius = board.striker_radius;
    s.type = -1;
    s.is_pocketed = 0;
    w.initial_x[board.coin_count] = s.x;
    w.initial_y[board.coin_count] = s.y;
}

void sim_apply_impulse(SimBody& striker, float angle_rad, float power,
                       float max_power) {
    if (striker.is_pocketed) return;
    if (max_power <= 0.0f) max_power = 1.0f;
    float p = power / max_power;
    if (p < 0.0f) p = 0.0f;
    if (p > 1.0f) p = 1.0f;
    // The exact impulse magnitude is game-tuned. A value of 20 body
    // lengths per second at full power is a reasonable default that we
    // refine per game once the pipeline records the observed striker
    // displacement after a max-power shot.
    const float base_speed = 20.0f;
    striker.vx = std::cos(angle_rad) * base_speed * p;
    striker.vy = std::sin(angle_rad) * base_speed * p;
}

void sim_step(SimWorld& w) {
    const float dt = w.fixed_dt;

    // ---- Integrate positions and velocities --------------------------
    const float drag_factor = 1.0f / (1.0f + w.linear_drag * dt);
    for (int i = 0; i < w.body_count; ++i) {
        SimBody& b = w.bodies[i];
        if (b.is_pocketed) continue;

        b.vx += w.gravity_x * dt;
        b.vy += w.gravity_y * dt;
        b.vx *= drag_factor;
        b.vy *= drag_factor;

        b.x += b.vx * dt;
        b.y += b.vy * dt;
    }

    // ---- Iterative collision resolution -----------------------------
    for (int iter = 0; iter < w.solver_iterations; ++iter) {
        for (int i = 0; i < w.body_count; ++i) {
            if (w.bodies[i].is_pocketed) continue;
            for (int j = i + 1; j < w.body_count; ++j) {
                if (w.bodies[j].is_pocketed) continue;
                resolve_ball_ball(w.bodies[i], w.bodies[j], w.restitution);
            }
        }
        for (int i = 0; i < w.body_count; ++i) {
            if (w.bodies[i].is_pocketed) continue;
            resolve_cushion(w.bodies[i], w.W, w.H, w.cushion_restitution);
        }
    }

    // ---- Pocket detection -------------------------------------------
    for (int i = 0; i < w.body_count; ++i) {
        SimBody& b = w.bodies[i];
        if (b.is_pocketed) continue;
        if (in_pocket(b, w)) {
            b.is_pocketed = 1;
            b.vx = 0.0f;
            b.vy = 0.0f;
        }
    }
}

float sim_kinetic_energy(const SimWorld& w) {
    float e = 0.0f;
    for (int i = 0; i < w.body_count; ++i) {
        const SimBody& b = w.bodies[i];
        if (b.is_pocketed) continue;
        e += 0.5f * b.mass * (b.vx * b.vx + b.vy * b.vy);
    }
    return e;
}

int sim_advance(SimWorld& w, int max_steps) {
    int steps = 0;
    while (steps < max_steps) {
        sim_step(w);
        ++steps;
        if (sim_kinetic_energy(w) < kRestThreshold) {
            // Extra guard: require two consecutive low-energy steps to
            // avoid stopping at the exact moment two bodies are about
            // to settle apart.
            sim_step(w);
            ++steps;
            if (sim_kinetic_energy(w) < kRestThreshold) break;
        }
    }
    return steps;
}

bool sim_striker_pocketed(const SimWorld& w) {
    if (w.body_count <= 0) return false;
    const SimBody& s = w.bodies[w.body_count - 1];
    return s.is_pocketed != 0;
}

bool sim_any_coin_moved(const SimWorld& w, float epsilon) {
    const float eps2 = epsilon * epsilon;
    for (int i = 0; i < w.coin_count; ++i) {
        const SimBody& b = w.bodies[i];
        float dx = b.x - w.initial_x[i];
        float dy = b.y - w.initial_y[i];
        if (dx * dx + dy * dy > eps2) return true;
        // Pocketed counts as moved even if the position has been
        // frozen at the pocket center.
        if (b.is_pocketed) return true;
    }
    return false;
}

int sim_count_pocketed_coins(const SimWorld& w) {
    int n = 0;
    for (int i = 0; i < w.coin_count; ++i) {
        if (w.bodies[i].is_pocketed) ++n;
    }
    return n;
}

SimBody* sim_find_striker(SimWorld& w) {
    if (w.body_count <= 0) return nullptr;
    return &w.bodies[w.body_count - 1];
}

const SimBody* sim_find_striker(const SimWorld& w) {
    if (w.body_count <= 0) return nullptr;
    return &w.bodies[w.body_count - 1];
}

const SimBody* sim_find_coin(const SimWorld& w, int coin_idx) {
    if (coin_idx < 0 || coin_idx >= w.coin_count) return nullptr;
    return &w.bodies[coin_idx];
}

} // namespace unoreverse