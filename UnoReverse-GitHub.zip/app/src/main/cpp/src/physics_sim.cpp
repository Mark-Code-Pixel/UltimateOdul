#include "physics_sim.h"
#include "unoreverse.h"
StepResult simulate(const BoardState* in, float angle, float power, const PhysicsConfig* cfg) {
    StepResult r{};
    if (in) r.state = *in;
    r.valid = 1; r.scratched = 0;
    return r;
}
