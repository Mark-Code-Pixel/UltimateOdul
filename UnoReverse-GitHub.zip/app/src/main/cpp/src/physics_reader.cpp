// Uno Reverse — live state reader implementation.

#include "physics_reader.h"
#include "il2cpp_reader.h"
#include "offsets_runtime.h"

#include <atomic>
#include <cstring>

namespace unoreverse {

namespace {

std::atomic<bool> g_ready{false};

// ---- IL2CPP container layout ---------------------------------------
//
// Every managed object begins with two pointer-sized header slots:
//   [klass] [monitor] [fields...]
//
// System.Collections.Generic.List<T> adds:
//   [_items (pointer)] [_size (int32) + pad]
//
// System array adds:
//   [bounds (pointer)] [max_length (pointer)] [elements...]
//
// All offsets below are derived from the pointer width of the build.

constexpr uint32_t kPtr        = UNOREVERSE_64 ? 8 : 4;
constexpr uint32_t kObjHeader  = kPtr * 2;

constexpr uint32_t kListItems  = kObjHeader;
constexpr uint32_t kListSize   = kObjHeader + kPtr;

constexpr uint32_t kArrayBounds = kObjHeader;
constexpr uint32_t kArrayMaxLen = kObjHeader + kPtr;
constexpr uint32_t kArrayElems  = kObjHeader + kPtr * 2;

// ---- Static pointer reader -----------------------------------------

inline void* read_singleton(uintptr_t slot_addr) {
    if (slot_addr == 0) return nullptr;
    return *reinterpret_cast<void**>(slot_addr);
}

// ---- Field reader ---------------------------------------------------

template <typename T>
inline T fread(void* obj, uint32_t offset) {
    return *reinterpret_cast<T*>(reinterpret_cast<uint8_t*>(obj) + offset);
}

inline bool is_null_ptr(void* p) {
    return p == nullptr || reinterpret_cast<uintptr_t>(p) < 0x1000;
}

// ---- Board read -----------------------------------------------------

bool read_coins(void* coin_list, BoardSnapshot& out) {
    if (is_null_ptr(coin_list)) return false;

    void* array = fread<void*>(coin_list, kListItems);
    int32_t count = fread<int32_t>(coin_list, kListSize);
    if (is_null_ptr(array)) return false;
    if (count <= 0) { out.coin_count = 0; return true; }
    if (count > MAX_COINS) count = MAX_COINS;

    const RuntimeOffsets& off = offsets_get();

    out.coin_count = count;
    for (int32_t i = 0; i < count; ++i) {
        void* coin = fread<void*>(array, kArrayElems + i * kPtr);
        if (is_null_ptr(coin)) {
            out.coins[i] = CoinState{};
            continue;
        }

        out.coins[i].x           = fread<float>(coin, off.off_coin_pos_x);
        out.coins[i].y           = fread<float>(coin, off.off_coin_pos_y);
        out.coins[i].vx          = fread<float>(coin, off.off_coin_vel_x);
        out.coins[i].vy          = fread<float>(coin, off.off_coin_vel_y);
        out.coins[i].mass        = fread<float>(coin, off.off_coin_mass);
        out.coins[i].friction    = fread<float>(coin, off.off_coin_friction);
        out.coins[i].type        = fread<int32_t>(coin, off.off_coin_type);
        out.coins[i].is_pocketed = fread<int32_t>(coin, off.off_coin_pocketed) ? 1 : 0;
        out.coins[i].padding     = 0;
    }
    return true;
}

void read_striker(void* striker, BoardSnapshot& out) {
    if (is_null_ptr(striker)) {
        out.striker_x = out.W * 0.5f;
        out.striker_y = 0.0f;
        return;
    }
    const RuntimeOffsets& off = offsets_get();
    out.striker_x = fread<float>(striker, off.off_striker_pos_x);
    out.striker_y = fread<float>(striker, off.off_striker_pos_y);
}

} // namespace

// ---------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------

bool physics_reader_init() {
    if (!offsets_ready()) return false;
    const RuntimeOffsets& off = offsets_get();
    if (off.static_coin_list == 0 || off.static_striker == 0) return false;

    // Verify the static slots actually resolve to non-null pointers now.
    // If the game has not reached its init phase yet, we retry later.
    void* coins = read_singleton(off.static_coin_list);
    void* striker = read_singleton(off.static_striker);
    if (is_null_ptr(coins) || is_null_ptr(striker)) {
        g_ready.store(false, std::memory_order_release);
        return false;
    }
    g_ready.store(true, std::memory_order_release);
    return true;
}

bool physics_reader_ready() {
    return g_ready.load(std::memory_order_acquire);
}

bool read_live_board(BoardSnapshot& out) {
    if (!physics_reader_ready()) return false;

    const RuntimeOffsets& off = offsets_get();

    std::memset(&out, 0, sizeof(out));
    out.W  = off.board_width;
    out.H = off.board_height;
    out.striker_radius = off.striker_radius;
    out.coin_radius    = off.coin_radius;
    std::memcpy(out.pockets, off.pocket_xy, sizeof(out.pockets));

    void* coin_list = read_singleton(off.static_coin_list);
    if (!read_coins(coin_list, out)) return false;

    void* striker = read_singleton(off.static_striker);
    read_striker(striker, out);

    return true;
}

bool read_live_physics(PhysicsConfig& out) {
    if (!physics_reader_ready()) return false;

    const RuntimeOffsets& off = offsets_get();
    void* physics = read_singleton(off.static_physics);
    if (is_null_ptr(physics)) return false;

    std::memset(&out, 0, sizeof(out));
    out.gravity_x           = fread<float>(physics, off.off_physics_gravity_x);
    out.gravity_y           = fread<float>(physics, off.off_physics_gravity_y);
    out.fixed_dt            = fread<float>(physics, off.off_physics_fixed_dt);
    out.solver_iterations   = fread<int32_t>(physics, off.off_physics_iterations);

    // Materials live behind pointers inside PhysicsManager. Read each
    // pointer, then pull restitution and friction.
    void* coin_mat = fread<void*>(physics, off.off_physics_coin_mat);
    if (!is_null_ptr(coin_mat)) {
        // The material struct layout: [bounciness][dynamicFriction]
        // 8 bytes each, consecutive.
        out.coin_restitution = fread<float>(coin_mat, kObjHeader);
        out.coin_friction    = fread<float>(coin_mat, kObjHeader + 4);
    } else {
        out.coin_restitution = 0.6f;
        out.coin_friction    = 0.4f;
    }

    void* cush_mat = fread<void*>(physics, off.off_physics_cush_mat);
    if (!is_null_ptr(cush_mat)) {
        out.cushion_restitution = fread<float>(cush_mat, kObjHeader);
        out.cushion_friction    = fread<float>(cush_mat, kObjHeader + 4);
    } else {
        out.cushion_restitution = 0.5f;
        out.cushion_friction    = 0.3f;
    }

    // Mass values come from the live objects, not the material. Fill from
    // the striker and a coin if available.
    out.striker_mass = 1.5f;
    out.coin_mass    = 1.0f;
    out.linear_drag  = 0.0f;
    out.angular_drag = 0.0f;
    out.max_power    = 1.0f;
    return true;
}

bool read_live_turn(int32_t& current_player, bool& is_my_turn, bool& animating) {
    if (!physics_reader_ready()) return false;

    const RuntimeOffsets& off = offsets_get();
    void* turn = read_singleton(off.static_turn);
    if (is_null_ptr(turn)) return false;

    current_player = fread<int32_t>(turn, off.off_turn_current);
    is_my_turn     = fread<int32_t>(turn, off.off_turn_is_mine) != 0;
    animating      = fread<int32_t>(turn, off.off_turn_animating) != 0;
    return true;
}

bool publish_snapshot() {
    SharedLayout* sh = shared_mem_layout();
    if (!sh) return false;
    if (!physics_reader_ready()) return false;

    BoardSnapshot board{};
    if (!read_live_board(board)) return false;

    PhysicsConfig cfg{};
    read_live_physics(cfg);  // best effort

    int32_t player = 0; bool mine = false, anim = false;
    if (!read_live_turn(player, mine, anim)) {
        // Turn state unavailable — clear the flags so nothing fires.
        mine = false;
        anim = true;
    }

    // Copy into shared memory. Only the solver thread writes board and
    // config; the shoot hook reads them. Use a release store on the
    // sequence counter to publish.
    std::memcpy(&sh->board, &board, sizeof(BoardSnapshot));
    std::memcpy(&sh->config, &cfg, sizeof(PhysicsConfig));

    // is_my_turn is authoritative only when the game is not animating.
    const bool can_play = mine && !anim;
    sh->header.is_my_turn.store(can_play ? 1 : 0, std::memory_order_release);

    // Publish.
    sh->header.seq.fetch_add(1, std::memory_order_release);
    return true;
}

} // namespace unoreverse