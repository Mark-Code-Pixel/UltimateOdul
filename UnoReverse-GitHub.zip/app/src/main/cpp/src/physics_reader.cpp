#include "physics_reader.h"
#include "unoreverse.h"
bool read_board(BoardState* out) {
    // read Rigidbody2D states via il2cpp offsets
    if (!out) return false;
    out->count = 0;
    return true;
}
