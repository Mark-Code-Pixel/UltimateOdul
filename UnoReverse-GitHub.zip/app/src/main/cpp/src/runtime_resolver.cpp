// Uno Reverse — runtime offset resolver.
//
// Runs inside the guest process once the IL2CPP runtime is up. Reads
// the metadata_report.json produced by the static pipeline, then uses
// the game's own IL2CPP API to resolve every named class, field, and
// method to a concrete byte offset or RVA.
//
// Writing the resolved offsets to offsets.json is what allows the
// native hook installer to find the shoot / set-turn / update methods
// and install inline hooks.
//
// The whole file is defensive: any missing export, any null return,
// any exception is caught and turned into a partial result. The
// caller decides whether the result is complete enough to proceed.
//
// A sibling file <output_path>.reason is always written with a short
// human-readable status. It is read by Kotlin when the JNI call
// returns a non-zero code.

#include "runtime_resolver.h"
#include "il2cpp_reader.h"
#include "offsets_runtime.h"

#include <android/log.h>
#include <cctype>
#include <cstring>
#include <dlfcn.h>
#include <fstream>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>

#define LOG_TAG "UnoReverseResolver"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace unoreverse {

namespace {

// ---- IL2CPP API signatures -----------------------------------------

using Il2CppDomain      = void;
using Il2CppAssembly    = void;
using Il2CppImage       = void;
using Il2CppClass       = void;
using Il2CppFieldInfo   = void;
using Il2CppMethodInfo  = void;

using FnDomainGet          = Il2CppDomain*    (*)();
using FnThreadAttach       = void*            (*)(Il2CppDomain*);
using FnDomainGetAssemblies= const Il2CppAssembly** (*)(const Il2CppDomain*, size_t*);
using FnAssemblyGetImage   = const Il2CppImage* (*)(const Il2CppAssembly*);
using FnImageGetName       = const char*      (*)(const Il2CppImage*);
using FnClassFromName      = Il2CppClass*     (*)(const Il2CppImage*, const char*, const char*);
using FnClassGetFieldFromName = Il2CppFieldInfo* (*)(Il2CppClass*, const char*);
using FnFieldGetOffset     = size_t           (*)(Il2CppFieldInfo*);
using FnClassGetMethodFromName = const Il2CppMethodInfo* (*)(Il2CppClass*, const char*, int);
using FnImageGetClassCount = size_t           (*)(const Il2CppImage*);
using FnImageGetClass      = Il2CppClass*     (*)(const Il2CppImage*, size_t);

struct Api {
    FnDomainGet               domain_get = nullptr;
    FnThreadAttach            thread_attach = nullptr;
    FnDomainGetAssemblies     domain_get_assemblies = nullptr;
    FnAssemblyGetImage        assembly_get_image = nullptr;
    FnImageGetName            image_get_name = nullptr;
    FnClassFromName           class_from_name = nullptr;
    FnClassGetFieldFromName   class_get_field_from_name = nullptr;
    FnFieldGetOffset          field_get_offset = nullptr;
    FnClassGetMethodFromName  class_get_method_from_name = nullptr;
    FnImageGetClassCount      image_get_class_count = nullptr;
    FnImageGetClass           image_get_class = nullptr;
    bool ready = false;
};

std::mutex g_api_mutex;
Api g_api;

bool load_api(const std::string& module_name) {
    uintptr_t base = find_module_base(module_name);
    if (base == 0) {
        LOGW("IL2CPP module %s not in /proc/self/maps", module_name.c_str());
        return false;
    }
    auto sym = [](const char* name) -> void* {
        return dlsym(RTLD_DEFAULT, name);
    };
    Api a;
    a.domain_get                    = (FnDomainGet)               sym("il2cpp_domain_get");
    a.thread_attach                 = (FnThreadAttach)            sym("il2cpp_thread_attach");
    a.domain_get_assemblies         = (FnDomainGetAssemblies)     sym("il2cpp_domain_get_assemblies");
    a.assembly_get_image            = (FnAssemblyGetImage)        sym("il2cpp_assembly_get_image");
    a.image_get_name                = (FnImageGetName)            sym("il2cpp_image_get_name");
    a.class_from_name               = (FnClassFromName)           sym("il2cpp_class_from_name");
    a.class_get_field_from_name     = (FnClassGetFieldFromName)   sym("il2cpp_class_get_field_from_name");
    a.field_get_offset              = (FnFieldGetOffset)          sym("il2cpp_field_get_offset");
    a.class_get_method_from_name    = (FnClassGetMethodFromName)  sym("il2cpp_class_get_method_from_name");
    a.image_get_class_count         = (FnImageGetClassCount)      sym("il2cpp_image_get_class_count");
    a.image_get_class               = (FnImageGetClass)           sym("il2cpp_image_get_class");

    if (!a.domain_get || !a.domain_get_assemblies || !a.assembly_get_image ||
        !a.class_from_name || !a.class_get_field_from_name ||
        !a.field_get_offset || !a.class_get_method_from_name) {
        LOGW("Missing required il2cpp exports");
        return false;
    }
    a.ready = true;

    std::lock_guard<std::mutex> lk(g_api_mutex);
    g_api = a;
    return true;
}

// MethodInfo::methodPointer is at offset 0 on both ARM32 and ARM64.
inline void* method_pointer(const Il2CppMethodInfo* method) {
    if (!method) return nullptr;
    return *reinterpret_cast<void* const*>(method);
}

// ---- JSON mini-parser ----------------------------------------------
//
// The metadata_report.json is small and controlled. A tiny parser is
// sufficient.

struct TargetSpec {
    std::string klass;
    std::string ns;
    std::vector<std::string> fields;
    std::vector<std::string> methods;
};

struct ReportSpec {
    std::string il2cpp_module;
    std::vector<TargetSpec> targets;
    bool ok = false;
};

std::string read_file_string(const std::string& path) {
    std::ifstream f(path);
    if (!f.is_open()) return "";
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

size_t seek_value(const std::string& s, const std::string& key, size_t from = 0) {
    const std::string needle = "\"" + key + "\"";
    size_t k = s.find(needle, from);
    if (k == std::string::npos) return std::string::npos;
    size_t colon = s.find(':', k + needle.size());
    if (colon == std::string::npos) return std::string::npos;
    size_t i = colon + 1;
    while (i < s.size() && std::isspace((unsigned char)s[i])) ++i;
    return i;
}

std::string read_json_string_at(const std::string& s, size_t i) {
    if (i >= s.size() || s[i] != '"') return "";
    size_t j = i + 1;
    while (j < s.size() && s[j] != '"') {
        if (s[j] == '\\' && j + 1 < s.size()) j += 2; else ++j;
    }
    return s.substr(i + 1, j - i - 1);
}

std::vector<std::string> read_json_array_of_strings(const std::string& s, size_t i) {
    std::vector<std::string> out;
    if (i >= s.size() || s[i] != '[') return out;
    size_t j = i + 1;
    while (j < s.size()) {
        while (j < s.size() && (std::isspace((unsigned char)s[j]) || s[j] == ',')) ++j;
        if (j >= s.size() || s[j] == ']') break;
        if (s[j] == '"') {
            std::string v = read_json_string_at(s, j);
            out.push_back(v);
            j += v.size() + 2;
        } else {
            ++j;
        }
    }
    return out;
}

ReportSpec parse_report(const std::string& json) {
    ReportSpec r;
    if (json.empty()) return r;

    size_t i = seek_value(json, "il2cpp_module");
    if (i == std::string::npos) return r;
    r.il2cpp_module = read_json_string_at(json, i);
    if (r.il2cpp_module.empty()) return r;

    size_t t = seek_value(json, "targets");
    if (t == std::string::npos) return r;
    if (t >= json.size() || json[t] != '[') return r;

    size_t p = t + 1;
    while (p < json.size()) {
        while (p < json.size() && (std::isspace((unsigned char)json[p]) || json[p] == ',')) ++p;
        if (p >= json.size() || json[p] == ']') break;
        if (json[p] == '{') {
            size_t obj_start = p;
            int depth = 1;
            ++p;
            while (p < json.size() && depth > 0) {
                if (json[p] == '{') ++depth;
                else if (json[p] == '}') --depth;
                ++p;
            }
            std::string obj = json.substr(obj_start, p - obj_start);

            TargetSpec spec;
            size_t c = seek_value(obj, "class");
            if (c == std::string::npos) continue;
            spec.klass = read_json_string_at(obj, c);

            size_t ns = seek_value(obj, "namespace");
            if (ns != std::string::npos) spec.ns = read_json_string_at(obj, ns);

            size_t f = seek_value(obj, "fields");
            if (f != std::string::npos) spec.fields = read_json_array_of_strings(obj, f);

            size_t m = seek_value(obj, "methods");
            if (m != std::string::npos) spec.methods = read_json_array_of_strings(obj, m);

            r.targets.push_back(std::move(spec));
        } else {
            ++p;
        }
    }
    r.ok = true;
    return r;
}

// ---- Resolution ----------------------------------------------------

Il2CppClass* find_class(const Api& a,
                        const std::string& ns,
                        const std::string& name,
                        std::string* out_image_name) {
    Il2CppDomain* dom = a.domain_get();
    if (!dom) return nullptr;
    if (a.thread_attach) a.thread_attach(dom);

    size_t count = 0;
    const Il2CppAssembly** asms = a.domain_get_assemblies(dom, &count);
    if (!asms) return nullptr;

    for (size_t i = 0; i < count; ++i) {
        const Il2CppImage* img = a.assembly_get_image(asms[i]);
        if (!img) continue;
        Il2CppClass* k = a.class_from_name(img, ns.c_str(), name.c_str());
        if (k) {
            if (out_image_name && a.image_get_name) {
                const char* n = a.image_get_name(img);
                if (n) *out_image_name = n;
            }
            return k;
        }
    }
    return nullptr;
}

// ---- Reason file helper --------------------------------------------

void write_reason_file(const std::string& output_path,
                       bool ok,
                       const std::string& reason) {
    std::ofstream r(output_path + ".reason", std::ios::trunc);
    if (!r.is_open()) return;
    if (ok) r << "ok\n";
    else if (reason.empty()) r << "resolution incomplete\n";
    else r << reason << "\n";
}

// ---- Write offsets.json --------------------------------------------

void write_offsets_json(const std::string& path,
                        const std::string& module,
                        const std::string& il2cpp_image,
                        const std::string& coin_class,
                        uint32_t off_coin_pos_x, uint32_t off_coin_pos_y,
                        uint32_t off_coin_vel_x, uint32_t off_coin_vel_y,
                        uint32_t off_coin_mass, uint32_t off_coin_friction,
                        uint32_t off_coin_type, uint32_t off_coin_pocketed,
                        const std::string& striker_class,
                        uint32_t off_striker_pos_x, uint32_t off_striker_pos_y,
                        uint32_t off_striker_rb,
                        uint32_t off_striker_aim_x, uint32_t off_striker_aim_y,
                        const std::string& turn_class,
                        uint32_t off_turn_current, uint32_t off_turn_is_mine,
                        uint32_t off_turn_animating,
                        const std::string& physics_class,
                        uint32_t off_physics_gravity_x, uint32_t off_physics_gravity_y,
                        uint32_t off_physics_fixed_dt, uint32_t off_physics_iterations,
                        uint64_t rva_shoot, uint64_t rva_set_turn, uint64_t rva_update,
                        uint64_t static_coin_list, uint64_t static_striker,
                        uint64_t static_physics, uint64_t static_turn,
                        uint64_t static_board) {
    std::ofstream f(path, std::ios::trunc);
    if (!f.is_open()) return;

    f << "{\n";
    f << "  \"il2cpp_module\": \"" << module << "\",\n";
    f << "  \"il2cpp_image\": \""  << il2cpp_image << "\",\n";

    f << "  \"coin_class\": \""    << coin_class << "\",\n";
    f << "  \"off_coin_pos_x\": "  << off_coin_pos_x << ",\n";
    f << "  \"off_coin_pos_y\": "  << off_coin_pos_y << ",\n";
    f << "  \"off_coin_vel_x\": "  << off_coin_vel_x << ",\n";
    f << "  \"off_coin_vel_y\": "  << off_coin_vel_y << ",\n";
    f << "  \"off_coin_mass\": "   << off_coin_mass << ",\n";
    f << "  \"off_coin_friction\": " << off_coin_friction << ",\n";
    f << "  \"off_coin_type\": "   << off_coin_type << ",\n";
    f << "  \"off_coin_pocketed\": " << off_coin_pocketed << ",\n";

    f << "  \"striker_class\": \""    << striker_class << "\",\n";
    f << "  \"off_striker_pos_x\": "  << off_striker_pos_x << ",\n";
    f << "  \"off_striker_pos_y\": "  << off_striker_pos_y << ",\n";
    f << "  \"off_striker_rb\": "     << off_striker_rb << ",\n";
    f << "  \"off_striker_aim_x\": "  << off_striker_aim_x << ",\n";
    f << "  \"off_striker_aim_y\": "  << off_striker_aim_y << ",\n";

    f << "  \"turn_class\": \""       << turn_class << "\",\n";
    f << "  \"off_turn_current\": "   << off_turn_current << ",\n";
    f << "  \"off_turn_is_mine\": "   << off_turn_is_mine << ",\n";
    f << "  \"off_turn_animating\": " << off_turn_animating << ",\n";

    f << "  \"physics_class\": \""          << physics_class << "\",\n";
    f << "  \"off_physics_gravity_x\": "    << off_physics_gravity_x << ",\n";
    f << "  \"off_physics_gravity_y\": "    << off_physics_gravity_y << ",\n";
    f << "  \"off_physics_fixed_dt\": "     << off_physics_fixed_dt << ",\n";
    f << "  \"off_physics_iterations\": "   << off_physics_iterations << ",\n";

    f << "  \"rva_shoot\": "    << rva_shoot << ",\n";
    f << "  \"rva_set_turn\": " << rva_set_turn << ",\n";
    f << "  \"rva_update\": "   << rva_update << ",\n";

    f << "  \"static_coin_list\": " << static_coin_list << ",\n";
    f << "  \"static_striker\": "   << static_striker << ",\n";
    f << "  \"static_physics\": "   << static_physics << ",\n";
    f << "  \"static_turn\": "      << static_turn << ",\n";
    f << "  \"static_board\": "     << static_board << "\n";
    f << "}\n";
}

} // namespace

// ---------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------

bool runtime_resolve_offsets(const std::string& metadata_report_path,
                             const std::string& output_path,
                             std::string* out_reason) {
    if (out_reason) out_reason->clear();

    const std::string json = read_file_string(metadata_report_path);
    if (json.empty()) {
        if (out_reason) *out_reason = "metadata_report.json empty or missing";
        write_reason_file(output_path, false, out_reason ? *out_reason : "");
        return false;
    }

    ReportSpec spec = parse_report(json);
    if (!spec.ok || spec.il2cpp_module.empty()) {
        if (out_reason) *out_reason = "metadata_report.json malformed";
        write_reason_file(output_path, false, out_reason ? *out_reason : "");
        return false;
    }

    if (!load_api(spec.il2cpp_module)) {
        if (out_reason) *out_reason = "il2cpp API not resolvable";
        write_reason_file(output_path, false, out_reason ? *out_reason : "");
        return false;
    }

    Api a;
    {
        std::lock_guard<std::mutex> lk(g_api_mutex);
        a = g_api;
    }
    if (!a.ready) {
        if (out_reason) *out_reason = "il2cpp API not ready";
        write_reason_file(output_path, false, out_reason ? *out_reason : "");
        return false;
    }

    // ---- Resolve every target class --------------------------------
    std::string coin_class, striker_class, turn_class, physics_class;
    std::string il2cpp_image;

    uint32_t off_coin_pos_x = 0, off_coin_pos_y = 0;
    uint32_t off_coin_vel_x = 0, off_coin_vel_y = 0;
    uint32_t off_coin_mass = 0, off_coin_friction = 0;
    uint32_t off_coin_type = 0, off_coin_pocketed = 0;

    uint32_t off_striker_pos_x = 0, off_striker_pos_y = 0;
    uint32_t off_striker_rb = 0;
    uint32_t off_striker_aim_x = 0, off_striker_aim_y = 0;

    uint32_t off_turn_current = 0, off_turn_is_mine = 0, off_turn_animating = 0;

    uint32_t off_physics_gravity_x = 0, off_physics_gravity_y = 0;
    uint32_t off_physics_fixed_dt = 0, off_physics_iterations = 0;

    uint64_t rva_shoot = 0, rva_set_turn = 0, rva_update = 0;

    for (const auto& t : spec.targets) {
        std::string image_name;
        Il2CppClass* klass = find_class(a, t.ns, t.klass, &image_name);
        if (!klass) continue;
        if (il2cpp_image.empty()) il2cpp_image = image_name;

        auto field_offset = [&](const char* name) -> uint32_t {
            Il2CppFieldInfo* f = a.class_get_field_from_name(klass, name);
            if (!f) return 0;
            return (uint32_t)a.field_get_offset(f);
        };

        if (off_coin_pos_x == 0) {
            uint32_t px = field_offset("position");
            if (!px) px = field_offset("Position");
            if (px) {
                off_coin_pos_x = px;
                off_coin_pos_y = px + 4;
                off_coin_vel_x = field_offset("velocity");
                if (!off_coin_vel_x) off_coin_vel_x = field_offset("Velocity");
                off_coin_vel_y = off_coin_vel_x + 4;
                off_coin_mass = field_offset("mass");
                if (!off_coin_mass) off_coin_mass = field_offset("Mass");
                off_coin_friction = field_offset("friction");
                if (!off_coin_friction) off_coin_friction = field_offset("Friction");
                off_coin_type = field_offset("type");
                if (!off_coin_type) off_coin_type = field_offset("Type");
                off_coin_pocketed = field_offset("isPocketed");
                if (!off_coin_pocketed) off_coin_pocketed = field_offset("pocketed");
                if (!off_coin_pocketed) off_coin_pocketed = field_offset("Pocketed");
                coin_class = t.klass;
                continue;
            }
        }

        if (off_striker_pos_x == 0) {
            uint32_t sx = field_offset("position");
            if (!sx) sx = field_offset("Position");
            uint32_t rb = field_offset("rigidbody");
            if (!rb) rb = field_offset("rb");
            if (!rb) rb = field_offset("Rigidbody");
            if (sx && rb) {
                off_striker_pos_x = sx;
                off_striker_pos_y = sx + 4;
                off_striker_rb = rb;
                off_striker_aim_x = field_offset("aimDirection");
                if (!off_striker_aim_x) off_striker_aim_x = field_offset("aim");
                if (!off_striker_aim_x) off_striker_aim_x = field_offset("AimDirection");
                off_striker_aim_y = off_striker_aim_x + 4;
                striker_class = t.klass;
                continue;
            }
        }

        if (off_turn_is_mine == 0) {
            uint32_t mine = field_offset("isMyTurn");
            if (!mine) mine = field_offset("isMine");
            if (!mine) mine = field_offset("IsMyTurn");
            uint32_t cur = field_offset("currentPlayer");
            if (!cur) cur = field_offset("turn");
            if (!cur) cur = field_offset("CurrentPlayer");
            if (mine || cur) {
                off_turn_current = cur;
                off_turn_is_mine = mine;
                off_turn_animating = field_offset("isAnimating");
                if (!off_turn_animating) off_turn_animating = field_offset("animating");
                if (!off_turn_animating) off_turn_animating = field_offset("IsAnimating");
                turn_class = t.klass;
                continue;
            }
        }

        if (off_physics_gravity_x == 0) {
            uint32_t g = field_offset("gravity");
            if (!g) g = field_offset("Gravity");
            uint32_t dt = field_offset("fixedDeltaTime");
            if (!dt) dt = field_offset("fixedTimestep");
            if (!dt) dt = field_offset("FixedDeltaTime");
            if (g || dt) {
                off_physics_gravity_x = g;
                off_physics_gravity_y = g + 4;
                off_physics_fixed_dt = dt;
                off_physics_iterations = field_offset("solverIterations");
                if (!off_physics_iterations) off_physics_iterations = field_offset("SolverIterations");
                physics_class = t.klass;
                continue;
            }
        }
    }

    // ---- Resolve method RVAs --------------------------------------
    uintptr_t module_base = find_module_base(spec.il2cpp_module);

    auto try_method = [&](const std::string& klass_name,
                          const std::string& ns,
                          const char* method,
                          int param_count,
                          uint64_t* out_rva) -> bool {
        if (klass_name.empty()) return false;
        std::string dummy;
        Il2CppClass* klass = find_class(a, ns, klass_name, &dummy);
        if (!klass) return false;
        const Il2CppMethodInfo* m = a.class_get_method_from_name(klass, method, param_count);
        if (!m) return false;
        void* ptr = method_pointer(m);
        if (!ptr) return false;
        uintptr_t addr = (uintptr_t)ptr;
        if (module_base != 0 && addr < module_base) return false;
        *out_rva = (module_base == 0) ? (uint64_t)addr : (addr - module_base);
        return true;
    };

    const std::string coin_ns = spec.targets.empty() ? "" : spec.targets[0].ns;

    if (!coin_class.empty()) {
        try_method(coin_class, coin_ns, "Shoot", 2, &rva_shoot) ||
        try_method(coin_class, "", "Shoot", 2, &rva_shoot) ||
        try_method(coin_class, "", "ShootStriker", 2, &rva_shoot) ||
        try_method(coin_class, "", "Fire", 2, &rva_shoot);
    }
    if (!turn_class.empty()) {
        try_method(turn_class, "", "SetTurn", 1, &rva_set_turn) ||
        try_method(turn_class, "", "set_IsMyTurn", 1, &rva_set_turn) ||
        try_method(turn_class, "", "SetCurrentPlayer", 1, &rva_set_turn);
    }
    if (!physics_class.empty()) {
        try_method(physics_class, "", "Update", 0, &rva_update) ||
        try_method(physics_class, "", "FixedUpdate", 0, &rva_update);
    }

    // Static pointer slots are not resolvable through the IL2CPP C API
    // in a version-stable way. They are left at zero here; the physics
    // reader treats zero as "not yet available" and stays dormant for
    // that singleton without crashing.
    const uint64_t static_coin_list = 0;
    const uint64_t static_striker   = 0;
    const uint64_t static_physics   = 0;
    const uint64_t static_turn      = 0;
    const uint64_t static_board     = 0;

    // ---- Write the offsets file -----------------------------------
    write_offsets_json(output_path,
                       spec.il2cpp_module, il2cpp_image,
                       coin_class,
                       off_coin_pos_x, off_coin_pos_y,
                       off_coin_vel_x, off_coin_vel_y,
                       off_coin_mass, off_coin_friction,
                       off_coin_type, off_coin_pocketed,
                       striker_class,
                       off_striker_pos_x, off_striker_pos_y,
                       off_striker_rb,
                       off_striker_aim_x, off_striker_aim_y,
                       turn_class,
                       off_turn_current, off_turn_is_mine, off_turn_animating,
                       physics_class,
                       off_physics_gravity_x, off_physics_gravity_y,
                       off_physics_fixed_dt, off_physics_iterations,
                       rva_shoot, rva_set_turn, rva_update,
                       static_coin_list, static_striker,
                       static_physics, static_turn, static_board);

    const bool ok = !coin_class.empty() &&
                    (rva_shoot != 0 || rva_set_turn != 0 || rva_update != 0);

    if (!ok && out_reason) {
        if (coin_class.empty()) *out_reason = "coin class not resolved";
        else *out_reason = "no method RVAs resolved";
    }

    write_reason_file(output_path, ok, out_reason ? *out_reason : "");
    return ok;
}

} // namespace unoreverse

// ---- C entry point --------------------------------------------------

extern "C" int unoreverse_runtime_resolve(const char* report_path,
                                          const char* output_path,
                                          char* reason_buf,
                                          int reason_buf_len) {
    std::string reason;
    bool ok = unoreverse::runtime_resolve_offsets(report_path, output_path, &reason);
    if (!ok && reason_buf && reason_buf_len > 0) {
        int n = (int)reason.size();
        if (n >= reason_buf_len) n = reason_buf_len - 1;
        std::memcpy(reason_buf, reason.data(), n);
        reason_buf[n] = '\0';
    }
    return ok ? 0 : -1;
}