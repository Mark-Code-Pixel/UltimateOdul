#include "il2cpp_reader.h"
#include <sys/uio.h>
uintptr_t find_module_base(const char* name) {
    // parse /proc/self/maps
    return 0;
}
bool read_mem(uintptr_t addr, void* buf, size_t len) {
    // process_vm_readv
    return false;
}
