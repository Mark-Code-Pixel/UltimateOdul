// Uno Reverse — module base discovery.

#include "il2cpp_reader.h"

#include <chrono>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <thread>

namespace unoreverse {

uintptr_t find_module_base(const std::string& module_name) {
    if (module_name.empty()) return 0;

    std::ifstream maps("/proc/self/maps");
    if (!maps.is_open()) return 0;

    std::string line;
    const std::string needle = "/" + module_name;

    while (std::getline(maps, line)) {
        // Match on the basename at the end of a path.
        if (line.find(needle) == std::string::npos) continue;

        // Accept only executable mappings — the first exec segment is the
        // module base the loader used.
        // Format: start-end perms offset dev inode pathname
        uintptr_t start = 0, end = 0;
        char perms[8] = {0};
        if (sscanf(line.c_str(), "%lx-%lx %7s", &start, &end, perms) != 3) continue;
        if (perms[2] != 'x') continue;

        return start;
    }
    return 0;
}

uintptr_t wait_for_module(const std::string& module_name, int timeout_ms) {
    using clock = std::chrono::steady_clock;
    const auto deadline = clock::now() + std::chrono::milliseconds(timeout_ms);
    while (clock::now() < deadline) {
        uintptr_t base = find_module_base(module_name);
        if (base != 0) return base;
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    return 0;
}

} // namespace unoreverse