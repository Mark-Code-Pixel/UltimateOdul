// Uno Reverse — scoring implementation.

#include "score.h"

#include <algorithm>
#include <cstring>

namespace unoreverse {

ShotResult score_shot(const SimWorld& initial_world,
                      const SimWorld& settled_world,
                      const Candidate& c,
                      const Objective& obj,
                      int steps_taken) {
    ShotResult r{};
    r.score = 0.0f;
    r.steps_taken = steps_taken;
    r.settle_time_s = steps_taken * initial_world.fixed_dt;
    r.pocketed_count = 0;
    r.scratched = false;
    r.missed = false;
    r.potted_target = false;

    // ---- Hard foul 1: striker pocketed -------------------------------
    r.scratched = sim_striker_pocketed(settled_world);
    if (r.scratched && obj.scratch_is_foul) {
        r.score = kScoreFoul;
        return r;
    }

    // ---- Hard foul 2: no coin touched --------------------------------
    r.missed = !sim_any_coin_moved(settled_world);
    if (r.missed && obj.miss_is_foul) {
        r.score = kScoreFoul;
        return r;
    }

    // ---- Count potted coins ------------------------------------------
    for (int i = 0; i < initial_world.coin_count; ++i) {
        const SimBody& was = initial_world.bodies[i];
        const SimBody& now = settled_world.bodies[i];
        if (was.is_pocketed) continue;    // already off the board
        if (!now.is_pocketed) continue;

        r.pocketed_count++;

        // Target-type check uses the original coin type, which lives on
        // the initial world's type field.
        const CoinState& src = settled_world.bodies[i].type < 0
            ? reinterpret_cast<const CoinState&>(settled_world.bodies[i])
            : reinterpret_cast<const CoinState&>(settled_world.bodies[i]);
        (void)src;

        uint32_t type = (uint32_t)settled_world.bodies[i].type;
        if (obj.target_type_mask == 0 ||
            (obj.target_type_mask & (1u << (type & 31))) != 0) {
            r.potted_target = true;
        }
    }

    if (r.pocketed_count == 0) {
        r.score = kScoreNoPot;
        return r;
    }

    // ---- Base score --------------------------------------------------
    float s = kScoreBase * (float)r.pocketed_count;

    // Bonus for target-type coins.
    if (r.potted_target) s += 500.0f;

    // Penalties.
    s -= (float)c.bounce_count * 50.0f;
    s -= c.path_length * 0.1f;
    s -= r.settle_time_s * 5.0f;

    // Bonus for harder shots.
    if (c.bounce_count >= 2) s += 200.0f;
    if (c.cut_angle > 0.7f)  s += 50.0f;   // 40+ degree cut

    // Required pocket constraint.
    if (obj.required_pocket >= 0 && c.pocket_idx != obj.required_pocket) {
        s -= 500.0f;
    }

    r.score = s;
    return r;
}

ShotResult verify_candidate(const SimWorld& initial_world,
                            const Candidate& c,
                            const PhysicsConfig& config,
                            const Objective& obj,
                            int max_steps) {
    // Copy the world — everything lives on the stack. No heap.
    SimWorld world = initial_world;

    SimBody* striker = sim_find_striker(world);
    if (!striker) {
        ShotResult r{};
        r.score = kScoreFoul;
        return r;
    }

    sim_apply_impulse(*striker, c.angle, 1.0f /* full power */,
                      config.max_power > 0.0f ? config.max_power : 1.0f);

    int steps = sim_advance(world, max_steps);

    return score_shot(initial_world, world, c, obj, steps);
}

} // namespace unoreverse