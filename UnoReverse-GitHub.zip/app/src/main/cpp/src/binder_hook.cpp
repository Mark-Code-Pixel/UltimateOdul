#include "binder_hook.h"
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "BinderHook", __VA_ARGS__)
void binder_hook_install() {
    // ioctl hook on BINDER_WRITE_READ would go here
    LOGI("binder_hook ready");
}
