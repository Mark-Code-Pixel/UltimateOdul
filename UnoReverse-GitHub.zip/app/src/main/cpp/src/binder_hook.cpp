// Uno Reverse — Binder ioctl hook implementation.
//
// The hook rewrites specific Binder transactions by mutating the
// Parcel data buffer in place. The write path is:
//
//   guest app
//     -> libbinder.so
//       -> ioctl(/dev/binder, BINDER_WRITE_READ, &bwr)
//         -> [our hook inspects bwr.write_buffer and bwr.read_buffer]
//           -> real ioctl
//
// We only rewrite two transaction codes:
//
//   GET_CALLING_UID_TRANSACTION (0x00000002)
//     The reply parcel carries a single int32. We overwrite it with the
//     guest's original UID.
//
//   GET_INSTALLED_PACKAGES_TRANSACTION
//     The reply is a ParceledListSlice. We do not parse it in the
//     native hook — package filtering is done at the Java layer where
//     the list is a plain List. The native hook only handles UID
//     spoofing.
//
// Everything else passes through.

#include "binder_hook.h"
#include "hook_backend.h"

#include <android/log.h>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <dlfcn.h>
#include <mutex>
#include <string>
#include <sys/ioctl.h>

#define LOG_TAG "UnoReverseBinder"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ---- Binder protocol constants -------------------------------------
//
// These are from linux/android/binder.h. They are stable across every
// Android version the container supports.

#define BINDER_WRITE_READ 0xC0186201

#define BC_TRANSACTION    0x40406300
#define BC_REPLY          0x40406301
#define BR_TRANSACTION    0x80407202
#define BR_REPLY          0x80407203

#define TF_ONE_WAY        0x01

// The transaction code that returns the caller's UID.
#define GET_CALLING_UID_TRANSACTION 0x00000002

namespace unoreverse {

namespace {

std::mutex g_lock;
bool g_installed = false;
bool g_layout_ok = false;
int  g_guest_uid = 0;
std::string g_guest_pkg;
std::string g_container_pkg;

typedef int (*IoctlFn)(int, unsigned long, ...);
static IoctlFn g_orig_ioctl = nullptr;

std::atomic<uint64_t> g_seen{0};
std::atomic<uint64_t> g_uid_rewrites{0};
std::atomic<uint64_t> g_pkg_filters{0};
std::atomic<uint64_t> g_layout_skips{0};

// ---- Binder structs ------------------------------------------------
//
// The kernel's binder_write_read. Fixed layout on both ABIs.
struct BinderWriteRead {
    int64_t  write_size;
    int64_t  write_consumed;
    uint64_t write_buffer;
    int64_t  read_size;
    int64_t  read_consumed;
    uint64_t read_buffer;
};

// binder_transaction_data. The layout is identical between 32-bit and
// 64-bit except for the pointer size in the target union, which we do
// not touch. Everything we read is fixed-width.
struct BinderTransactionData {
    uint32_t target_handle;    // union { handle, ptr }
    uint32_t target_ptr_pad;
    uint32_t cookie;
    uint32_t code;
    uint32_t flags;
    int32_t  sender_pid;
    uint32_t sender_euid;
    uint64_t data_size;
    uint64_t offsets_size;
    uint64_t data_ptr;
    uint64_t offsets_ptr;
};

// Where the parcel payload starts inside the transaction buffer.
constexpr size_t kTransactionHeaderSize =
    sizeof(uint32_t) * 3 + // cmd + size + target handle/ptr
    sizeof(uint32_t) +     // cookie
    sizeof(uint32_t) +     // code
    sizeof(uint32_t) +     // flags
    sizeof(int32_t) +      // sender_pid
    sizeof(uint32_t) +     // sender_euid
    sizeof(uint64_t) * 2 + // data_size + offsets_size
    sizeof(uint64_t) * 2;  // data + offsets

// ---- Layout probe --------------------------------------------------

bool probe_layout() {
    // We verify the struct size is what the kernel expects. If a future
    // Android changes the layout, this check fails and the hook becomes
    // a no-op. Better to pass everything through than to corrupt
    // transactions.
    if (sizeof(BinderTransactionData) != 0x38) {
        LOGW("binder_transaction_data size %zu not 0x38; hook disabled",
             sizeof(BinderTransactionData));
        return false;
    }
    if (sizeof(BinderWriteRead) != 0x30) {
        LOGW("binder_write_read size %zu not 0x30; hook disabled",
             sizeof(BinderWriteRead));
        return false;
    }
    return true;
}

// ---- Reply rewrite -------------------------------------------------

// The reply buffer format is:
//   [cmd (BC_REPLY)] [binder_transaction_data] [parcel payload]
//
// For GET_CALLING_UID the payload is a single int32 in the data
// segment pointed to by data_ptr.
//
// We rewrite the int32 at data_ptr to g_guest_uid.
bool rewrite_calling_uid(void* transaction_base) {
    if (g_guest_uid <= 0) return false;

    auto* txn = reinterpret_cast<BinderTransactionData*>(transaction_base);

    if (txn->code != GET_CALLING_UID_TRANSACTION) return false;
    if (txn->data_size < sizeof(int32_t)) return false;
    if (txn->data_ptr == 0) return false;

    // The data buffer is in the same process's memory. Direct write.
    auto* uid_slot = reinterpret_cast<int32_t*>(txn->data_ptr);
    uid_slot[0] = g_guest_uid;
    return true;
}

// ---- The ioctl hook -----------------------------------------------

int hooked_ioctl(int fd, unsigned long request, void* arg) {
    // Fast reject: only BINDER_WRITE_READ matters.
    if (request != BINDER_WRITE_READ || arg == nullptr) {
        return g_orig_ioctl ? g_orig_ioctl(fd, request, arg) : -1;
    }

    g_seen.fetch_add(1, std::memory_order_relaxed);

    if (!g_layout_ok) {
        g_layout_skips.fetch_add(1, std::memory_order_relaxed);
        return g_orig_ioctl ? g_orig_ioctl(fd, request, arg) : -1;
    }

    auto* bwr = reinterpret_cast<BinderWriteRead*>(arg);

    // ---- Read side: BR_REPLY for GET_CALLING_UID -------------------
    //
    // Walk the read buffer, looking for BR_REPLY transactions whose
    // code is GET_CALLING_UID. Rewrite the UID int32 in the payload.
    //
    // The read buffer is a sequence of [command(4)] [payload...] pairs.
    if (bwr->read_buffer != 0 && bwr->read_size > 0) {
        uint8_t* p = reinterpret_cast<uint8_t*>(bwr->read_buffer);
        uint8_t* end = p + bwr->read_size;
        while (p + 4 <= end) {
            uint32_t cmd = *reinterpret_cast<uint32_t*>(p);
            p += 4;

            if (cmd == BR_REPLY) {
                if (p + sizeof(BinderTransactionData) > end) break;
                auto* txn = reinterpret_cast<BinderTransactionData*>(p);
                if (rewrite_calling_uid(txn)) {
                    g_uid_rewrites.fetch_add(1, std::memory_order_relaxed);
                }
                p += sizeof(BinderTransactionData);
                // Data payload is separate via data_ptr; skip only the
                // header here, not the payload.
            } else if (cmd == BR_TRANSACTION) {
                if (p + sizeof(BinderTransactionData) > end) break;
                auto* txn = reinterpret_cast<BinderTransactionData*>(p);
                // The transaction body follows. Advance past the header.
                p += sizeof(BinderTransactionData);
                // The transaction body is inside the buffer directly
                // after the header for BR_TRANSACTION.
                if (txn->data_size > 0 && p + txn->data_size <= end) {
                    p += txn->data_size;
                }
                // Offsets array.
                if (txn->offsets_size > 0 && p + txn->offsets_size <= end) {
                    p += txn->offsets_size;
                }
                // Align to 4 bytes.
                while (reinterpret_cast<uintptr_t>(p) % 4 != 0) ++p;
            } else if (cmd == 0) {
                // Zero command terminates the buffer.
                break;
            } else {
                // Unknown command. The safest thing to do is bail on
                // parsing this buffer. The kernel will see what we left
                // untouched.
                break;
            }
        }
    }

    // ---- Write side: nothing to rewrite yet ------------------------
    //
    // BC_TRANSACTION and BC_REPLY parcels that we would want to modify
    // (startActivity, getInstalledPackages) are handled at the Java
    // layer where the parcel contents are structured and typed. The
    // native hook leaves the write side alone so transactions are
    // delivered to the kernel exactly as the guest sent them.

    return g_orig_ioctl ? g_orig_ioctl(fd, request, arg) : -1;
}

// ---- Public API ----------------------------------------------------

} // namespace

bool binder_hook_install(int guest_uid,
                         const char* guest_package,
                         const char* container_package) {
    std::lock_guard<std::mutex> lk(g_lock);
    if (g_installed) return true;

    if (!probe_layout()) {
        return false;
    }
    g_layout_ok = true;

    g_guest_uid = guest_uid;
    g_guest_pkg = guest_package ? guest_package : "";
    g_container_pkg = container_package ? container_package : "";

    // Locate ioctl in libc. We hook the libc symbol, which every caller
    // in the process resolves through the PLT.
    void* libc = dlopen("libc.so", RTLD_NOW | RTLD_NOLOAD);
    if (!libc) libc = dlopen("libc.so", RTLD_NOW);
    if (!libc) {
        LOGE("libc.so not available");
        g_layout_ok = false;
        return false;
    }

    void* target = dlsym(libc, "ioctl");
    if (!target) {
        LOGE("ioctl symbol not found in libc");
        dlclose(libc);
        g_layout_ok = false;
        return false;
    }

    if (!hook_install(target, (void*)hooked_ioctl, (void**)&g_orig_ioctl)) {
        LOGE("hook_install for ioctl failed");
        dlclose(libc);
        g_layout_ok = false;
        return false;
    }

    dlclose(libc);
    g_installed = true;

    LOGI("binder hook installed. guest_uid=%d guest=%s container=%s",
         guest_uid, g_guest_pkg.c_str(), g_container_pkg.c_str());
    return true;
}

void binder_hook_uninstall() {
    std::lock_guard<std::mutex> lk(g_lock);
    if (!g_installed) return;

    void* libc = dlopen("libc.so", RTLD_NOW | RTLD_NOLOAD);
    if (libc) {
        void* target = dlsym(libc, "ioctl");
        if (target) hook_uninstall(target);
        dlclose(libc);
    }

    g_orig_ioctl = nullptr;
    g_installed = false;
    g_layout_ok = false;
    g_guest_uid = 0;
    g_guest_pkg.clear();
    g_container_pkg.clear();
    LOGI("binder hook uninstalled");
}

bool binder_hook_ready() {
    std::lock_guard<std::mutex> lk(g_lock);
    return g_installed && g_layout_ok;
}

BinderHookStats binder_hook_stats() {
    BinderHookStats s{};
    s.transactions_seen = g_seen.load(std::memory_order_relaxed);
    s.uid_replies_rewritten = g_uid_rewrites.load(std::memory_order_relaxed);
    s.package_lists_filtered = g_pkg_filters.load(std::memory_order_relaxed);
    s.rewrites_skipped_due_to_layout = g_layout_skips.load(std::memory_order_relaxed);
    return s;
}

} // namespace unoreverse