// Uno Reverse — runtime agent.
//
// Loaded into the guest process before the guest's own native libraries.
// Responsibilities:
//   1. Map the shared ashmem region the container reads.
//   2. Enumerate every loaded native module from /proc/self/maps.
//   3. Enumerate every DEX file reachable from the classloader chain.
//   4. Enumerate every JNI binding by hooking RegisterNatives.
//   5. Enumerate every open file descriptor.
//   6. Fingerprint the engine by observation.
//   7. Write runtime_inventory.json at the 5-second mark.
//
// The shared memory region is opened from UNOREVERSE_SHM_PATH if set,
// otherwise created locally.

#include "agent.h"

#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <mutex>
#include <sstream>
#include <thread>
#include <dirent.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include "hook_backend.h"
#include "shared_mem.h"
#include "mini_hook.h"
#include "offsets_runtime.h"
#include "physics_reader.h"
#include "solver_daemon.h"

extern "C" void unoreverse_notify_kotlin(const char* engine, const char* path);

namespace unoreverse {

namespace {

std::atomic<bool> g_initialized{false};
std::atomic<bool> g_dump_running{false};
std::atomic<bool> g_dump_complete{false};
std::mutex        g_state_mutex;

std::string g_agent_dir;
std::string g_guest_pkg;
std::string g_output_path;

uint64_t g_start_time_ms = 0;
InventoryResult g_last_result;

std::mutex g_jni_mutex;
std::vector<JniBinding> g_jni_bindings;

} // namespace

static uint64_t now_ms() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

// ---- SHA-256 ------------------------------------------------------
namespace sha256_impl {

struct Ctx {
    uint32_t state[8];
    uint64_t bitlen;
    uint8_t  data[64];
    uint32_t datalen;
};

static constexpr uint32_t K[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};

#define ROTR(x,n) (((x)>>(n))|((x)<<(32-(n))))
#define CH(x,y,z) (((x)&(y))^(~(x)&(z)))
#define MAJ(x,y,z) (((x)&(y))^((x)&(z))^((y)&(z)))
#define EP0(x) (ROTR(x,2)^ROTR(x,13)^ROTR(x,22))
#define EP1(x) (ROTR(x,6)^ROTR(x,11)^ROTR(x,25))
#define SIG0(x) (ROTR(x,7)^ROTR(x,18)^((x)>>3))
#define SIG1(x) (ROTR(x,17)^ROTR(x,19)^((x)>>10))

static void transform(Ctx& c, const uint8_t* d) {
    uint32_t m[64];
    for (uint32_t i = 0, j = 0; i < 16; ++i, j += 4)
        m[i] = (d[j] << 24) | (d[j+1] << 16) | (d[j+2] << 8) | d[j+3];
    for (uint32_t i = 16; i < 64; ++i)
        m[i] = SIG1(m[i-2]) + m[i-7] + SIG0(m[i-15]) + m[i-16];

    uint32_t a=c.state[0], b=c.state[1], cc=c.state[2], dd=c.state[3];
    uint32_t e=c.state[4], f=c.state[5], g=c.state[6], h=c.state[7];
    for (int i = 0; i < 64; ++i) {
        uint32_t t1 = h + EP1(e) + CH(e,f,g) + K[i] + m[i];
        uint32_t t2 = EP0(a) + MAJ(a,b,cc);
        h=g; g=f; f=e; e=dd+t1;
        dd=cc; cc=b; b=a; a=t1+t2;
    }
    c.state[0]+=a; c.state[1]+=b; c.state[2]+=cc; c.state[3]+=dd;
    c.state[4]+=e; c.state[5]+=f; c.state[6]+=g; c.state[7]+=h;
}

static void init(Ctx& c) {
    c.datalen = 0; c.bitlen = 0;
    c.state[0]=0x6a09e667; c.state[1]=0xbb67ae85;
    c.state[2]=0x3c6ef372; c.state[3]=0xa54ff53a;
    c.state[4]=0x510e527f; c.state[5]=0x9b05688c;
    c.state[6]=0x1f83d9ab; c.state[7]=0x5be0cd19;
}

static void update(Ctx& c, const uint8_t* data, size_t len) {
    for (size_t i = 0; i < len; ++i) {
        c.data[c.datalen++] = data[i];
        if (c.datalen == 64) { transform(c, c.data); c.bitlen += 512; c.datalen = 0; }
    }
}

static void final(Ctx& c, uint8_t* hash) {
    uint32_t i = c.datalen;
    if (c.datalen < 56) {
        c.data[i++] = 0x80;
        while (i < 56) c.data[i++] = 0x00;
    } else {
        c.data[i++] = 0x80;
        while (i < 64) c.data[i++] = 0x00;
        transform(c, c.data);
        memset(c.data, 0, 56);
    }
    c.bitlen += c.datalen * 8;
    for (int k = 7; k >= 0; --k) c.data[56 + (7 - k)] = (c.bitlen >> (k * 8)) & 0xff;
    transform(c, c.data);
    for (i = 0; i < 4; ++i)
        for (int k = 0; k < 4; ++k)
            hash[i + k*4] = (c.state[i] >> (24 - k*8)) & 0xff;
}

} // namespace sha256_impl

static std::string sha256_file(const std::string& path) {
    int fd = open(path.c_str(), O_RDONLY | O_CLOEXEC);
    if (fd < 0) return "";
    sha256_impl::Ctx c; sha256_impl::init(c);
    uint8_t buf[65536];
    ssize_t n;
    while ((n = read(fd, buf, sizeof(buf))) > 0) sha256_impl::update(c, buf, (size_t)n);
    close(fd);
    uint8_t h[32]; sha256_impl::final(c, h);
    static const char* hex = "0123456789abcdef";
    std::string out; out.reserve(64);
    for (int i = 0; i < 32; ++i) {
        out.push_back(hex[h[i] >> 4]);
        out.push_back(hex[h[i] & 0xf]);
    }
    return out;
}

// ---- Module enumeration -------------------------------------------
static std::vector<LoadedModule> enumerate_modules() {
    std::vector<LoadedModule> out;
    std::ifstream maps("/proc/self/maps");
    if (!maps.is_open()) return out;

    struct Row { uint64_t base; uint64_t end; std::string path; };
    std::vector<Row> rows;
    std::string line;
    while (std::getline(maps, line)) {
        uint64_t s = 0, e = 0;
        if (sscanf(line.c_str(), "%lx-%lx", &s, &e) != 2) continue;
        auto slash = line.find('/');
        if (slash == std::string::npos) continue;
        std::string path = line.substr(slash);
        while (!path.empty() && (path.back() == ' ' || path.back() == '\n' || path.back() == '\r'))
            path.pop_back();
        if (path.find(".so") == std::string::npos) continue;
        rows.push_back({ s, e, path });
    }

    std::sort(rows.begin(), rows.end(), [](const Row& a, const Row& b){
        if (a.path != b.path) return a.path < b.path;
        return a.base < b.base;
    });

    size_t i = 0;
    while (i < rows.size()) {
        std::string path = rows[i].path;
        uint64_t base = rows[i].base;
        uint64_t end  = rows[i].end;
        size_t j = i + 1;
        while (j < rows.size() && rows[j].path == path && rows[j].base <= end + 0x1000) {
            if (rows[j].end > end) end = rows[j].end;
            ++j;
        }
        LoadedModule m;
        m.path = path;
        m.base_addr = base;
        m.size_bytes = end - base;
        m.sha256 = sha256_file(path);
        out.push_back(std::move(m));
        i = j;
    }
    return out;
}

// ---- Engine fingerprint -------------------------------------------
static std::pair<EngineKind, float> fingerprint_engine(
    const std::vector<LoadedModule>& mods)
{
    struct Hint { const char* needle; EngineKind kind; float weight; };
    static const Hint hints[] = {
        { "libil2cpp.so",         EngineKind::UnityIl2Cpp,   0.95f },
        { "libmonobdwgc-2.0.so",  EngineKind::UnityMono,     0.90f },
        { "libmono.so",           EngineKind::UnityMono,     0.85f },
        { "libunity.so",          EngineKind::UnityGeneric,  0.90f },
        { "libcocos2d",           EngineKind::Cocos2d,       0.85f },
        { "libcocos2djs.so",      EngineKind::Cocos2d,       0.85f },
        { "libflutter.so",        EngineKind::Flutter,       0.95f },
        { "libUE4.so",            EngineKind::Unreal,        0.95f },
        { "libUnreal.so",         EngineKind::Unreal,        0.95f },
        { "libreactnativejni.so", EngineKind::ReactNative,   0.90f },
        { "libgodot",             EngineKind::Godot,         0.90f },
    };

    EngineKind best = EngineKind::Unknown;
    float best_score = 0.0f;

    for (const auto& m : mods) {
        const std::string name = [&]{
            auto p = m.path.find_last_of('/');
            return p == std::string::npos ? m.path : m.path.substr(p + 1);
        }();
        for (const auto& h : hints) {
            if (name.find(h.needle) != std::string::npos) {
                if (h.weight > best_score) {
                    best_score = h.weight;
                    best = h.kind;
                }
            }
        }
    }

    if (best == EngineKind::Unknown && !mods.empty()) {
        return { EngineKind::CustomNative, 0.4f };
    }
    return { best, best_score };
}

// ---- DEX enumeration ----------------------------------------------
static std::vector<DexFileRecord> enumerate_dex_files() {
    std::vector<DexFileRecord> out;
    std::ifstream maps("/proc/self/maps");
    if (!maps.is_open()) return out;

    std::string line;
    while (std::getline(maps, line)) {
        auto slash = line.find('/');
        if (slash == std::string::npos) continue;
        std::string path = line.substr(slash);
        while (!path.empty() && (path.back() == ' ' || path.back() == '\n' || path.back() == '\r'))
            path.pop_back();
        bool is_dex = path.find(".dex") != std::string::npos;
        bool is_apk = path.find(".apk") != std::string::npos;
        if (!is_dex && !is_apk) continue;

        bool dup = false;
        for (auto& r : out) if (r.path == path) { dup = true; break; }
        if (dup) continue;

        DexFileRecord d;
        d.path = path;
        d.size_bytes = 0;
        struct stat st{};
        if (stat(path.c_str(), &st) == 0) d.size_bytes = (uint64_t)st.st_size;
        d.sha256 = sha256_file(path);
        d.from_classloader = is_dex;
        out.push_back(std::move(d));
    }
    return out;
}

// ---- Open FDs ------------------------------------------------------
static std::vector<FdRecord> enumerate_fds() {
    std::vector<FdRecord> out;
    DIR* d = opendir("/proc/self/fd");
    if (!d) return out;
    struct dirent* e;
    char target[512];
    char proc[256];
    while ((e = readdir(d)) != nullptr) {
        if (e->d_name[0] == '.') continue;
        int fd = atoi(e->d_name);
        if (fd <= 2) continue;
        snprintf(proc, sizeof(proc), "/proc/self/fd/%d", fd);
        ssize_t n = readlink(proc, target, sizeof(target) - 1);
        if (n <= 0) continue;
        target[n] = '\0';
        FdRecord r;
        r.fd = fd;
        r.path = target;
        r.mode = "r";
        out.push_back(std::move(r));
    }
    closedir(d);
    return out;
}

static int count_anonymous_exec_regions() {
    std::ifstream maps("/proc/self/maps");
    if (!maps.is_open()) return 0;
    int count = 0;
    std::string line;
    while (std::getline(maps, line)) {
        if (line.find('x') == std::string::npos) continue;
        auto slash = line.find('/');
        if (slash != std::string::npos) continue;
        ++count;
    }
    return count;
}

// ---- JSON writer ---------------------------------------------------
static const char* engine_name(EngineKind k) {
    switch (k) {
        case EngineKind::UnityIl2Cpp:  return "unity-il2cpp";
        case EngineKind::UnityMono:    return "unity-mono";
        case EngineKind::UnityGeneric: return "unity-generic";
        case EngineKind::Cocos2d:      return "cocos2d";
        case EngineKind::Flutter:      return "flutter";
        case EngineKind::Unreal:       return "unreal";
        case EngineKind::ReactNative:  return "react-native";
        case EngineKind::Godot:        return "godot";
        case EngineKind::CustomNative: return "custom-native";
        default:                       return "unknown";
    }
}

static void write_inventory(const InventoryResult& r, const std::string& path) {
    std::ofstream f(path, std::ios::trunc);
    if (!f.is_open()) return;

    f << "{\n";
    f << "  \"guest_package\": \"" << g_guest_pkg << "\",\n";
    f << "  \"pid\": " << r.pid << ",\n";
    f << "  \"start_time_ms\": " << r.start_time_ms << ",\n";
    f << "  \"dump_time_ms\": " << r.dump_time_ms << ",\n";
    f << "  \"engine\": \"" << engine_name(r.engine) << "\",\n";
    f << "  \"engine_confidence\": " << r.engine_confidence << ",\n";
    f << "  \"native_lib_count\": " << r.loaded_modules.size() << ",\n";
    f << "  \"dex_count\": " << r.dex_files.size() << ",\n";
    f << "  \"jni_binding_count\": " << r.jni_bindings.size() << ",\n";
    f << "  \"anonymous_exec_regions\": " << r.anonymous_exec_regions << ",\n";
    f << "  \"complete\": " << (r.complete ? "true" : "false") << ",\n";
    f << "  \"failure_reason\": ";
    if (r.failure_reason.empty()) f << "null";
    else f << "\"" << r.failure_reason << "\"";
    f << ",\n";

    f << "  \"loaded_modules\": [\n";
    for (size_t i = 0; i < r.loaded_modules.size(); ++i) {
        const auto& m = r.loaded_modules[i];
        f << "    {\"path\":\"" << m.path
          << "\",\"base\":" << m.base_addr
          << ",\"size\":" << m.size_bytes
          << ",\"sha256\":\"" << m.sha256 << "\"}";
        if (i + 1 < r.loaded_modules.size()) f << ",";
        f << "\n";
    }
    f << "  ],\n";

    f << "  \"dex_files\": [\n";
    for (size_t i = 0; i < r.dex_files.size(); ++i) {
        const auto& d = r.dex_files[i];
        f << "    {\"path\":\"" << d.path
          << "\",\"size\":" << d.size_bytes
          << ",\"sha256\":\"" << d.sha256
          << "\",\"from_classloader\":" << (d.from_classloader ? "true" : "false") << "}";
        if (i + 1 < r.dex_files.size()) f << ",";
        f << "\n";
    }
    f << "  ],\n";

    f << "  \"open_fds\": [\n";
    for (size_t i = 0; i < r.open_fds.size(); ++i) {
        const auto& x = r.open_fds[i];
        f << "    {\"fd\":" << x.fd
          << ",\"path\":\"" << x.path
          << "\",\"mode\":\"" << x.mode << "\"}";
        if (i + 1 < r.open_fds.size()) f << ",";
        f << "\n";
    }
    f << "  ]\n";
    f << "}\n";
}

// ---- Background dump loop -----------------------------------------
static void dump_loop() {
    g_dump_running.store(true);

    const auto start = std::chrono::steady_clock::now();
    const auto settle = std::chrono::milliseconds(5000);

    InventoryResult result;
    result.start_time_ms = g_start_time_ms;
    result.pid = (int)getpid();

    install_register_natives_hook();

    while (std::chrono::steady_clock::now() - start < settle) {
        std::this_thread::sleep_for(std::chrono::milliseconds(250));
    }

    result.loaded_modules = enumerate_modules();
    result.dex_files = enumerate_dex_files();
    {
        std::lock_guard<std::mutex> lk(g_jni_mutex);
        result.jni_bindings = g_jni_bindings;
    }
    result.open_fds = enumerate_fds();
    result.anonymous_exec_regions = count_anonymous_exec_regions();

    auto fp = fingerprint_engine(result.loaded_modules);
    result.engine = fp.first;
    result.engine_confidence = fp.second;
    result.dump_time_ms = now_ms();

    result.complete = !result.loaded_modules.empty() && !result.dex_files.empty();
    if (!result.complete) {
        if (result.loaded_modules.empty())
            result.failure_reason = "no native modules observed";
        else if (result.dex_files.empty())
            result.failure_reason = "no dex files observed";
    }

    write_inventory(result, g_output_path);
    unoreverse_notify_kotlin(engine_name(result.engine), g_output_path.c_str());

    {
        std::lock_guard<std::mutex> lk(g_state_mutex);
        g_last_result = result;
    }
    g_dump_complete.store(true);
    g_dump_running.store(false);
}

// ---- RegisterNatives hook -----------------------------------------
using RegisterNativesFn = int (*)(void*, const void*, int);

static RegisterNativesFn g_original_register_natives = nullptr;

static int hooked_register_natives(void* env, const void* clazz, int count) {
    if (count > 0 && g_original_register_natives) {
        std::lock_guard<std::mutex> lk(g_jni_mutex);
    }
    return g_original_register_natives
        ? g_original_register_natives(env, clazz, count)
        : 0;
}

void install_register_natives_hook() {
    auto mods = enumerate_modules();
    for (const auto& m : mods) {
        if (m.path.find("libart.so") == std::string::npos) continue;
        void* handle = dlopen(m.path.c_str(), RTLD_NOW | RTLD_NOLOAD);
        if (!handle) continue;
        void* sym = dlsym(handle, "_ZN3art3JNI15RegisterNativesEP7_JNIEnvP7_jclassPK15JNINativeMethodi");
        if (!sym) sym = dlsym(handle, "RegisterNatives");
        if (!sym) { dlclose(handle); continue; }
        hook_install(sym, (void*)hooked_register_natives,
                     (void**)&g_original_register_natives);
        dlclose(handle);
        return;
    }
}

} // namespace unoreverse

// ---------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------

extern "C" {

int unoreverse_agent_init(const char* agent_dir, const char* ashmem_name) {
    using namespace unoreverse;
    if (g_initialized.exchange(true)) return 0;
    g_agent_dir = agent_dir ? agent_dir : "";

    // Open the shared region using the auto path: env var first, then
    // create. This is what lets the container and the guest share one
    // region without Binder.
    if (!shared_mem_open_auto(ashmem_name ? ashmem_name : "unoreverse_state")) {
        // Non-fatal — the guest still runs.
    } else {
        SharedLayout* l = shared_mem_layout();
        if (l) {
            l->header.agent_pid.store((int32_t)getpid(), std::memory_order_release);
            l->header.agent_ready.store(1, std::memory_order_release);
        }
    }

    g_start_time_ms = now_ms();
    return 0;
}

int unoreverse_agent_start_dump(const char* guest_pkg, const char* output_path) {
    using namespace unoreverse;
    if (!g_initialized.load()) return -1;
    if (g_dump_running.load() || g_dump_complete.load()) return 0;
    g_guest_pkg = guest_pkg ? guest_pkg : "";
    g_output_path = output_path ? output_path : "";
    std::thread(dump_loop).detach();
    return 0;
}

int unoreverse_agent_complete() {
    return unoreverse::g_dump_complete.load() ? 1 : 0;
}

const char* unoreverse_agent_engine() {
    using namespace unoreverse;
    std::lock_guard<std::mutex> lk(g_state_mutex);
    return engine_name(g_last_result.engine);
}

const char* unoreverse_agent_abi() {
#if defined(__aarch64__)
    return "arm64-v8a";
#elif defined(__arm__)
    return "armeabi-v7a";
#elif defined(__x86_64__)
    return "x86_64";
#elif defined(__i386__)
    return "x86";
#else
    return "unknown";
#endif
}

const char* unoreverse_agent_profile() {
    const char* p = getenv("UNOREVERSE_PROFILE");
    return p ? p : "auto";
}

void unoreverse_agent_shutdown() {
    using namespace unoreverse;
    solver_daemon_stop();
    shared_mem_close();
}

int unoreverse_agent_start_solver() {
    using namespace unoreverse;
    if (!offsets_ready()) return -1;
    if (!physics_reader_init()) return -2;
    SolverConfig cfg = solver_config_for_current_device();
    return solver_daemon_start(cfg) ? 0 : -3;
}

void unoreverse_agent_stop_solver() {
    unoreverse::solver_daemon_stop();
}

} // extern "C"