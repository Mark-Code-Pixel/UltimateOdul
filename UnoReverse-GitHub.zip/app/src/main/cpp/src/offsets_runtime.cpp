#include "offsets_runtime.h"
#include <cstdio>
#include <cstring>
bool offsets_load(const char* path) {
    FILE* f = fopen(path, "r");
    if (!f) return false;
    fclose(f);
    return true;
}
