// Uno Reverse — runtime offset loader.
// Minimal hand-rolled JSON reader. Tolerates whitespace, comments, and
// missing keys. No external dependency.

#include "offsets_runtime.h"

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <mutex>
#include <sstream>

namespace unoreverse {

namespace {

std::mutex g_lock;
RuntimeOffsets g_offsets;

// ---- Tolerant JSON value extraction --------------------------------

std::string find_value_string(const std::string& s, const std::string& key) {
    const std::string needle = "\"" + key + "\"";
    auto k = s.find(needle);
    if (k == std::string::npos) return "";
    auto colon = s.find(':', k + needle.size());
    if (colon == std::string::npos) return "";
    size_t i = colon + 1;
    while (i < s.size() && std::isspace((unsigned char)s[i])) ++i;
    if (i >= s.size()) return "";
    if (s[i] == '"') {
        size_t start = i + 1;
        size_t end = start;
        while (end < s.size() && s[end] != '"') {
            if (s[end] == '\\' && end + 1 < s.size()) end += 2;
            else ++end;
        }
        return s.substr(start, end - start);
    }
    return "";
}

long long find_value_int(const std::string& s, const std::string& key, long long fallback = 0) {
    const std::string needle = "\"" + key + "\"";
    auto k = s.find(needle);
    if (k == std::string::npos) return fallback;
    auto colon = s.find(':', k + needle.size());
    if (colon == std::string::npos) return fallback;
    size_t i = colon + 1;
    while (i < s.size() && std::isspace((unsigned char)s[i])) ++i;
    if (i >= s.size()) return fallback;
    if (s[i] == '"') {
        ++i;
        long long v = 0;
        bool neg = false;
        if (i < s.size() && s[i] == '-') { neg = true; ++i; }
        while (i < s.size() && std::isdigit((unsigned char)s[i])) {
            v = v * 10 + (s[i] - '0');
            ++i;
        }
        return neg ? -v : v;
    }
    bool neg = false;
    if (s[i] == '-') { neg = true; ++i; }
    long long v = 0;
    while (i < s.size() && std::isdigit((unsigned char)s[i])) {
        v = v * 10 + (s[i] - '0');
        ++i;
    }
    return neg ? -v : v;
}

double find_value_double(const std::string& s, const std::string& key, double fallback = 0.0) {
    const std::string needle = "\"" + key + "\"";
    auto k = s.find(needle);
    if (k == std::string::npos) return fallback;
    auto colon = s.find(':', k + needle.size());
    if (colon == std::string::npos) return fallback;
    size_t i = colon + 1;
    while (i < s.size() && std::isspace((unsigned char)s[i])) ++i;
    if (i >= s.size()) return fallback;
    if (s[i] == '"') ++i;
    char* endp = nullptr;
    double v = std::strtod(s.c_str() + i, &endp);
    return (endp == s.c_str() + i) ? fallback : v;
}

} // namespace

// ---- Public API ----------------------------------------------------

bool offsets_load(const std::string& json_path) {
    std::lock_guard<std::mutex> lk(g_lock);

    std::ifstream f(json_path);
    if (!f.is_open()) return false;

    std::stringstream ss;
    ss << f.rdbuf();
    const std::string s = ss.str();
    if (s.empty()) return false;

    RuntimeOffsets o;

    o.il2cpp_module        = find_value_string(s, "il2cpp_module");
    o.rva_shoot            = (uint64_t)find_value_int(s, "rva_shoot");
    o.rva_set_turn         = (uint64_t)find_value_int(s, "rva_set_turn");
    o.rva_update           = (uint64_t)find_value_int(s, "rva_update");
    o.rva_camera_w2s       = (uint64_t)find_value_int(s, "rva_camera_w2s");

    o.off_coin_pos_x       = (uint32_t)find_value_int(s, "off_coin_pos_x");
    o.off_coin_pos_y       = (uint32_t)find_value_int(s, "off_coin_pos_y");
    o.off_coin_vel_x       = (uint32_t)find_value_int(s, "off_coin_vel_x");
    o.off_coin_vel_y       = (uint32_t)find_value_int(s, "off_coin_vel_y");
    o.off_coin_mass        = (uint32_t)find_value_int(s, "off_coin_mass");
    o.off_coin_friction    = (uint32_t)find_value_int(s, "off_coin_friction");
    o.off_coin_type        = (uint32_t)find_value_int(s, "off_coin_type");
    o.off_coin_pocketed    = (uint32_t)find_value_int(s, "off_coin_pocketed");

    o.off_striker_pos_x    = (uint32_t)find_value_int(s, "off_striker_pos_x");
    o.off_striker_pos_y    = (uint32_t)find_value_int(s, "off_striker_pos_y");
    o.off_striker_rb       = (uint32_t)find_value_int(s, "off_striker_rb");
    o.off_striker_aim_x    = (uint32_t)find_value_int(s, "off_striker_aim_x");
    o.off_striker_aim_y    = (uint32_t)find_value_int(s, "off_striker_aim_y");

    o.off_turn_current     = (uint32_t)find_value_int(s, "off_turn_current");
    o.off_turn_is_mine     = (uint32_t)find_value_int(s, "off_turn_is_mine");
    o.off_turn_animating   = (uint32_t)find_value_int(s, "off_turn_animating");

    o.off_physics_gravity_x = (uint32_t)find_value_int(s, "off_physics_gravity_x");
    o.off_physics_gravity_y = (uint32_t)find_value_int(s, "off_physics_gravity_y");
    o.off_physics_fixed_dt  = (uint32_t)find_value_int(s, "off_physics_fixed_dt");
    o.off_physics_iterations= (uint32_t)find_value_int(s, "off_physics_iterations");
    o.off_physics_coin_mat  = (uint32_t)find_value_int(s, "off_physics_coin_mat");
    o.off_physics_cush_mat  = (uint32_t)find_value_int(s, "off_physics_cush_mat");

    o.board_width          = (float)find_value_double(s, "board_width");
    o.board_height         = (float)find_value_double(s, "board_height");
    o.striker_radius       = (float)find_value_double(s, "striker_radius");
    o.coin_radius          = (float)find_value_double(s, "coin_radius");

    // Pocket coordinates — four {x,y} pairs, indexed by key.
    static const char* pocket_keys[4][2] = {
        {"pocket_0_x", "pocket_0_y"},
        {"pocket_1_x", "pocket_1_y"},
        {"pocket_2_x", "pocket_2_y"},
        {"pocket_3_x", "pocket_3_y"},
    };
    for (int i = 0; i < 4; ++i) {
        o.pocket_xy[i * 2 + 0] = (float)find_value_double(s, pocket_keys[i][0]);
        o.pocket_xy[i * 2 + 1] = (float)find_value_double(s, pocket_keys[i][1]);
    }

    o.static_coin_list = (uintptr_t)find_value_int(s, "static_coin_list");
    o.static_striker   = (uintptr_t)find_value_int(s, "static_striker");
    o.static_physics   = (uintptr_t)find_value_int(s, "static_physics");
    o.static_turn      = (uintptr_t)find_value_int(s, "static_turn");
    o.static_board     = (uintptr_t)find_value_int(s, "static_board");

    o.source_json_path = json_path;

    // A table is usable if the module name is non-empty and at least one
    // method RVA is present. Static slots may be zero on first run — the
    // pipeline fills them once the game has been observed at runtime.
    o.loaded = !o.il2cpp_module.empty() &&
               (o.rva_shoot != 0 || o.rva_set_turn != 0 || o.rva_update != 0);

    g_offsets = std::move(o);
    return g_offsets.loaded;
}

bool offsets_ready() {
    std::lock_guard<std::mutex> lk(g_lock);
    return g_offsets.loaded;
}

const RuntimeOffsets& offsets_get() {
    return g_offsets;
}

void offsets_clear() {
    std::lock_guard<std::mutex> lk(g_lock);
    g_offsets = RuntimeOffsets{};
}

} // namespace unoreverse