// Uno Reverse — solver daemon implementation.

#include "solver_daemon.h"

#include "neon_dispatch.h"
#include "physics_reader.h"
#include "shared_mem.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstring>
#include <mutex>
#include <thread>

namespace unoreverse {

namespace {

std::atomic<bool> g_running{false};
std::thread        g_thread;
SolverConfig       g_config{};
std::atomic<uint64_t> g_solve_count{0};

// Rolling average of solve times.
constexpr int kAvgWindow = 64;
std::atomic<int64_t> g_avg_window[kAvgWindow];
std::atomic<int>     g_avg_idx{0};
std::atomic<int64_t> g_avg_us{0};

// Buffers owned by the daemon. Never allocated inside the loop.
std::vector<Candidate>  g_candidates;
SolverPool              g_pool;
SimWorld                g_initial_world;
PhysicsConfig           g_last_config;
Objective               g_objective;

// Colours for line rendering. Packed ARGB. The overlay reads them as-is.
constexpr uint32_t kColorCandidateHigh = 0xFFD4AF37;   // bright gold
constexpr uint32_t kColorCandidateMid  = 0xFF8A7030;   // mid gold
constexpr uint32_t kColorCandidateLow  = 0xFF4A3A18;   // dim gold
constexpr uint32_t kColorChosen        = 0xFFFF3B30;   // red
constexpr uint32_t kColorGhost         = 0xFFFFFFFF;   // white ghost dot
constexpr uint32_t kColorPocket        = 0xFF22C55E;   // green pocket dot

// ---- Line packing --------------------------------------------------

// Emit a segment into the shared layout's line array. Returns the new
// index, or the unchanged index if the buffer is full.
int emit_line(SharedLayout* sh, int idx,
              float x0, float y0, float x1, float y1,
              uint32_t color) {
    if (idx >= MAX_LINES) return idx;
    Line& l = sh->lines[idx];
    l.x0 = x0; l.y0 = y0;
    l.x1 = x1; l.y1 = y1;
    l.color = color;
    return idx + 1;
}

// Emit a candidate's polyline: striker path (S -> bounce(s) -> ghost)
// followed by the coin path (coin -> pocket). Up to 4 segments per
// candidate. Every segment carries the same color, chosen by the
// caller.
int emit_candidate_lines(SharedLayout* sh, int idx,
                         const Candidate& c,
                         const BoardSnapshot& board,
                         uint32_t color) {
    const float sx = board.striker_x;
    const float sy = board.striker_y;

    // Striker path.
    float prev_x = sx;
    float prev_y = sy;

    if (c.bounce_count >= 1) {
        idx = emit_line(sh, idx, prev_x, prev_y,
                        c.bounce_x[0], c.bounce_y[0], color);
        prev_x = c.bounce_x[0];
        prev_y = c.bounce_y[0];
    }
    if (c.bounce_count >= 2) {
        idx = emit_line(sh, idx, prev_x, prev_y,
                        c.bounce_x[1], c.bounce_y[1], color);
        prev_x = c.bounce_x[1];
        prev_y = c.bounce_y[1];
    }
    idx = emit_line(sh, idx, prev_x, prev_y,
                    c.ghost_x, c.ghost_y, color);

    // Coin path.
    if (c.coin_idx >= 0 && c.coin_idx < board.coin_count) {
        const CoinState& coin = board.coins[c.coin_idx];
        const float px = board.pockets[c.pocket_idx][0];
        const float py = board.pockets[c.pocket_idx][1];
        idx = emit_line(sh, idx, coin.x, coin.y, px, py, color);
    }
    return idx;
}

// ---- Colour ramp ---------------------------------------------------

uint32_t colour_for_score(float score, float best, float worst) {
    if (best <= worst) return kColorCandidateMid;
    const float t = (score - worst) / (best - worst);  // 0..1
    if (t > 0.66f) return kColorCandidateHigh;
    if (t > 0.33f) return kColorCandidateMid;
    return kColorCandidateLow;
}

// ---- One solve iteration -------------------------------------------

void run_one_solve() {
    SharedLayout* sh = shared_mem_layout();
    if (!sh) return;

    // The board and config are written by the physics reader thread.
    // Take a local copy guarded by the sequence counter to avoid torn
    // reads across threads.
    uint32_t seq_before = sh->header.seq.load(std::memory_order_acquire);

    BoardSnapshot board;
    std::memcpy(&board, &sh->board, sizeof(BoardSnapshot));

    PhysicsConfig config;
    std::memcpy(&config, &sh->config, sizeof(PhysicsConfig));

    uint32_t seq_after = sh->header.seq.load(std::memory_order_acquire);
    if (seq_before != seq_after) return;   // torn read, retry next tick
    if (board.coin_count <= 0) return;
    if (config.fixed_dt <= 0.0f) return;

    g_last_config = config;

    // Build the initial world once. Every candidate is verified against
    // a copy of this world.
    sim_init(g_initial_world, board, config);

    // Analytical candidate generation.
    build_candidates(board, config, g_config.profile, g_candidates);
    const int total_candidates = (int)g_candidates.size();
    if (total_candidates == 0) {
        sh->header.ready_to_fire.store(0, std::memory_order_release);
        sh->header.candidate_count.store(0, std::memory_order_release);
        return;
    }

    // Verify the top N in parallel.
    const int verify_n = std::min(g_config.top_n_verify, total_candidates);
    g_pool.configure(g_config.thread_count, verify_n);
    g_pool.verify_all(g_candidates, g_initial_world, config, g_objective,
                      g_config.max_sim_steps);

    // Record timing.
    const int64_t run_us = g_pool.last_run_us();
    const int slot = g_avg_idx.fetch_add(1, std::memory_order_acq_rel) % kAvgWindow;
    g_avg_window[slot].store(run_us, std::memory_order_release);
    int64_t sum = 0; int n = 0;
    for (int i = 0; i < kAvgWindow; ++i) {
        int64_t v = g_avg_window[i].load(std::memory_order_acquire);
        if (v > 0) { sum += v; ++n; }
    }
    if (n > 0) g_avg_us.store(sum / n, std::memory_order_release);
    g_solve_count.fetch_add(1, std::memory_order_release);

    // Publish the chosen shot if a valid one exists.
    const int best = g_pool.best_index();
    const bool have_shot = best >= 0;

    if (have_shot) {
        const Candidate& c = g_candidates[best];
        sh->header.best_angle.store(c.angle, std::memory_order_release);
        sh->header.best_power.store(1.0f, std::memory_order_release);
        sh->header.best_coin_idx.store(c.coin_idx, std::memory_order_release);
        sh->header.best_pocket_idx.store(c.pocket_idx, std::memory_order_release);
    }

    // ---- Publish candidate lines -----------------------------------
    int line_idx = 0;

    // Determine the score range across the verified candidates so we can
    // colour each line by its relative strength.
    float best_score = -1.0e30f;
    float worst_score = 1.0e30f;
    for (int i = 0; i < verify_n; ++i) {
        const ShotResult& r = g_pool.result(i);
        if (r.score <= kScoreNoPot) continue;
        best_score = std::max(best_score, r.score);
        worst_score = std::min(worst_score, r.score);
    }

    // Draw up to line_candidates candidate polylines. Chosen shot last
    // and on top.
    const int draw_count = std::min(g_config.line_candidates, verify_n);
    for (int i = 0; i < draw_count; ++i) {
        if (i == best) continue;   // drawn separately in red
        const ShotResult& r = g_pool.result(i);
        if (r.score <= kScoreNoPot) continue;
        uint32_t col = colour_for_score(r.score, best_score, worst_score);
        line_idx = emit_candidate_lines(sh, line_idx,
                                        g_candidates[i], board, col);
        if (line_idx >= MAX_LINES) break;
    }

    if (have_shot && line_idx + 4 <= MAX_LINES) {
        // Chosen shot in red, drawn last so it overlays.
        line_idx = emit_candidate_lines(sh, line_idx,
                                        g_candidates[best], board,
                                        kColorChosen);
        // Ghost marker: a single-pixel line at the ghost position
        // rendered as a thin tick.
        line_idx = emit_line(sh, line_idx,
                             g_candidates[best].ghost_x,
                             g_candidates[best].ghost_y,
                             g_candidates[best].ghost_x,
                             g_candidates[best].ghost_y,
                             kColorGhost);
        // Pocket marker.
        line_idx = emit_line(sh, line_idx,
                             board.pockets[g_candidates[best].pocket_idx][0],
                             board.pockets[g_candidates[best].pocket_idx][1],
                             board.pockets[g_candidates[best].pocket_idx][0],
                             board.pockets[g_candidates[best].pocket_idx][1],
                             kColorPocket);
    }

    // Write line count and shots.
    sh->header.line_count.store(line_idx, std::memory_order_release);
    sh->header.candidate_count.store(verify_n, std::memory_order_release);
    sh->header.solve_time_us.store((int32_t)run_us, std::memory_order_release);

    // Arm the shot only if the turn is ours, autoplay is enabled, and a
    // valid shot exists. The shoot hook consumes the flag.
    const bool autoplay = sh->header.autoplay.load(std::memory_order_acquire) != 0;
    const bool my_turn  = sh->header.is_my_turn.load(std::memory_order_acquire) != 0;
    const bool armed    = sh->header.ready_to_fire.load(std::memory_order_acquire) != 0;

    if (autoplay && my_turn && have_shot && !armed) {
        sh->header.ready_to_fire.store(1, std::memory_order_release);
    } else if (!my_turn && armed) {
        // Turn flipped; clear stale shot.
        sh->header.ready_to_fire.store(0, std::memory_order_release);
    } else if (!autoplay && armed) {
        sh->header.ready_to_fire.store(0, std::memory_order_release);
    }
}

// ---- Thread loop ---------------------------------------------------

void solver_loop() {
    using clock = std::chrono::steady_clock;

    // Reserve the candidate buffer once.
    g_candidates.reserve((size_t)MAX_CANDIDATES);

    auto next = clock::now();

    while (g_running.load(std::memory_order_acquire)) {
        // Rate limiting: solve at most solve_rate_hz times per second.
        const int rate = g_config.solve_rate_hz > 0 ? g_config.solve_rate_hz : 30;
        const auto interval = std::chrono::milliseconds(1000 / rate);

        next += interval;
        const auto now = clock::now();
        if (next > now) {
            std::this_thread::sleep_until(next);
        } else {
            // We fell behind. Reset the schedule rather than sprint.
            next = now + interval;
        }

        run_one_solve();
    }
}

} // namespace

// ---------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------

SolverConfig solver_config_for_current_device() {
    SolverConfig c{};
    const int profile = selected_profile();
    c.profile = profile;

    switch (profile) {
        case 1: // Full
            c.top_n_verify    = 24;
            c.thread_count    = 4;
            c.max_sim_steps   = 90;
            c.line_candidates = 16;
            c.solve_rate_hz   = 60;
            break;
        case 2: // Lean
            c.top_n_verify    = 8;
            c.thread_count    = 2;
            c.max_sim_steps   = 50;
            c.line_candidates = 12;
            c.solve_rate_hz   = 30;
            break;
        default: // DirectOnly
            c.top_n_verify    = 4;
            c.thread_count    = 1;
            c.max_sim_steps   = 40;
            c.line_candidates = 8;
            c.solve_rate_hz   = 15;
            break;
    }
    return c;
}

bool solver_daemon_start(const SolverConfig& config) {
    bool expected = false;
    if (!g_running.compare_exchange_strong(expected, true)) {
        return true;   // already running
    }
    g_config = config;

    // Clear rolling average window.
    for (int i = 0; i < kAvgWindow; ++i) {
        g_avg_window[i].store(0, std::memory_order_release);
    }
    g_avg_idx.store(0, std::memory_order_release);
    g_avg_us.store(0, std::memory_order_release);
    g_solve_count.store(0, std::memory_order_release);

    g_thread = std::thread(solver_loop);
    return true;
}

void solver_daemon_stop() {
    bool expected = true;
    if (!g_running.compare_exchange_strong(expected, false)) {
        return;
    }
    if (g_thread.joinable()) g_thread.join();
}

bool solver_daemon_running() {
    return g_running.load(std::memory_order_acquire);
}

uint64_t solver_daemon_solve_count() {
    return g_solve_count.load(std::memory_order_acquire);
}

int64_t solver_daemon_avg_solve_us() {
    return g_avg_us.load(std::memory_order_acquire);
}

} // namespace unoreverse