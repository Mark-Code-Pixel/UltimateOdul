#include "neon_dispatch.h"
#if defined(__ARM_NEON) || defined(__ARM_NEON__)
#include <arm_neon.h>
#endif
void neon_batch_score(const float* in, float* out, int n) {
    for (int i = 0; i < n; i++) out[i] = in[i];
}
