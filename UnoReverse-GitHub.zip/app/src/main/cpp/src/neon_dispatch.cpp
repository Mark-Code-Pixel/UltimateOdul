// Uno Reverse — platform probe.

#include "neon_dispatch.h"

#include <atomic>
#include <cctype>
#include <cstring>
#include <fstream>
#include <string>

namespace unoreverse {

namespace {

std::atomic<bool> g_neon{false};
std::atomic<int>  g_cores{1};
std::atomic<unsigned long long> g_ram{0};
std::atomic<int>  g_profile{3};  // default to direct-only, overridden in probe
std::atomic<bool> g_probed{false};

bool detect_neon_from_cpuinfo() {
#if defined(__aarch64__)
    // NEON/ASIMD is mandatory on ARMv8-A. Every 64-bit ARM chip has it.
    return true;
#elif defined(__arm__)
    std::ifstream f("/proc/cpuinfo");
    if (!f.is_open()) return false;
    std::string line;
    while (std::getline(f, line)) {
        // Look for "Features" and check for "neon" token.
        if (line.find("Features") == std::string::npos) continue;
        // Case-insensitive contains "neon"
        for (size_t i = 0; i + 4 <= line.size(); ++i) {
            if (std::tolower((unsigned char)line[i])     == 'n' &&
                std::tolower((unsigned char)line[i + 1]) == 'e' &&
                std::tolower((unsigned char)line[i + 2]) == 'o' &&
                std::tolower((unsigned char)line[i + 3]) == 'n') {
                return true;
            }
        }
    }
    return false;
#else
    return false;
#endif
}

int detect_cores() {
    std::ifstream f("/proc/cpuinfo");
    if (!f.is_open()) return 1;
    std::string line;
    int n = 0;
    while (std::getline(f, line)) {
        if (line.rfind("processor", 0) == 0) ++n;
    }
    if (n <= 0) n = 1;
    if (n > 16) n = 16;
    return n;
}

unsigned long long detect_ram() {
    std::ifstream f("/proc/meminfo");
    if (!f.is_open()) return 0;
    std::string line;
    while (std::getline(f, line)) {
        if (line.rfind("MemTotal:", 0) != 0) continue;
        // Format: "MemTotal:       16384000 kB"
        unsigned long long kb = 0;
        const char* p = line.c_str() + 9;
        while (*p && !std::isdigit((unsigned char)*p)) ++p;
        while (*p &&  std::isdigit((unsigned char)*p)) {
            kb = kb * 10 + (*p - '0');
            ++p;
        }
        return kb * 1024ULL;
    }
    return 0;
}

} // namespace

bool neon_available() {
    return g_neon.load(std::memory_order_acquire);
}

int cpu_core_count() {
    return g_cores.load(std::memory_order_acquire);
}

unsigned long long total_ram_bytes() {
    return g_ram.load(std::memory_order_acquire);
}

void platform_probe() {
    bool expected = false;
    if (!g_probed.compare_exchange_strong(expected, true)) return;

    const bool neon = detect_neon_from_cpuinfo();
    const int cores = detect_cores();
    const unsigned long long ram = detect_ram();

    g_neon.store(neon, std::memory_order_release);
    g_cores.store(cores, std::memory_order_release);
    g_ram.store(ram, std::memory_order_release);

    // Profile selection:
    //   Full        — 64-bit, >=6 cores, >=4GB RAM, NEON
    //   Lean        — NEON available (any core / RAM), or 64-bit with low cores
    //   DirectOnly  — no NEON (scalar), 32-bit-only, 2GB or less
    int profile;
    if (UNOREVERSE_64 && cores >= 6 && ram >= (4ULL << 30) && neon) {
        profile = 1;
    } else if (neon) {
        profile = 2;
    } else {
        profile = 3;
    }
    g_profile.store(profile, std::memory_order_release);
}

const char* selected_profile_name() {
    switch (selected_profile()) {
        case 1: return "full";
        case 2: return "lean";
        default: return "direct-only";
    }
}

int selected_profile() {
    return g_profile.load(std::memory_order_acquire);
}

} // namespace unoreverse