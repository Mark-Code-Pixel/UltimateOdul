// Uno Reverse — hook implementations.
//
// The hook signatures match the standard IL2CPP instance-method ABI:
// `this` in the first argument register, then the declared parameters.
// Vec2 is passed by value as an 8-byte aggregate, marshalled per the
// platform ABI.

#include "hooks.h"
#include "hook_backend.h"
#include "il2cpp_reader.h"
#include "offsets_runtime.h"
#include "shared_mem.h"

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstring>
#include <dlfcn.h>
#include <mutex>

namespace unoreverse {

namespace {

// ---------------------------------------------------------------------
// Hook state
// ---------------------------------------------------------------------
std::mutex g_lock;
bool g_shoot_installed = false;
bool g_set_turn_installed = false;
bool g_update_installed = false;
uintptr_t g_module_base = 0;

using ShootFn   = void (*)(void* self, Vec2 dir, float power);
using SetTurnFn = void (*)(void* self, int32_t player);
using UpdateFn  = void (*)(void* self);

ShootFn   g_original_shoot    = nullptr;
SetTurnFn g_original_set_turn = nullptr;
UpdateFn  g_original_update   = nullptr;

// ---------------------------------------------------------------------
// hooked_shoot
// ---------------------------------------------------------------------
void hooked_shoot(void* self, Vec2 dir, float power) {
    SharedLayout* sh = shared_mem_layout();
    if (sh) {
        const bool autoplay = sh->header.autoplay.load(std::memory_order_acquire) != 0;
        const bool my_turn  = sh->header.is_my_turn.load(std::memory_order_acquire) != 0;
        const bool ready    = sh->header.ready_to_fire.load(std::memory_order_acquire) != 0;

        if (autoplay && my_turn && ready) {
            sh->header.ready_to_fire.store(0, std::memory_order_release);

            const float angle = sh->header.best_angle.load(std::memory_order_acquire);
            const float pw    = sh->header.best_power.load(std::memory_order_acquire);

            dir.x = std::cos(angle);
            dir.y = std::sin(angle);
            power = pw;
        }
    }

    if (g_original_shoot) {
        g_original_shoot(self, dir, power);
    }
}

// ---------------------------------------------------------------------
// hooked_set_turn
// ---------------------------------------------------------------------
void hooked_set_turn(void* self, int32_t player) {
    SharedLayout* sh = shared_mem_layout();
    if (sh) {
        sh->header.ready_to_fire.store(0, std::memory_order_release);
    }

    if (g_original_set_turn) {
        g_original_set_turn(self, player);
    }
}

// ---------------------------------------------------------------------
// hooked_update
// ---------------------------------------------------------------------
void hooked_update(void* self) {
    if (g_original_update) {
        g_original_update(self);
    }

    SharedLayout* sh = shared_mem_layout();
    if (!sh) return;

    static std::atomic<uint32_t> last_publish_ms{0};
    const int32_t rate = sh->header.solve_rate_hz.load(std::memory_order_acquire);
    if (rate > 0) {
        using namespace std::chrono;
        const uint32_t now = (uint32_t)duration_cast<milliseconds>(
            steady_clock::now().time_since_epoch()).count();
        const uint32_t interval = 1000u / (uint32_t)rate;
        const uint32_t last = last_publish_ms.load(std::memory_order_relaxed);
        if (now - last < interval) return;
        last_publish_ms.store(now, std::memory_order_relaxed);
    }

    sh->header.seq.fetch_add(1, std::memory_order_release);
}

} // namespace

// ---------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------

bool hooks_install_all() {
    std::lock_guard<std::mutex> lk(g_lock);

    if (!offsets_ready()) {
        return false;
    }

    const RuntimeOffsets& off = offsets_get();

    g_module_base = wait_for_module(off.il2cpp_module, 3000);
    if (g_module_base == 0) {
        return false;
    }

    bool all_ok = true;

    if (off.rva_shoot != 0) {
        void* target = (void*)(g_module_base + off.rva_shoot);
        if (hook_install(target, (void*)hooked_shoot, (void**)&g_original_shoot)) {
            g_shoot_installed = true;
        } else {
            all_ok = false;
        }
    }

    if (off.rva_set_turn != 0) {
        void* target = (void*)(g_module_base + off.rva_set_turn);
        if (hook_install(target, (void*)hooked_set_turn, (void**)&g_original_set_turn)) {
            g_set_turn_installed = true;
        } else {
            all_ok = false;
        }
    }

    if (off.rva_update != 0) {
        void* target = (void*)(g_module_base + off.rva_update);
        if (hook_install(target, (void*)hooked_update, (void**)&g_original_update)) {
            g_update_installed = true;
        } else {
            all_ok = false;
        }
    }

    return all_ok;
}

void hooks_uninstall_all() {
    std::lock_guard<std::mutex> lk(g_lock);

    const RuntimeOffsets& off = offsets_get();

    if (g_shoot_installed && g_module_base && off.rva_shoot) {
        hook_uninstall((void*)(g_module_base + off.rva_shoot));
        g_shoot_installed = false;
        g_original_shoot = nullptr;
    }
    if (g_set_turn_installed && g_module_base && off.rva_set_turn) {
        hook_uninstall((void*)(g_module_base + off.rva_set_turn));
        g_set_turn_installed = false;
        g_original_set_turn = nullptr;
    }
    if (g_update_installed && g_module_base && off.rva_update) {
        hook_uninstall((void*)(g_module_base + off.rva_update));
        g_update_installed = false;
        g_original_update = nullptr;
    }

    g_module_base = 0;
}

bool hooks_shoot_ready() {
    std::lock_guard<std::mutex> lk(g_lock);
    return g_shoot_installed && g_original_shoot != nullptr;
}

HookStatus hooks_status() {
    std::lock_guard<std::mutex> lk(g_lock);
    return HookStatus{
        g_shoot_installed,
        g_set_turn_installed,
        g_update_installed,
        g_module_base
    };
}

} // namespace unoreverse