#include "hooks.h"
#include "hook_backend.h"
void hooks_install() {
    // shoot / set-turn / update
}
