// Uno Reverse — shared memory bridge implementation.

#include "overlay_bridge.h"

#include <atomic>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>

#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#if defined(__ANDROID__)
  #include <linux/ashmem.h>
  #include <sys/ioctl.h>
#endif

namespace unoreverse {

namespace {

std::mutex    g_lock;
int           g_fd = -1;
SharedLayout* g_layout = nullptr;
bool          g_is_owner = false;

} // namespace

std::string overlay_create_region() {
    std::lock_guard<std::mutex> lk(g_lock);

    if (g_layout && g_is_owner) {
        // Already created. Return the path again.
        char path[128];
        snprintf(path, sizeof(path), "/proc/%d/fd/%d", getpid(), g_fd);
        return std::string(path);
    }

    const size_t size = sizeof(SharedLayout);

#if defined(__ANDROID__)
    int fd = open("/dev/ashmem", O_RDWR | O_CLOEXEC);
    if (fd < 0) return "";
    if (ioctl(fd, ASHMEM_SET_NAME, "unoreverse_state") < 0) {
        close(fd); return "";
    }
    if (ioctl(fd, ASHMEM_SET_SIZE, (unsigned long)size) < 0) {
        close(fd); return "";
    }
#else
    // POSIX fallback.
    shm_unlink("/unoreverse_state");
    int fd = shm_open("/unoreverse_state", O_CREAT | O_RDWR, 0600);
    if (fd < 0) return "";
    if (ftruncate(fd, size) != 0) { close(fd); return ""; }
#endif

    void* p = mmap(nullptr, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) {
        close(fd);
        return "";
    }

    g_fd = fd;
    g_layout = (SharedLayout*)p;
    g_is_owner = true;

    // Zero the header, then set defaults.
    std::memset(&g_layout->header, 0, sizeof(StateHeader));
    g_layout->header.running.store(1, std::memory_order_release);
    g_layout->header.line_count.store(16, std::memory_order_release);
    g_layout->header.solve_rate_hz.store(30, std::memory_order_release);
    g_layout->header.autoplay.store(1, std::memory_order_release);
    g_layout->header.autoqueue.store(1, std::memory_order_release);
    g_layout->header.keep_line.store(1, std::memory_order_release);
    g_layout->header.show_lines.store(0, std::memory_order_release);

    char path[128];
    snprintf(path, sizeof(path), "/proc/%d/fd/%d", getpid(), g_fd);
    return std::string(path);
}

bool overlay_map_region(const std::string& path) {
    std::lock_guard<std::mutex> lk(g_lock);

    if (g_layout) return true;

    int fd = open(path.c_str(), O_RDWR | O_CLOEXEC);
    if (fd < 0) return false;

    void* p = mmap(nullptr, sizeof(SharedLayout),
                   PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) {
        close(fd);
        return false;
    }

    g_fd = fd;
    g_layout = (SharedLayout*)p;
    g_is_owner = false;
    return true;
}

void overlay_unmap_region() {
    std::lock_guard<std::mutex> lk(g_lock);
    if (g_layout) {
        munmap(g_layout, sizeof(SharedLayout));
        g_layout = nullptr;
    }
    if (g_fd >= 0) {
        close(g_fd);
        g_fd = -1;
    }
    g_is_owner = false;
}

bool overlay_is_mapped() {
    std::lock_guard<std::mutex> lk(g_lock);
    return g_layout != nullptr;
}

SharedLayout* overlay_layout() {
    return g_layout;
}

} // namespace unoreverse