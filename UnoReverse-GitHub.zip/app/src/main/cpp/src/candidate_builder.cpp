// Uno Reverse — analytical candidate builder implementation.

#include "candidate_builder.h"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace unoreverse {

namespace {

// ---- Small vector helpers ------------------------------------------

inline Vec2 v_make(float x, float y) { return Vec2{ x, y }; }
inline Vec2 v_sub(Vec2 a, Vec2 b)   { return Vec2{ a.x - b.x, a.y - b.y }; }
inline Vec2 v_add(Vec2 a, Vec2 b)   { return Vec2{ a.x + b.x, a.y + b.y }; }
inline Vec2 v_mul(Vec2 a, float s)  { return Vec2{ a.x * s, a.y * s }; }
inline float v_dot(Vec2 a, Vec2 b)  { return a.x * b.x + a.y * b.y; }
inline float v_len2(Vec2 a)         { return a.x * a.x + a.y * a.y; }
inline float v_len(Vec2 a)          { return std::sqrt(v_len2(a)); }

inline Vec2 v_norm(Vec2 a) {
    float l = v_len(a);
    if (l < 1e-6f) return Vec2{ 0.f, 0.f };
    return Vec2{ a.x / l, a.y / l };
}

// ---- Cushion indices -----------------------------------------------

enum Cushion : int {
    CUSHION_LEFT   = 0,
    CUSHION_RIGHT  = 1,
    CUSHION_BOTTOM = 2,
    CUSHION_TOP    = 3,
};

Vec2 mirror_across(Vec2 p, int cushion, float W, float H) {
    switch (cushion) {
        case CUSHION_LEFT:   return v_make(-p.x, p.y);
        case CUSHION_RIGHT:  return v_make(2.f * W - p.x, p.y);
        case CUSHION_BOTTOM: return v_make(p.x, -p.y);
        case CUSHION_TOP:    return v_make(p.x, 2.f * H - p.y);
        default:             return p;
    }
}

float intersect_cushion(Vec2 S, Vec2 d, int cushion, float W, float H) {
    const float eps = 1e-6f;
    switch (cushion) {
        case CUSHION_LEFT:   if (std::fabs(d.x) < eps) return -1.f; return (0.f - S.x) / d.x;
        case CUSHION_RIGHT:  if (std::fabs(d.x) < eps) return -1.f; return (W  - S.x) / d.x;
        case CUSHION_BOTTOM: if (std::fabs(d.y) < eps) return -1.f; return (0.f - S.y) / d.y;
        case CUSHION_TOP:    if (std::fabs(d.y) < eps) return -1.f; return (H  - S.y) / d.y;
        default:             return -1.f;
    }
}

bool on_cushion(Vec2 p, int cushion, float W, float H, float margin) {
    switch (cushion) {
        case CUSHION_LEFT:   return p.y >= -margin && p.y <= H + margin && std::fabs(p.x) < margin;
        case CUSHION_RIGHT:  return p.y >= -margin && p.y <= H + margin && std::fabs(p.x - W) < margin;
        case CUSHION_BOTTOM: return p.x >= -margin && p.x <= W + margin && std::fabs(p.y) < margin;
        case CUSHION_TOP:    return p.x >= -margin && p.x <= W + margin && std::fabs(p.y - H) < margin;
        default:             return false;
    }
}

bool solve_direct(Vec2 S, Vec2 C, Vec2 P,
                  float R_s, float R_c,
                  float* out_angle, Vec2* out_ghost) {
    Vec2 cp = v_norm(v_sub(P, C));
    if (cp.x == 0.f && cp.y == 0.f) return false;
    Vec2 ghost = v_sub(C, v_mul(cp, R_s + R_c));
    Vec2 sg = v_sub(ghost, S);
    float d = v_len(sg);
    if (d < R_s * 0.5f) return false;

    Vec2 dir = v_norm(sg);
    if (dir.x == 0.f && dir.y == 0.f) return false;

    float alignment = v_dot(dir, cp);
    if (alignment <= 0.05f) return false;

    float cut = std::acos(std::max(-1.f, std::min(1.f, alignment)));
    if (cut > 1.396f) return false;

    *out_angle = std::atan2(sg.y, sg.x);
    *out_ghost = ghost;
    return true;
}

float point_segment_distance(Vec2 P, Vec2 A, Vec2 B) {
    Vec2 ab = v_sub(B, A);
    Vec2 ap = v_sub(P, A);
    float ab_len2 = v_len2(ab);
    if (ab_len2 < 1e-9f) return v_len(ap);
    float t = v_dot(ap, ab) / ab_len2;
    if (t < 0.f) t = 0.f;
    else if (t > 1.f) t = 1.f;
    Vec2 proj = v_add(A, v_mul(ab, t));
    return v_len(v_sub(P, proj));
}

bool path_clear(Vec2 A, Vec2 B,
                const BoardSnapshot& board,
                int ignore_coin_a, int ignore_coin_b,
                float coin_radius) {
    const float need = coin_radius * 2.f;
    const float need2 = need * need;
    for (int i = 0; i < board.coin_count; ++i) {
        if (i == ignore_coin_a || i == ignore_coin_b) continue;
        if (board.coins[i].is_pocketed) continue;
        Vec2 C{ board.coins[i].x, board.coins[i].y };
        float d = point_segment_distance(C, A, B);
        if (d * d < need2) return false;
    }
    return true;
}

inline Vec2 pocket_pos(const BoardSnapshot& b, int idx) {
    return Vec2{ b.pockets[idx][0], b.pockets[idx][1] };
}

float estimate_score(const Candidate& c) {
    float s = 1000.f;
    s -= c.path_length * 0.5f;
    s -= c.cut_angle * 200.f;
    s -= (float)c.bounce_count * 50.f;
    return s;
}

void fill_angle_grid(std::vector<float>& angles, float step_deg) {
    angles.clear();
    const int n = (int)(360.f / step_deg);
    angles.reserve((size_t)n);
    for (int i = 0; i < n; ++i) {
        angles.push_back(i * step_deg * 3.14159265f / 180.f);
    }
}

} // namespace

// ---------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------

void build_direct_candidates(const BoardSnapshot& board,
                             const PhysicsConfig& config,
                             std::vector<Candidate>& out) {
    out.clear();
    if (board.coin_count <= 0) return;

    const float R_s = board.striker_radius;
    const float R_c = board.coin_radius;
    const Vec2 S{ board.striker_x, board.striker_y };
    const int n_pockets = 4;

    for (int ci = 0; ci < board.coin_count; ++ci) {
        const CoinState& coin = board.coins[ci];
        if (coin.is_pocketed) continue;
        const Vec2 C{ coin.x, coin.y };

        for (int pi = 0; pi < n_pockets; ++pi) {
            const Vec2 P = pocket_pos(board, pi);
            float angle = 0.f;
            Vec2 ghost{ 0.f, 0.f };
            if (!solve_direct(S, C, P, R_s, R_c, &angle, &ghost)) continue;

            if (!path_clear(S, ghost, board, -1, ci, R_c)) continue;
            if (!path_clear(C, P, board, ci, -1, R_c)) continue;

            Candidate c{};
            c.angle        = angle;
            c.coin_idx     = ci;
            c.pocket_idx   = pi;
            c.cushion_mask = 0;
            c.bounce_count = 0;
            c.ghost_x      = ghost.x;
            c.ghost_y      = ghost.y;
            c.path_length  = v_len(v_sub(ghost, S)) + v_len(v_sub(P, C));
            {
                Vec2 cp = v_norm(v_sub(P, C));
                Vec2 dir = v_norm(v_sub(ghost, S));
                c.cut_angle = std::acos(std::max(-1.f, std::min(1.f, v_dot(dir, cp))));
            }
            c.score = estimate_score(c);
            out.push_back(c);
        }
    }
}

static void build_one_cushion(const BoardSnapshot& board,
                              std::vector<Candidate>& out) {
    const float R_s = board.striker_radius;
    const float R_c = board.coin_radius;
    const float W = board.board_width;
    const float H = board.board_height;
    const Vec2 S{ board.striker_x, board.striker_y };
    const float margin = 2.f;

    for (int ci = 0; ci < board.coin_count; ++ci) {
        const CoinState& coin = board.coins[ci];
        if (coin.is_pocketed) continue;
        const Vec2 C{ coin.x, coin.y };

        for (int pi = 0; pi < 4; ++pi) {
            const Vec2 P = pocket_pos(board, pi);

            for (int k = 0; k < 4; ++k) {
                const Vec2 mp = mirror_across(P, k, W, H);
                float angle = 0.f;
                Vec2 ghost{ 0.f, 0.f };
                if (!solve_direct(S, C, mp, R_s, R_c, &angle, &ghost)) continue;

                Vec2 dir{ std::cos(angle), std::sin(angle) };
                float t = intersect_cushion(S, dir, k, W, H);
                if (t <= 0.f) continue;
                Vec2 bounce = v_add(S, v_mul(dir, t));
                if (!on_cushion(bounce, k, W, H, margin)) continue;

                if (!path_clear(S, bounce, board, -1, ci, R_c)) continue;
                if (!path_clear(C, P, board, ci, -1, R_c)) continue;

                Candidate c{};
                c.angle        = angle;
                c.coin_idx     = ci;
                c.pocket_idx   = pi;
                c.cushion_mask = (1 << k);
                c.bounce_count = 1;
                c.bounce_x[0]  = bounce.x;
                c.bounce_y[0]  = bounce.y;
                c.ghost_x      = ghost.x;
                c.ghost_y      = ghost.y;
                c.path_length  = v_len(v_sub(bounce, S)) +
                                 v_len(v_sub(ghost, bounce)) +
                                 v_len(v_sub(P, C));
                {
                    Vec2 cp = v_norm(v_sub(P, C));
                    Vec2 d  = v_norm(v_sub(ghost, S));
                    c.cut_angle = std::acos(std::max(-1.f, std::min(1.f, v_dot(d, cp))));
                }
                c.score = estimate_score(c);
                out.push_back(c);
            }
        }
    }
}

static void build_two_cushion(const BoardSnapshot& board,
                              std::vector<Candidate>& out) {
    const float R_s = board.striker_radius;
    const float R_c = board.coin_radius;
    const float W = board.board_width;
    const float H = board.board_height;
    const Vec2 S{ board.striker_x, board.striker_y };
    const float margin = 2.f;

    for (int ci = 0; ci < board.coin_count; ++ci) {
        const CoinState& coin = board.coins[ci];
        if (coin.is_pocketed) continue;
        const Vec2 C{ coin.x, coin.y };

        for (int pi = 0; pi < 4; ++pi) {
            const Vec2 P = pocket_pos(board, pi);

            for (int k1 = 0; k1 < 4; ++k1) {
                for (int k2 = 0; k2 < 4; ++k2) {
                    if (k1 == k2) continue;
                    if ((k1 ^ 1) == k2 && (k1 >> 1) == (k2 >> 1)) continue;

                    Vec2 m1 = mirror_across(P, k1, W, H);
                    Vec2 m2 = mirror_across(m1, k2, W, H);

                    float angle = 0.f;
                    Vec2 ghost{ 0.f, 0.f };
                    if (!solve_direct(S, C, m2, R_s, R_c, &angle, &ghost)) continue;

                    Vec2 dir{ std::cos(angle), std::sin(angle) };
                    float t1 = intersect_cushion(S, dir, k1, W, H);
                    if (t1 <= 0.f) continue;
                    Vec2 b1 = v_add(S, v_mul(dir, t1));
                    if (!on_cushion(b1, k1, W, H, margin)) continue;

                    float t2 = intersect_cushion(b1, dir, k2, W, H);
                    if (t2 <= 0.f) continue;
                    Vec2 b2 = v_add(b1, v_mul(dir, t2));
                    if (!on_cushion(b2, k2, W, H, margin)) continue;

                    if (!path_clear(S, b1, board, -1, ci, R_c)) continue;
                    if (!path_clear(b1, b2, board, -1, ci, R_c)) continue;
                    if (!path_clear(C, P, board, ci, -1, R_c)) continue;

                    Candidate c{};
                    c.angle        = angle;
                    c.coin_idx     = ci;
                    c.pocket_idx   = pi;
                    c.cushion_mask = (1 << k1) | (1 << k2);
                    c.bounce_count = 2;
                    c.bounce_x[0]  = b1.x; c.bounce_y[0] = b1.y;
                    c.bounce_x[1]  = b2.x; c.bounce_y[1] = b2.y;
                    c.ghost_x      = ghost.x;
                    c.ghost_y      = ghost.y;
                    c.path_length  = v_len(v_sub(b1, S)) +
                                     v_len(v_sub(b2, b1)) +
                                     v_len(v_sub(ghost, b2)) +
                                     v_len(v_sub(P, C));
                    {
                        Vec2 cp = v_norm(v_sub(P, C));
                        Vec2 d  = v_norm(v_sub(ghost, S));
                        c.cut_angle = std::acos(std::max(-1.f, std::min(1.f, v_dot(d, cp))));
                    }
                    c.score = estimate_score(c);
                    out.push_back(c);
                }
            }
        }
    }
}

void build_candidates(const BoardSnapshot& board,
                      const PhysicsConfig& config,
                      int profile,
                      std::vector<Candidate>& out) {
    out.clear();
    if (board.coin_count <= 0) return;

    build_direct_candidates(board, config, out);

    if (profile != 3) {
        build_one_cushion(board, out);
    }

    if (profile == 1) {
        build_two_cushion(board, out);
    }

    if (profile == 2 && out.size() > 120) {
        std::partial_sort(out.begin(), out.begin() + 120, out.end(),
            [](const Candidate& a, const Candidate& b) {
                return a.score > b.score;
            });
        out.resize(120);
    }

    sort_candidates(out);
}

void sort_candidates(std::vector<Candidate>& candidates) {
    std::stable_sort(candidates.begin(), candidates.end(),
        [](const Candidate& a, const Candidate& b) {
            return a.score > b.score;
        });
}

} // namespace unoreverse