#include "candidate_builder.h"
#include "unoreverse.h"
int build_candidates(const BoardState* board, Candidate* out, int max) {
    // ghost-ball + mirrored cushions
    if (!board || !out || max <= 0) return 0;
    out[0].angle = 0; out[0].power = 0.5f; out[0].score = 1.f; out[0].cushions = 0;
    return 1;
}
