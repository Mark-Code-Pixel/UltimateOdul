// Uno Reverse — compile-time ABI verification.
//
// This translation unit produces no object code. It exists so the
// static asserts below run for both ABIs. If any assertion fails the
// build stops before the .so is written, which is exactly when the
// developer most needs to know that a struct layout changed.

#include <cstdint>
#include <cstddef>
#include <atomic>
#include <type_traits>

namespace {

// ---- ABI macros ---------------------------------------------------

#if defined(UNOREVERSE_64) && UNOREVERSE_64 == 1
static_assert(sizeof(void*) == 8, "64-bit build must have 8-byte pointers");
static_assert(sizeof(uintptr_t) == 8, "uintptr_t must be 8 bytes");
#elif defined(UNOREVERSE_32) && UNOREVERSE_32 == 1
static_assert(sizeof(void*) == 4, "32-bit build must have 4-byte pointers");
static_assert(sizeof(uintptr_t) == 4, "uintptr_t must be 4 bytes");
#else
#error "UNOREVERSE_32 or UNOREVERSE_64 must be defined by CMake"
#endif

// ---- Fixed-width primitives ---------------------------------------

static_assert(sizeof(float)    == 4, "float must be 32-bit");
static_assert(sizeof(double)   == 8, "double must be 64-bit");
static_assert(sizeof(int8_t)   == 1, "int8_t must be 1 byte");
static_assert(sizeof(int16_t)  == 2, "int16_t must be 2 bytes");
static_assert(sizeof(int32_t)  == 4, "int32_t must be 4 bytes");
static_assert(sizeof(int64_t)  == 8, "int64_t must be 8 bytes");
static_assert(sizeof(uint8_t)  == 1, "uint8_t must be 1 byte");
static_assert(sizeof(uint16_t) == 2, "uint16_t must be 2 bytes");
static_assert(sizeof(uint32_t) == 4, "uint32_t must be 4 bytes");
static_assert(sizeof(uint64_t) == 8, "uint64_t must be 8 bytes");

// ---- Atomics ------------------------------------------------------
//
// The command and response rings depend on lock-free 32-bit atomics.
// If these are not lock-free on the target, the ring implementation
// would need a mutex and the hot path would slow down noticeably. The
// asserts guarantee we hear about that at build time.

static_assert(std::atomic<int32_t>::is_always_lock_free,
              "atomic<int32_t> must be lock-free");
static_assert(std::atomic<uint32_t>::is_always_lock_free,
              "atomic<uint32_t> must be lock-free");
static_assert(std::atomic<int64_t>::is_always_lock_free,
              "atomic<int64_t> must be lock-free on the supported ABIs");
static_assert(std::atomic<float>::is_always_lock_free,
              "atomic<float> must be lock-free");

// ---- Struct packing ------------------------------------------------
//
// Every struct mirrored from a guest object uses fixed-width fields and
// no natural alignment surprises. These assertions protect against a
// compiler or ABI change that would silently shift field offsets.

struct Padded32 {
    float    x;
    float    y;
    int32_t  a;
    int32_t  b;
};
static_assert(sizeof(Padded32) == 16, "Padded32 must be 16 bytes");

struct Padded64 {
    uint64_t p;
    float    x;
    float    y;
    uint32_t pad;
};
static_assert(sizeof(Padded64) == 24, "Padded64 must be 24 bytes");

// ---- Enum width --------------------------------------------------

enum class CommandKind : int32_t { A = 0, B = 1 };
static_assert(sizeof(CommandKind) == 4, "enum class with int32_t backing must be 4 bytes");

} // namespace