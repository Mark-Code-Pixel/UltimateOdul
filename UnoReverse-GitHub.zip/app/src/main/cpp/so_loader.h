#pragma once
/**
 * Load extracted libgame-CARROM into our process address space for
 * symbol inspection / optional local analysis.
 * Guest game still runs as its own process; this is for offline RE hooks
 * and verifying the extracted SO matches the live module.
 *
 * Dual ABI: path chosen by caller (arm64 vs armv7 under uno_engine/).
 */
#include <cstdint>
#include <string>

namespace uno {

struct LoadedSo {
    bool        ok = false;
    void*       handle = nullptr;
    uintptr_t   base = 0;
    std::string path;
    std::string error;
};

/** dlopen extracted engine SO (RTLD_NOW | RTLD_LOCAL). */
LoadedSo loadExtractedEngine(const char* absolutePath);

/** dlclose if opened. */
void unloadSo(LoadedSo& so);

/**
 * Compare live process module base name against extracted file basename.
 * Returns true when a mapped module matches libgame-CARROM*1477*.
 */
bool liveEngineMatchesExtract(pid_t pid, const char* extractedBasename);

} // namespace uno
