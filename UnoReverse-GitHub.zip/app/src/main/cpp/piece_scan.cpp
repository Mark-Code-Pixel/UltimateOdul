#include "piece_scan.h"
#include "memory.h"
#include <android/log.h>
#include <algorithm>
#include <cmath>
#include <vector>
#include <cstring>

#define LOG_TAG "UnoPieceScan"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)

namespace uno {

static bool inBoard(float v, const PieceScanConfig& c) {
    return v >= c.boardMin && v <= c.boardMax && std::isfinite(v);
}

static bool plausiblePair(float x, float y, const PieceScanConfig& c) {
    return inBoard(x, c) && inBoard(y, c);
}

/**
 * Read a window of memory and search for sequences of float x,y pairs
 * that look like pieces on a carrom table.
 */
bool scanPieceCluster(
    pid_t pid,
    const PhysicsAnchor& phys,
    const PieceScanConfig& cfg,
    BoardSnapshot* out
) {
    if (!out) return false;
    out->valid = false;
    out->pieces.clear();
    if (pid <= 0 || !phys.found) return false;

    uintptr_t center = phys.blockAddr ? phys.blockAddr : phys.moduleBase;
    if (!center) return false;

    uintptr_t start = (center > cfg.searchRadius) ? (center - cfg.searchRadius) : 0;
    uintptr_t end = center + cfg.searchRadius;

    // Prefer module bounds if available
    if (phys.moduleBase && phys.moduleEnd > phys.moduleBase) {
        start = phys.moduleBase;
        end = phys.moduleEnd;
        // also allow a bit past module for BSS
        if (end - start < cfg.searchRadius) end = start + cfg.searchRadius;
    }

    const size_t chunk = 0x10000;
    std::vector<uint8_t> buf(chunk);
    int bestScore = 0;
    std::vector<Piece> best;

    for (uintptr_t addr = start; addr + 64 < end; addr += (chunk / 2)) {
        size_t toRead = std::min(chunk, (size_t)(end - addr));
        if (!readRemote(pid, addr, buf.data(), toRead)) continue;

        // slide by 4 bytes looking for dense float-pair clusters
        for (size_t off = 0; off + 32 < toRead; off += 4) {
            std::vector<Piece> cluster;
            // try stride 8 (x,y packed) and 16 (x,y + padding)
            for (int stride : {8, 12, 16, 20, 24, 32}) {
                cluster.clear();
                for (int i = 0; i < cfg.maxPieces; i++) {
                    size_t o = off + (size_t)i * (size_t)stride;
                    if (o + 8 > toRead) break;
                    float x, y;
                    std::memcpy(&x, buf.data() + o, 4);
                    std::memcpy(&y, buf.data() + o + 4, 4);
                    if (!plausiblePair(x, y, cfg)) {
                        if (cluster.size() >= (size_t)cfg.minPieces) break;
                        if (!cluster.empty()) break; // gap ends cluster for this stride
                        continue;
                    }
                    // reject near-duplicates
                    bool dup = false;
                    for (const auto& p : cluster) {
                        float dx = p.pos.x - x, dy = p.pos.y - y;
                        if (dx * dx + dy * dy < 0.25f) { dup = true; break; }
                    }
                    if (dup) continue;
                    Piece pc;
                    pc.pos = {x, y};
                    pc.id = (int)cluster.size();
                    cluster.push_back(pc);
                }
                if ((int)cluster.size() < cfg.minPieces) continue;

                // score: count + spatial spread (not all stacked)
                float minx = cluster[0].pos.x, maxx = minx, miny = cluster[0].pos.y, maxy = miny;
                for (const auto& p : cluster) {
                    minx = std::min(minx, p.pos.x);
                    maxx = std::max(maxx, p.pos.x);
                    miny = std::min(miny, p.pos.y);
                    maxy = std::max(maxy, p.pos.y);
                }
                float spread = (maxx - minx) + (maxy - miny);
                if (spread < 8.f) continue; // too tight = false positive

                int score = (int)cluster.size() * 10 + (int)spread;
                if (score > bestScore) {
                    bestScore = score;
                    best = std::move(cluster);
                    out->boardMinX = minx;
                    out->boardMaxX = maxx;
                    out->boardMinY = miny;
                    out->boardMaxY = maxy;
                }
            }
        }
    }

    if (bestScore < cfg.minPieces * 10 + 8) {
        LOGW("no confident piece cluster (best=%d)", bestScore);
        return false;
    }

    // Striker = often largest radius proxy: pick piece nearest center of mass as optional
    float cx = 0, cy = 0;
    for (const auto& p : best) { cx += p.pos.x; cy += p.pos.y; }
    cx /= (float)best.size();
    cy /= (float)best.size();

    out->pieces = std::move(best);
    out->striker = {cx, cy}; // refined later when striker signature locked
    out->valid = true;
    LOGI("piece cluster valid n=%zu score=%d", out->pieces.size(), bestScore);
    return true;
}

} // namespace uno
