// Uno Reverse — analytical candidate builder.
//
// Given a board snapshot and the physics constants, produces an ordered
// list of analytically-valid shots: every direct shot and every
// one-/two-/three-cushion bank that geometrically reaches a pocket
// without the striker passing through another coin on the way.
//
// The physics simulation runs afterward, on the top N candidates, to
// verify each one and score it. This module is pure geometry. It does
// not integrate anything. It produces candidates in microseconds.
#pragma once

#include "shared_mem.h"

#include <cstdint>
#include <vector>

namespace unoreverse {

// A candidate shot: aim angle, plus the geometric bounce points so the
// overlay can draw the full multi-cushion path.
struct Candidate {
    float   angle;
    float   score;         // higher is better; filled by the scorer
    int32_t coin_idx;      // index into BoardSnapshot.coins
    int32_t pocket_idx;    // 0..3
    int32_t cushion_mask;  // bit 0 = left, 1 = right, 2 = bottom, 3 = top
    int32_t bounce_count;  // 0..3
    float   bounce_x[3];
    float   bounce_y[3];
    float   ghost_x;       // striker center at moment of contact
    float   ghost_y;
    float   path_length;   // total travel distance, in board units
    float   cut_angle;     // radians; lower is a fuller hit
};

// Build candidates for the given board. The profile controls how
// aggressively the search runs:
//   1 = Full       — 0.5 deg angular step, all cushions, no cap
//   2 = Lean       — 3.0 deg coarse then 0.25 deg fine, cap at 120
//   3 = DirectOnly — direct shots only, no bank shots
//
// Results are appended to `out`, which is cleared first. The function
// never allocates inside the loop; `out` is expected to be reserved to
// at least 512 elements by the caller.
void build_candidates(const BoardSnapshot& board,
                      const PhysicsConfig& config,
                      int profile,
                      std::vector<Candidate>& out);

// Build only direct candidates.
void build_direct_candidates(const BoardSnapshot& board,
                             const PhysicsConfig& config,
                             std::vector<Candidate>& out);

// Sort candidates by score descending.
void sort_candidates(std::vector<Candidate>& candidates);

} // namespace unoreverse