#pragma once
#include "unoreverse.h"
int build_candidates(const BoardState* board, Candidate* out, int max);
