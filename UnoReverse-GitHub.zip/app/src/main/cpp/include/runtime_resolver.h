// Uno Reverse — runtime offset resolver interface.
#pragma once

#include <string>

namespace unoreverse {

// Reads metadata_report.json (produced by the static OffsetPipeline)
// and writes offsets.json at output_path. Returns true when at least
// the coin class and one method RVA were resolved.
//
// Runs inside the guest process, after the IL2CPP runtime is up.
// out_reason receives a short human-readable failure message on false.
bool runtime_resolve_offsets(const std::string& metadata_report_path,
                             const std::string& output_path,
                             std::string* out_reason);

} // namespace unoreverse