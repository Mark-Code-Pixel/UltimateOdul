// Uno Reverse — memory reader for guest objects.
//
// Because the agent runs INSIDE the guest process (same UID, same
// address space), reads are direct pointer dereferences. No
// process_vm_readv. This is roughly fifty times faster than the same
// operation from an external process.
//
// All offsets come from offsets_get(). None are hardcoded.
#pragma once

#include <cstdint>
#include <string>

namespace unoreverse {

// Locate a loaded module's base address by scanning /proc/self/maps.
// Returns 0 if not found.
uintptr_t find_module_base(const std::string& module_name);

// Wait for a module to appear, up to timeout_ms. Returns base or 0.
uintptr_t wait_for_module(const std::string& module_name, int timeout_ms);

// Direct field read at obj + offset. Caller guarantees the address is
// valid. No bounds checking — this is called from hot loops.
template <typename T>
inline T read_field(void* obj, uint32_t offset) {
    return *reinterpret_cast<T*>(reinterpret_cast<uint8_t*>(obj) + offset);
}

template <typename T>
inline void write_field(void* obj, uint32_t offset, T value) {
    *reinterpret_cast<T*>(reinterpret_cast<uint8_t*>(obj) + offset) = value;
}

// Atomic write for the ready_to_fire flag and other cross-thread fields.
template <typename T>
inline void write_field_atomic(void* obj, uint32_t offset, T value) {
    auto* p = reinterpret_cast<std::atomic<T>*>(
        reinterpret_cast<uint8_t*>(obj) + offset);
    p->store(value, std::memory_order_release);
}

// Read from raw address.
template <typename T>
inline T read_at(uintptr_t addr) {
    return *reinterpret_cast<T*>(addr);
}

} // namespace unoreverse