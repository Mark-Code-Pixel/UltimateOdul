#pragma once
#include <cstdint>
uintptr_t find_module_base(const char* name);
bool read_mem(uintptr_t addr, void* buf, size_t len);
