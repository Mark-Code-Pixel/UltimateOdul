// Uno Reverse — runtime agent interface.
// ABI-agnostic. No engine assumed. No specific library named.
#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>

namespace unoreverse {

// A loaded native module observed in /proc/self/maps.
struct LoadedModule {
    std::string path;
    uint64_t    base_addr;
    uint64_t    size_bytes;
    std::string sha256;
};

// A DEX file observed either on disk (in the guest's virtual APK dir)
// or in the classloader chain at runtime.
struct DexFileRecord {
    std::string path;
    uint64_t    size_bytes;
    std::string sha256;
    bool        from_classloader;
};

// A JNI method registered via RegisterNatives.
struct JniBinding {
    std::string class_name;
    std::string method_name;
    std::string signature;
    uint64_t    fn_ptr;
    std::string module;
};

// An open file descriptor observed in /proc/self/fd.
struct FdRecord {
    int         fd;
    std::string path;
    std::string mode;
};

// Engine fingerprint learned by observation.
enum class EngineKind {
    Unknown,
    UnityIl2Cpp,
    UnityMono,
    UnityGeneric,
    Cocos2d,
    Flutter,
    Unreal,
    ReactNative,
    Godot,
    CustomNative
};

struct InventoryResult {
    EngineKind engine;
    float      engine_confidence;

    std::vector<LoadedModule> loaded_modules;
    std::vector<DexFileRecord> dex_files;
    std::vector<JniBinding>   jni_bindings;
    std::vector<FdRecord>     open_fds;
    int                       anonymous_exec_regions;

    bool        complete;
    std::string failure_reason;
    uint64_t    start_time_ms;
    uint64_t    dump_time_ms;
    int         pid;
};

// ---- Public API -----------------------------------------------------

// Called once by the JNI bridge. Initializes shared memory and reads the
// static extraction report.
bool agent_init(const std::string& agent_dir, const std::string& ashmem_name);

// Begin the 5-second settling dump. Runs on a background thread.
// Writes runtime_inventory.json to the output path when finished.
bool agent_start_runtime_dump(const std::string& guest_pkg,
                              const std::string& output_path);

bool agent_inventory_complete();
std::string agent_engine_name();
std::string agent_active_abi();
std::string agent_default_profile();
void agent_shutdown();

} // namespace unoreverse