#pragma once
void binder_hook_install();
