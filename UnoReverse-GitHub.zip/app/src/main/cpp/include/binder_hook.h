// Uno Reverse — Binder ioctl hook for the guest process.
//
// The Java-level ServiceManagerProxy handles high-level Binder traffic
// that passes through ServiceManager.getService(). Native calls that
// bypass the Java layer — Google Play Services, Facebook SDK, some
// system services — go straight to ioctl() on /dev/binder and never
// reach the proxy.
//
// This file installs the native hook that catches those calls. The two
// things it does for the container:
//
//   1. UID spoofing. When a framework service asks the kernel for the
//      caller's UID, the reply parcel is rewritten to the guest's
//      original UID. This is what makes Google Sign-In, Facebook
//      Login, and Play Integrity reach the expected auth paths.
//
//   2. Package hiding. getInstalledPackages replies are filtered so
//      the container and other guests do not appear in the list.
//
// Everything else is passed through untouched. The hook does not
// rewrite transaction codes it does not recognize.
//
// The struct layout of binder_transaction_data differs between Android
// versions and between 32-bit and 64-bit. The implementation probes the
// layout once at install time and refuses to rewrite if the probe
// fails. A failed probe is safe: the hook passes every transaction
// through unchanged.
#pragma once

#include <cstdint>

namespace unoreverse {

// Arm the hook. guest_uid must be the guest's original UID (the value
// that the framework expects to see). Pass 0 to disable UID spoofing.
// Pass an empty package name to disable package hiding.
bool binder_hook_install(int guest_uid,
                         const char* guest_package,
                         const char* container_package);

// Remove the hook. Safe to call when not installed.
void binder_hook_uninstall();

// True if the hook is installed and the layout probe succeeded.
bool binder_hook_ready();

// Diagnostic counters, readable from the container for logging.
struct BinderHookStats {
    uint64_t transactions_seen;
    uint64_t uid_replies_rewritten;
    uint64_t package_lists_filtered;
    uint64_t rewrites_skipped_due_to_layout;
};
BinderHookStats binder_hook_stats();

} // namespace unoreverse