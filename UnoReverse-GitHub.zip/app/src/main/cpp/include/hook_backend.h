#pragma once
bool hook_install(void* target, void* replace, void** original);
