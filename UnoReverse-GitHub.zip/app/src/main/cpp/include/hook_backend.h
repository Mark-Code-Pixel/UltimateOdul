// Uno Reverse — hook backend dispatcher.
//
// At runtime we prefer Dobby when it is available (it has a mature
// trampoline allocator and ABI handling). When it is not, we fall back to
// mini_hook, a self-contained inline hook that works on ARM32 and ARM64
// without external dependencies.
//
// The dispatcher is chosen once at agent init and reused for every hook.
// Callers never care which backend is active.
#pragma once

#include <cstdint>

namespace unoreverse {

enum class HookBackendKind {
    None,
    Dobby,
    Mini
};

// Install a hook: redirect `target` to `handler`, store the original
// function pointer in *out_original. Returns true on success.
bool hook_install(void* target, void* handler, void** out_original);

// Remove a previously installed hook. Returns true on success.
bool hook_uninstall(void* target);

// Which backend is active.
HookBackendKind hook_backend_kind();

// Human-readable backend name.
const char* hook_backend_name();

} // namespace unoreverse