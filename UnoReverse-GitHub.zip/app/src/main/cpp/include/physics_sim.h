#pragma once
#include "unoreverse.h"
StepResult simulate(const BoardState* in, float angle, float power, const PhysicsConfig* cfg);
