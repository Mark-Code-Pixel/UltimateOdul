// Uno Reverse — deterministic 2D rigid-body simulator.
//
// Models the guest's physics closely enough that a verified shot in
// simulation matches the game's outcome. Semi-implicit Euler with the
// game's own fixed_dt, gravity, restitution, and friction, read live
// from the guest's Rigidbody2D components.
//
// Bounded. Fixed-size arrays. No heap in step() or advance(). No
// -ffast-math so the result is bit-identical across runs on the same
// device and build.
#pragma once

#include "shared_mem.h"

namespace unoreverse {

// Internal representation. one body per coin plus one striker.
struct SimBody {
    float    x, y;
    float    vx, vy;
    float    mass;
    float    inv_mass;
    float    radius;
    int32_t  type;         // -1 = striker, 0..n-1 = coin index
    int32_t  is_pocketed;
    uint32_t _pad;
};

struct SimWorld {
    SimBody  bodies[MAX_COINS + 1];
    int32_t  body_count;    // coins + 1 striker
    int32_t  coin_count;

    float    W, H;
    float    pockets[4][2];
    float    pocket_capture_radius;

    float    gravity_x, gravity_y;
    float    fixed_dt;
    int32_t  solver_iterations;
    float    restitution;
    float    friction;
    float    cushion_restitution;
    float    cushion_friction;
    float    linear_drag;
    float    angular_drag;

    // Recorded at init so post-step comparisons can detect what changed.
    float    initial_x[MAX_COINS + 1];
    float    initial_y[MAX_COINS + 1];
};

// Build a SimWorld from a snapshot and config.
void sim_init(SimWorld& world,
              const BoardSnapshot& board,
              const PhysicsConfig& config);

// Advance the world one fixed timestep. Integrates positions, resolves
// collisions iteratively, then flags bodies that landed in a pocket.
void sim_step(SimWorld& world);

// Total linear kinetic energy across all non-pocketed bodies.
float sim_kinetic_energy(const SimWorld& world);

// Run steps until the world settles or max_steps is hit. Returns the
// number of steps actually executed.
int sim_advance(SimWorld& world, int max_steps);

// True if the striker has been pocketed (a scratch).
bool sim_striker_pocketed(const SimWorld& world);

// True if any coin moved from its initial position by more than epsilon.
bool sim_any_coin_moved(const SimWorld& world, float epsilon = 0.005f);

// Number of coins that were on the board initially and are pocketed now.
int sim_count_pocketed_coins(const SimWorld& world);

// Exact impulse application. Used by fast_verify to launch the striker
// before stepping.
void sim_apply_impulse(SimBody& striker, float angle_rad, float power,
                       float max_power);

// Find helpers — return nullptr if not present.
SimBody*       sim_find_striker(SimWorld& world);
const SimBody* sim_find_striker(const SimWorld& world);
const SimBody* sim_find_coin(const SimWorld& world, int coin_idx);

} // namespace unoreverse