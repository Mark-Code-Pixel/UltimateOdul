// Uno Reverse — shared memory channel between the guest agent and the
// host process (which owns the overlay and the solver).
//
// Layout:
//   [StateHeader]              — atomics for control flags + seq
//   [BoardSnapshot]            — latest board state from the guest
//   [PhysicsConfig]            — constants read from the guest
//   [CandidateLines[64]]       — candidate shots for the overlay
//   [CommandRing[256]]         — host -> agent commands
//   [ResponseRing[256]]        — agent -> host responses
//
// All cross-thread fields are std::atomic. No raw pointers cross the
// channel. Sizes are fixed. ABI-neutral — the struct uses only fixed-
// width types and is identical between 32-bit and 64-bit builds.
//
// Two open modes:
//   shared_mem_open(name)       — creates a new ashmem region in this
//                                 process (container side).
//   shared_mem_open_path(path)  — opens an existing region by fd path
//                                 (guest side, overlay side).
//
// The container creates the region, writes /proc/<pid>/fd/<n> to a
// file inside the virtual directory, and passes that path to the guest
// via the UNOREVERSE_SHM_PATH environment variable. The guest and the
// overlay both open by path. Same-UID access is the only requirement.
#pragma once

#include <cstdint>
#include <atomic>
#include <string>

namespace unoreverse {

constexpr int MAX_COINS       = 20;
constexpr int MAX_CANDIDATES  = 512;
constexpr int MAX_LINES       = 64;
constexpr int RING_CAPACITY   = 256;
constexpr int STATUS_TEXT_LEN = 128;

struct Vec2 { float x, y; };

struct CoinState {
    float x, y;
    float vx, vy;
    float mass;
    float friction;
    int32_t type;
    int32_t is_pocketed;
    uint32_t padding;
};

struct BoardSnapshot {
    float W, H;
    int32_t coin_count;
    CoinState coins[MAX_COINS];
    float striker_x, striker_y;
    float pockets[4][2];
    float striker_radius;
    float coin_radius;
};

struct PhysicsConfig {
    float gravity_x, gravity_y;
    float fixed_dt;
    int32_t solver_iterations;
    float coin_restitution;
    float coin_friction;
    float cushion_restitution;
    float cushion_friction;
    float striker_mass;
    float coin_mass;
    float linear_drag;
    float angular_drag;
    float max_power;
};

struct Line {
    float x0, y0, x1, y1;
    uint32_t color;
};

enum class CmdKind : int32_t {
    Nop            = 0,
    SetAutoplay    = 1,
    SetAutoqueue   = 2,
    SetKeepLine    = 3,
    SetShowLines   = 4,
    SetLineCount   = 5,
    SetSolveRateHz = 6,
    SetProfile     = 7,
    ForceSolve     = 8,
    ReloadOffsets  = 9,
    Shutdown       = 10,
};

struct Command {
    std::atomic<int32_t> seq;
    std::atomic<int32_t> kind;
    std::atomic<int64_t> arg;
    std::atomic<int32_t> ack;
};

struct Response {
    std::atomic<int32_t> seq;
    std::atomic<int32_t> code;
    std::atomic<int64_t> value;
};

struct StateHeader {
    std::atomic<uint32_t> seq;
    std::atomic<int32_t>  running;
    std::atomic<int32_t>  agent_ready;

    std::atomic<int32_t>  autoplay;
    std::atomic<int32_t>  autoqueue;
    std::atomic<int32_t>  keep_line;
    std::atomic<int32_t>  show_lines;
    std::atomic<int32_t>  is_my_turn;
    std::atomic<int32_t>  ready_to_fire;
    std::atomic<int32_t>  line_count;
    std::atomic<int32_t>  solve_rate_hz;
    std::atomic<int32_t>  profile;

    std::atomic<float>    best_angle;
    std::atomic<float>    best_power;
    std::atomic<int32_t>  best_coin_idx;
    std::atomic<int32_t>  best_pocket_idx;

    std::atomic<int32_t>  agent_pid;
    std::atomic<int32_t>  solve_time_us;
    std::atomic<int32_t>  candidate_count;
    std::atomic<int32_t>  foul_rejects;

    std::atomic<uint32_t> cmd_head;
    std::atomic<uint32_t> cmd_tail;
    std::atomic<uint32_t> rsp_head;
    std::atomic<uint32_t> rsp_tail;

    char status_text[STATUS_TEXT_LEN];
    uint32_t _pad0;
};

struct SharedLayout {
    StateHeader   header;
    BoardSnapshot board;
    PhysicsConfig config;
    Line          lines[MAX_LINES];
    Command       commands[RING_CAPACITY];
    Response      responses[RING_CAPACITY];
};

// ---- Public API -----------------------------------------------------

// Create a fresh region in this process and mmap it. Returns true on
// success. Sets the internal fd to the new ashmem fd.
bool shared_mem_open(const char* name);

// Open an existing region by fd path. The path is typically
// /proc/<owner_pid>/fd/<n>. Returns true on success.
bool shared_mem_open_path(const std::string& path);

// Open the region by inspecting the environment:
//   UNOREVERSE_SHM_PATH  — preferred, direct open by path
//   UNOREVERSE_SHM_FD    — fallback, inherited fd number
// If neither is set, creates a fresh region using `name`.
// Returns true on success.
bool shared_mem_open_auto(const char* name);

void shared_mem_close();

SharedLayout* shared_mem_layout();

bool shared_mem_push_command(CmdKind kind, int64_t arg);
bool shared_mem_pop_command(Command* out);
bool shared_mem_push_response(int32_t code, int64_t value);
bool shared_mem_pop_response(Response* out);
void shared_mem_publish();

// Returns the /proc/<pid>/fd/<n> path of the current region. Empty if
// not open. Only valid in the process that created the region.
std::string shared_mem_owner_path();

} // namespace unoreverse