#pragma once
#include "unoreverse.h"
SharedState* shared_create();
