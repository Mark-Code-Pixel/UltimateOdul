// Uno Reverse — shared memory bridge for the host process.
//
// The container process creates the ashmem region and writes its
// /proc/<pid>/fd/<n> path to disk. The host process opens that path,
// gets a second fd to the same region, and mmaps it.
//
// This is the only way to share anonymous memory between two
// processes under the same UID without Binder.
#pragma once

#include <cstdint>

#include "shared_mem.h"

namespace unoreverse {

// Create a fresh region in this process. Returns the /proc path string
// that other same-UID processes can open. Empty string on failure.
std::string overlay_create_region();

// Map an existing region by path. Returns true on success.
bool overlay_map_region(const std::string& path);

// Tear down the mapping.
void overlay_unmap_region();

// Is the region mapped?
bool overlay_is_mapped();

// Direct access. Null if not mapped.
SharedLayout* overlay_layout();

} // namespace unoreverse