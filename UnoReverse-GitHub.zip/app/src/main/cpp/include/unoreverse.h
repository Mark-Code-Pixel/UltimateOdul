#pragma once
#include <cstdint>
#include <atomic>
#include <cstring>

struct Vec2 { float x, y; };
struct CoinState { Vec2 pos; Vec2 vel; float radius; int32_t id; int32_t pocketed; };
struct BoardState { CoinState coins[20]; int32_t count; Vec2 cue; float angle; float power; };
struct PhysicsConfig { float friction; float restitution; float gravity; };
struct Candidate { float angle; float power; float score; int32_t cushions; };
struct StepResult { BoardState state; int32_t scratched; int32_t valid; };
struct Line { float x0, y0, x1, y1; };
struct SharedState {
    std::atomic<int32_t> seq;
    std::atomic<int32_t> autoPlay;
    std::atomic<int32_t> solveRate;
    float chosenLine[4];
    float candidates[64][4];
    int32_t candidateCount;
};
