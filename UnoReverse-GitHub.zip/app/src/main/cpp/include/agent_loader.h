// Uno Reverse — guest agent loader.
//
// The agent (libunoreverse.so) must be loaded into the guest process
// before the guest's own native libraries, so that its constructor runs
// first and installs the ioctl hook that captures RegisterNatives.
//
// Three load paths, tried in order:
//
//   1. DT_NEEDED injection. At import time the container makes a copy
//      of the guest's primary .so and appends a DT_NEEDED entry for
//      libunoreverse.so. The linker then loads the agent automatically
//      when the guest's own library is loaded.
//
//   2. LD_LIBRARY_PATH + preload. The container sets LD_LIBRARY_PATH
//      to include both the agent's directory and the guest's virtual
//      lib directory, and preloads libunoreverse.so. This is the
//      fallback for library layouts the DT_NEEDED path cannot handle.
//
//   3. Direct dlopen. As a last resort the loader dlopens the agent
//      from GuestMain, before anything else.
//
// This header declares the API used by agent.cpp and GuestMain. The
// implementation tries each path and reports which succeeded.
#pragma once

#include <string>

namespace unoreverse {

enum class LoadResult {
    Success,
    LibraryNotFound,
    DlopenFailed,
    DtNeededFailed,
    NotAttempted
};

struct LoadReport {
    LoadResult result = LoadResult::NotAttempted;
    std::string method;         // "dt_needed" | "preload" | "dlopen" | ""
    std::string agent_path;
    std::string detail;         // Human-readable, for the log
};

// Attempt to load the agent. Called once, from GuestMain, before any
// guest native library is loaded.
//
//   agent_path     — absolute path to libunoreverse.so
//   guest_lib_dir  — the guest's virtual lib directory
//   guest_pkg      — the guest package name (for logging)
LoadReport agent_loader_load(const std::string& agent_path,
                             const std::string& guest_lib_dir,
                             const std::string& guest_pkg);

// Record that the DT_NEEDED path was applied at import time. The
// loader consults this flag to skip the fallback paths.
void agent_loader_mark_dt_needed(const std::string& agent_basename);

// True if the DT_NEEDED path is armed.
bool agent_loader_dt_needed_armed();

} // namespace unoreverse