// Uno Reverse — runtime NEON detection and dispatch.
//
// The solver's hot loops use vector math. On ARM32 devices that support
// NEON, the compiler generates NEON instructions when the flags allow.
// On devices without NEON (older Cortex-A7/A9 with NEON disabled), the
// compiler falls back to scalar VFP, which is 3-4x slower.
//
// At agent init we probe /proc/cpuinfo once and record the result. The
// solver reads this flag to pick between Full, Lean, and DirectOnly
// profiles. No code branching inside the hot loop — the profile is
// chosen once, then the appropriate path runs for the whole session.
#pragma once

namespace unoreverse {

// True if the CPU supports NEON (ARM) or ASIMD (ARM64 — mandatory).
bool neon_available();

// Recorded CPU core count from /proc/cpuinfo, clamped to [1, 16].
int cpu_core_count();

// Recorded total RAM in bytes. Zero if unknown.
unsigned long long total_ram_bytes();

// Call once at agent init. Reads /proc/cpuinfo and /proc/meminfo.
void platform_probe();

// Human-readable profile name for the current device.
// "full" | "lean" | "direct-only"
const char* selected_profile_name();

// Numeric profile id: 1=full, 2=lean, 3=direct-only.
int selected_profile();

} // namespace unoreverse