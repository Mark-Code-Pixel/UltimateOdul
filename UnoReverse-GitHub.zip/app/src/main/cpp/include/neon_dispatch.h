#pragma once
void neon_batch_score(const float* in, float* out, int n);
