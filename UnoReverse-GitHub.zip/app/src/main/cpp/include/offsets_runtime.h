// Uno Reverse — runtime offset table.
//
// Loaded from offsets.json, produced by the Kotlin OffsetPipeline at
// first launch. Every field is a real value observed from the guest's
// metadata. No compile-time constants are baked in.
//
// The table is read-only after load. Callers use the accessor functions
// below rather than touching the struct directly.
#pragma once

#include <cstdint>
#include <string>

namespace unoreverse {

struct RuntimeOffsets {
    // The module that carries the game logic. Discovered by ELF scanning
    // on the Kotlin side, not hardcoded.
    std::string il2cpp_module;

    // Method RVAs (relative to the module base).
    uint64_t rva_shoot       = 0;
    uint64_t rva_set_turn    = 0;
    uint64_t rva_update      = 0;
    uint64_t rva_camera_w2s  = 0;

    // Field offsets inside the game's own classes. These are offsets
    // from the object header (after the Il2CppClass* and monitor slots).
    uint32_t off_coin_pos_x      = 0;
    uint32_t off_coin_pos_y      = 0;
    uint32_t off_coin_vel_x      = 0;
    uint32_t off_coin_vel_y      = 0;
    uint32_t off_coin_mass       = 0;
    uint32_t off_coin_friction   = 0;
    uint32_t off_coin_type       = 0;
    uint32_t off_coin_pocketed   = 0;

    uint32_t off_striker_pos_x   = 0;
    uint32_t off_striker_pos_y   = 0;
    uint32_t off_striker_rb      = 0;
    uint32_t off_striker_aim_x   = 0;
    uint32_t off_striker_aim_y   = 0;

    uint32_t off_turn_current    = 0;
    uint32_t off_turn_is_mine    = 0;
    uint32_t off_turn_animating  = 0;

    uint32_t off_physics_gravity_x = 0;
    uint32_t off_physics_gravity_y = 0;
    uint32_t off_physics_fixed_dt  = 0;
    uint32_t off_physics_iterations= 0;
    uint32_t off_physics_coin_mat  = 0;
    uint32_t off_physics_cush_mat  = 0;

    // Board dimensions and pocket layout.
    float    board_width   = 0.f;
    float    board_height  = 0.f;
    float    striker_radius = 0.f;
    float    coin_radius    = 0.f;
    float    pocket_xy[8]   = {0};   // 4 pockets, {x,y} pairs

    // Static field addresses emitted by the pipeline. Each is the address
    // of a pointer slot in the module's data section that holds the
    // current instance of the named singleton.
    uintptr_t static_coin_list = 0;
    uintptr_t static_striker   = 0;
    uintptr_t static_physics   = 0;
    uintptr_t static_turn      = 0;
    uintptr_t static_board     = 0;

    // Bookkeeping.
    bool     loaded = false;
    std::string source_json_path;
};

// Load the offsets from the given JSON file. Returns true on success.
// The file is produced by the Kotlin pipeline and must exist before the
// agent attempts hook installation.
bool offsets_load(const std::string& json_path);

// True if offsets are loaded and the module name is non-empty.
bool offsets_ready();

// Direct read access to the loaded table. Undefined behavior if not loaded.
const RuntimeOffsets& offsets_get();

// Clear the table.
void offsets_clear();

} // namespace unoreverse