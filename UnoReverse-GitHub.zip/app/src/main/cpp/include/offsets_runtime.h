#pragma once
bool offsets_load(const char* path);
