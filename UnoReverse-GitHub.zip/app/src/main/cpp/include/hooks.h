#pragma once
void hooks_install();
