// Uno Reverse — game function hooks.
//
// Each hook is installed at (module_base + rva). The RVAs come from
// offsets_get(), never from compile-time constants.
//
// The hooked_shoot handler is the entry point for autoplay. It reads
// the shared state, overrides angle and power when autoplay is active
// and the ready flag is set, then calls through to the original.
#pragma once

#include <cstdint>

namespace unoreverse {

// Install all hooks. Returns true if every hook that has a non-zero RVA
// was installed successfully. Hooks with a zero RVA are skipped — the
// game may not have those methods exposed in the current build.
bool hooks_install_all();

// Remove all hooks. Called on agent shutdown.
void hooks_uninstall_all();

// True when the shoot hook is installed and ready to fire.
bool hooks_shoot_ready();

// Per-hook status for diagnostics.
struct HookStatus {
    bool shoot_installed;
    bool set_turn_installed;
    bool update_installed;
    uintptr_t module_base;
};
HookStatus hooks_status();

} // namespace unoreverse