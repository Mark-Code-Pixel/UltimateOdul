// Uno Reverse — worker pool for parallel candidate verification.
//
// A pool owns a fixed-size results array and a fixed number of worker
// threads. Each worker atomically pulls the next candidate index,
// verifies it, and writes the result into its slot. No heap allocation
// after construction. No mutex on the hot path — the atomic index is
// the only shared state, and the results array is written by disjoint
// indices.
#pragma once

#include "candidate_builder.h"
#include "scorer.h"
#include "shared_mem.h"

#include <cstdint>
#include <thread>
#include <vector>

namespace unoreverse {

class SolverPool {
public:
    SolverPool();
    ~SolverPool();

    SolverPool(const SolverPool&) = delete;
    SolverPool& operator=(const SolverPool&) = delete;

    // Configure how many worker threads to use and how many candidates
    // to verify this run. Call before verify_all. Thread count is
    // clamped to [1, 8] and to the number of candidates.
    void configure(int thread_count, int candidate_count);

    // Run verification. `candidates` must have at least
    // `candidate_count()` entries. `initial_world` and `objective` are
    // shared read-only across workers. `config` supplies max_power.
    // max_steps bounds each candidate's simulation length.
    void verify_all(const std::vector<Candidate>& candidates,
                    const SimWorld& initial_world,
                    const PhysicsConfig& config,
                    const Objective& objective,
                    int max_steps);

    // Index of the highest-scoring verified candidate, or -1 if every
    // candidate fouled out.
    int best_index() const;

    // Access results after verify_all.
    int result_count() const;
    const ShotResult& result(int i) const;

    // Snapshot of how long the last verify_all took, in microseconds.
    int64_t last_run_us() const;

private:
    void worker_loop();

    std::vector<std::thread> m_threads;
    int m_thread_count;
    int m_candidate_count;

    // Shared index advanced atomically by workers.
    std::atomic<int> m_next_index;

    // Results array. Sized once at configure time; never resized while
    // workers are running.
    std::vector<ShotResult> m_results;

    // Read-only inputs for the current run.
    const std::vector<Candidate>* m_candidates;
    const SimWorld*                m_initial_world;
    const PhysicsConfig*           m_config;
    const Objective*               m_objective;
    int                            m_max_steps;

    int64_t m_last_run_us;
};

} // namespace unoreverse