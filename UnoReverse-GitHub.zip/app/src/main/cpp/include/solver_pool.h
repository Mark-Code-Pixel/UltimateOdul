#pragma once
#include "unoreverse.h"
Candidate solve_best(const BoardState* board, const PhysicsConfig* cfg);
