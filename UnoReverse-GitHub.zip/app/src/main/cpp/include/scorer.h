#pragma once
#include "unoreverse.h"
float score_result(const StepResult* r);
