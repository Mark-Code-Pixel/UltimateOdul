// Uno Reverse — mini_hook: self-contained inline hook for ARM32/ARM64.
//
// No external dependencies. Works on Android 7 through 14, both ABIs.
//
// ARM64 patch (16 bytes at target):
//     LDR X17, #8          ; load literal into X17
//     BR  X17              ; branch to X17
//     <64-bit handler>     ; literal
//
// ARM32 ARM-mode patch (8 bytes):
//     LDR PC, [PC, #-4]    ; load literal into PC
//     <32-bit handler>     ; literal
//
// ARM32 Thumb-mode patch (8 bytes, using BLX immediate):
//     LDR.W PC, [PC, #0]   ; load literal into PC
//     <32-bit handler>     ; literal
//
// Trampoline: the original instructions at the patch site are copied to
// an executable page, followed by a jump back to the instruction after
// the patch. The trampoline pointer is returned as the "original"
// function.
#pragma once

#include <cstdint>

namespace unoreverse {

// One-time init. Allocates the executable page pool. Safe to call
// multiple times.
bool mini_hook_init();

// Install a hook. Returns true on success. out_original receives a
// callable pointer that executes the original prologue then jumps back.
bool mini_hook_install(void* target, void* handler, void** out_original);

// Remove a hook previously installed by mini_hook.
bool mini_hook_uninstall(void* target);

// Release all pool memory.
void mini_hook_shutdown();

} // namespace unoreverse