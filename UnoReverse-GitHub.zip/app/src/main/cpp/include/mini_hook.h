#pragma once
namespace mini_hook {
bool install(void* target, void* replace, void** original);
}
