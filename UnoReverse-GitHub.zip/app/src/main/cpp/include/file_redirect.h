// Uno Reverse — filesystem redirect for the guest process.
//
// Every path the guest opens is rewritten so that anything under
// /data/data/<guest_pkg>/, /data/user/0/<guest_pkg>/, or /data/data/
// for the container's own package is redirected to
// <virtual_root>/data/ inside the container's private directory.
//
// The redirect has two halves:
//
//   1. Path rewriting. A pure-string operation on the path argument
//      before the syscall reaches the kernel.
//
//   2. Directory creation. The redirected path's parent directories
//      are created on demand so that open() succeeds without the guest
//      having to call mkdir first.
//
// Hooks are installed on:
//   open, openat, fopen, stat, lstat, access, mkdir, rmdir, unlink
//
// Every hook passes through unchanged if the path is outside the
// guest's package or if no redirect rule matches.
#pragma once

#include <string>

namespace unoreverse {

// Initialize the redirect table. Called once during agent init with the
// guest package and the virtual root path.
bool file_redirect_init(const std::string& guest_package,
                        const std::string& virtual_root);

// Install the hooks. Safe to call multiple times.
bool file_redirect_install();

// Remove the hooks. Called during agent shutdown.
void file_redirect_uninstall();

// True if the redirect table is initialized.
bool file_redirect_ready();

// The path rewrite function. Exposed for testing. Returns the input
// unchanged if no rule matches.
std::string file_redirect_rewrite(const std::string& path);

} // namespace unoreverse