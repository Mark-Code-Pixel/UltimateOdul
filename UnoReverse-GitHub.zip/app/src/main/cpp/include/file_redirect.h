#pragma once
void file_redirect_install(const char* virtualRoot);
