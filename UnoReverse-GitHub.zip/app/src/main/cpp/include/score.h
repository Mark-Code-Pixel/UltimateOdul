// Uno Reverse — outcome evaluation.
//
// Given a candidate, the initial world, and the settled world, produce a
// single float score. Higher is better. Two hard floors dominate every
// other term: a scratch (striker pocketed) and a miss (no coin touched)
// both return kScoreFoul, which is far below any valid shot.
#pragma once

#include "candidate_builder.h"
#include "physics_sim.h"

namespace unoreverse {

constexpr float kScoreFoul   = -1.0e9f;   // hard foul
constexpr float kScoreNoPot  = -1.0e6f;   // no coin pocketed
constexpr float kScoreBase   =  1.0e3f;   // baseline for a pot

struct Objective {
    // Bit i set means CoinState.type == i is a target. 0 means any type.
    uint32_t target_type_mask = 0;
    // Whether pocketing the striker is a hard foul.
    bool scratch_is_foul = true;
    // Whether touching no coin during the shot is a hard foul.
    bool miss_is_foul = true;
    // Whether the target coin must be in a specific pocket. -1 = any.
    int required_pocket = -1;
};

struct ShotResult {
    float   score;
    int32_t pocketed_count;   // coins pocketed in this shot
    bool    scratched;
    bool    missed;
    bool    potted_target;    // at least one target-type coin potted
    int     steps_taken;      // simulation steps until settling
    float   settle_time_s;    // steps * fixed_dt
};

// Evaluate a single candidate against a settled world.
ShotResult score_shot(const SimWorld& initial_world,
                      const SimWorld& settled_world,
                      const Candidate& candidate,
                      const Objective& objective,
                      int steps_taken);

// Convenience wrapper that runs the full pipeline for a single
// candidate: copy the initial world, apply the impulse, advance, score.
ShotResult verify_candidate(const SimWorld& initial_world,
                            const Candidate& candidate,
                            const PhysicsConfig& config,
                            const Objective& objective,
                            int max_steps);

} // namespace unoreverse