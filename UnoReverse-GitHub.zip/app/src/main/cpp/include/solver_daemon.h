// Uno Reverse — solver daemon.
//
// A single background thread inside the guest process. It:
//   1. Watches the shared memory board snapshot.
//   2. Reads the board whenever the sequence counter changes.
//   3. Builds analytical candidates from the current board.
//   4. Runs parallel verification on the top N.
//   5. Scores each verified candidate.
//   6. Publishes the top-K polylines and the best shot to shared memory.
//
// The thread never allocates inside its loop. Every buffer is a member
// of the daemon struct, preallocated at start.
#pragma once

#include "candidate_builder.h"
#include "physics_sim.h"
#include "scorer.h"
#include "solver_pool.h"

#include <atomic>
#include <thread>
#include <vector>

namespace unoreverse {

struct SolverConfig {
    int   profile;          // 1 full, 2 lean, 3 direct-only
    int   top_n_verify;     // 24 / 8 / 4
    int   thread_count;     // 4 / 2 / 1
    int   max_sim_steps;    // 90 / 50 / 40
    int   line_candidates;  // how many candidates to draw (16 / 12 / 8)
    int   solve_rate_hz;    // how often to solve
};

// Default config chosen at runtime based on the platform probe.
SolverConfig solver_config_for_current_device();

// Start the daemon thread. Returns true on success. Safe to call
// multiple times — a second call is a no-op while running.
bool solver_daemon_start(const SolverConfig& config);

// Stop the daemon and join the thread.
void solver_daemon_stop();

// True while the daemon thread is alive.
bool solver_daemon_running();

// Total solves performed since start.
uint64_t solver_daemon_solve_count();

// Average solve time in microseconds over the last 64 solves.
int64_t solver_daemon_avg_solve_us();

} // namespace unoreverse