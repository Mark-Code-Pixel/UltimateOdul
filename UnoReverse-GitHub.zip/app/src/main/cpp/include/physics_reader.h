#pragma once
#include "unoreverse.h"
bool read_board(BoardState* out);
