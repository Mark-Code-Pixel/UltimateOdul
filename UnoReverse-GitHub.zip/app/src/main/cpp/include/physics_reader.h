// Uno Reverse — live state reader.
//
// Converts the guest's live object graph into the plain BoardSnapshot /
// PhysicsConfig structs that the solver consumes. Runs on the agent's
// update thread. Every read is a direct dereference — the agent lives
// inside the guest process.
//
// Reads are safe against torn values:
//   - All float fields are 4-byte aligned, atomic on ARM32 and ARM64.
//   - All pointer fields are naturally aligned, atomic on both ABIs.
//   - The game updates physics on its own thread; we tolerate a frame of
//     skew between related fields. The solver only needs the state to be
//     self-consistent within a single snapshot, which it is because we
//     read under one tick.
#pragma once

#include "shared_mem.h"

namespace unoreverse {

// Initialize once. Returns false if offsets are not loaded or the static
// pointers are zero. The reader stays dormant until both are true.
bool physics_reader_init();

// True when the reader has a live pointer to every singleton it needs.
bool physics_reader_ready();

// Snapshot functions. Each returns true on success, false if any
// required singleton is null (game not loaded yet, or wrong offsets).
bool read_live_board(BoardSnapshot& out);
bool read_live_physics(PhysicsConfig& out);
bool read_live_turn(int32_t& current_player, bool& is_my_turn, bool& animating);

// One-shot helper: read board + turn and publish both to shared memory.
// Returns true if the publish happened. Never blocks.
bool publish_snapshot();

} // namespace unoreverse