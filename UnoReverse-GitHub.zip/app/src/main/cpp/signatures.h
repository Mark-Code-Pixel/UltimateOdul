#pragma once
/**
 * Version-keyed signature table for Carrom Pool (Miniclip).
 * Sensitive offsets / patterns live only in native.
 *
 * When a new game build ships, add a SignatureSet entry.
 * Pattern bytes use 'x' in mask for fixed, '?' for wildcard.
 */

#include <cstdint>
#include <cstddef>

namespace uno {

struct SignatureSet {
    const char* gameVersion;     // e.g. "19.4.0" or "*" wildcard
    const char* moduleHint;      // "libil2cpp.so" / "libunity.so"
    // Pattern to locate piece-list related code or static pointer
    const char* pattern;
    const char* mask;
    // Once pattern hits, optional relative offsets to follow
    int32_t     ptrRelOffset;    // add to match address to read a pointer
    int32_t     arrayLengthOff;  // from object: offset to count
    int32_t     arrayDataOff;    // from object: offset to items pointer
    int32_t     pieceStride;     // bytes per piece struct
    int32_t     piecePosXOff;    // float x inside piece
    int32_t     piecePosYOff;    // float y
    int32_t     pieceTypeOff;    // int type / color
    int32_t     pieceFlagsOff;   // pocketed flag
    int32_t     strikerXOff;     // global or from root
    int32_t     strikerYOff;
};

/** Built-in sets – extend as real dumps are locked. */
inline const SignatureSet* signatureTable(size_t* outCount) {
    static const SignatureSet kTable[] = {
        // Generic / unknown version – patterns left as research hooks
        {
            "*",
            "libil2cpp.so",
            // placeholder NOP-ish pattern – replace with real dump
            "\x00\x00\x00\x00\x00\x00\x00\x00",
            "????????",
            0, 0x18, 0x10, 0x30, 0x10, 0x14, 0x18, 0x1C, 0, 0
        },
        // Example slot for a known future version
        {
            "19.4.0",
            "libil2cpp.so",
            "\x00\x00\x00\x00\x00\x00\x00\x00",
            "????????",
            0, 0x18, 0x10, 0x30, 0x10, 0x14, 0x18, 0x1C, 0, 0
        },
    };
    *outCount = sizeof(kTable) / sizeof(kTable[0]);
    return kTable;
}

} // namespace uno
