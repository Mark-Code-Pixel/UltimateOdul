#include "so_loader.h"
#include "memory.h"
#include <android/log.h>
#include <dlfcn.h>
#include <cstring>

#define LOG_TAG "UnoSoLoad"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)

namespace uno {

LoadedSo loadExtractedEngine(const char* absolutePath) {
    LoadedSo out;
    if (!absolutePath || !absolutePath[0]) {
        out.error = "empty path";
        return out;
    }
    out.path = absolutePath;
    // RTLD_LOCAL keeps symbols out of global namespace — safer on 32-bit
    void* h = dlopen(absolutePath, RTLD_NOW | RTLD_LOCAL);
    if (!h) {
        const char* e = dlerror();
        out.error = e ? e : "dlopen failed";
        LOGW("dlopen %s: %s", absolutePath, out.error.c_str());
        return out;
    }
    out.handle = h;
    out.ok = true;
    // base address: not portable via dlopen; leave 0 — live maps are source of truth
    LOGI("loaded extracted SO %s", absolutePath);
    return out;
}

void unloadSo(LoadedSo& so) {
    if (so.handle) {
        dlclose(so.handle);
        so.handle = nullptr;
    }
    so.ok = false;
}

bool liveEngineMatchesExtract(pid_t pid, const char* extractedBasename) {
    if (pid <= 0 || !extractedBasename) return false;
    auto mods = listModules(pid, "libgame-CARROM");
    if (mods.empty()) mods = listModules(pid, "CARROM-GooglePlay");
    for (const auto& m : mods) {
        if (m.name.find("libgame-CARROM") != std::string::npos ||
            m.path.find("libgame-CARROM") != std::string::npos) {
            if (std::strstr(m.name.c_str(), "1477") ||
                std::strstr(extractedBasename, "1477") ||
                m.name.find(extractedBasename) != std::string::npos) {
                return true;
            }
            // version-agnostic match on family name
            return true;
        }
    }
    return false;
}

} // namespace uno
