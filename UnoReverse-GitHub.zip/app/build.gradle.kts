import java.io.File
import java.net.URL
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.uno.reverse"
    compileSdk = 34
    ndkVersion = "26.1.10909125"

    defaultConfig {
        applicationId = "com.uno.reverse"
        minSdk = 24
        targetSdk = 34
        versionCode = 200
        versionName = "2.0.0-power"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++20", "-fno-exceptions", "-fno-rtti")
                arguments += listOf("-DANDROID_STL=c++_static")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    splits {
        abi {
            isEnable = true
            reset()
            include("armeabi-v7a", "arm64-v8a")
            isUniversalApk = true
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            isDebuggable = true
            ndk {
                debugSymbolLevel = "FULL"
            }
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            ndk {
                debugSymbolLevel = "SYMBOL_TABLE"
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-Xjvm-default=all",
            "-opt-in=kotlin.RequiresOptIn"
        )
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    packaging {
        jniLibs {
            useLegacyPackaging = false
        }
        resources {
            excludes += listOf(
                "META-INF/*.kotlin_module",
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt"
            )
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

/*
 * Dobby fetch. Downloads the prebuilt libdobby.a for each ABI into
 * app/.cxx/dobby/<abi>/. CMake picks it up if present, otherwise the
 * mini_hook fallback is used and the build still succeeds.
 *
 * Network is not required: if the download fails, the task completes
 * silently and the build proceeds with mini_hook.
 */
val dobbyDir = file(".cxx/dobby")

val dobbyUrls = mapOf(
    "armeabi-v7a" to "https://github.com/jmpews/Dobby/releases/download/v1.0.0/libdobby-android-armv7.a",
    "arm64-v8a" to "https://github.com/jmpews/Dobby/releases/download/v1.0.0/libdobby-android-arm64.a"
)

val fetchDobby by tasks.registering {
    outputs.dir(dobbyDir)
    doLast {
        dobbyUrls.forEach { (abi, url) ->
            val out = File(dobbyDir, "$abi/libdobby.a")
            if (out.exists() && out.length() > 0L) {
                logger.lifecycle("Dobby for $abi already present")
                return@forEach
            }
            out.parentFile?.mkdirs()
            try {
                val tmp = File(out.parentFile, "libdobby.a.part")
                URL(url).openStream().use { input ->
                    tmp.outputStream().use { output ->
                        input.copyTo(output, 64 * 1024)
                    }
                }
                tmp.renameTo(out)
                logger.lifecycle("Dobby for $abi downloaded: ${out.length()} bytes")
            } catch (t: Throwable) {
                logger.lifecycle("Dobby download for $abi failed: ${t.message}. mini_hook fallback will be used.")
            }
        }
    }
}

tasks.named("preBuild") {
    dependsOn(fetchDobby)
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-service:2.7.0")
    implementation("androidx.lifecycle:lifecycle-process:2.7.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.coroutines:coroutines-android:1.7.3")
    implementation("androidx.annotation:annotation:1.7.1")
    implementation("com.google.android.material:material:1.11.0")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}